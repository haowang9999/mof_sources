---
title: "Use metal choice and atomic ratio to tune lattice parameters and exposed crystal planes (monitor via ...[TRUNCATED]... "
type: design_rule
tags: [pld, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_340141308b]
confidence: medium
---


# Use metal choice and atomic ratio to tune lattice parameters and exposed crystal planes (monitor via ...[TRUNCATED]... 

## Rule

Use metal choice and atomic ratio to tune lattice parameters and exposed crystal planes (monitor via XRD) as a route to modify pore geometry and aperture exposure.

## IF conditions

- Working with M(BDC)TED0.5 frameworks where different divalent metals (Zn, Cu, Co, Ni) can be substituted
- Ability to perform XRD and morphological characterization

## THEN actions

- Systematically vary metal species and fraction (x) and record XRD peak shifts and relative intensities
- Correlate XRD changes with BET/pore size distribution to infer effects on pore/aperture geometry
- Target compositions that show favorable lattice adjustments without structural collapse

## Why

XRD analysis shows peak shifts and intensity changes depending on metal atomic radius and bimetal ratio; authors interpret these as subtle structural changes that can affect which crystal planes are exposed.

## Failure modes

- Excessive lattice distortion could degrade crystallinity or porosity
- Some ratios produce only minor or no beneficial pore changes

## Agent use stage

- planner
- candidate_filter

## Evidence

> The diffraction peak of Ni(BDC)TED0.5 at 9.2° almost disappeared, and the diffraction peak of Co(BDC)TED0.5 at 9.2° appeared red-shifted. ... The crystal structure of bimetallic MOFs is jointly affected by the metal species and the bimetallic atomic ratio.

## Links

- Source: [[sources/src_340141308b]]