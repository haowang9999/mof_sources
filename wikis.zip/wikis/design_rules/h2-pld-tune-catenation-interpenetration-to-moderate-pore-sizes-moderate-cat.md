---
title: "Tune catenation/interpenetration to moderate pore sizes: moderate catenation can raise high-pressure ...[TRUNCATED]... "
type: design_rule
tags: [h2|pld, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_ff1b0c9d63]
confidence: medium
---


# Tune catenation/interpenetration to moderate pore sizes: moderate catenation can raise high-pressure ...[TRUNCATED]... 

## Rule

Tune catenation/interpenetration to moderate pore sizes: moderate catenation can raise high-pressure H2 uptake via stronger host–guest interactions and framework strength; avoid excessive interpenetration that blocks open metal sites or reduces surface area.

## IF conditions

- goal is high-pressure H2 storage
- MOF synthesis conditions allow control over catenation

## THEN actions

- introduce moderate framework interpenetration to reduce pore size without blocking key adsorption sites
- use synthesis controls (templates, linker design, concentration, temperature) to prevent over-catenation
- characterize OMS accessibility and BET area to ensure low-pressure uptake is not sacrificed

## Why

Catenation changes pore size and can increase H2 adsorption at higher pressures (PCN-6 vs PCN-60 showed higher na for catenated PCN-6 at 50 bar), but catenation that blocks open metal sites reduces low-pressure adsorption and excessive interpenetration lowers surface area and uptake.

## Failure modes

- blocking of open metal sites leading to lower low-pressure adsorption
- too much interpenetration producing low BET area and poor uptake

## Agent use stage

- planner
- candidate_filter
- executor

## Evidence

> After activation at 323 K, H2 adsorption at 77 K and 1 bar was 1.74 and 1.35 wt% for PCN-6 and PCN-60... INS experiments suggested open metal sites are most favorable for H2, and at higher P the interaction becomes stronger in the catenated PCN-6. Table 3 shows higher na for catenated PCN-6 than non-catenated PCN-60 at 50 bar. ... When MOFs are catenated too much, they show very low H2 adsorption... three-fold interpenetrated frameworks showed low H2 adsorption capacities.

## Links

- Source: [[sources/src_ff1b0c9d63]]