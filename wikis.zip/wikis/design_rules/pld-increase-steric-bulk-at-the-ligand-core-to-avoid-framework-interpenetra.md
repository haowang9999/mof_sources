---
title: "Increase steric bulk at the ligand core to avoid framework interpenetration and increase pore size/p ...[TRUNCATED]... "
type: design_rule
tags: [pld, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_3b254ae858]
confidence: high
---


# Increase steric bulk at the ligand core to avoid framework interpenetration and increase pore size/p ...[TRUNCATED]... 

## Rule

Increase steric bulk at the ligand core to avoid framework interpenetration and increase pore size/porosity in Zn4O-based pcu MOFs (and more generally use rational linker design to control catenation).

## IF conditions

- Designing Zn4O-based IRMOFs (pcu net) using clathrochelate-derived linear ditopic ligands
- Goal: favor non-interpenetrated topology to increase crystallographic pore size/porosity
- Synthesis performed under conditions similar to those used for NU-650/NU-651 (e.g., mixed 1,2-dichlorobenzene and DMF, ~120 °C or comparable solvothermal conditions)

## THEN actions

- Introduce bulky substituents (e.g., n-butyl groups) to ligand core
- Select or design organic building blocks (linker size/shape/functionalization) to favor or disfavor catenation as required
- Expect formation of non-interpenetrated pcu framework (e.g., NU-651) with larger simulated pores (~1.9 nm) and higher crystallographic porosity

## Why

Bulky cores sterically hinder the close packing/entanglement of independent polymeric networks, preventing catenation and leading to a singular larger-pore framework; rational linker design has been reported as an effective handle to control catenation in the literature.

## Failure modes

- Other synthesis variables (solvent choice, concentration, temperature, counterions) may still induce interpenetration despite bulky ligands
- Predicted porosity may not be experimentally accessible if activation fails (NU-651 porosity was not confirmed experimentally in this study)
- Unexpected kinetic vs thermodynamic outcomes in synthesis may produce undesired topologies

## Agent use stage

- planner
- candidate_filter
- executor
- reflection

## Evidence

> The use of clathrochelate-based carboxylate ligands with bulky cores of n-butyl groups led to the synthesis of a Zn-MOF with the pcu net, while clathrochelate linkers with relatively fewer bulky cores give a twofold interpenetrated Zn-MOF structure under similar conditions... These bulky cores of the linkers further prohibit the formation of catenated networks in NU-651.
"Control over catenation in metal−organic frameworks via rational design of the organic building block." (Farha, O. K.; Malliakas, C. D.; Kanatzidis, M. G.; Hupp, J. T. J. Am. Chem. Soc. 2010, 132, 950−952.)

## Links

- Source: [[sources/src_3b254ae858]]