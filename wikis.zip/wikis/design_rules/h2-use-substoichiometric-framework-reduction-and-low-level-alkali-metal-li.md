---
title: "Use substoichiometric framework reduction and low-level alkali-metal (Li+/Na+/K+) doping to boost cr ...[TRUNCATED]... "
type: design_rule
tags: [h2, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_b0ea8c70ab]
confidence: high
---


# Use substoichiometric framework reduction and low-level alkali-metal (Li+/Na+/K+) doping to boost cr ...[TRUNCATED]... 

## Rule

Use substoichiometric framework reduction and low-level alkali-metal (Li+/Na+/K+) doping to boost cryogenic H2 uptake in interpenetrated (catenated) MOFs, but avoid over-doping which reduces microporosity and performance.

## IF conditions

- Material is a reducible, interpenetrated (doubly/triply catenated) MOF with reducible ligand (e.g., diPyTz)
- Objective is to increase gravimetric H2 uptake at cryogenic temperatures (77–87 K, ~1 atm)
- Alkali-metal dopants (Li+, Na+, K+) can be introduced via chemical reduction

## THEN actions

- Perform controlled chemical reduction and load alkali-metal cations at low M/Zn (target ≈0.05–0.10)
- Activate samples carefully (e.g., 110 °C under vacuum) and quantify residual solvent (1H NMR) to ensure consistent evacuation
- Measure N2 adsorption (BET/t-plot) and H2 isotherms to confirm enhancement and to track micropore volume
- Avoid increasing dopant loading into ranges (e.g., Li/Zn ≈0.35) that have been shown to halve micropore volume and reduce H2 uptake

## Why

Experimental data show greatest H2 uptake enhancement at M/Zn ≈0.05–0.10; higher loading can reduce micropore volume and uptake. Residual solvent/activation issues can confound interpretation, so careful activation and solvent quantification are necessary.

## Failure modes

- Over-doping leads to decreased micropore volume and H2 uptake
- Incomplete evacuation (residual solvent) can mask true micropore accessibility and lead to misleading BET/t-plot results
- Dopants may be structurally shielded in catenated frameworks and not accessible as binding sites

## Agent use stage

- planner
- candidate_filter
- executor

## Evidence

> We find that improved adsorption performance for these materials is obtained at doping levels that are much lower than 1 cation per dipyridyl ligand; the greatest enhancements are found for M/Zn ≈0.05 to 0.10... Further doping ... leads to less effective H2 uptake. (For example, increasing Li/Zn from 0.05 to 0.35 caused the H2 loading at 77 K and 1 atm to drop by ca. (relatively) 50%...) Notably, the micropore volume for 1·Li* is about half that of 1, as is the H2 uptake at 1 atm.

## Links

- Source: [[sources/src_b0ea8c70ab]]