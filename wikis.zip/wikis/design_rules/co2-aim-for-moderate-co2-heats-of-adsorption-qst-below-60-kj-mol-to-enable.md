---
title: "Aim for moderate CO2 heats of adsorption (Qst) below ~60 kJ/mol to enable energy-efficient regenerat ...[TRUNCATED]... "
type: design_rule
tags: [co2, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_36df794947]
confidence: high
---


# Aim for moderate CO2 heats of adsorption (Qst) below ~60 kJ/mol to enable energy-efficient regenerat ...[TRUNCATED]... 

## Rule

Aim for moderate CO2 heats of adsorption (Qst) below ~60 kJ/mol to enable energy-efficient regeneration while achieving strong low-pressure uptake.

## IF conditions

- objective = energy-efficient direct air capture / trace-CO2 removal
- preference = physisorption over chemisorption for lower regeneration energy

## THEN actions

- design physisorptive adsorption sites producing Qst in the ~40–55 kJ/mol range
- validate regeneration temperature and energy experimentally (e.g., desorption complete at modest temperatures under vacuum)

## Why

Authors note the need for moderate heat of adsorption (<60 kJ/mol) and report NbOFFIVE-1-Ni desorbs CO2 completely at 328 K under vacuum with an associated energy input of 54 kJ/mol.

## Failure modes

- too low Qst reduces selectivity/uptake at trace pressures
- too high Qst increases regeneration energy and may approach chemisorption behavior

## Agent use stage

- planner
- candidate_filter
- executor

## Evidence

> there is a need to develop ... physical adsorbent materials with a moderate CO2 heat of adsorption, i.e., below 60 kJ/mol. ... NbOFFIVE-1-Ni offers the complete CO2 desorption at 328 K under vacuum with an associated moderate energy input of 54 kJ/mol.

## Links

- Source: [[sources/src_36df794947]]