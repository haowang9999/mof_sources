---
title: "Use DFT binding energies (with dispersion corrections) to validate or rank specific host–guest affin ...[TRUNCATED]... "
type: design_rule
tags: [pld, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_fc58db74fa]
confidence: high
---


# Use DFT binding energies (with dispersion corrections) to validate or rank specific host–guest affin ...[TRUNCATED]... 

## Rule

Use DFT binding energies (with dispersion corrections) to validate or rank specific host–guest affinities obtained from force-field GCMC.

## IF conditions

- You need quantitative ranking of specific adsorption sites or host–guest binding strengths
- Force-field predictions require validation

## THEN actions

- Perform DFT (e.g., PBE + D3(BJ)) calculations of coordinated host–guest complexes and compute ΔE = E_coordinated − E_MOF − E_guest
- Use DFT-derived rankings to refine selection of high-affinity candidates

## Why

The study carried out DFT (PBE + D3(BJ)) and defined binding energy as ΔE = E_coordinated − E_MOF − E_guest to quantify host–guest interactions.

## Failure modes

- DFT cluster or periodic models must represent the adsorption geometry used in GCMC; mismatches reduce validity
- Computational cost limits DFT-only screening of large candidate sets

## Agent use stage

- candidate_filter
- reflection

## Evidence

> “DFT calculations were carried out with the Perdew-Burke-Ernzerhof (PBE) functional... DFT-D3(BJ) dispersion corrections were included... the binding energy between the MOF and guest gas molecule was determined through the following equation: ΔE = E_coordinated − E_MOF − E_guest”

## Links

- Source: [[sources/src_fc58db74fa]]