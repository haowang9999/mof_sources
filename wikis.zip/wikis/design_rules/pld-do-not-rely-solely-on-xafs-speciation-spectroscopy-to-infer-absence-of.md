---
title: "Do not rely solely on XAFS/speciation spectroscopy to infer absence of pore-size effects on adsorpti ...[TRUNCATED]... "
type: design_rule
tags: [pld, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_c88d608b3b]
confidence: medium
---


# Do not rely solely on XAFS/speciation spectroscopy to infer absence of pore-size effects on adsorpti ...[TRUNCATED]... 

## Rule

Do not rely solely on XAFS/speciation spectroscopy to infer absence of pore-size effects on adsorption; pair spectroscopic speciation with adsorption calorimetry or other energetic measurements to capture pore-size dependent adsorption strength.

## IF conditions

- you are testing the impact of pore diameter or window aperture on adsorption speciation/strength
- speciation is probed only by XAFS or similar first-shell-sensitive spectroscopies

## THEN actions

- add adsorption calorimetry or other thermodynamic/energetic measurements to the characterization plan
- compare spectroscopic speciation and calorimetric energetics to get a fuller picture of pore-size effects

## Why

This study found identical first-shell XAFS signatures for Lu3+ across different pore sizes while prior calorimetry work detected pore-size impacts on adsorption energetics; spectroscopy may miss energetic changes.

## Failure modes

- concluding no pore-size effect based only on XAFS and missing changes in adsorption capacity or energetics
- designing pore-size modifications expecting changes in coordination geometry when only adsorption energetics change

## Agent use stage

- planner
- candidate_filter
- reflection

## Evidence

> "no pore-size dependency on surface speciation could be detected spectroscopically when pore diameters decreased from 7 to 4 nm; however, pore-size impact on adsorption was detected and quantified with calorimetric measurements... The pore size impacts on Ln adsorption in MOFs should therefore be addressed in future studies with calorimetry or other techniques to complement the spectroscopic investigations presented here."

## Links

- Source: [[sources/src_c88d608b3b]]