---
title: "When designing MOF membranes for CO2 permeation, explicitly consider limiting pore diameter and pore ...[TRUNCATED]... "
type: design_rule
tags: [pld, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_1fa85425f9]
confidence: high
---


# When designing MOF membranes for CO2 permeation, explicitly consider limiting pore diameter and pore ...[TRUNCATED]... 

## Rule

When designing MOF membranes for CO2 permeation, explicitly consider limiting pore diameter and pore size distribution as tunable parameters.

## IF conditions

- goal: membrane‑based CO2 (e.g., CO2/CH4) separation
- material class: MOF membranes (hMOFs or synthesized MOF membranes)

## THEN actions

- optimize/engineer PLD to match desired sieving or diffusivity for CO2
- narrow the pore size distribution to achieve consistent transport properties

## Why

PLD and PSD are reported to be key factors affecting CO2 permeation in hMOF membranes.

## Failure modes

- Ignoring PLD/PSD may produce membranes with poor selectivity/permeance or inconsistent performance.

## Agent use stage

- planner
- candidate_filter

## Evidence

> "The limiting pore diameter and pore size distribution were reported as the key factors that affect CO2 permeation of hMOF membranes (Qiao et al., 2016b)." (page 3).

## Links

- Source: [[sources/src_1fa85425f9]]