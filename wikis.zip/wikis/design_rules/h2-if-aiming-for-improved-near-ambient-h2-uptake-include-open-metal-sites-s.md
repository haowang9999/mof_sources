---
title: "If aiming for improved near-ambient H2 uptake, include open metal sites (SBUs or metalated linkers)  ...[TRUNCATED]... "
type: design_rule
tags: [h2, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_ff1b0c9d63]
confidence: high
---


# If aiming for improved near-ambient H2 uptake, include open metal sites (SBUs or metalated linkers)  ...[TRUNCATED]... 

## Rule

If aiming for improved near-ambient H2 uptake, include open metal sites (SBUs or metalated linkers) and polarizing cations; otherwise, prioritize pore-size tuning for cryogenic storage.

## IF conditions

- operating temperature >= 298 K
- goal to improve deliverable H2 at moderate pressures

## THEN actions

- incorporate open metal centers via SBUs (desolvation of coordinated solvents) or postsynthetic metalation of linkers
- consider ion-exchange to introduce polar cations
- verify that open sites remain accessible after activation

## Why

Open metal sites have been shown experimentally to increase Qst and raise 298 K uptakes (effect pronounced in high As MOFs); example frameworks (SNU-15/SNU-150', PCN-9, Ni2(m-dobdc)) demonstrate this.

## Failure modes

- framework collapse during activation (loss of As)
- metal aggregation or protected metal sites reducing accessibility

## Agent use stage

- planner
- candidate_filter
- executor

## Evidence

> Open metal sites ... may increase the Qst value. In practice, the H2 adsorption values measured at 298 K for MOFs with open metal sites are higher ... Ni2(m-dobdc) ... results were explained by the presence of open metal cation sites (highly polarizing Ni2+), which strongly interacted with H2 molecules.

## Links

- Source: [[sources/src_ff1b0c9d63]]