---
title: "Combine rapid geometric screening (PLD/LCD) with fast estimators of adsorption affinity (Henry's con ...[TRUNCATED]... "
type: design_rule
tags: [mixed, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_97052fb350]
confidence: high
---


# Combine rapid geometric screening (PLD/LCD) with fast estimators of adsorption affinity (Henry's con ...[TRUNCATED]... 

## Rule

Combine rapid geometric screening (PLD/LCD) with fast estimators of adsorption affinity (Henry's constant) and diffusion activation energy to triage large MOF/zeolite databases before experimental testing.

## IF conditions

- Large materials database (>100 structures) to screen for kinetic separations
- Access to crystallographic structures and computational resources for fast molecular modeling

## THEN actions

- Compute PLD/LCD for all structures (grid ~0.1 Å for speed, refine for promising hits)
- Estimate Henry's constants and diffusion activation energies for spherical probes representing target gases
- Select subset with strong predicted differences in diffusion coefficients and acceptable adsorption behavior for further detailed simulation or experiments

## Why

Geometry identifies materials that can sterically differentiate species, while Henry's constants and diffusion barriers capture chemical interactions and kinetics; together they efficiently narrow candidates.

## Failure modes

- Static-framework assumption may miss flexibility-driven behavior; check flexibility for top candidates
- Spherical-probe approximations may not capture anisotropic molecules correctly

## Agent use stage

- planner
- candidate_filter
- reflection

## Evidence

> We show that efficient computational models can be used to evaluate large numbers of MOFs for kinetic separations ... We introduce a geometric approach that rapidly identifies the key features of a pore structure that control molecular diffusion and couple this with efficient molecular modeling calculations that predict the Henry’s constant and diffusion activation energy for a range of spherical adsorbates.

## Links

- Source: [[sources/src_97052fb350]]