---
title: "To realize direct dopant–H2 binding (higher Qst and larger ambient/high-pressure gains), design MOFs ...[TRUNCATED]... "
type: design_rule
tags: [h2|pld, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_b0ea8c70ab]
confidence: medium
---


# To realize direct dopant–H2 binding (higher Qst and larger ambient/high-pressure gains), design MOFs ...[TRUNCATED]... 

## Rule

To realize direct dopant–H2 binding (higher Qst and larger ambient/high-pressure gains), design MOFs that expose dopant ions—favor single (non-catenated), permanently microporous networks over catenated frameworks.

## IF conditions

- Goal is increased H2 binding energy (higher isosteric heats) and enhanced uptake at ambient temperature/high pressure
- Direct dopant–H2 interaction is required

## THEN actions

- Design MOFs with non-catenated (single) frameworks that expose dopant ions to pore space
- Avoid embedding dopant ions within interwoven/catenated networks which can shield ions from gas access
- Use computational screening to identify candidate frameworks where dopant ions are accessible and predicted to increase heats of adsorption, then validate experimentally

## Why

Computational studies predict large gains if direct ion–H2 interaction can be achieved; experimentally, catenation shields dopants preventing such interactions, so single networks may enable the computationally predicted benefits.

## Failure modes

- Exposed dopant ions may be unstable or cause framework collapse
- Dopant exposure could lead to unwanted side reactions or cation solvation (must be checked experimentally)

## Agent use stage

- planner
- candidate_filter
- reflection

## Evidence

> Recent computational studies suggest ... provided that direct interaction of dopant ions with hydrogen can be achieved. In efforts toward direct dopant-H2 interaction, current work is focused on reducing and characterizing permanently microporous MOF materials comprising single rather than multiple (i.e., catenated) networks.

## Links

- Source: [[sources/src_b0ea8c70ab]]