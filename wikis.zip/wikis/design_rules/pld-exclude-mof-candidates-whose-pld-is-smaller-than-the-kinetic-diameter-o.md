---
title: "Exclude MOF candidates whose PLD is smaller than the kinetic diameter of the target molecule (e.g.,  ...[TRUNCATED]... "
type: design_rule
tags: [pld, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_fc58db74fa]
confidence: high
---


# Exclude MOF candidates whose PLD is smaller than the kinetic diameter of the target molecule (e.g.,  ...[TRUNCATED]... 

## Rule

Exclude MOF candidates whose PLD is smaller than the kinetic diameter of the target molecule (e.g., CH3I ≈ 4.23 Å) when aiming to adsorb that molecule.

## IF conditions

- target_molecule = CH3I
- PLD < 4.23 Å

## THEN actions

- filter_out_candidate_from_CH3I_adsorption_set
- or consider pore-expanding modifications or choose a different MOF

## Why

A PLD smaller than the molecular kinetic diameter prevents the molecule from entering pore space, rendering adsorption negligible.

## Failure modes

- Neglecting defects or flexible framework breathing that could transiently allow access (not covered in rigid-framework screening)
- Molecular sieving exceptions if adsorption happens on external surface (limited capacity)

## Agent use stage

- candidate_filter
- planner

## Evidence

> “...the PLD was smaller than the kinetic diameter of CH3I molecules (4.23 Å), rendering them unsuitable for evaluating CH3I adsorption performance.”

## Links

- Source: [[sources/src_fc58db74fa]]