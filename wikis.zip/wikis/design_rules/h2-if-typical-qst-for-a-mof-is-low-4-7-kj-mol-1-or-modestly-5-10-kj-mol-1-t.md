---
title: "If typical Qst for a MOF is low (≈4–7 kJ·mol−1 or modestly 5–10 kJ·mol−1), then expect limited H2 up ...[TRUNCATED]... "
type: design_rule
tags: [h2, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_ff1b0c9d63]
confidence: high
---


# If typical Qst for a MOF is low (≈4–7 kJ·mol−1 or modestly 5–10 kJ·mol−1), then expect limited H2 up ...[TRUNCATED]... 

## Rule

If typical Qst for a MOF is low (≈4–7 kJ·mol−1 or modestly 5–10 kJ·mol−1), then expect limited H2 uptake at ambient temperature; to improve room-temperature uptake, introduce stronger adsorption sites to increase Qst.

## IF conditions

- Material: MOF or nanoporous sorbent
- Measured Qst ≈ 4–10 kJ·mol−1

## THEN actions

- Incorporate or expose stronger binding sites (e.g., open metal sites, functionalized linkers, polar cations)
- Consider metalation of linkers, cation exchange, or incorporation of polarizing SBUs

## Why

Typical physisorption enthalpies (4–7 or modestly 5–10 kJ·mol−1) are too weak to retain significant H2 at higher temperatures; increasing binding energy shifts adsorption favorability to higher T.

## Failure modes

- Excessively strong binding may impede reversibility or desorption kinetics
- Functionalization or added mass may reduce usable pore volume or surface area

## Agent use stage

- planner
- candidate_filter

## Evidence

> The heat values of hydrogen adsorption for most nanoporous materials, including MOFs... are within the range of 4–7 kJ·mol–1 [24]. ... Qst values in most porous MOFs is within the range of 5–10 kJ·mol–1. To increase the interaction at the ambient temperature, creation of open metal sites, cations, doping, infiltration of nanoparticles, and linker functionalization have been used.

## Links

- Source: [[sources/src_ff1b0c9d63]]