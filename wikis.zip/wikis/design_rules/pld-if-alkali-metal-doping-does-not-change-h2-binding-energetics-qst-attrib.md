---
title: "If alkali-metal doping does not change H2 binding energetics (Qst), attribute uptake increases first ...[TRUNCATED]... "
type: design_rule
tags: [pld, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_b0ea8c70ab]
confidence: medium
---


# If alkali-metal doping does not change H2 binding energetics (Qst), attribute uptake increases first ...[TRUNCATED]... 

## Rule

If alkali-metal doping does not change H2 binding energetics (Qst), attribute uptake increases first to pore-structure changes (BET/micropore area) and investigate cation accessibility if pore metrics do not explain the effect.

## IF conditions

- Measured isosteric heats (Qst) for doped and undoped MOF are similar across loadings
- Observed increase in H2 uptake upon doping

## THEN actions

- Measure BET surface area and t-plot micropore metrics using N2 at 77 K to assess changes in accessible surface area
- If BET/micropore increases correlate with H2 uptake, attribute enhancement to increased accessible surface area (e.g., displacement of interwoven networks)
- If BET/micropore do not increase, investigate dopant cation accessibility (solvation, localization) and structural changes via 1H NMR, PXRD, single-crystal XRD, and other techniques

## Why

Study found closely matching Qst values for 1 and 1·M while BET surface areas increased for doped samples and tracked H2 uptake, suggesting structural (pore) changes are responsible rather than stronger binding.

## Failure modes

- Residual solvent could mask true micropore accessibility; ensure thorough activation and solvent quantification
- BET analysis limitations in microporous regime—use complementary t-plot analysis and be cautious interpreting small changes

## Agent use stage

- planner
- candidate_filter
- reflection

## Evidence

> the more striking observation (Figure 4) is just how closely isosteric heats agree for 1, 1·Li, 1·Na, and 1·K... As shown in Table 2, the BET surface areas for the various 1·M materials significantly exceed those for the undoped parent material. Furthermore, the ordering of surface areas ... matches the ordering for hydrogen adsorption.

## Links

- Source: [[sources/src_b0ea8c70ab]]