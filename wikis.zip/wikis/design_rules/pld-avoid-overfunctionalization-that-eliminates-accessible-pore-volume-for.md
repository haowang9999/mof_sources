---
title: "Avoid overfunctionalization that eliminates accessible pore volume for target adsorbates; if blockin ...[TRUNCATED]... "
type: design_rule
tags: [pld, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_a318a71841]
confidence: high
---


# Avoid overfunctionalization that eliminates accessible pore volume for target adsorbates; if blockin ...[TRUNCATED]... 

## Rule

Avoid overfunctionalization that eliminates accessible pore volume for target adsorbates; if blocking is unavoidable, consider selecting feed conditions/adsorbates that exploit host–guest affinity to open gates.

## IF conditions

- functionalization introduces long/bulky side chains (e.g., DB) that may block channels
- target adsorbate has lower interaction strength relative to others

## THEN actions

- prefer shorter/less-blocking substituents where access to adsorption sites is critical
- if blocking is desired for selectivity, pair with adsorbates having strong host–guest interactions to enable access when needed
- verify with PSD simulations and breakthrough tests

## Why

Overly long/bulky side chains (DB) may fully block pores and prevent guest access unless strong host–guest interactions are present; DB only porous toward adsorptives with suitable interactions.

## Failure modes

- complete pore blocking prevents any useful adsorption for some targets
- unexpected non-linear PSD responses may complicate predictability

## Agent use stage

- planner
- candidate_filter

## Evidence

> "DB only is porous toward adsorptives with suitable host−guest interactions, enabling diffusion through formally blocked channels."

## Links

- Source: [[sources/src_a318a71841]]