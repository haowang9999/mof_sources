---
title: "Use generic force fields and approximate charge schemes for rapid, large‑scale screening but re-eval ...[TRUNCATED]... "
type: design_rule
tags: [co2, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_1fa85425f9]
confidence: medium
---


# Use generic force fields and approximate charge schemes for rapid, large‑scale screening but re-eval ...[TRUNCATED]... 

## Rule

Use generic force fields and approximate charge schemes for rapid, large‑scale screening but re-evaluate top candidates with higher‑fidelity models or experiment.

## IF conditions

- goal: high‑throughput screening across thousands of MOFs
- compute budget: limited such that ab initio FFs / DFT charges for all materials is infeasible

## THEN actions

- use UFF/Dreiding and fast charge schemes (e.g., PQeq) for initial ranking
- validate top‑ranked materials with ab initio force fields and DFT-derived charges or experimental data

## Why

Generic FFs and approximate charges enable screening and often reproduce trends, but quantitative differences (generic vs ab initio FFs; PQeq vs quantum charges) can affect predicted uptakes and selectivities.

## Failure modes

- Relying solely on generic FFs/approximate charges could cause false positives or quantitative misranking of top candidates.

## Agent use stage

- candidate_filter
- executor
- reflection

## Evidence

> "Molecular simulations employing either UFF or Dreiding showed good agreement with the experimentally measured gas uptake data ..." and "Significant quantitative differences between the CO2 uptakes predicted by the generic FF and the ab initio FF were reported." and "Comparison between PQeq and high quality point charges ... showed a considerable disagreement ... although the PQeq charges ... give a quick estimate ..." (pages 4-5).

## Links

- Source: [[sources/src_1fa85425f9]]