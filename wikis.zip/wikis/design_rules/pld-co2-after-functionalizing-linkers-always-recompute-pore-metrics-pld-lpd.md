---
title: "After functionalizing linkers, always recompute pore metrics (PLD, LPD), void fraction and surface a ...[TRUNCATED]... "
type: design_rule
tags: [pld|co2, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_c42cf01235]
confidence: high
---


# After functionalizing linkers, always recompute pore metrics (PLD, LPD), void fraction and surface a ...[TRUNCATED]... 

## Rule

After functionalizing linkers, always recompute pore metrics (PLD, LPD), void fraction and surface area (e.g., with Zeo++) and simulate adsorption to ensure intended chemistry improvements are not offset by adverse changes in pore geometry.

## IF conditions

- linker functionalization applied
- goal includes preserving pore access and adsorption capacity

## THEN actions

- compute PLD and LPD, surface area, and void fraction
- compare to parent MOF values and run adsorption simulations to validate net effect

## Why

Functionalization can change pore size/topology which in turn impacts CO2 sorption; isolating chemistry effects requires monitoring geometric changes.

## Failure modes

- functional group steric bulk reduces PLD leading to lowered uptake or blocked diffusion
- topology change upon synthesis that is not captured by initial design

## Agent use stage

- planner
- candidate_filter
- executor

## Evidence

> “Another difficulty faced by experiments to isolate the role of functionalization is that the latter can alter variables such as pore size, which, in turn, also impact CO2 sorption." || "Largest and limiting pore diameters (LPD and PLD, respectively) were calculated using Zeo++."

## Links

- Source: [[sources/src_c42cf01235]]