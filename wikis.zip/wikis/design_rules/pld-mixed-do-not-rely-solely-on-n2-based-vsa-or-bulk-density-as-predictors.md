---
title: "Do not rely solely on N2-based VSA or bulk density as predictors of permselectivity; verify accessib ...[TRUNCATED]... "
type: design_rule
tags: [pld|mixed, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_90953381a0]
confidence: high
---


# Do not rely solely on N2-based VSA or bulk density as predictors of permselectivity; verify accessib ...[TRUNCATED]... 

## Rule

Do not rely solely on N2-based VSA or bulk density as predictors of permselectivity; verify accessibility with gas-sized probes or direct permeability evaluations.

## IF conditions

- Using VSA (N2 probe-based) or density to screen MOFs

## THEN actions

- Verify accessibility using gas-sized probes (e.g., CO2-sized probe ~3.3 Å) or direct permeability simulations/experiments
- Use VSA as a complementary descriptor, not the sole criterion

## Why

VSA determined by N2 probe (3.64 Å) can be zero while smaller gases still access pores; VSA and ρ showed no clear effect on permselectivity in 1D analyses but may contribute in multivariate contexts.

## Failure modes

- False negatives: discarding MOFs with low N2-VSA that nevertheless pass smaller target gases
- False positives: using VSA alone to predict separation without considering affinity/diffusion

## Agent use stage

- candidate_filter
- planner

## Evidence

> "the VSA was determined using N2 as a probe with a diameter of 3.64 Å... when the VSA of a MOF is zero or small, the smaller gas could pass the MOF such as CO2 (3.3 Å) and H2S (3.6 Å)."

## Links

- Source: [[sources/src_90953381a0]]