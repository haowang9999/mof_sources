---
title: "If the objective is high room-temperature H2 capacity, design small micropore diameters (~4–7 Å) and ...[TRUNCATED]... "
type: design_rule
tags: [pld|h2, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_ff1b0c9d63]
confidence: medium
---


# If the objective is high room-temperature H2 capacity, design small micropore diameters (~4–7 Å) and ...[TRUNCATED]... 

## Rule

If the objective is high room-temperature H2 capacity, design small micropore diameters (~4–7 Å) and appropriate pore-wall functionality rather than only maximizing surface area.

## IF conditions

- target: room-temperature (≈298 K) H2 adsorption
- pressure: moderate (multi-bar range)

## THEN actions

- tune linker/pillar lengths and connectivity to create narrow pore widths
- functionalize pore walls or introduce polar sites to increase local affinity
- test for pore accessibility after activation

## Why

A small pore diameter was found to be an important factor for the achievement of a high value of hydrogen adsorption capacity at room temperature; morphology (pore width, volume, roughness) is critical.

## Failure modes

- too small pores may block diffusion or reduce usable porosity
- functionalization may cause framework collapse or reduce free volume

## Agent use stage

- planner
- candidate_filter
- executor

## Evidence

> In the case of microporous MOFs, the morphology of the pores represents their main characteristics ... A small pore diameter was found to be an important factor for the achievement of a high value of hydrogen adsorption capacity at room temperature.

## Links

- Source: [[sources/src_ff1b0c9d63]]