---
title: "Prefer Ce nodes over Zr nodes in MOF-801-type frameworks if the design objective includes enhanced H ...[TRUNCATED]... "
type: design_rule
tags: [h2, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_20cacd73e1]
confidence: medium
---


# Prefer Ce nodes over Zr nodes in MOF-801-type frameworks if the design objective includes enhanced H ...[TRUNCATED]... 

## Rule

Prefer Ce nodes over Zr nodes in MOF-801-type frameworks if the design objective includes enhanced H2 chemisorption/activation at metal nodes (use DFT as a guide and validate experimentally).

## IF conditions

- Comparing isostructural MOF-801 frameworks with Ce vs Zr nodes
- Objective includes enhancing H2 activation at unsaturated metal sites

## THEN actions

- Design catalysts with Ce nodes to exploit stronger H2 chemical adsorption energies predicted by DFT
- Validate computational predictions with experimental probes (in situ FTIR/DRIFTS, catalytic tests) under relevant conditions

## Why

DFT shows the Ce node has a larger chemical adsorption energy for H2 than the Zr node, suggesting more favorable adsorption/activation at Ce sites in the modeled environments.

## Failure modes

- DFT predictions may not account for solvent, co-adsorbates, extended defects or dynamic restructuring; experimental validation is required
- Ce incorporation changes other properties (redox behavior, stability) that may adversely affect performance in some contexts

## Agent use stage

- planner
- candidate_filter
- executor

## Evidence

> The DFT results revealed that the chemical adsorption energy of H2 on the Ce node is larger than that on the Zr node, suggesting adsorption and activation of H2 are energetically more favorable at Ce sites; authors recommend validation with experiments.

## Links

- Source: [[sources/src_20cacd73e1]]