---
title: "Use synthesis-condition levers (modulated synthesis, linker conformation control, or liquid-phase ep ...[TRUNCATED]... "
type: design_rule
tags: [pld, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_3b254ae858]
confidence: medium
---


# Use synthesis-condition levers (modulated synthesis, linker conformation control, or liquid-phase ep ...[TRUNCATED]... 

## Rule

Use synthesis-condition levers (modulated synthesis, linker conformation control, or liquid-phase epitaxy where applicable) to tune interpenetration and thereby influence PLD and porosity.

## IF conditions

- Goal: increase or decrease accessible pore-limiting diameter or porosity via synthesis
- Material system allows modulation of synthesis conditions or epitaxial film growth

## THEN actions

- Apply modulated synthesis to influence linker conformation and packing
- Consider liquid-phase epitaxy for film/heterostructure growth to control interpenetration
- Optimize solvent, concentration, temperature, and modulators to favor the desired topology

## Why

Literature reports that linker conformation in modulated synthesis and liquid-phase epitaxy can control interpenetration, offering synthetic levers beyond linker molecular design.

## Failure modes

- Specific modulation conditions or conformations required may be system-dependent and not directly transferable
- Methods like liquid-phase epitaxy may not scale to bulk powder synthesis
- Aggressive modulation or activation to remove guests may damage framework or induce collapse

## Agent use stage

- planner
- candidate_filter
- executor

## Evidence

> "Controlling interpenetration through linker conformation in the modulated synthesis of sc metal−organic frameworks." (Marshall, R. J.; Lennon, C. T.; Tao, A.; Senn, H. M.; Wilson, C.; Fairen-Jimenez, D.; Forgan, R. S. J. Mater. Chem. A 2018.)
"Controlling interpenetration in metal−organic frameworks by liquid-phase epitaxy." (Shekhah, O.; Wang, H.; Paradinas, M.; Ocal, C.; Schüpbach, B.; Terfort, A.; Zacher, D.; Fischer, R. A.; Wöll, C. Nat. Mater. 2009.)

## Links

- Source: [[sources/src_3b254ae858]]