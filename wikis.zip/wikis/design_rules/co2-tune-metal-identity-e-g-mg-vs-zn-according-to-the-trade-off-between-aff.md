---
title: "Tune metal identity (e.g., Mg vs Zn) according to the trade-off between affinity/selectivity and regenerability."
type: design_rule
tags: [co2, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_20dae1036b]
confidence: high
---


# Tune metal identity (e.g., Mg vs Zn) according to the trade-off between affinity/selectivity and regenerability.

## Rule

Tune metal identity (e.g., Mg vs Zn) according to the trade-off between affinity/selectivity and regenerability.

## IF conditions

- process requires low regeneration energy / facile TSA
- high selectivity is needed but not at the expense of impractical regeneration energy

## THEN actions

- consider Zn (weaker-binding) when regenerability and lower desorption temperature are priority
- consider Mg when maximal affinity/selectivity is required and higher regeneration energy is acceptable

## Why

Mg open sites produce stronger CO2 interactions and higher selectivity but require higher desorption temperatures; Zn provides weaker binding and easier regeneration.

## Failure modes

- choosing Zn may reduce low-pressure uptake/selectivity if binding becomes too weak
- choosing Mg may render TSA regeneration impractically energy-intensive

## Agent use stage

- planner
- candidate_filter

## Evidence

> “stronger interactions are achieved but the regeneration will be more difficult... simulated structures using a less attractive metal, such as Zinc, were also performed... Mg-MOF-74 has the highest carbon dioxide selectivity...”

## Links

- Source: [[sources/src_20dae1036b]]