---
title: "If the design objective is to tune pore size or aperture (PLD/LCD) for gas uptake, employ isoreticul ...[TRUNCATED]... "
type: design_rule
tags: [pld, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_71bcf59437]
confidence: medium
---


# If the design objective is to tune pore size or aperture (PLD/LCD) for gas uptake, employ isoreticul ...[TRUNCATED]... 

## Rule

If the design objective is to tune pore size or aperture (PLD/LCD) for gas uptake, employ isoreticular/reticular design (choice of linker length/functional groups and SBUs/nets) to systematically control pore size and functionality.

## IF conditions

- objective includes specific pore size/aperture targets or tuning of internal functionality
- using synthetic/reticular design strategies

## THEN actions

- select appropriate SBUs and nets to realize the desired topology
- alter linker length and functionality within an isoreticular series to tune PLD/LCD and chemical environment
- use computational screening to predict gas uptake changes with pore modifications

## Why

Studies on modular chemistry and isoreticular MOFs report systematic design of pore size and functionality to achieve targeted gas storage (example: methane storage), and literature emphasizes SBUs/nets as the basis for designing porosity and robustness.

## Failure modes

- Scaling up synthesis may introduce defects or different interpenetration behavior altering pore sizes.
- Functionalization can reduce accessible pore volume or introduce unforeseen host-guest interactions.

## Agent use stage

- planner
- candidate_filter
- executor

## Evidence

> "Modular chemistry: secondary building units as a basis for the design of highly porous and robust metal-organic carboxylate frameworks."; "Systematic design of pore size and functionality in isoreticular MOFs and their application in methane storage."; "Secondary building units, nets and bonding in the chemistry of metal-organic frameworks." (cited references)

## Links

- Source: [[sources/src_71bcf59437]]