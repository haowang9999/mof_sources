---
title: "If ultrahigh deliverable capacity per mass and volume is desired and T/P swings are acceptable, prio ...[TRUNCATED]... "
type: design_rule
tags: [h2, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_b1552d4a9d]
confidence: high
---


# If ultrahigh deliverable capacity per mass and volume is desired and T/P swings are acceptable, prio ...[TRUNCATED]... 

## Rule

If ultrahigh deliverable capacity per mass and volume is desired and T/P swings are acceptable, prioritize ultrahigh gravimetric and volumetric BET areas plus an operational T/P swing protocol.

## IF conditions

- Deliverable capacity (usable H2 upon discharge) is primary metric
- Cryogenic and pressure-swing operation acceptable

## THEN actions

- Prioritize materials with very high gravimetric and volumetric BET areas (e.g., NU-1501-Al)
- Design operational protocol using combined temperature and pressure changes to maximize delivered amount

## Why

NU-1501-Al's very high gravimetric/volumetric BET areas were linked to high hydrogen storage when using a combined temperature/pressure swing.

## Failure modes

- Operational complexity and energy cost of T/P swings may offset storage benefits
- Materials may degrade under repeated thermal cycling

## Agent use stage

- planner
- reflection

## Evidence

> NU-1501-Al's high BET areas were considered main reasons for 14.0 wt% and 46.2 g·dm−3 delivered under combined T/P cycling from 77 K & 100 bar to 160 K & 5 bar.

## Links

- Source: [[sources/src_b1552d4a9d]]