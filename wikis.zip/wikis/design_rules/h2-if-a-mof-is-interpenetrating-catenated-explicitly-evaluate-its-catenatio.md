---
title: "If a MOF is interpenetrating/catenated, explicitly evaluate its catenation/interpenetration effect o ...[TRUNCATED]... "
type: design_rule
tags: [h2, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_71bcf59437]
confidence: medium
---


# If a MOF is interpenetrating/catenated, explicitly evaluate its catenation/interpenetration effect o ...[TRUNCATED]... 

## Rule

If a MOF is interpenetrating/catenated, explicitly evaluate its catenation/interpenetration effect on H2 uptake (e.g., run GCMC) rather than assuming performance from non-interpenetrated analogs.

## IF conditions

- material_family is MOF
- structure is interpenetrating or catenated (interpenetration detected or likely)

## THEN actions

- perform GCMC or comparable adsorption simulations focused on H2
- compare uptake with non-interpenetrated analogs

## Why

Reference work specifically studies the catenation effect on hydrogen adsorption by GCMC, indicating interpenetration materially influences H2 adsorption behavior.

## Failure modes

- Interpenetration effects are context-dependent (could increase or decrease uptake depending on pore size, confinement and accessible surface area).
- Experimental defects or pore blockage not captured by idealized simulations can change real uptake.

## Agent use stage

- candidate_filter
- planner

## Evidence

> "Grand canonical Monte Carlo simulation study on the catenation effect on hydrogen adsorption onto the interpenetrating metal-organic frameworks." (cited reference)

## Links

- Source: [[sources/src_71bcf59437]]