---
title: "Activation protocol before CO2 sorption: select temperature and method according to catenation state ...[TRUNCATED]... "
type: design_rule
tags: [co2, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_90ad344e79]
confidence: high
---


# Activation protocol before CO2 sorption: select temperature and method according to catenation state ...[TRUNCATED]... 

## Rule

Activation protocol before CO2 sorption: select temperature and method according to catenation state; consider supercritical CO2 for materials that lose surface area with heating.

## IF conditions

- Characterizing CO2-accessible porosity of Zn paddlewheel pillared MOFs (compounds similar to 1-8)

## THEN actions

- Activate noncatenated samples ~24 h at 90 °C
- Activate catenated samples ~24 h at 100 °C
- If thermal/solvent-exchange activation results in very low surface area (as observed for some ligands), use supercritical CO2 activation

## Why

Authors report these specific activation conditions prior to CO2 adsorption measurements and note supercritical CO2 rescued surface area for L5-based material.

## Failure modes

- Specific temperatures/times may not be optimal for other MOFs and may risk partial decomposition if used improperly (authors note no further mass loss until 300–400 °C for materials tested)
- Supercritical CO2 activation may not always recover surface area for all chemistries

## Agent use stage

- planner
- executor

## Evidence

> “...pore evacuation/‘activation’ was performed for 24 h at 90 and 100 °C for the noncatenated and catenated, respectively. The only exception was compound L5, which was activated using supercritical CO2 because heating and low-boiling-solvent exchange gave a very low surface area.”

## Links

- Source: [[sources/src_90ad344e79]]