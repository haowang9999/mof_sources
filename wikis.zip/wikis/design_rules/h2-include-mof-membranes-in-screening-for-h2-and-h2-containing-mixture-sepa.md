---
title: "Include MOF membranes in screening for H2 (and H2-containing mixture) separations since simulations  ...[TRUNCATED]... "
type: design_rule
tags: [h2, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_1fa85425f9]
confidence: medium
---


# Include MOF membranes in screening for H2 (and H2-containing mixture) separations since simulations  ...[TRUNCATED]... 

## Rule

Include MOF membranes in screening for H2 (and H2-containing mixture) separations since simulations indicate MOFs may outperform polymer membranes in CH4/H2 selectivity.

## IF conditions

- Screening for membranes targeting H2 separations or CH4/H2 separations

## THEN actions

- Evaluate MOF membrane candidates via MD/permeation simulations in addition to polymer benchmarks
- Prioritize MOFs that simulation indicates have improved CH4/H2 selectivity

## Why

Molecular simulation studies indicated several MOFs outperform polymer membranes in selectivity for CH4/H2 separations.

## Failure modes

- Simulation-predicted membrane performance may not translate to thin-film experimental membranes due to fabrication challenges

## Agent use stage

- planner
- candidate_filter

## Evidence

> Recent molecular simulation studies indicated that several MOFs outperform well-known polymer membranes in terms of selectivity for CH4/H2 separations (Erucar and Keskin, 2016). (page 5).

## Links

- Source: [[sources/src_1fa85425f9]]