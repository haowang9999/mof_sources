---
title: "If DFT binding to the intended functional group is weak, evaluate node/linker geometry for π-pocket  ...[TRUNCATED]... "
type: design_rule
tags: [co2, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_c42cf01235]
confidence: medium
---


# If DFT binding to the intended functional group is weak, evaluate node/linker geometry for π-pocket  ...[TRUNCATED]... 

## Rule

If DFT binding to the intended functional group is weak, evaluate node/linker geometry for π-pocket adsorption sites as an alternative mechanism to boost CO2 uptake.

## IF conditions

- DFT binding to the intended functional group is weak (e.g., -(H)4, -(CH3)2)
- GCMC density maps or structural analysis show linker convergence at nodes

## THEN actions

- explore topology/linker arrangements that produce overlapping potentials at nodes (π pockets)
- consider designing/retaining node environments to exploit this adsorption mechanism

## Why

Weak functional-group binding cases showed CO2 preferentially adsorbing at nodes where the overlap of potentials creates adsorption sites (π pockets) stronger than sites adjacent to the functional groups.

## Failure modes

- π-pocket formation depends on topology and linker geometry and may not be reproducible across frameworks
- relying on π pockets may not provide selectivity improvements if not combined with appropriate pore sizes

## Agent use stage

- planner
- executor
- candidate_filter

## Evidence

> “in the -(H)4, and -(CH3)2 cases ... CO2 preferentially adsorbs at the nodes of the framework. There, the linkers 'converge', and the overlap of potentials creates adsorption sites (π pockets) stronger than the sites adjacent to the functional groups."

## Links

- Source: [[sources/src_c42cf01235]]