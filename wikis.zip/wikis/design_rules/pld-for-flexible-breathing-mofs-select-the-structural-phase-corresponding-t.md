---
title: "For flexible/breathing MOFs, select the structural phase corresponding to the operating temperature  ...[TRUNCATED]... "
type: design_rule
tags: [pld, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_fc58db74fa]
confidence: high
---


# For flexible/breathing MOFs, select the structural phase corresponding to the operating temperature  ...[TRUNCATED]... 

## Rule

For flexible/breathing MOFs, select the structural phase corresponding to the operating temperature prior to adsorption prediction (e.g., MIL-53-Al-ht for 423 K).

## IF conditions

- The MOF is known to exhibit breathing or polymorphic pore phases (e.g., MIL-53-Al)
- Operating temperature differs from ambient (e.g., high-temperature operation)

## THEN actions

- Use the structural phase representative of the operating temperature (e.g., MIL-53-Al-ht for 423 K) in simulations
- If phase behavior under conditions is uncertain, consider flexible-framework simulation methods or experimental validation

## Why

MIL-53-Al breathing causes large tunable changes in pore size; the authors explicitly used MIL-53-Al-ht to match 423 K conditions.

## Failure modes

- Using the wrong phase leads to incorrect PLD and erroneous adsorption predictions
- Neglecting dynamic phase transitions under operating conditions

## Agent use stage

- planner
- candidate_filter
- executor

## Evidence

> “Considering the well-known breathing effect of MIL-53-Al... the high temperature form of MIL-53-Al (MIL-53-Al-ht) was used to conform to the high temperature environment of 423 K.”

## Links

- Source: [[sources/src_fc58db74fa]]