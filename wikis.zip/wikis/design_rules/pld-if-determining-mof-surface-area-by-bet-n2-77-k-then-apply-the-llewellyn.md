---
title: "If determining MOF surface area by BET (N2, 77 K), then apply the Llewellyn criteria for p/p0 select ...[TRUNCATED]... "
type: design_rule
tags: [pld, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_ff1b0c9d63]
confidence: high
---


# If determining MOF surface area by BET (N2, 77 K), then apply the Llewellyn criteria for p/p0 select ...[TRUNCATED]... 

## Rule

If determining MOF surface area by BET (N2, 77 K), then apply the Llewellyn criteria for p/p0 selection: use the linear region where n(1−p/p0) increases, ensure positive C≥10, and confirm nm corresponds to region; consider alternative probe gases or complementary methods for microporous MOFs.

## IF conditions

- Characterization method: BET from N2 isotherm (77 K)
- Material: MOF with micropores / supermicropores / ultramicropores

## THEN actions

- Restrict BET fit to the validated p/p0 range where n(1−p/p0) is continuous
- Ensure BET constant C is positive and ≥ 10
- Ensure nm corresponds to p/p0 within chosen linear region
- Use complementary porosimetry or probe gases when needed

## Why

The standard BET pressure range and assumptions are not generally valid for microporous MOFs; improper use yields inaccurate surface areas and misleads performance assessment.

## Failure modes

- Applying the standard 0.05–0.3 p/p0 range blindly yields erroneous areas for microporous MOFs
- Structural deformation under subcritical adsorption can change apparent area

## Agent use stage

- executor
- candidate_filter

## Evidence

> In the case of supermicroporous MOFs and ultramicroporous materials ... the BET calculation on the surface area is inaccurate. In 2007, Llewellyn et al. recommended consistent criteria ... the BET equation to determine the surface area of MOFs should be adapted to a specific situation.

## Links

- Source: [[sources/src_ff1b0c9d63]]