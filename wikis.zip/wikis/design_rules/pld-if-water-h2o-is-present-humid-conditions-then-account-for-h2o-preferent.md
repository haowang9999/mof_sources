---
title: "If water (H2O) is present (humid conditions), then account for H2O preferential binding at Al-cluste ...[TRUNCATED]... "
type: design_rule
tags: [pld, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_fc58db74fa]
confidence: medium
---


# If water (H2O) is present (humid conditions), then account for H2O preferential binding at Al-cluste ...[TRUNCATED]... 

## Rule

If water (H2O) is present (humid conditions), then account for H2O preferential binding at Al-cluster/hydroxyl sites and design to avoid water occupying the central channel adsorption sites needed by large iodine species.

## IF conditions

- humid gas streams with competitive adsorption (H2O present)
- framework contains Al clusters and hydroxyls or other strong hydrogen-bond donors

## THEN actions

- consider limiting exposed hydrophilic sites in channel center or sequestering them away from central adsorption volume
- use functionalization strategies that steer H2O to secondary sites while keeping central cavity available for I2/CH3I
- simulate competitive adsorption density to verify spatial partitioning

## Why

GCMC density plots and DFT show H2O prefers Al-cluster/backbone sites (high binding energies via hydrogen bonding), while I2/CH3I occupy channel center; water occupying key sites could reduce effective uptake or alter selectivity.

## Failure modes

- functionalization that increases hydrophilicity in the central channel can cause water to outcompete iodine at key adsorption positions
- neglecting spatial adsorption preferences can lead to overestimated iodine capacity

## Agent use stage

- planner
- candidate_filter
- executor

## Evidence

> “I2 and CH3I molecules were primarily concentrated near the center of pore channels, whereas the H2O molecules were mainly located near the backbones of the framework. ... Al clusters were the optimal adsorption sites [for H2O] with the highest binding energy of 40.52 kJ/mol ... hydroxyl functional groups connected to Al clusters played a significant role in hydrogen bonding interactions to achieve a high binding energy.”

## Links

- Source: [[sources/src_fc58db74fa]]