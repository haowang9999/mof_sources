---
title: "Incorporate charged (ionic) framework sites, exposed metal coordination sites, and narrow/interconne ...[TRUNCATED]... "
type: design_rule
tags: [h2, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_532b708453]
confidence: high
---


# Incorporate charged (ionic) framework sites, exposed metal coordination sites, and narrow/interconne ...[TRUNCATED]... 

## Rule

Incorporate charged (ionic) framework sites, exposed metal coordination sites, and narrow/interconnected pores to enhance many-body polarization and increase H2 physisorption at cryogenic conditions (~78 K).

## IF conditions

- material has ionically charged framework or proximate charged anions/cations and/or exposed metal coordination sites (e.g., In SBUs)
- pore/channel diameters are narrow (example: ~1 nm as in soc-MOF) and interconnected

## THEN actions

- expect amplified many-body polarization contributions to H2 binding
- prioritize such materials for high-density H2 uptake at ~78 K/1 atm
- consider engineering linkers or SBUs to produce local charge separations

## Why

The paper shows that soc-MOF's highly ionic framework, exposed indium sites, and narrow pores lead to relatively strong hydrogen interactions via enhanced polarization, producing large uptake near liquid H2 density at 78 K/1 atm.

## Failure modes

- quantitative uptake may be overestimated if nuclear quantum dispersion is neglected (~10-15% effect)
- excessive nanostructuring increases framework mass per unit volume (tradeoff)
- if pores are too large, molecules in pore centers will not be polarized and uptake will be limited

## Agent use stage

- planner
- candidate_filter

## Evidence

> The simulations demonstrate that it is both of these physical characteristics (highly ionic framework, exposed metal sites, and narrow pores) that lead to relatively strong hydrogen interactions in the MOF and ultimately large hydrogen uptake. Since polarization interactions are significantly enhanced by the presence of a charged framework with narrow pores, MOFs are excellent hydrogen storage candidates.

## Links

- Source: [[sources/src_532b708453]]