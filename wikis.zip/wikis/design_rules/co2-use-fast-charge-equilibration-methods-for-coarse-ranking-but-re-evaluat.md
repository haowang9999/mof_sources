---
title: "Use fast charge-equilibration methods for coarse ranking but re-evaluate promising candidates with h ...[TRUNCATED]... "
type: design_rule
tags: [co2, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_1fa85425f9]
confidence: high
---


# Use fast charge-equilibration methods for coarse ranking but re-evaluate promising candidates with h ...[TRUNCATED]... 

## Rule

Use fast charge-equilibration methods for coarse ranking but re-evaluate promising candidates with higher-accuracy, quantum-chemistry-derived point charges when ranking materials for CO2/N2 separations.

## IF conditions

- Performing large-scale screening for CO2/N2 separations
- Using PQeq or other fast charge assignment methods for initial ranking

## THEN actions

- Apply PQeq for initial throughput-limited ranking
- Recompute electrostatic interactions with higher-quality point charges for top candidates before final selection

## Why

PQeq gives a quick estimate but can disagree considerably with high-quality quantum-chemistry-derived charges for CO2/N2 selectivities of top materials.

## Failure modes

- Relying solely on PQeq may mis-rank top candidates for CO2/N2 separations

## Agent use stage

- planner
- candidate_filter

## Evidence

> Comparison between PQeq and high quality point charges derived from quantum chemistry for the top performing materials showed a considerable disagreement in the calculated CO2/N2 selectivities although the PQeq charges were shown to give a quick estimate about the potential of the material (Haldoupis et al., 2012a,b). (page 5).

## Links

- Source: [[sources/src_1fa85425f9]]