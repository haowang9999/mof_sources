---
title: "If the target application prioritizes deliverable H2 at ambient temperature (298 K), aim for an aver ...[TRUNCATED]... "
type: design_rule
tags: [h2, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_b1552d4a9d]
confidence: medium
---


# If the target application prioritizes deliverable H2 at ambient temperature (298 K), aim for an aver ...[TRUNCATED]... 

## Rule

If the target application prioritizes deliverable H2 at ambient temperature (298 K), aim for an average Qst near ~20 kJ·mol−1 and validate with GCMC/delivery simulations, balancing Qst increases against porosity loss.

## IF conditions

- goal: maximize deliverable gravimetric H2 at 298 K between low and high pressures (e.g., 1.5–120 bar)
- willingness to trade porosity vs binding strength

## THEN actions

- Engineer binding sites (open metals, polar cations, functionalized linkers) to raise Qst toward ~20 kJ·mol−1
- Use GCMC or equivalent to simulate deliverable capacity and validate tradeoffs between Qst and usable free volume

## Why

Simulations indicate an optimal Qst around 20 kJ·mol−1 for maximizing delivery at 298 K; practical strategies to raise Qst include open sites, cation fields, metal doping or functionalization.

## Failure modes

- raising Qst too far may trap H2 and reduce deliverable capacity or reversibility
- strategies that increase Qst (e.g., metal loading) may reduce porosity and lower gravimetric uptake

## Agent use stage

- planner
- candidate_filter

## Evidence

> GCMC calculations suggested an optimal Qst ≈ 20 kJ·mol−1 for maximum H2 delivery at 298 K between low and high pressure states. Review recommends creating open metal sites, cations, metal doping or linker functionalization to increase affinity.

## Links

- Source: [[sources/src_b1552d4a9d]]