---
title: "If functionalization reduces bonded deformation barriers (e.g., polar ligands), consider linker func ...[TRUNCATED]... "
type: design_rule
tags: [pld, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_8ce39338bc]
confidence: medium
---


# If functionalization reduces bonded deformation barriers (e.g., polar ligands), consider linker func ...[TRUNCATED]... 

## Rule

If functionalization reduces bonded deformation barriers (e.g., polar ligands), consider linker functionalization to facilitate diffusion but evaluate trade-offs with host–guest binding and stability.

## IF conditions

- Bonded deformation contributes significantly to diffusion barrier
- Functionalization will not introduce undesired trapping via strong host–guest interactions

## THEN actions

- Consider polar or flexible linker functionalization (e.g., -NH2) to lower bonded barriers
- Evaluate whether functional groups increase adsorption too much or alter pH-sensitivity/stability

## Why

UiO-66(NH2) showed lower SMD bonded potential energy barrier than UiO-66, consistent with polar ligands lowering rotation/deformation barriers.

## Failure modes

- Functional groups could increase specific host–guest binding and slow release
- Chemical stability or pH-sensitivity could be adversely affected

## Agent use stage

- planner
- candidate_filter

## Evidence

> The SMD bonded potential energy barrier was higher in UiO-66 (ΔUbonded,SMD = 406 kJ/mol) compared to UiO-66(NH2) (ΔUbonded,SMD = 184 kJ/mol). The higher bonded barrier for UiO-66 agrees with trends that polar ligands lower rotation barriers.

## Links

- Source: [[sources/src_8ce39338bc]]