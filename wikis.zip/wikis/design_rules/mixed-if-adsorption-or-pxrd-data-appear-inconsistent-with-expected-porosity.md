---
title: "If adsorption or PXRD data appear inconsistent with expected porosity, check for framework interpene ...[TRUNCATED]... "
type: design_rule
tags: [mixed, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_3b254ae858]
confidence: medium
---


# If adsorption or PXRD data appear inconsistent with expected porosity, check for framework interpene ...[TRUNCATED]... 

## Rule

If adsorption or PXRD data appear inconsistent with expected porosity, check for framework interpenetration and occluded species and adjust characterization/activation accordingly.

## IF conditions

- Observed adsorption or powder XRD results inconsistent with expected porosity or structure
- Samples synthesized via routes prone to catenation/interpenetration

## THEN actions

- Investigate possible interpenetration or trapped organic/inorganic species in nanocavities (e.g., additional characterization including SCXRD if available, alternative activation protocols)
- Consider synthesis modifications to avoid unwanted interpenetration or trapping of guests

## Why

MOF-5 inconsistencies in adsorption and PXRD have been rationalized by framework interpenetration and the presence of species in cavities; checking for interpenetration/occluded guests can explain apparent anomalies.

## Failure modes

- Hidden interpenetration may be difficult to detect without single-crystal data
- Aggressive activation to remove occluded species may damage framework or induce collapse

## Agent use stage

- executor
- reflection

## Evidence

> "The inconsistency in adsorption properties and powder xrd data of MOF-5 is rationalized by framework interpenetration and the presence of organic and inorganic species in the nanocavities." (Hafizovic et al. J. Am. Chem. Soc. 2007.)

## Links

- Source: [[sources/src_3b254ae858]]