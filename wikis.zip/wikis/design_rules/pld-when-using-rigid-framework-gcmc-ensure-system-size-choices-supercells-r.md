---
title: "When using rigid-framework GCMC, ensure system-size choices (supercells) respect nonbonded cutoff di ...[TRUNCATED]... "
type: design_rule
tags: [pld, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_fc58db74fa]
confidence: high
---


# When using rigid-framework GCMC, ensure system-size choices (supercells) respect nonbonded cutoff di ...[TRUNCATED]... 

## Rule

When using rigid-framework GCMC, ensure system-size choices (supercells) respect nonbonded cutoff distances (e.g., 12 Å) to avoid artifacts.

## IF conditions

- GCMC uses a finite nonbonded cutoff (e.g., 12 Å)
- Periodic boundary conditions are applied

## THEN actions

- Apply supercells so that system dimensions are at least twice the cutoff distance
- Check that chosen supercell is compatible with computational cost constraints

## Why

The authors applied supercells to ensure the system size was twice longer than the cutoff distance (12 Å) when necessary.

## Failure modes

- Too-small cells produce spurious self-interactions
- Excessively large supercells increase computational cost unnecessarily

## Agent use stage

- executor
- planner

## Evidence

> “when necessary, supercells were applied to ensure the system size to be twice longer than the cutoff distance (12 Å ).”

## Links

- Source: [[sources/src_fc58db74fa]]