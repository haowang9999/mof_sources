---
title: "Include explicit many-body electronic polarization (e.g., Thole-Applequist) in computational models  ...[TRUNCATED]... "
type: design_rule
tags: [h2|mixed, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_532b708453]
confidence: high
---


# Include explicit many-body electronic polarization (e.g., Thole-Applequist) in computational models  ...[TRUNCATED]... 

## Rule

Include explicit many-body electronic polarization (e.g., Thole-Applequist) in computational models of H2 adsorption in ionic or highly polar porous materials to capture dominant induction effects; otherwise predictions of binding and uptake can be qualitatively different.

## IF conditions

- modeling H2 adsorption in MOFs or other porous materials with charged centers or strong local electric fields
- predicting adsorption energetics, site populations, or radial distributions

## THEN actions

- use polarizable force fields or many-body polarization schemes in Monte Carlo or molecular dynamics
- iteratively solve induced-dipole equations to convergence (set and document convergence tolerance)
- compare polarizable and nonpolarizable results to quantify polarization-driven effects
- validate polarizable-model predictions experimentally where feasible (e.g., spectroscopy)

## Why

The simulations show many-body polarization is a dominant attractive contribution and has a dramatic effect on physisorption compared to models omitting it.

## Failure modes

- explicit polarization increases computational cost and may be infeasible for very large cells or exhaustive screening
- classical polarizable models still neglect nuclear quantum effects which can alter absolute uptake by ~10–15%

## Agent use stage

- candidate_filter
- planner
- executor

## Evidence

> Previous simulations ... have not focused on the role of polarization effects, but they are demonstrated here to be the dominant contribution to hydrogen physisorption. ... "Molecular polarization was explicitly included in the Monte Carlo simulations by use of the Thole-Applequist model." ... "The calculation of the system dipoles consumes approximately 95% of the total CPU time."

## Links

- Source: [[sources/src_532b708453]]