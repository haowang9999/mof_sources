---
title: "Tune both local polarizability and sorption-site accessibility via linker functionalization to contr ...[TRUNCATED]... "
type: design_rule
tags: [mixed, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_a318a71841]
confidence: high
---


# Tune both local polarizability and sorption-site accessibility via linker functionalization to contr ...[TRUNCATED]... 

## Rule

Tune both local polarizability and sorption-site accessibility via linker functionalization to control gating pressure, adsorption energetics, and selectivity between similarly sized gases (e.g., CO2 vs C2H2).

## IF conditions

- target separation involves gases with similar size but different polarizability/electronic properties (e.g., C2H2 vs CO2)
- framework is rigid so gating arises from adsorptive interactions and side-chain conformation rather than global phase change

## THEN actions

- modify linker substituents to increase/decrease polarizability at the sorption sites
- alter side-chain steric bulk/rigidity to tune site accessibility
- measure multi-temperature isotherms, derive thermodynamic metrics, and perform breakthrough experiments to quantify effects

## Why

Polarizability and sorption site accessibility are identified as the two dominating, tunable factors that determine gating in this rigid MOF series.

## Failure modes

- changes to polarizability may have non-linear or competing effects with steric changes
- overfunctionalization can create blocked channels requiring strong host–guest interactions to access (e.g., DB)

## Agent use stage

- planner
- candidate_filter
- reflection

## Evidence

> "Two dominating factors that determine gating properties are identified: polarizability and sorption site accessibility. These factors are accessible through linker functionalization..."

## Links

- Source: [[sources/src_a318a71841]]