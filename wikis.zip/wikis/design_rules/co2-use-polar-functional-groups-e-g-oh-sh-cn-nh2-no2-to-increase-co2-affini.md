---
title: "Use polar functional groups (e.g., OH, SH, CN, NH2, NO2) to increase CO2 affinity, but validate each ...[TRUNCATED]... "
type: design_rule
tags: [co2, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_c42cf01235]
confidence: medium
---


# Use polar functional groups (e.g., OH, SH, CN, NH2, NO2) to increase CO2 affinity, but validate each ...[TRUNCATED]... 

## Rule

Use polar functional groups (e.g., OH, SH, CN, NH2, NO2) to increase CO2 affinity, but validate each case against the specific pore topology and pore-metric changes because topology strongly modulates the effect.

## IF conditions

- goal = increase CO2 physisorption/affinity
- functionalization feasible on linker

## THEN actions

- introduce hydroxyl, thiol, cyano, amino, or nitro functionalities on pore-facing linkers
- recompute pore metrics (PLD/LPD, surface area, void fraction) after functionalization and simulate adsorption in that topology to confirm benefit

## Why

DFT/GCMC/ML results show these functional groups often improve CO2 capture metrics, but improvements are topology-dependent and functionalization can alter pore geometry.

## Failure modes

- functionalization reduces pore aperture or changes topology, negating expected gains
- topology may prevent functional group from forming an effective electrostatic pocket

## Agent use stage

- planner
- candidate_filter
- executor

## Evidence

> “Functionalization with hydroxyl, thiol, cyano, amino, or nitro chemistries was found to often improve CO2 capture metrics ... the efficacy of this strategy depended strongly on the pore topology.” || "Another difficulty ... is that the latter can alter variables such as pore size, which, in turn, also impact CO2 sorption."

## Links

- Source: [[sources/src_c42cf01235]]