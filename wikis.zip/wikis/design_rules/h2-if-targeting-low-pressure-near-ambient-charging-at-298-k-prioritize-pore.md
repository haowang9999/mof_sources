---
title: "If targeting low-pressure/near-ambient charging at 298 K, prioritize pore volume; if targeting high- ...[TRUNCATED]... "
type: design_rule
tags: [h2, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_b1552d4a9d]
confidence: high
---


# If targeting low-pressure/near-ambient charging at 298 K, prioritize pore volume; if targeting high- ...[TRUNCATED]... 

## Rule

If targeting low-pressure/near-ambient charging at 298 K, prioritize pore volume; if targeting high-pressure charging, prioritize surface area.

## IF conditions

- temperature: 298 K (ambient); pressure regime: low vs high charging pressure

## THEN actions

- Optimize synthesis for larger pore volume when application involves low-pressure adsorption
- Focus on maximizing accessible surface area for high-pressure storage

## Why

At 298 K the amount adsorbed correlates mainly with pore volume at low pressure and with surface area at high pressure.

## Failure modes

- overemphasis on one metric may impair the other (e.g., very high surface area frameworks can have low free volume)
- measured correlations may vary with pore morphology and specific chemistries

## Agent use stage

- planner
- candidate_filter

## Evidence

> At 298 K the n value correlates mainly with the V value at low P(H2) and the A value at high P(H2).

## Links

- Source: [[sources/src_b1552d4a9d]]