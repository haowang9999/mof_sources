---
title: "Introduce exposed/open metal sites or metal cations to increase CO2 binding."
type: design_rule
tags: [co2, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_a034d4944a]
confidence: medium
---


# Introduce exposed/open metal sites or metal cations to increase CO2 binding.

## Rule

Introduce exposed/open metal sites or metal cations to increase CO2 binding.

## IF conditions

- target gas is CO2
- material platform supports access to metal nodes (e.g., coordinatively unsaturated metal sites)

## THEN actions

- design linkers or post-synthetic treatments to expose metal cations or create open metal sites
- evaluate CO2 uptake at relevant temperatures/pressures

## Why

CO2 has strong dipole/quadrupole interactions with metal cations leading to higher binding energies and enhanced adsorption.

## Failure modes

- exposed metal sites may be deactivated by moisture or other contaminants
- framework instability under operating conditions (high temp/humidity)

## Agent use stage

- planner
- candidate_filter
- executor

## Evidence

> The higher boiling point of CO2 ... strong dipole–dipole interactions and the high quadrupole–quadrupole interactions between CO2 molecules and the metal cations in the MOFs. ... open metal sites on the surface of MOFs are typically used as active sites has been proven to be a promising approach. (page 4 & pages 5-6)

## Links

- Source: [[sources/src_a034d4944a]]