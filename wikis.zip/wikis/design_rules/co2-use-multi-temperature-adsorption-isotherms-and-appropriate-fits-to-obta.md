---
title: "Use multi-temperature adsorption isotherms and appropriate fits to obtain isosteric enthalpies and H ...[TRUNCATED]... "
type: design_rule
tags: [co2, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_a318a71841]
confidence: high
---


# Use multi-temperature adsorption isotherms and appropriate fits to obtain isosteric enthalpies and H ...[TRUNCATED]... 

## Rule

Use multi-temperature adsorption isotherms and appropriate fits to obtain isosteric enthalpies and Henry constants to correlate linker functionalization with CO2 adsorption strength and selectivity.

## IF conditions

- aim is to quantify how linker functionalization alters adsorption thermodynamics for CO2 (and competing gases)
- experimental access to isotherms at multiple temperatures is available

## THEN actions

- measure CO2 and relevant gas isotherms over a temperature range (authors used 298, 288, 278 K)
- fit data with dual-site Langmuir–Freundlich for isosteric enthalpy (via Clausius–Clapeyron) and virial fits for Henry constants
- use resulting thermodynamic metrics to rank functionalization effects

## Why

The authors derived isosteric enthalpies and Henry constants from multi-temperature isotherms to correlate adsorption strength with linker chemistry.

## Failure modes

- poor isotherm quality or insufficient temperature spread can lead to unreliable enthalpy/Henry estimates
- fitting model choice may bias derived parameters if not appropriate for observed isotherm shapes

## Agent use stage

- executor
- candidate_filter

## Evidence

> "Adsorption isotherms of C2H2 and CO2 at 298, 288, and 278 K were fitted using a dual-site Langmuir−Freundlich equation...All isotherms were in parallel, fitted using the virial equation of adsorption to derive Henry’s law constants."

## Links

- Source: [[sources/src_a318a71841]]