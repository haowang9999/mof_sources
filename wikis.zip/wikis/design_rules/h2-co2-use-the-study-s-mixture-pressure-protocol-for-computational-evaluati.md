---
title: "Use the study's mixture/pressure protocol for computational evaluation of precombustion CO2 capture  ...[TRUNCATED]... "
type: design_rule
tags: [h2|co2, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_c42cf01235]
confidence: high
---


# Use the study's mixture/pressure protocol for computational evaluation of precombustion CO2 capture  ...[TRUNCATED]... 

## Rule

Use the study's mixture/pressure protocol for computational evaluation of precombustion CO2 capture metrics to enable comparability: simulate adsorption of 20:80 CO2:H2 at 20 bar and desorption as pure CO2 at 1 bar (at 313 K) to compute working capacity and selectivity, but inspect selectivity because desorption-phase approximations can mislead.

## IF conditions

- evaluating precombustion CO2 capture performance via simulation
- wanting comparability with this study's reported metrics

## THEN actions

- run GCMC for 20:80 CO2:H2 at 20 bar (adsorption) and pure CO2 at 1 bar (desorption) at 313 K
- compute selectivity and working capacity, and flag negative WC cases for low selectivity

## Why

This is the protocol used in the study to derive precombustion-relevant CO2 capture metrics; the desorption-phase gas assumption can give negative WC for poorly selective materials.

## Failure modes

- materials with insufficient CO2/H2 selectivity yield negative WC because of desorption-phase composition assumption
- differences in temperature/pressure protocols reduce comparability

## Agent use stage

- planner
- candidate_filter

## Evidence

> “MOF CO2 capture metrics relevant to precombustion carbon capture were evaluated by simulating adsorption for a 20:80 CO2:H2 mixture at 20 bar (adsorption conditions) and pure CO2 at 1 bar (desorption conditions)...This assumption breaks down when a given material is not selective enough, which is manifested in a negative working capacity."

## Links

- Source: [[sources/src_c42cf01235]]