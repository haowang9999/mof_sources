---
title: "When relying on classical simulation results for cryogenic H2 uptake, apply caution: predicted absol ...[TRUNCATED]... "
type: design_rule
tags: [h2|mixed, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_532b708453]
confidence: medium
---


# When relying on classical simulation results for cryogenic H2 uptake, apply caution: predicted absol ...[TRUNCATED]... 

## Rule

When relying on classical simulation results for cryogenic H2 uptake, apply caution: predicted absolute uptakes may be modestly overestimated if nuclear quantum effects are neglected (expect ~10–15% reduction based on prior PIMC comparisons).

## IF conditions

- using classical (non-PIMC) simulations to predict H2 uptake at low temperatures
- polarization is included but nuclear quantum effects are not

## THEN actions

- treat predicted uptakes as potentially optimistic and consider an uncertainty margin
- if quantitative accuracy is required, perform PIMC or other quantum treatments where computationally feasible

## Why

Prior PIMC work found a 10–15% decrease in sorption relative to purely classical simulations; the present study focuses on electronic polarization within a classical model.

## Failure modes

- computationally expensive PIMC with polarization may be infeasible for routine screening
- the exact correction may depend on the specific pore environment

## Agent use stage

- candidate_filter
- planner
- reflection

## Evidence

> The results showed a decreased sorption of 10-15% relative to the purely classical simulations. ... it is computationally prohibitive to perform PIMC simulations including polarization, the present study will focus on the role of electronic polarization within a classical model.

## Links

- Source: [[sources/src_532b708453]]