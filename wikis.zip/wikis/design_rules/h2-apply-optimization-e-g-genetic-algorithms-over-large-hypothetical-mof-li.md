---
title: "Apply optimization (e.g., genetic algorithms) over large hypothetical‑MOF libraries to identify targ ...[TRUNCATED]... "
type: design_rule
tags: [h2, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_1fa85425f9]
confidence: medium
---


# Apply optimization (e.g., genetic algorithms) over large hypothetical‑MOF libraries to identify targ ...[TRUNCATED]... 

## Rule

Apply optimization (e.g., genetic algorithms) over large hypothetical‑MOF libraries to identify target ranges of physical properties for CO2/H2 separations, then filter for synthesizability.

## IF conditions

- goal: maximize CO2/H2 separation performance across a vast hMOF library
- sufficient structural descriptors (pore size, PLD, surface area) are available

## THEN actions

- run genetic algorithm or other global optimizer with simulated performance metrics (e.g., selectivity, working capacity) as objective
- analyze resulting optimal property ranges and prioritize experimentally realizable candidates within those ranges

## Why

A cited study screened 55,163 hMOFs for CO2/H2 and used a genetic algorithm to identify optimum physical properties correlated with highest separation performance.

## Failure modes

- Optimized hMOFs may be impractical to synthesize; ignoring synthesizability may waste experimental resources.

## Agent use stage

- planner
- candidate_filter

## Evidence

> "... screened 55,163 hMOFs for CO2/H2 separation and a genetic algorithm including optimization methods was used to identify the optimum physical properties of hMOFs which showed the highest separation performance (Chung et al., 2016)." (page 3).

## Links

- Source: [[sources/src_1fa85425f9]]