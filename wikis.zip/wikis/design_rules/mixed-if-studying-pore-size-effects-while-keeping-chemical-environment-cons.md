---
title: "If studying pore-size effects while keeping chemical environment constant, use isoreticular series ( ...[TRUNCATED]... "
type: design_rule
tags: [mixed, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_ff1b0c9d63]
confidence: high
---


# If studying pore-size effects while keeping chemical environment constant, use isoreticular series ( ...[TRUNCATED]... 

## Rule

If studying pore-size effects while keeping chemical environment constant, use isoreticular series (e.g., MOF-5/IRMOFs) to vary pore size while preserving topology and surface chemistry.

## IF conditions

- Objective: isolate effect of pore size on adsorption
- Available materials: isoreticular MOF series

## THEN actions

- Select MOF-5 / IRMOF members with different linker lengths/pore sizes
- Compare adsorption isotherms across series under identical conditions

## Why

Isoreticular series maintain consistent topology and surface chemistry while changing pore size, enabling focused study of pore-size-dependent mechanisms.

## Failure modes

- Unintended differences in defect concentration or activation may confound comparisons

## Agent use stage

- planner
- candidate_filter
- reflection

## Evidence

> The focus is on the MOF-5 and its isorecticular MOF series (IRMOFs), that have the same framework topology and surface environment, but different pore sizes.

## Links

- Source: [[sources/src_ff1b0c9d63]]