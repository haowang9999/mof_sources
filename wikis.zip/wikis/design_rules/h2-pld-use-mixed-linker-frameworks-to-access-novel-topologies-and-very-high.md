---
title: "Use mixed-linker frameworks to access novel topologies and very high surface areas for enhanced H2 u ...[TRUNCATED]... "
type: design_rule
tags: [h2|pld, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_ff1b0c9d63]
confidence: high
---


# Use mixed-linker frameworks to access novel topologies and very high surface areas for enhanced H2 u ...[TRUNCATED]... 

## Rule

Use mixed-linker frameworks to access novel topologies and very high surface areas for enhanced H2 uptake at elevated pressures, but verify low-pressure behavior.

## IF conditions

- synthetic capability to incorporate multiple linkers
- target application involves high-pressure H2 storage

## THEN actions

- design MOFs with two or more linkers that create new framework topologies
- measure high-pressure H2 uptake (e.g., 46–80 bar) to capture benefits
- expect possible lower low-pressure uptake in very large-pore materials and validate

## Why

Mixed-linker MOFs (UMCM-2, MOF-205, MOF-210) achieved extremely high BET/Langmuir areas and high H2 uptake at elevated pressures (MOF-210: 8.6 wt% at 56 bar, 17.6 wt% at 80 bar at 77 K).

## Failure modes

- synthetic complexity and difficulty obtaining desired topology
- very large pores giving poor low-pressure uptake

## Agent use stage

- planner
- candidate_filter

## Evidence

> A combination of two types of organic linker within the same MOF structure could be another approach to increase the pore characteristics... For MOF-210, the hydrogen adsorption capacity at 77 K was 8.6 wt% at 56 bar of H2 and 17.6 wt% at 80 bar of H2.

## Links

- Source: [[sources/src_ff1b0c9d63]]