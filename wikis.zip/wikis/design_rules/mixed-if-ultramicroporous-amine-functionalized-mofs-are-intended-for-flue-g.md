---
title: "If ultramicroporous amine-functionalized MOFs are intended for flue-gas applications, then explicitl ...[TRUNCATED]... "
type: design_rule
tags: [mixed, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_83cde498f9]
confidence: medium
---


# If ultramicroporous amine-functionalized MOFs are intended for flue-gas applications, then explicitl ...[TRUNCATED]... 

## Rule

If ultramicroporous amine-functionalized MOFs are intended for flue-gas applications, then explicitly validate moisture resilience across relevant RH and durations and avoid structural motifs that allow water access to vulnerable metal sites; if experimental zero-coverage Qst is low (~25–30 kJ mol−1), consider vacuum swing adsorption (VSA) but confirm water limits first.

## IF conditions

- application involves humid flue gas (e.g., up to tens of %RH)
- material contains metal centers that could be hydrolyzed
- experimental zero-coverage Qst ≲ ~30 kJ mol−1

## THEN actions

- perform breakthrough tests at relevant RH (e.g., 40–60% RH) and longer-term exposure (e.g., 80% RH for days) and humidity cycling
- consider linker orientations and metal coordination geometry to block water access (avoid irregular geometries that admit H2O to metal sites)
- if Qst is low and material is stable to intended RH, consider VSA process designs and shaping with alcohol-based solvents/binders

## Why

Cu(adci)-2 retained CO2 capture in 60% RH breakthrough tests but lost porosity and CO2 capacity after 80% RH for 1 week or liquid water exposure—irregular Cu(I) tetrahedra likely allowed water access to metal atoms. Authors note low Qst and chemical stability support feasibility for shaping and VSA but caution that high humidity or liquid water reduce capacity.

## Failure modes

- short-term/mid-level RH tolerance (e.g., single 60% RH test) may not predict long-term stability
- immersion in liquid water or prolonged exposure to high RH can appreciably reduce surface area and CO2 capacity

## Agent use stage

- planner
- executor
- candidate_filter

## Evidence

> Page 1 (abstract) and pages 2-5: "breakthrough experiments under dry and 60% relative humidity conditions show that its CO2 capture ability is retained..."; "BET surface areas were ... after exposure to 80% relative humidity for 1 week, to liquid water for 1 day..."; authors state low Qst and chemical stability make Cu(adci)-2 feasible for shaping and VSA but note humidity limitations.

## Links

- Source: [[sources/src_83cde498f9]]