---
title: "If using framework flexibility (breathing/gate-opening) to target pressure-dependent adsorption, acc ...[TRUNCATED]... "
type: design_rule
tags: [h2, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_ff1b0c9d63]
confidence: high
---


# If using framework flexibility (breathing/gate-opening) to target pressure-dependent adsorption, acc ...[TRUNCATED]... 

## Rule

If using framework flexibility (breathing/gate-opening) to target pressure-dependent adsorption, account for likely low ambient-temperature gravimetric capacity and use flexibility to tune pressure thresholds rather than absolute capacity.

## IF conditions

- design includes flexible/dynamic linkers capable of breathing or gate-opening

## THEN actions

- characterize adsorption isotherms across full pressure range at target temperatures
- use flexibility to achieve selective adsorption or pressure-triggered uptake rather than to maximize 298 K weight percent

## Why

Flexible MOFs can show gate-opening at low pressure and shift adsorption to higher pressures, but reported flexible examples have low wt% at 298 K even at high pressures.

## Failure modes

- expectation mismatch: flexibility may not deliver high room-temperature deliverable capacity
- mechanical fatigue or hysteresis could complicate reversibility

## Agent use stage

- planner
- reflection

## Evidence

> The hydrogen adsorption analysis ... M-URJC-n ... showed ... gate-opening type adsorption mechanism ... The hydrogen adsorption capacities ... were 2.81, 2.21, and 1.99 wt% ... at 77 K and up to 18 bar, and 0.12, 0.14, and 0.13 wt% at 298 K and 170 bar, due to the presence of flexible ligands.

## Links

- Source: [[sources/src_ff1b0c9d63]]