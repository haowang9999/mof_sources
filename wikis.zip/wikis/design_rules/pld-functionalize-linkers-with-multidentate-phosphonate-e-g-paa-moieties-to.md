---
title: "Functionalize linkers with multidentate phosphonate (e.g., PAA) moieties to achieve strong, localize ...[TRUNCATED]... "
type: design_rule
tags: [pld, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_c88d608b3b]
confidence: medium
---


# Functionalize linkers with multidentate phosphonate (e.g., PAA) moieties to achieve strong, localize ...[TRUNCATED]... 

## Rule

Functionalize linkers with multidentate phosphonate (e.g., PAA) moieties to achieve strong, localized lanthanide chemisorption that can out-compete monodentate oxo-cluster binding.

## IF conditions

- MOF has accessible linkers that can be chemically modified
- target is aqueous lanthanide capture (Ln3+)
- MOF retains structural integrity after functionalization

## THEN actions

- graft phosphonate-containing moieties onto linkers (e.g., convert −NH2 linkers to NH-PAA)
- characterize localization of lanthanides with XAFS and measure adsorption energetics in aqueous conditions
- validate DFT-predicted ordering with full aqueous experiments (e.g., calorimetry, batch adsorption)

## Why

Experimental XAFS and adsorption show UiO-66-NH-PAA had highest Ln uptake attributed to phosphonates; periodic DFT finds multidentate PAA binding much more favorable than monodentate Zr-oxo in the model (protonation sensitivity ~0.14 eV is small versus site-to-site energy difference).

## Failure modes

- functionalization may sterically block pores/windows or reduce accessible porosity if overfunctionalized
- DFT energetics were obtained under 'dry' conditions with limited explicit water; aqueous energetics may differ quantitatively
- phosphonate grafting chemistry may affect framework stability or introduce competing interactions

## Agent use stage

- planner
- candidate_filter
- executor

## Evidence

> "MOF functionalization with phosphonate groups led to Ln chemisorption onto these groups, which out-compete metal cluster sites."; "In case (a), we have tested two different protonation states and have found that reprotonation ... decreases the Gd3+ binding energy by 0.14 eV... it is far less than the energy difference between cases (a) and (b)."; "The overall adsorption capacity was the highest for the UiO-66-NH-PAA MOF... attributed to the higher affinity of phosphonate groups for Ln."

## Links

- Source: [[sources/src_c88d608b3b]]