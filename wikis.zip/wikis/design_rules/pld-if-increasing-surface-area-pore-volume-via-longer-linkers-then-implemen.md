---
title: "If increasing surface area/pore volume via longer linkers, then implement synthesis controls to prev ...[TRUNCATED]... "
type: design_rule
tags: [pld, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_b1552d4a9d]
confidence: high
---


# If increasing surface area/pore volume via longer linkers, then implement synthesis controls to prev ...[TRUNCATED]... 

## Rule

If increasing surface area/pore volume via longer linkers, then implement synthesis controls to prevent catenation and preserve accessible porosity.

## IF conditions

- Goal is to increase As and V for enhanced high-pressure H2 uptake
- Linker extension is synthetically feasible

## THEN actions

- Select longer rigid linkers or add aromatic rings to increase As and V
- Employ synthesis templates or linker substitutions (e.g., bromination) and tune reaction conditions to avoid framework interpenetration

## Why

Longer linkers (UiO-67 vs UiO-66) showed higher As and V and higher H2 uptake, but catenation can occur and block adsorption sites unless controlled.

## Failure modes

- Uncontrolled catenation leads to blocking of open metal sites and reduced uptake
- Long linkers may reduce framework stability if not properly designed

## Agent use stage

- planner
- candidate_filter
- executor

## Evidence

> UiO-67 (longer linker) had higher As and V and nearly double H2 uptake vs UiO-66. Catenation may be controlled by templates or linker design; it directly affects H2 adsorption.

## Links

- Source: [[sources/src_b1552d4a9d]]