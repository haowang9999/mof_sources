---
title: "Balance ABET/pore volume against bulk/particle density when optimizing for volumetric H2 capacity; d ...[TRUNCATED]... "
type: design_rule
tags: [h2|pld, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_fa8cccd644]
confidence: high
---


# Balance ABET/pore volume against bulk/particle density when optimizing for volumetric H2 capacity; d ...[TRUNCATED]... 

## Rule

Balance ABET/pore volume against bulk/particle density when optimizing for volumetric H2 capacity; do not optimize ABET alone.

## IF conditions

- Target: H2 storage at cryogenic conditions (≈77 K) or volumetric capacity is a priority
- ABET or pore volume is being increased

## THEN actions

- Compute volumetric uptake using realistic packing or single-crystal density, not only gravimetric ABET
- Prefer pore architectures and synthesis routes that provide high accessible area while preserving packing density (consider interpenetration or controlled densification)
- If densification is used, verify porosity retention after compaction

## Why

Increasing ABET tends to increase pore volume but reduces particle density, which can lower volumetric H2 capacity despite higher gravimetric uptake; volumetric uptake can plateau for very high-BET MOFs.

## Failure modes

- Designs maximizing ABET yield poor volumetric capacity due to low packing density
- Densification/pelletization may cause pore collapse or amorphization and reduce capacity

## Agent use stage

- planner
- candidate_filter
- reflection

## Evidence

> The increase in pore volume also results in a reduction of particle density ... while absolute gravimetric H2 capacities reach values as high as 12 wt%, volumetric H2 capacities peak at values of around 40 kg H2 per m3. For MOFs with high BET areas, a plateau in volumetric H2 uptake is reached.

## Links

- Source: [[sources/src_fa8cccd644]]