---
title: "Choose pore aperture relative to gas kinetic diameters to select separation mechanism: smaller-than- ...[TRUNCATED]... "
type: design_rule
tags: [co2|pld, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_a034d4944a]
confidence: high
---


# Choose pore aperture relative to gas kinetic diameters to select separation mechanism: smaller-than- ...[TRUNCATED]... 

## Rule

Choose pore aperture relative to gas kinetic diameters to select separation mechanism: smaller-than-undesired-species apertures for molecular sieving; larger pores with high interaction-site density for equilibrium selectivity; exploit diffusivity contrasts and tortuosity for kinetic separations.

## IF conditions

- there is a known kinetic diameter or size difference between gas components
- synthesis or post-synthetic modification can tune pore aperture

## THEN actions

- for molecular sieving: design apertures that sterically exclude undesired species
- for equilibrium separations: maximize interaction site density while allowing access to all species
- for kinetic separations: engineer pore-path tortuosity and aperture to slow down undesired species diffusion

## Why

Separation mechanism is governed by steric (size) effects, diffusion (kinetics), or thermodynamic adsorption preferences governed by pore size/topology and interactions.

## Failure modes

- inability to precisely control pore dimensions
- adsorbate-framework interactions may change effective pore size
- competitive adsorption or humidity may alter mechanism

## Agent use stage

- planner
- candidate_filter

## Evidence

> Adsorptive separation mechanisms can be divided into three categories ... The steric mechanism ... is based on the incompatibility of the substrate pores' shape and size with those of the adsorbate gas molecules. ... In kinetics separation, adsorption ... is determined by the diffusivity of each gas component. ... The thermodynamic equilibrium effect occurs when specific components preferentially adsorb on the surface of an adsorbent due to various adsorbate surface and/or adsorbate packing interactions. (pages 5-6)

## Links

- Source: [[sources/src_a034d4944a]]