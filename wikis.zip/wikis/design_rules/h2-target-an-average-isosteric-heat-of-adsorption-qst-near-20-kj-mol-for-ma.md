---
title: "Target an average isosteric heat of adsorption (Qst) near ~20 kJ/mol for maximizing deliverable H2 c ...[TRUNCATED]... "
type: design_rule
tags: [h2, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_8d4a290e19]
confidence: medium
---


# Target an average isosteric heat of adsorption (Qst) near ~20 kJ/mol for maximizing deliverable H2 c ...[TRUNCATED]... 

## Rule

Target an average isosteric heat of adsorption (Qst) near ~20 kJ/mol for maximizing deliverable H2 capacity at 298 K between 120 and 1.5 bar.

## IF conditions

- Goal: maximize deliverable H2 between storage P1=120 bar and discharge P2=1.5 bar
- Temperature is ~298 K
- Material is a MOF

## THEN actions

- Design or modify MOFs to achieve an average Qst of roughly 18.5–22 kJ/mol
- Prioritize candidate frameworks for modification that already have very large surface areas

## Why

GCMC simulations across eight MOFs show a narrow optimal Qst range (18.5–22 kJ/mol) that maximizes deliverable capacity under these conditions.

## Failure modes

- Increasing Qst beyond the optimum increases low-pressure uptake and reduces deliverable capacity
- Chemical modifications used to raise Qst may reduce free volume or add heavy atoms, lowering gravimetric capacity

## Agent use stage

- planner
- candidate_filter

## Evidence

> "the results show that an optimal Qst giving the maximum deliverable capacity exists for each MOF structure... optimal Qst values for all of the different MOFs are located in a very narrow range (18.5–22 kJ/mol)." and "Creating materials with large surface area (>4800 m2/g) with large Qst (around 20 kJ/mol) is a significant challenge."

## Links

- Source: [[sources/src_8d4a290e19]]