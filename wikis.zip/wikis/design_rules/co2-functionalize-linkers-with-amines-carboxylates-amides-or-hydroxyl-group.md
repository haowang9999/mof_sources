---
title: "Functionalize linkers with amines, carboxylates, amides, or hydroxyl groups (and ensure site accessi ...[TRUNCATED]... "
type: design_rule
tags: [co2, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_a034d4944a]
confidence: high
---


# Functionalize linkers with amines, carboxylates, amides, or hydroxyl groups (and ensure site accessi ...[TRUNCATED]... 

## Rule

Functionalize linkers with amines, carboxylates, amides, or hydroxyl groups (and ensure site accessibility) to increase CO2 affinity and selectivity via Lewis basic, polar and hydrogen-bond interactions.

## IF conditions

- goal is to increase CO2 adsorption selectivity or capacity
- linker chemistry allows introduction of functional groups and sites are accessible

## THEN actions

- synthesize or post-synthetically graft amine/carboxylate/amide/hydroxyl functional groups on linkers
- measure CO2 isotherms and selectivity vs. competing gases; verify accessibility and stability

## Why

Functional groups such as carboxylate groups, aliphatic amines, monodentate hydroxide and other Lewis-basic/polar groups form stronger interactions with CO2 molecules and are commonly used to enhance binding.

## Failure modes

- functional groups may reduce porosity if bulky or be sterically inaccessible
- chemical/thermal instability of functionalization under operating conditions
- some amide-functionalized MOFs have been reported not to bind guests as expected (framework-specific effects)

## Agent use stage

- planner
- candidate_filter
- executor

## Evidence

> The most common way to achieve the binding of CO2 molecules into MOFs is the use of functional groups that can form stronger interactions with CO2 molecules, such as carboxylate groups, aliphatic amines, monodentate hydroxide, open metal sites on the surface of MOFs are typically used as active sites has been proven to be a promising approach. (pages 5-6) || The high performance of the amine, amide and hydroxyl functions in CO2 separation was observed in MOFs with CO2 vacancies. (page 14)

## Links

- Source: [[sources/src_a034d4944a]]