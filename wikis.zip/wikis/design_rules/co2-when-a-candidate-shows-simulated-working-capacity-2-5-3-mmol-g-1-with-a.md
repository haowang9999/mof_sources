---
title: "When a candidate shows simulated working capacity ≳2.5–3 mmol·g−1 with a realistic regeneration swin ...[TRUNCATED]... "
type: design_rule
tags: [co2, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_20dae1036b]
confidence: medium
---


# When a candidate shows simulated working capacity ≳2.5–3 mmol·g−1 with a realistic regeneration swin ...[TRUNCATED]... 

## Rule

When a candidate shows simulated working capacity ≳2.5–3 mmol·g−1 with a realistic regeneration swing (~60°C), advance it to process-level simulation and experimental validation, but explicitly include humidity and impurities in follow-up evaluations.

## IF conditions

- simulated working capacity ≥ ~2.5–3 mmol·g−1 with realistic regeneration swing (~60°C)
- initial evaluation based on GCMC/process-level simulation

## THEN actions

- advance material to detailed PSA/TSA process simulation, experimental isotherms under humid conditions, and cycling stability tests
- validate assumptions used in screening (force fields, framework flexibility, presence of water/impurities)

## Why

mda-Zn/DOBPDC was identified in simulations as being in the optimum range with ~2.9 mmol·g−1 and 60°C regeneration, indicating promising process-level performance but requiring validation.

## Failure modes

- simulation conditions may omit impurities or humidity effects; experimental validation may show reduced performance

## Agent use stage

- candidate_filter
- planner
- executor

## Evidence

> “mda-Zn/DOBPDC shows performance in the optimum range for post-combustion CO2 capture... enabling a working capacity of 2.9 mmol·g−1 with a 1T = 60◦C for regeneration.”

## Links

- Source: [[sources/src_20dae1036b]]