---
title: "Ensure catalyst nanoparticles do not block pore channels and, where beneficial, disperse nanoparticl ...[TRUNCATED]... "
type: design_rule
tags: [h2, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_0abff73929]
confidence: medium
---


# Ensure catalyst nanoparticles do not block pore channels and, where beneficial, disperse nanoparticl ...[TRUNCATED]... 

## Rule

Ensure catalyst nanoparticles do not block pore channels and, where beneficial, disperse nanoparticles within the porous network without impeding atomic-H diffusion.

## IF conditions

- Using supported metal catalysts (Pt, Pd or similar) to generate atomic H for spillover
- MOF pore channels are narrow or easily blocked by nanoparticles

## THEN actions

- Select nanoparticle sizes, loadings, and placements that avoid obstructing pore entrances or internal channels
- Consider distributing catalysts near pore mouths or inside larger channels/mesopores to maximize emitted atomic-H access

## Why

Embedded nanoparticles that impede pore-channel access will prevent atomic H from entering pore volumes, negating spillover transport benefits.

## Failure modes

- Particles too large or agglomerated blocking pore mouths
- Embedding catalysts in narrow channels that restrict H emission/access

## Agent use stage

- planner
- candidate_filter
- executor

## Evidence

> "the embedded nanoparticles should not impede the diffusion of atomic H into the pore channels."

## Links

- Source: [[sources/src_0abff73929]]