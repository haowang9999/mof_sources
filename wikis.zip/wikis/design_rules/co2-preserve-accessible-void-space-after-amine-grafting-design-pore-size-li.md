---
title: "Preserve accessible void space after amine grafting: design pore size, linker placement, and amine c ...[TRUNCATED]... "
type: design_rule
tags: [co2, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_20dae1036b]
confidence: medium
---


# Preserve accessible void space after amine grafting: design pore size, linker placement, and amine c ...[TRUNCATED]... 

## Rule

Preserve accessible void space after amine grafting: design pore size, linker placement, and amine chemistry so appended amines leave sufficient free volume for CO2 access and cooperative binding.

## IF conditions

- material has open metal sites and will be functionalized with appended amines
- goal is high working capacity, selectivity, and regenerability in cyclic operation

## THEN actions

- model the post-grafting accessible void fraction and steric packing before synthesis
- prefer expanded pores for bulky grafts, or adopt partial functionalization to retain pore volume
- screen amine chemistries for balance of binding strength and steric footprint

## Why

Simulations show that the available void space left by the amine and the amine type critically determine capture properties; excessive loading or bulky amines can block pores and reduce working capacity.

## Failure modes

- excessive amine loading or bulky amines blocking pores → reduced CO2 access and low working capacity
- choosing amines that bind too weakly → low cyclic capacity

## Agent use stage

- planner
- candidate_filter

## Evidence

> “Simulations have shown that the available void space left by the amine and the type of amine functional group plays a crucial role in achieving optimal CO2 capture properties...”

## Links

- Source: [[sources/src_20dae1036b]]