---
title: "If aiming for high gravimetric capacity at 298 K, target a combination of moderate Qst (15–25 kJ·mol ...[TRUNCATED]... "
type: design_rule
tags: [h2, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_ff1b0c9d63]
confidence: medium
---


# If aiming for high gravimetric capacity at 298 K, target a combination of moderate Qst (15–25 kJ·mol ...[TRUNCATED]... 

## Rule

If aiming for high gravimetric capacity at 298 K, target a combination of moderate Qst (15–25 kJ·mol−1), Va ~2.5 cm3·g−1 and high porosity (~85%), balancing surface area vs pore volume according to operating pressure.

## IF conditions

- operating temperature ~298 K
- goal = high gravimetric H2 storage

## THEN actions

- optimize pore volume for low-pressure uptake and surface area for high-pressure uptake
- implement modest strategies to increase Qst (open metal sites, electrostatics) without large mass penalty

## Why

Authors summarized that these metrics (Qst 15–25 kJ·mol−1, Va ~2.5 cm3·g−1, porosity ~85%) are desirable to approach DOE-like high wt% targets.

## Failure modes

- increasing Qst via heavy functionalization that decreases gravimetric capacity
- sacrificing accessible porosity while adding mass (e.g., metal hydride nanoconfinement)

## Agent use stage

- planner
- candidate_filter

## Evidence

> Numerous calculations suggest with values of Qst within the range of 15–25 kJ·mol–1, with a Va value of ~2.5 cm3·g–1 and porosity of ~85%, would be desirable for an MOF as a successful candidate for hydrogen storage with 9 wt% of H2. At 298 K, the na value correlates mainly with the Va value at low P(H2) and the As value at high P(H2).

## Links

- Source: [[sources/src_ff1b0c9d63]]