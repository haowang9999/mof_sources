---
title: "Expect product metal incorporation ratios to differ from nominal feed ratios; quantify composition ( ...[TRUNCATED]... "
type: design_rule
tags: [pld, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_340141308b]
confidence: high
---


# Expect product metal incorporation ratios to differ from nominal feed ratios; quantify composition ( ...[TRUNCATED]... 

## Rule

Expect product metal incorporation ratios to differ from nominal feed ratios; quantify composition (e.g., by ICP) and adjust synthesis feed/conditions to achieve intended stoichiometry because different metals interact with ligands with different strengths (e.g., Cu2+ was found to incorporate at higher fraction).

## IF conditions

- Synthesizing nominal 1:1 or other feed-ratio bimetallic MxM1−x(BDC)TED0.5 formulations

## THEN actions

- Perform ICP (or equivalent) to quantify metal content in the product
- Adjust feed ratios or synthesis parameters to reach desired stoichiometry if necessary
- Use confirmed product composition when correlating structure–property trends

## Why

ICP results in the study showed actual metal atom ratios deviate from feed ratios due to differing metal–ligand interactions; Cu2+ incorporated preferentially in some samples.

## Failure modes

- Assuming feed = product ratio leads to misinterpretation of property-composition relationships
- Uncorrected composition differences can mask true structure–property trends

## Agent use stage

- planner
- candidate_filter
- executor

## Evidence

> ICP analysis was performed ... the metal atom ratio in the actual material is different from 1:1 used in synthesis, which indicates that different metal ions have different interaction forces with organic ligands. Among these metal ions, Cu2+ ions have the strongest electron-withdrawing ability, ... resulting in a higher proportion of copper ions in M0.5M0.5(BDC)TED0.5.

## Links

- Source: [[sources/src_340141308b]]