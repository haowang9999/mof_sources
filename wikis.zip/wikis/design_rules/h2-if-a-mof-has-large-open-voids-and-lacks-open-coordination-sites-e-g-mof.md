---
title: "If a MOF has large open voids and lacks open coordination sites (e.g., MOF-5), then do not expect si ...[TRUNCATED]... "
type: design_rule
tags: [h2, design_rule, agent]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_532b708453]
confidence: medium-high
---


# If a MOF has large open voids and lacks open coordination sites (e.g., MOF-5), then do not expect si ...[TRUNCATED]... 

## Rule

If a MOF has large open voids and lacks open coordination sites (e.g., MOF-5), then do not expect significant many-body polarization effects or enhanced H2 sorption from induced dipoles; deprioritize such architectures for cryogenic H2 storage that relies on induced polarization.

## IF conditions

- material has large void spaces / open topology
- no exposed metal coordination sites on SBU
- weakly polar framework

## THEN actions

- deprioritize such architectures for cryogenic H2 storage targets aiming to exploit induced polarization
- consider functionalizing pores or introducing polar sites if H2 uptake enhancement is required

## Why

Large pores place adsorbates far from charged surfaces and reduce framework polarizing field; absence of open metal sites reduces local field strength.

## Failure modes

- post-synthetic modifications may be required to add polarizing sites; performance gains depend on successful introduction of such sites

## Agent use stage

- candidate_filter
- planner

## Evidence

> MOF-5 ... does not possess an open coordination site on its zinc SBU and thus produces a more weakly polarizing field ... MOF-5 ... has an open topology with larger void spaces. This comparison strongly suggests that MOFs, like MOF-5, with large pores are not the best target materials for super-hydrogen-storage.

## Links

- Source: [[sources/src_532b708453]]