---
title: "Quantitative estimate example: for molecular hydrogen placed 0.30 nm from a double-charged cation (r ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_532b708453]
confidence: high
---


# Quantitative estimate example: for molecular hydrogen placed 0.30 nm from a double-charged cation (r ...[TRUNCATED]... 

## Mechanism claim

Quantitative estimate example: for molecular hydrogen placed 0.30 nm from a double-charged cation (representative of indium in the soc-MOF SBU), polarization energy is about a factor of 4 larger than the quadrupolar interaction and is always attractive.

## Applicability

- Task: `h2`
- Mechanism type: `quantitative interaction comparison`
- Condition scope: `{"gas": "H2", "temperature_K": null, "pressure_bar": null, "material_family": "model of H2 near a double-charged cation (representative of indium in soc-MOF)", "method": "theoretical estimate / simulation argument"}`

## Positive design features

- polarization much larger than quadrupole in this model geometry

## Negative design features

- Not specified

## Agent design implication

Designs that place H2 within ~0.3 nm of charged sites will gain larger binding energy from polarization than from quadrupolar interactions; emphasize electronic polarizability and charged centers in design.

## Evidence

> As an estimate of the relative importance of quadrupole (that are typically accounted for) and polarization (usually neglected) terms, consider a polarizable site with a point quadrupole... placed 0.30 nm distant from a double-charged cation... Given the most favorable geometry for the quadrupolar interactions, the polarization energy is a factor of 4 larger and is always attractive.

Evidence location: page 2

## Links

- Source: [[sources/src_532b708453]]