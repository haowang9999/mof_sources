---
title: "Ultra-microporous single-ligand MOFs and pore designs that create single-molecule traps can enable s ...[TRUNCATED]... "
type: mechanism
tags: [co2|h2|mixed, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_c42cf01235]
confidence: medium
---


# Ultra-microporous single-ligand MOFs and pore designs that create single-molecule traps can enable s ...[TRUNCATED]... 

## Mechanism claim

Ultra-microporous single-ligand MOFs and pore designs that create single-molecule traps can enable selective and low-energy CO2 capture and effective CO2/H2 separation via molecular sieving and strong confinement.

## Applicability

- Task: `co2|h2|mixed`
- Mechanism type: `pore size / molecular sieving and single-molecule trap confinement`
- Condition scope: `{"gas": "CO2/H2 (precombustion) and CO2 generally", "temperature_K": null, "pressure_bar": null, "material_family": "single-ligand ultra-microporous MOFs; porous materials with pre-designed single-molecule traps", "method": "experimental reports referenced"}`

## Positive design features

- ultra-microporosity (very small pore apertures)
- single-ligand or designed trap motifs that precisely size the adsorption site

## Negative design features

- Not specified

## Agent design implication

Design MOFs with ultra-microporous pore sizes and/or pre-designed single-molecule traps to enable CO2 separation from H2 and low-energy selective capture.

## Evidence

> References: "A Single-Ligand Ultra-Microporous MOF for Precombustion CO2 Capture and Hydrogen Purification."; "Porous Materials with Pre-Designed Single-Molecule Traps for CO2 Selective Adsorption."; "Low-Energy Selective Capture of Carbon Dioxide by a Pre-Designed Elastic Single-Molecule Trap."

Evidence location: pages 11-13 (References)

## Links

- Source: [[sources/src_c42cf01235]]