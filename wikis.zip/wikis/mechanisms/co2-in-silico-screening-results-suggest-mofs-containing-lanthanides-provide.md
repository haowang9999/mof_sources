---
title: "In silico screening results suggest MOFs containing lanthanides provide best performance for CO2/CH4 ...[TRUNCATED]... "
type: mechanism
tags: [co2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_1fa85425f9]
confidence: medium
---


# In silico screening results suggest MOFs containing lanthanides provide best performance for CO2/CH4 ...[TRUNCATED]... 

## Mechanism claim

In silico screening results suggest MOFs containing lanthanides provide best performance for CO2/CH4 separation whereas MOFs with alkali metals have the worst separation performance.

## Applicability

- Task: `co2`
- Mechanism type: `composition–performance relationship`
- Condition scope: `{"gas": "CO2 and CH4", "temperature_K": null, "pressure_bar": null, "material_family": "MOFs differentiated by metal type (lanthanide vs alkali)", "method": "in silico screening (simulation)"}`

## Positive design features

- Lanthanide-containing MOFs: best CO2/CH4 separation performance (per cited screening)

## Negative design features

- Alkali-metal-containing MOFs: worst CO2/CH4 separation performance (per cited screening)

## Agent design implication

When designing or selecting MOFs for CO2/CH4 separations, prioritize lanthanide-based MOFs and deprioritize alkali-metal-based MOFs based on reported screening trends, but verify experimentally or with detailed simulations.

## Evidence

> A recent work showed that MOFs containing lanthanides provide the best performance for CO2/CH4 separation whereas MOFs with alkali metals have the worst separation performance (Qiao et al., 2016a,b). (page 6).

Evidence location: page 6

## Links

- Source: [[sources/src_1fa85425f9]]