---
title: "The total interaction potential in the simulations combines Ewald electrostatics, explicit many-body ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_532b708453]
confidence: high
---


# The total interaction potential in the simulations combines Ewald electrostatics, explicit many-body ...[TRUNCATED]... 

## Mechanism claim

The total interaction potential in the simulations combines Ewald electrostatics, explicit many-body polarization (Thole-Applequist induced dipoles), and Lennard-Jones (UFF) pair potentials; H2 is modeled as a rigid diatomic three-point electrostatic model with a center-of-mass charge chosen to reproduce the molecular quadrupole.

## Applicability

- Task: `h2`
- Mechanism type: `electrostatics + van der Waals + polarization (model composition)`
- Condition scope: `{"gas": "H2", "temperature_K": 78, "pressure_bar": null, "material_family": "soc-MOF", "method": "simulation"}`

## Positive design features

- electrostatic Ewald treatment
- explicit polarization (Thole-Applequist)
- Lennard-Jones UFF for dispersion/repulsion
- H2 quadrupole reproduced via charge at center-of-mass

## Negative design features

- Not specified

## Agent design implication

When modeling H2 adsorption in polar MOFs, represent interactions by combining Ewald electrostatics, explicit many-body polarization, and appropriate Lennard-Jones parameters; model H2 with a rigid diatomic three-point electrostatic model that reproduces its quadrupole.

## Evidence

> The electrostatic model is a three-point model with a charge located at the center of mass. ... the hydrogen ... interact(s) (between distinct molecules) via a polarizable many-body potential, along with the Coulombic and UFF-defined Lennard-Jones intermolecular pair potentials. ... The total potential for the system is described by where Uelect is the electrostatic potential energy calculated from the Ewald field, Upol is the polarization energy..., and ULJ is the Lennard-Jones potential.

Evidence location: pages 4-6 (electrostatic model, potentials, total potential)

## Links

- Source: [[sources/src_532b708453]]