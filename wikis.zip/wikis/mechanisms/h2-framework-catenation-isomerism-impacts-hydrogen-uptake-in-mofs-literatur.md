---
title: "Framework catenation/isomerism impacts hydrogen uptake in MOFs (literature example)."
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_3b254ae858]
confidence: medium
---


# Framework catenation/isomerism impacts hydrogen uptake in MOFs (literature example).

## Mechanism claim

Framework catenation/isomerism impacts hydrogen uptake in MOFs (literature example).

## Applicability

- Task: `h2`
- Mechanism type: `topology → adsorption (structural influence)`
- Condition scope: `{"gas": "H2", "temperature_K": null, "pressure_bar": null, "material_family": "metal-organic frameworks (general; cited example)", "method": "experimental (cited literature)"}`

## Positive design features

- ability to tune adsorption by changing catenation/isomerism (reported in cited study)

## Negative design features

- no quantitative direction or magnitude given in the citation title shown in this paper

## Agent design implication

Controlling framework catenation/isomerism (e.g., by synthesis or linker design) can be used as a lever to tune hydrogen uptake in MOFs; evaluate catenation state when optimizing H2 storage.

## Evidence

> "Framework-catenation isomerism in metal−organic frameworks and its impact on hydrogen uptake." (Ma, S.; Sun, D.; Ambrogio, M.; Fillinger, J. A.; Parkin, S.; Zhou, H.-C. J. Am. Chem. Soc. 2007, 129, 1858−1859.)

Evidence location: references (23), pages 6669-6670

## Links

- Source: [[sources/src_3b254ae858]]