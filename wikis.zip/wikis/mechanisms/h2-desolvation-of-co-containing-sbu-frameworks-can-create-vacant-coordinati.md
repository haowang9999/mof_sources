---
title: "Desolvation of Co-containing SBU frameworks can create vacant coordination sites on Co2+ that bind H ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_ff1b0c9d63]
confidence: high
---


# Desolvation of Co-containing SBU frameworks can create vacant coordination sites on Co2+ that bind H ...[TRUNCATED]... 

## Mechanism claim

Desolvation of Co-containing SBU frameworks can create vacant coordination sites on Co2+ that bind H2 side-on and produce relatively high Qst (example: SNU-150′ Qst ~15 kJ·mol−1 at zero coverage).

## Applicability

- Task: `h2`
- Mechanism type: `open metal site creation by desolvation enabling side-on H2 binding`
- Condition scope: `{"gas": "H2", "temperature_K": 77, "pressure_bar": 1, "material_family": "SNU-15 and SNU-150′ (Co-based frameworks)", "method": "experiment"}`

## Positive design features

- side-on bonding geometry possible due to Co–Co distances
- measured Qst ~15 kJ·mol−1

## Negative design features

- Not specified

## Agent design implication

Create open Co2+ coordination sites by removing coordinated solvent from appropriate SBUs to enable stronger (side-on) H2 binding and increase Qst toward ~15 kJ·mol−1.

## Evidence

> When the coordinated H2O molecules are removed, the vacant coordination sites are created on the Co2+ ions. Due to the values of the Co–Co distance, H2 molecules can be bonded in a side-on manner that results in the Qst value of 15 kJ·mol−1 at zero coverage. The same high Qst value was found for the [CoII4(µ-OH2)4(MTB)2]n ... prepared by heating the SNU-15 at 493 K under a vacuum for 24 h.

Evidence location: page 18

## Links

- Source: [[sources/src_ff1b0c9d63]]