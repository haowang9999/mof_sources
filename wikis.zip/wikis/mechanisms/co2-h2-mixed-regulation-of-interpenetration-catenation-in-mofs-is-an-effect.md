---
title: "Regulation of interpenetration/catenation in MOFs is an effective approach to control pore size, por ...[TRUNCATED]... "
type: mechanism
tags: [co2|h2|mixed, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_3b254ae858]
confidence: medium
---


# Regulation of interpenetration/catenation in MOFs is an effective approach to control pore size, por ...[TRUNCATED]... 

## Mechanism claim

Regulation of interpenetration/catenation in MOFs is an effective approach to control pore size, pore environment, and framework stability, which can fine-tune macroscopic properties including gas storage and separation.

## Applicability

- Task: `co2|h2|mixed`
- Mechanism type: `literature-based conceptual mechanism (review statement and cited studies)`
- Condition scope: `{"gas": "general (gas storage/separation mentioned)", "temperature_K": null, "pressure_bar": null, "material_family": "MOFs (general statement citing literature)", "method": "review / synthesis & design (cited experimental and conceptual studies)"}`

## Positive design features

- Interpenetration control directly alters pore architecture and environment
- Consequential impact on macroscopic properties (e.g., gas storage, separation) is explicitly stated in the article and by cited literature

## Negative design features

- This paper provides no experimental CO2 or H2 adsorption data to quantify the effect for NU-650/NU-651; literature examples cited are qualitative or from other systems

## Agent design implication

When aiming to optimize MOFs for gas storage/separation (CO2, H2), consider design strategies that control interpenetration (steric ligand modification, reaction conditions, epitaxy, modulation) to tailor pore size/environment and stability; however, validate effects experimentally for the target gas and conditions.

## Evidence

> Regulation of interpenetration in MOFs is an effective way to control the pore size, pore environment, and framework stability, consequently fine-tuning related macroscopic properties such as catalysis, gas storage, and separation.
"Control over catenation in metal−organic frameworks via rational design of the organic building block." (Farha, O. K.; Malliakas, C. D.; Kanatzidis, M. G.; Hupp, J. T. J. Am. Chem. Soc. 2010, 132, 950−952.)

Evidence location: page 1 (Introduction) and references (26), pages 6669-6670

## Links

- Source: [[sources/src_3b254ae858]]