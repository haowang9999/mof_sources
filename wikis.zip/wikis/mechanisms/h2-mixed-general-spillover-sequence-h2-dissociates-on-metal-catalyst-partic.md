---
title: "General spillover sequence: H2 dissociates on metal catalyst particles to produce atomic H; atomic H ...[TRUNCATED]... "
type: mechanism
tags: [h2|mixed, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_0abff73929]
confidence: high
---


# General spillover sequence: H2 dissociates on metal catalyst particles to produce atomic H; atomic H ...[TRUNCATED]... 

## Mechanism claim

General spillover sequence: H2 dissociates on metal catalyst particles to produce atomic H; atomic H transfers to the MOF receptor either in the gas phase or as weakly physisorbed species; atomic H sticks to receptor binding sites (linkers) to form chemisorbed H; Eley–Rideal (ER) recombination between gas-phase H and adsorbed H can reform H2 and limit net storage.

## Applicability

- Task: `h2|mixed`
- Mechanism type: `mechanistic_steps`
- Condition scope: `{"gas": "H2 → atomic H (gas-phase or weakly physisorbed)", "temperature_K": 298, "pressure_bar": null, "material_family": "MOFs (discussion centered on IRMOF-1 / BDC linkers)", "method": "DFT/simulation + literature-cited experiments"}`

## Positive design features

- Defines discrete steps that separate catalyst activity, transport, sticking, and recombination
- Explains how spillover can enable room-temperature uptake compared with physisorption

## Negative design features

- ER recombination can rapidly undo chemisorbed H and limit penetration depth
- Transport step requires access/pathways (defects, mesopores) and sufficient supply of atomic H

## Agent design implication

Optimize (a) catalyst ability to dissociate H2 and emit atomic H, (b) pore connectivity/entrances or mesopores to allow gas-phase/physisorbed H access, and (c) binding-site chemistry to favor stable chemisorption while mitigating ER recombination.

## Evidence

> "Hydrogen storage on such materials has been described through H spillover, a mechanism that involves the dissociation of H2 on the metal particles, atomic H diffusion from the particles to the sorbent, and chemisorption of atomic hydrogen on the material’s binding sites." "the proposed mechanism of spillover, consisting of the generation of gas-phase atomic H on the metal catalyst, H transfer in gas phase or physisorbed form, sticking of H atoms on the binding sites of the receptor, and Eley-Rideal recombination reactions, might be general and applicable to various spillover materials"

Evidence location: page 1 (abstract/introduction); page 7 (discussion/summary)

## Links

- Source: [[sources/src_0abff73929]]