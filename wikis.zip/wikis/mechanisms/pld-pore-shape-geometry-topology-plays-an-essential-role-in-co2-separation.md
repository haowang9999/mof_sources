---
title: "Pore shape (geometry/topology) plays an essential role in CO2 separation and pore‑recognition/topolo ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_1fa85425f9]
confidence: medium
---


# Pore shape (geometry/topology) plays an essential role in CO2 separation and pore‑recognition/topolo ...[TRUNCATED]... 

## Mechanism claim

Pore shape (geometry/topology) plays an essential role in CO2 separation and pore‑recognition/topological analysis can identify MOFs with similar pore geometries to top performing structures.

## Applicability

- Task: `pld`
- Mechanism type: `structural / pore geometry influence on adsorption/separation`
- Condition scope: `{"gas": "CO2 separations generally", "temperature_K": null, "pressure_bar": null, "material_family": "MOFs", "method": "analysis / computational classification (topological data analysis)"}`

## Positive design features

- specific pore geometries similar to top performers

## Negative design features

- Not specified

## Agent design implication

Use pore-recognition and topological data analysis to find MOFs with pore geometries similar to known top performers as a route to identify synthesizable analogs with high CO2 selectivity.

## Evidence

> "A pore recognition approach was recently developed to quantify similarity of pore structures and materials were classified using topological data analysis (Lee et al., 2017). With this approach, MOFs with similar pore geometries were identified and materials that are similar to top performing structures were screened for CH4 storage. Future studies focusing on CO2 separation will be useful since the shape of the pores plays an essential role in the CO2 separation." (pages 3-4).

Evidence location: page 3-4 (Conclusion and future prospective / MOF Databases)

## Links

- Source: [[sources/src_1fa85425f9]]