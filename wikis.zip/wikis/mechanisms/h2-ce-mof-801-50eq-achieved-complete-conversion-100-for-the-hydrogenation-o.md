---
title: "Ce-MOF-801-50eq achieved complete conversion (100%) for the hydrogenation of dicyclopentadiene (DCPD ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_20cacd73e1]
confidence: medium
---


# Ce-MOF-801-50eq achieved complete conversion (100%) for the hydrogenation of dicyclopentadiene (DCPD ...[TRUNCATED]... 

## Mechanism claim

Ce-MOF-801-50eq achieved complete conversion (100%) for the hydrogenation of dicyclopentadiene (DCPD) under the reported catalytic conditions (H2 at 2 MPa, 100 °C, 5 h), and the authors attribute the superior catalytic performance to defect-engineering-derived features (high SSA, favorable pore-size distribution/mesoporosity, abundant unsaturated metal sites, and favorable Ce3+/Ce4+ ratio).

## Applicability

- Task: `h2`
- Mechanism type: `defect-mediated catalytic activity (structure → activity link for hydrogenation)`
- Condition scope: `{"gas": "H2 (reactant gas in hydrogenation)", "temperature_K": 373, "pressure_bar": 20, "material_family": "Ce-MOF-801-50eq (compared to other Ce-MOF-801-neq and M-MOF-801-50eq where M = Zr, Hf)", "method": "experiment (catalytic hydrogenation testing)"}`

## Positive design features

- Reported 100% conversion of DCPD for Ce-MOF-801-50eq under specified conditions
- Authors cite high SSA, appropriate pore size distribution (mesoporosity/micropore mix), abundant unsaturated Ce sites, and Ce3+/Ce4+ ratio as contributing factors

## Negative design features

- Other Ce-MOF-801 variants show much lower conversions (examples in paper include low conversions for 0eq and 200eq samples), indicating sensitivity to defect tuning
- Catalytic attribution is correlative (authors associate structural features with activity but intrinsic mechanistic proof beyond correlative characterization is not exhaustive)

## Agent design implication

For hydrogenation of bulky substrates like DCPD, engineer missing-linker defects and tune pore-size distribution in Ce-MOF-801 (e.g., via ~50 eq formic-acid modulation and cell pulverization pretreatment as per study) to increase accessible surface area and unsaturated metal sites, which correlated with enhanced conversion in this work.

## Evidence

> Among the different samples studied, the optimal Ce-MOF-801-50eq sample exhibited remarkable catalytic activity for DCPD hydrogenation, achieving a conversion rate of 100%. The enhanced catalytic performance of Ce-MOF-801-50eq can be attributed to advantages provided by defect engineering, such as the high specific surface area, proper pore size distribution, abundant unsaturated metal sites, and Ce3+/Ce4+ atom ratio, which have been supported by various characterizations. The catalytic performance of the Ce-MOF-801-neq samples toward DCPD hydrogenation was evaluated under identical reaction conditions (H2 at 2 MPa, 100 °C, 5 h).

Evidence location: Pages 1–3 (Abstract; Catalytic Performance Test conditions and comparisons)

## Links

- Source: [[sources/src_20cacd73e1]]