---
title: "Framework catenation/interpenetration reduces accessible open metal sites and accessible porosity, l ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_b1552d4a9d]
confidence: high
---


# Framework catenation/interpenetration reduces accessible open metal sites and accessible porosity, l ...[TRUNCATED]... 

## Mechanism claim

Framework catenation/interpenetration reduces accessible open metal sites and accessible porosity, lowering H2 uptake; catenation can be influenced/mitigated by linker design and synthesis conditions (templates, precursor concentration, temperature, ligand substitution).

## Applicability

- Task: `pld`
- Mechanism type: `structural blocking / synthesis control`
- Condition scope: `{"gas": "H2", "temperature_K": 77, "pressure_bar": 1, "material_family": "PCN-6 (catenated) vs PCN-60 (non-catenated) and general MOFs", "method": "review / reported experiments"}`

## Positive design features

- non-catenated frameworks can expose open metal sites increasing low-pressure H2 uptake

## Negative design features

- catenation can block adsorption sites and reduce uptake

## Agent design implication

Control catenation during synthesis (use templates, tune linker substitution, and reaction parameters) to maintain open metal sites and accessible pore volume when targeting high low-pressure uptake.

## Evidence

> Interweaving and interpenetration ... catenation may be controlled by adding a template during the solvothermal MOF synthesis ... Using a brominated and non-brominated ligand ... concluded that catenation may be controlled by the organic linker design. ... after activation the hydrogen adsorption capacity at 77 K and 1 bar was higher for the non-catenated PCN-60, explained by exposed open metal sites that were blocked in the catenated PCN-6.

Evidence location: pages 6-7

## Links

- Source: [[sources/src_b1552d4a9d]]