---
title: "MOFs can be highly CO2-selective membranes according to experiments; molecular simulations can help  ...[TRUNCATED]... "
type: mechanism
tags: [co2|pld|mixed, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_1fa85425f9]
confidence: medium
---


# MOFs can be highly CO2-selective membranes according to experiments; molecular simulations can help  ...[TRUNCATED]... 

## Mechanism claim

MOFs can be highly CO2-selective membranes according to experiments; molecular simulations can help identify promising MOF membranes to guide challenging and time-consuming experimental membrane fabrication and testing.

## Applicability

- Task: `co2|pld|mixed`
- Mechanism type: `membrane selectivity / design guidance`
- Condition scope: `{"gas": "CO2 separations (membrane context)", "temperature_K": null, "pressure_bar": null, "material_family": "MOF membranes", "method": "experiment (selectivity claim) and simulation (screening guidance)"}`

## Positive design features

- High experimental CO2 selectivity reported for some MOF membranes

## Negative design features

- Experimental fabrication/testing of thin-layer membranes is challenging and time-consuming

## Agent design implication

Use computational screening (including MD for diffusion) to prioritize MOF membrane candidates for CO2 separations before committing to difficult experimental membrane fabrication and testing.

## Evidence

> Several experiments showed that MOFs can be highly CO2 selective membranes (Adatoz et al., 2015). Considering the experimental challenges in fabricating thin-layer membranes from new materials and long time requirements of membrane testing, identification of promising MOF membranes using computer simulations will greatly contribute in directing experimental efforts. (page 5).

Evidence location: page 5

## Links

- Source: [[sources/src_1fa85425f9]]