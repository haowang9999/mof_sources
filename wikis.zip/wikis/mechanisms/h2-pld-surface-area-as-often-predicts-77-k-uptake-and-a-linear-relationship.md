---
title: "Surface area (As) often predicts 77 K uptake and a linear relationship between As and uptake is obse ...[TRUNCATED]... "
type: mechanism
tags: [h2|pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_b1552d4a9d]
confidence: high
---


# Surface area (As) often predicts 77 K uptake and a linear relationship between As and uptake is obse ...[TRUNCATED]... 

## Mechanism claim

Surface area (As) often predicts 77 K uptake and a linear relationship between As and uptake is observed over a broad range, but at low pressure (~1 bar) and very high As (> ~2000 m2·g−1) the correlation breaks down because surface cannot be fully covered and adsorption is dominated by highest-affinity sites.

## Applicability

- Task: `h2|pld`
- Mechanism type: `structural (surface area) effect with caveat`
- Condition scope: `{"gas": "H2", "temperature_K": 77, "pressure_bar": 1, "material_family": "general MOFs", "method": "review"}`

## Positive design features

- surface area is predictive of uptake across many materials and As ranges
- higher As (and consequently V) generally beneficial for 77 K storage

## Negative design features

- correlation between As and uptake at 1 bar fails for very high As values
- low-pressure uptake may instead be controlled by highest-affinity sites (Qst) and site accessibility

## Agent design implication

For 77 K intermediate-pressure applications increasing As is beneficial; for low-pressure (~1 bar) targets, simply increasing As beyond ~2000 m2·g−1 may not increase uptake — prioritize creating high-affinity adsorption sites and ensuring site accessibility.

## Evidence

> A linear relationship between the H2 adsorption capacity at 77 K and the As value has been confirmed in numerous publications. The adsorption capacity at 77 K and 1 bar of H2 is related to the As values within the range of 100–2000 m2·g−1 and does not correlate in the case of higher As values. This may be because the sorbent surface cannot be fully covered by H2 molecules at these high As and low P(H2) values. In addition, it is most likely that the H2 molecules will preferentially bind on the most thermodynamically favorable sites...

Evidence location: pages 4-6

## Links

- Source: [[sources/src_b1552d4a9d]]