---
title: "Simulated binding energies for the MC-minimized CO2 site (DFT-D single-point −39.4 kJ mol−1; optimiz ...[TRUNCATED]... "
type: mechanism
tags: [co2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_83cde498f9]
confidence: medium
---


# Simulated binding energies for the MC-minimized CO2 site (DFT-D single-point −39.4 kJ mol−1; optimiz ...[TRUNCATED]... 

## Mechanism claim

Simulated binding energies for the MC-minimized CO2 site (DFT-D single-point −39.4 kJ mol−1; optimization −42.7 kJ mol−1) are larger than the experimentally measured zero-coverage Qst (~27.6 kJ mol−1), indicating simulations may overestimate binding strength at low coverage.

## Applicability

- Task: `co2`
- Mechanism type: `energetics (simulation vs experiment)`
- Condition scope: `{"gas": "CO2", "temperature_K": null, "pressure_bar": null, "material_family": "Cu(adci)-2", "method": "DFT-D single-point and geometry optimization; comparison to experimental Qst"}`

## Positive design features

- DFT-D binding energies near −39 to −43 kJ mol−1 (MC-minimized site)

## Negative design features

- simulated zero-coverage enthalpy (~39.5 kJ mol−1) overestimates experimental Qst (~27.6 kJ mol−1)

## Agent design implication

Treat simulation-derived binding energies as potentially overestimated upper bounds; validate binding energetics and low-pressure uptake with experimental Qst measurements when designing regeneration strategies.

## Evidence

> Pages 5-6: "The binding energy for the MC-minimized site was estimated to be −39.4 kJ mol−1 according to single-point density functional theory calculations with dispersion correction ... binding energy: −42.7 kJ mol−1. ... one explanation being that the simulated zero-coverage Qst values are higher than the experimental outcomes (∼39.5 vs 27.6 kJ mol−1)."

Evidence location: pages 5-6 (binding energies and comparison to Qst)

## Links

- Source: [[sources/src_83cde498f9]]