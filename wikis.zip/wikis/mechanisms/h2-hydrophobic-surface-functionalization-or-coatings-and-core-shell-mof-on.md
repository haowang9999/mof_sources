---
title: "Hydrophobic surface functionalization or coatings and core–shell MOF-on-MOF architectures can protec ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_fa8cccd644]
confidence: high
---


# Hydrophobic surface functionalization or coatings and core–shell MOF-on-MOF architectures can protec ...[TRUNCATED]... 

## Mechanism claim

Hydrophobic surface functionalization or coatings and core–shell MOF-on-MOF architectures can protect water-sensitive MOF cores from degradation, preserving crystal structure, morphology, surface area and H2 uptake after aqueous exposure.

## Applicability

- Task: `h2`
- Mechanism type: `hydrophobic modification / core–shell protection → moisture protection → retention of porosity and uptake`
- Condition scope: `{"gas": "H2 (performance retention after aqueous exposure)", "temperature_K": null, "pressure_bar": null, "material_family": "water-sensitive MOFs (examples: DUT-4, bio-MOF-11/core with bio-MOF-14 shell)", "method": "hydrophobic coating experiments; MOF-on-MOF synthesis and water stability testing"}`

## Positive design features

- preserved structure and H2 uptake after water exposure
- improved water stability and selective gas storage properties for core–shell hybrids

## Negative design features

- coatings/shells can block pores if not applied carefully

## Agent design implication

Apply hydrophobic coatings, non-polar linker functionalization, or design core–shell MOF-on-MOF hybrids with hydrophobic shells to shield water-sensitive cores while monitoring pore accessibility.

## Evidence

> Qian et al. synthesized a hydrophobic DUT-4 that preserved crystal structure, morphology, surface area and H2 uptake after aqueous exposure. || Li et al. developed a MOF-on-MOF where a hydrophobic bio-MOF-14 shell protected a water-sensitive core; resulting hybrids showed selective gas storage and improved water stability.

Evidence location: page 8 (section 3.3 Hydrophobicity) || page 10 (section 4.1.2 MOF-on-MOF)

## Links

- Source: [[sources/src_fa8cccd644]]