---
title: "Activation (pore evacuation) conditions used before CO2 sorption: 24 h at 90 °C for noncatenated sam ...[TRUNCATED]... "
type: mechanism
tags: [co2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_90ad344e79]
confidence: high
---


# Activation (pore evacuation) conditions used before CO2 sorption: 24 h at 90 °C for noncatenated sam ...[TRUNCATED]... 

## Mechanism claim

Activation (pore evacuation) conditions used before CO2 sorption: 24 h at 90 °C for noncatenated samples and 24 h at 100 °C for catenated samples; L5 (one compound) was activated using supercritical CO2 because heating and low-boiling-solvent exchange gave very low surface area.

## Applicability

- Task: `co2`
- Mechanism type: `activation_protocol_effect_on_accessible_surface_area`
- Condition scope: `{"gas": "CO2 (measurement)", "temperature_K": 273, "pressure_bar": null, "material_family": "compounds 1-8 (Zn paddlewheel MOFs)", "method": "experiment (sample activation prior to CO2 sorption)"}`

## Positive design features

- supercritical CO2 activation can rescue surface area in cases where thermal/solvent-exchange activation gives low surface area

## Negative design features

- heating and solvent exchange may reduce measurable surface area for some materials (example: L5)

## Agent design implication

For porous Zn paddlewheel MOFs, follow differential activation temperatures (noncatenated ~90 °C, catenated ~100 °C for 24 h) before CO2 sorption; consider supercritical CO2 activation if conventional activation yields low surface area.

## Evidence

> “Based on the TGA... pore evacuation/‘activation’ was performed for 24 h at 90 and 100 °C for the noncatenated and catenated, respectively. The only exception was compound L5, which was activated using supercritical CO2 because heating and low-boiling-solvent exchange gave a very low surface area.”

Evidence location: page 3

## Links

- Source: [[sources/src_90ad344e79]]