---
title: "Relevant PLD ranges for modeled spherical adsorbates are tabulated; for H2 the indicated dmin–dmax r ...[TRUNCATED]... "
type: mechanism
tags: [h2|pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_97052fb350]
confidence: high
---


# Relevant PLD ranges for modeled spherical adsorbates are tabulated; for H2 the indicated dmin–dmax r ...[TRUNCATED]... 

## Mechanism claim

Relevant PLD ranges for modeled spherical adsorbates are tabulated; for H2 the indicated dmin–dmax range of PLD of interest is 1.952–2.705 Å (based on H2 LJ σ mapping).

## Applicability

- Task: `h2|pld`
- Mechanism type: `PLD sizing guidance for target gas (H2)`
- Condition scope: `{"gas": "H2 (modeled as spherical, nonpolar, united-atom LJ)", "temperature_K": null, "pressure_bar": null, "material_family": "MOFs", "method": "simulation / geometric mapping"}`

## Positive design features

- provides explicit numerical PLD ranges to focus screening for H2-sized probes

## Negative design features

- based on spherical nonpolar model for H2; ignores quantum effects, framework flexibility

## Agent design implication

When designing or screening MOFs for H2 diffusion/adsorption, prioritize materials with PLD in the ~1.95–2.71 Å window to match the modeled H2 probe size.

## Evidence

> Table 1. ... H2: ε/kB = 38; σ = 2.9415 Å; dmin = 1.952 Å; dmax = 2.705 Å.

Evidence location: page 4, Table 1

## Links

- Source: [[sources/src_97052fb350]]