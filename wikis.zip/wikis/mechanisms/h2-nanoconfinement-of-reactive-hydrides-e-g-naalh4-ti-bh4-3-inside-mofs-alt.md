---
title: "Nanoconfinement of reactive hydrides (e.g., NaAlH4, Ti(BH4)3) inside MOFs alters decomposition pathw ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_ff1b0c9d63]
confidence: high
---


# Nanoconfinement of reactive hydrides (e.g., NaAlH4, Ti(BH4)3) inside MOFs alters decomposition pathw ...[TRUNCATED]... 

## Mechanism claim

Nanoconfinement of reactive hydrides (e.g., NaAlH4, Ti(BH4)3) inside MOFs alters decomposition pathways and kinetics, lowering activation energies and stabilizing volatile species, while increasing local gas density and often reducing measured BET surface area.

## Applicability

- Task: `h2`
- Mechanism type: `nanoconfinement-mediated kinetic/thermochemical modification`
- Condition scope: `{"gas": "H2 (in context of hydride loading/release)", "temperature_K": [433, 350], "pressure_bar": [105, null], "material_family": "hydride@MOF composites (NaAlH4@MOF-74(Mg), Ti(BH4)3@UiO-66)", "method": "experiment"}`

## Positive design features

- micropores allow intimate contact with pore walls to stabilize decomposition products
- lowered activation energy and faster kinetics
- stabilization of volatile hydrides at higher temperatures

## Negative design features

- added MOF mass reduces gravimetric hydrogen storage capacity
- post-infiltration BET surface area decreases

## Agent design implication

Use microporous MOFs as nanoscaffolds to nanoconfine metal hydrides when the goal is to reduce decomposition activation energy and improve kinetics/reversibility, accepting reduced gravimetric capacity and verifying stability and safety.

## Evidence

> Micropores of MOF-74(Mg) allow NaAlH4 to be in close contact with the pore walls; hence, the chemical environment of all of the pore walls can stabilize the final decomposition products... Infiltrated in MOF-74(Mg) 3 mol% Ti Ea 57.4 kJ·mol–1 vs bulk 118.1 kJ·mol–1. Highly reactive gaseous Ti(BH4)3 molecules at 298 K were infiltrated into UiO-66. The nanoconfined hydride was stabilized in the porous MOF up to 350 K under vacuum and reached approximately double gas density. After Ti(BH4)3 infiltration, the value of UiO-66 obtained by the BET method decreased from 1200 to 770 m2·g−1.

Evidence location: page 25 (Table 4) and surrounding text; page 25

## Links

- Source: [[sources/src_ff1b0c9d63]]