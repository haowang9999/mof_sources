---
title: "The distribution of pore apertures and largest channel sizes responds nonlinearly to linker function ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_a318a71841]
confidence: medium
---


# The distribution of pore apertures and largest channel sizes responds nonlinearly to linker function ...[TRUNCATED]... 

## Mechanism claim

The distribution of pore apertures and largest channel sizes responds nonlinearly to linker functionalization: most materials (except DB) show increased apertures/volumes, BPY shows a pronounced increase, and DP/DE exhibit bimodal aperture distributions due to two distinct pores.

## Applicability

- Task: `pld`
- Mechanism type: `dynamic conformational effects producing non-linear PSD responses to functionalization`
- Condition scope: `{"gas": "general (PSD measured with inert probe in simulations)", "temperature_K": 298, "pressure_bar": null, "material_family": "Zn2(fu-bdc)2bipy series", "method": "molecular dynamics simulations / dynamic PSD analysis"}`

## Positive design features

- BPY shows pronounced increase in aperture/volume
- DP and DE exhibit bimodal pore diameter distributions

## Negative design features

- DB does not follow trend (not guest-accessible under same conditions)

## Agent design implication

Expect non-linear and structure-specific changes in accessible pore sizes when varying linker side-chain length/type; some functionalizations (e.g., BPY) may dramatically increase apparent aperture/volume, while others (DB) may block pores unless compensated by host–guest interactions.

## Evidence

> "Notably, the distribution of the pore aperture and the largest channel size behave in a nonlinear fashion. While all apertures and volumes (excluding DB) increase, this is significantly more pronounced for BPY. In DP and DE, two distinct pores in the framework produce a bimodal distribution of pore diameters..."

Evidence location: PAGE 3 (Results and Discussion)

## Links

- Source: [[sources/src_a318a71841]]