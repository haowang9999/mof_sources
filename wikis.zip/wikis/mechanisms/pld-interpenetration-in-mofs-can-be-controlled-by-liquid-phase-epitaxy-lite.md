---
title: "Interpenetration in MOFs can be controlled by liquid-phase epitaxy (literature example)."
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_3b254ae858]
confidence: medium
---


# Interpenetration in MOFs can be controlled by liquid-phase epitaxy (literature example).

## Mechanism claim

Interpenetration in MOFs can be controlled by liquid-phase epitaxy (literature example).

## Applicability

- Task: `pld`
- Mechanism type: `synthetic method → topology control`
- Condition scope: `{"gas": "", "temperature_K": null, "pressure_bar": null, "material_family": "metal-organic frameworks (example: film growth by liquid-phase epitaxy)", "method": "liquid-phase epitaxy (experimental film growth method, cited study)"}`

## Positive design features

- liquid-phase epitaxy as an approach to control interpenetration (reported in cited work)

## Negative design features

- applicability to bulk powders or all topologies is not specified in the citation

## Agent design implication

Use liquid-phase epitaxy when synthesis workflow permits (e.g., film growth) to achieve controlled interpenetration states and tailor pore architecture.

## Evidence

> "Controlling interpenetration in metal−organic frameworks by liquid-phase epitaxy." (Shekhah, O.; Wang, H.; Paradinas, M.; Ocal, C.; Schüpbach, B.; Terfort, A.; Zacher, D.; Fischer, R. A.; Wöll, C. Nat. Mater. 2009, 8, 481−484.)

Evidence location: references (15), pages 6669-6670

## Links

- Source: [[sources/src_3b254ae858]]