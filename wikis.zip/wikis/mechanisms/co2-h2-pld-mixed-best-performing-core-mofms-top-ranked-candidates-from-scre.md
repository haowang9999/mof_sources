---
title: "Best-performing CoRE-MOFMs (top-ranked candidates from screening) are concentrated at PLD = 2.5–3.5  ...[TRUNCATED]... "
type: mechanism
tags: [co2|h2|pld|mixed, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_90953381a0]
confidence: high
---


# Best-performing CoRE-MOFMs (top-ranked candidates from screening) are concentrated at PLD = 2.5–3.5  ...[TRUNCATED]... 

## Mechanism claim

Best-performing CoRE-MOFMs (top-ranked candidates from screening) are concentrated at PLD = 2.5–3.5 Å (≈80% of top candidates), porosity ϕ = 0.1–0.3 (≈63.3%), and LCD = 3.3–5.0 Å (≈63.3%), indicating narrow pores and modest porosity favor separation performance across many gas pairs in this computational ranking.

## Applicability

- Task: `co2|h2|pld|mixed`
- Mechanism type: `empirical selection bias from top-ranked computational candidates`
- Condition scope: `{"gas": "various binary mixtures (15 mixtures studied, including CO2- and H2-containing pairs)", "temperature_K": null, "pressure_bar": null, "material_family": "CoRE-MOFMs / CoRE‑MOF membranes", "method": "high-throughput computational screening followed by benchmark filtering"}`

## Positive design features

- Top candidates clustered at PLD 2.5–3.5 Å and moderate porosity

## Negative design features

- Not specified

## Agent design implication

When selecting or synthesizing MOF membranes for mixed-gas separations (including CO2 and H2 pairs), focus initial candidates on PLD ≈ 2.5–3.5 Å, porosity 0.1–0.3, and LCD ≈ 3.3–5.0 Å to increase likelihood of good permselectivity/permeability tradeoffs (recognizing dataset and ranking caveats).

## Evidence

> "Table 2 shows that the PLD was concentrated between 2.5–3.5 Å (80.0%)... indicating that ϕ also was a relatively important factor... there was a relatively comprehensive separation effect at smaller apertures when the LCD was between 3.3–5.0 Å (63.3%)."

Evidence location: pages 9-10

## Links

- Source: [[sources/src_90953381a0]]