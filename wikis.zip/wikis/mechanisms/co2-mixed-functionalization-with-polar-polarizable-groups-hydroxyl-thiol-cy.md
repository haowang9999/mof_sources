---
title: "Functionalization with polar/polarizable groups (hydroxyl, thiol, cyano, amino, nitro and related mo ...[TRUNCATED]... "
type: mechanism
tags: [co2|mixed, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_c42cf01235]
confidence: medium
---


# Functionalization with polar/polarizable groups (hydroxyl, thiol, cyano, amino, nitro and related mo ...[TRUNCATED]... 

## Mechanism claim

Functionalization with polar/polarizable groups (hydroxyl, thiol, cyano, amino, nitro and related motifs) often improves CO2 capture metrics of parent MOFs, but the efficacy strongly depends on pore topology and on any geometry changes induced by the functionalization.

## Applicability

- Task: `co2|mixed`
- Mechanism type: `functional group chemistry modifying adsorption affinity/selectivity (electrostatics-driven)`
- Condition scope: `{"gas": "CO2 (pure and mixture contexts evaluated in study)", "temperature_K": 313, "pressure_bar": null, "material_family": "computationally generated MOFs (multiple topologies × functionalized linkers; parent MOFs and derivatives)", "method": "DFT + GCMC + ML (simulation-driven analysis)"}`

## Positive design features

- hydroxyl (OH)
- thiol (SH)
- cyano (CN)
- amino (NH2, including -(NH2)2 motifs)
- nitro (NO2)

## Negative design features

- nonpolar or bulky modifications (e.g., -CH3, -CF3) and some halogenations often fail to improve or reduce gravimetric loading
- benefit can be negated if functionalization reduces pore aperture or alters topology

## Agent design implication

Consider polar/polarizable functional groups to enhance CO2 affinity, but evaluate each functionalization in the context of the specific pore topology and verify that pore metrics are not adversely changed.

## Evidence

> “Functionalization with hydroxyl, thiol, cyano, amino, or nitro chemistries was found to often improve CO2 capture metrics of the parent MOFs, but the efficacy of this strategy depended strongly on the pore topology.” || "functionalization of the parent MOF with -(OH)2, -(SH)2, -(NH2)2, -(CN)X, or -(NO2)2 significantly enhanced the CO2 loading of the original structure, whereas functionalization with -(CH)3, -(F)X, -(CF)3, -(Br)X either barely improved or notably reduced the CO2 loading."

Evidence location: page 1 (Abstract); page 5

## Links

- Source: [[sources/src_c42cf01235]]