---
title: "Algorithms and tools exist for high-throughput geometry-based analysis of crystalline porous materia ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_3b254ae858]
confidence: high
---


# Algorithms and tools exist for high-throughput geometry-based analysis of crystalline porous materia ...[TRUNCATED]... 

## Mechanism claim

Algorithms and tools exist for high-throughput geometry-based analysis of crystalline porous materials (e.g., Zeo++), enabling computation of pore geometry descriptors.

## Applicability

- Task: `pld`
- Mechanism type: `computational → pore characterization`
- Condition scope: `{"gas": "", "temperature_K": null, "pressure_bar": null, "material_family": "crystalline porous materials (MOFs, zeolites, COFs)", "method": "simulation / computational analysis (geometry-based)"}`

## Positive design features

- availability of computational geometry tools to analyze PLD, pore volume, surface area (established literature/tooling)

## Negative design features

- this reference is to tools/descriptions; specific computed values are not provided in the reference itself

## Agent design implication

Use geometry-based high-throughput tools (e.g., Zeo++) to compute pore-limiting diameters, accessible surface areas, and pore volumes as part of PLD-led design and screening workflows.

## Evidence

> "Algorithms and tools for high-throughput geometry-based analysis of crystalline porous materials." (Willems, T. F.; Rycroft, C. H.; Kazi, M.; Meza, J. C.; Haranczyk, M. Microporous Mesoporous Mater. 2012, 149, 134−141.)

Evidence location: references (42), page 6670

## Links

- Source: [[sources/src_3b254ae858]]