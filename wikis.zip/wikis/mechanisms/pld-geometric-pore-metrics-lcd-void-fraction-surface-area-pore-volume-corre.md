---
title: "Geometric pore metrics (LCD, void fraction, surface area, pore volume) correlate with I2 and CH3I up ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_fc58db74fa]
confidence: medium
---


# Geometric pore metrics (LCD, void fraction, surface area, pore volume) correlate with I2 and CH3I up ...[TRUNCATED]... 

## Mechanism claim

Geometric pore metrics (LCD, void fraction, surface area, pore volume) correlate with I2 and CH3I uptake across the screened MOFs; empirically identified optimal ranges for higher uptake were LCD ≈ 7.1 Å, void fraction 0.3–0.7, surface area 450–2230 m2/g, and pore volume 0.2–0.9 cm3/g.

## Applicability

- Task: `pld`
- Mechanism type: `structure–property correlation (pore-metric tuning)`
- Condition scope: `{"gas": "I2 and CH3I (mixed humid stream)", "temperature_K": 423, "pressure_bar": 1, "material_family": "MOFs (screened set of chemically stable MOFs)", "method": "GCMC simulation and pore-metric analysis (Zeo++)"}`

## Positive design features

- LCD around ~7.1 Å
- void fraction in 0.3–0.7
- surface area in 450–2230 m2/g
- pore volume in 0.2–0.9 cm3/g

## Negative design features

- Not specified

## Agent design implication

Target MOFs with LCD ≈ 7 Å, moderate void fraction (0.3–0.7), and moderate-to-high surface area and pore volume within the stated ranges to maximize I2/CH3I uptake under the simulated humid conditions, while also checking hydrophilicity (see separate rule).

## Evidence

> “For I2 and CH3I adsorption, Figures 1A and 1B showed that the optimal LCD and void fraction were around 7.1 Å and at the range of 0.3–0.7, respectively; Figures 1C and 1D indicated that the optimal surface area and pore volume were at the range of 450–2230 m2/g and 0.2–0.9 cm3/g, respectively.”

Evidence location: page 4

## Links

- Source: [[sources/src_fc58db74fa]]