---
title: "The soc-MOF's highly ionic (charged) framework, open indium coordination sites, and narrow pores (~1 ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_532b708453]
confidence: high
---


# The soc-MOF's highly ionic (charged) framework, open indium coordination sites, and narrow pores (~1 ...[TRUNCATED]... 

## Mechanism claim

The soc-MOF's highly ionic (charged) framework, open indium coordination sites, and narrow pores (~1 nm channels) enhance polarization interactions and are responsible for relatively strong hydrogen interactions and large uptake.

## Applicability

- Task: `h2`
- Mechanism type: `structure-property linkage (charged framework & pore size → polarization enhancement)`
- Condition scope: `{"gas": "H2", "temperature_K": 78, "pressure_bar": 1.0, "material_family": "soc-MOF (ionic framework, ~1 nm narrow channels, exposed In SBUs)", "method": "experiment + simulation (paper links experimental uptake to simulated mechanisms)"}`

## Positive design features

- charged lattice
- open metal coordination sites (indium SBUs)
- narrow channels/windows (azobenzene linker windows)
- many relatively small channels and high extraframework surface area

## Negative design features

- Not specified

## Agent design implication

To increase physisorptive H2 uptake at cryogenic conditions, target charged/ionic frameworks with narrow pores and exposed metal sites to amplify many-body polarization interactions.

## Evidence

> The MOF is remarkable because at 78 K and 1.0 atm it sorbs hydrogen at a density near that of liquid hydrogen... Unlike most other MOFs that have been investigated for hydrogen storage, it has a highly ionic framework and many relatively small channels. The simulations demonstrate that it is both of these physical characteristics that lead to relatively strong hydrogen interactions in the MOF and ultimately large hydrogen uptake. ... The low dipolar population is associated with the electric field of the positively charged and highly polarizable indium ions of the SBU.

Evidence location: pages 1-2, page 7 (Figures and discussion)

## Links

- Source: [[sources/src_532b708453]]