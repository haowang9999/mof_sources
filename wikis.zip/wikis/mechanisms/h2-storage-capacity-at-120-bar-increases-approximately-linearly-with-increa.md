---
title: "Storage capacity at 120 bar increases approximately linearly with increasing low-loading isosteric h ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_8d4a290e19]
confidence: high
---


# Storage capacity at 120 bar increases approximately linearly with increasing low-loading isosteric h ...[TRUNCATED]... 

## Mechanism claim

Storage capacity at 120 bar increases approximately linearly with increasing low-loading isosteric heat of adsorption (Qst) in the simulated MOFs.

## Applicability

- Task: `h2`
- Mechanism type: `adsorption capacity vs interaction strength`
- Condition scope: `{"gas": "H2", "temperature_K": 298, "pressure_bar": 120, "material_family": "same eight MOFs", "method": "simulation"}`

## Positive design features

- Higher Qst yields higher absolute storage capacity at high pressure

## Negative design features

- Not specified

## Agent design implication

Increasing adsorbate–framework interaction strength (Qst) will raise high-pressure storage capacity, but the effect on deliverable capacity must be assessed separately.

## Evidence

> "As Qost increases, the storage capacity of each MOF increases linearly. This indicates that it is possible for all MOF structures to attain the DOE targets if Qost is increased enough without loss in free volume."

Evidence location: page 2 (Results and discussion, description of Fig. 3a)

## Links

- Source: [[sources/src_8d4a290e19]]