---
title: "CO2 preferentially binds in a 'sandwich-like' site between two facing NH2-bearing ligands in the one ...[TRUNCATED]... "
type: mechanism
tags: [co2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_83cde498f9]
confidence: high
---


# CO2 preferentially binds in a 'sandwich-like' site between two facing NH2-bearing ligands in the one ...[TRUNCATED]... 

## Mechanism claim

CO2 preferentially binds in a 'sandwich-like' site between two facing NH2-bearing ligands in the one-dimensional channels of Cu(adci)-2, as predicted by Monte Carlo simulation and radial distribution analysis.

## Applicability

- Task: `co2`
- Mechanism type: `specific_adsorption_site (simulation-predicted)`
- Condition scope: `{"gas": "CO2", "temperature_K": 298, "pressure_bar": null, "material_family": "Cu(adci)-2", "method": "GCMC simulation + radial distribution function (RDF) analysis; MC-minimized binding-site geometry"}`

## Positive design features

- pair of NH2 groups facing each other on opposite sides of channel walls
- CO2 localizes between two ligands showing a sandwich-like configuration

## Negative design features

- prediction is derived from simulation and MC-minimized geometries (no single-crystal CO2-loaded structure reported in the chunks)

## Agent design implication

Place amine functional groups to face each other across a narrow channel so that CO2 can occupy a cooperative 'sandwich' site between two ligands, increasing binding without high chemisorption energy.

## Evidence

> Page 3 / pages 5-6: "the NH2 groups of the ligands face each other in the channel of Cu(adci)-2."; "In a Monte Carlo simulation and a radial distribution analysis, the preferential CO2 binding site of Cu(adci)-2 was predicted to be between two ligands, forming a sandwich-like structure..."; "Figure 3c shows a preferential CO2 binding site ... linear-shaped molecule lies in the middle of two ligands facing each other, with an orientation identical to that of the ligands. Consequently, the CO2 atoms are influenced by the two ligands almost equally, showing a sandwich-like configuration."

Evidence location: page 1 (Abstract); page 3 (structure description); pages 5-6 (simulation results, RDF and MC-minimized binding site descriptions)

## Links

- Source: [[sources/src_83cde498f9]]