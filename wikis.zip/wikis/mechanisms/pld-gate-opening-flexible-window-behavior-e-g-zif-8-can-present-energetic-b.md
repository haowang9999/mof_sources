---
title: "Gate-opening/flexible-window behavior (e.g., ZIF-8) can present energetic barriers to cisplatin diff ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_8ce39338bc]
confidence: medium
---


# Gate-opening/flexible-window behavior (e.g., ZIF-8) can present energetic barriers to cisplatin diff ...[TRUNCATED]... 

## Mechanism claim

Gate-opening/flexible-window behavior (e.g., ZIF-8) can present energetic barriers to cisplatin diffusion because nominal pore-window diameters (reported ~3.4 Å for ZIF-8; ZIF-11 reported ~3 Å in parts of the text) are small compared to the quoted cisplatin size (~5 Å), so diffusion requires ligand rotation / gate opening and incurs an energetic cost.

## Applicability

- Task: `pld`
- Mechanism type: `gate-opening / flexible-window diffusion hindrance`
- Condition scope: `{"gas": "", "temperature_K": null, "pressure_bar": null, "material_family": "ZIF-8, ZIF-11 (sodalite and kno channel topologies referenced)", "method": "structural analysis and SMD/umbrella sampling context"}`

## Positive design features

- Not specified

## Negative design features

- pore window diameters comparable to or smaller than guest size lead to hindered diffusion and require gate-opening

## Agent design implication

For flexible-window ZIFs anticipate gate-opening barriers for large drug molecules; consider larger-window frameworks, functionalization to create adsorption hotspots, or in situ encapsulation strategies.

## Evidence

> The pore window diameter of ZIF-8 (∼3.4 Å) is comparable to the size of cisplatin (∼5 Å); thus, CPT diffusion will be substantially hindered by gate-opening energetic barriers. The largest pore-window size in ZIF-11 is reported as ∼3 Å and ligand rotation can provide an example of diffusion hindrance due to framework displacement.

Evidence location: page 3-4; pages 12-13

## Links

- Source: [[sources/src_8ce39338bc]]