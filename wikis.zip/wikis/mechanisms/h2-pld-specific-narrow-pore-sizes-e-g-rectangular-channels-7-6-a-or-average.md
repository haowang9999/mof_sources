---
title: "Specific narrow pore sizes (e.g., rectangular channels ~7 × 6 Å or average pore diameters ~4.5 Å) co ...[TRUNCATED]... "
type: mechanism
tags: [h2|pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_ff1b0c9d63]
confidence: medium
---


# Specific narrow pore sizes (e.g., rectangular channels ~7 × 6 Å or average pore diameters ~4.5 Å) co ...[TRUNCATED]... 

## Mechanism claim

Specific narrow pore sizes (e.g., rectangular channels ~7 × 6 Å or average pore diameters ~4.5 Å) correlate with significant H2 uptake even when BET area is modest, indicating pore size can dominate uptake.

## Applicability

- Task: `h2|pld`
- Mechanism type: `size-dependent physisorption / confinement effect`
- Condition scope: `{"gas": "H2", "temperature_K": null, "pressure_bar": null, "material_family": "selected MOF examples with narrow channels", "method": "experiment"}`

## Positive design features

- narrow channels ~7 × 6 Å
- average pore diameter ~4.5 Å correlated with uptake

## Negative design features

- Not specified

## Agent design implication

When targeting H2 uptake, prioritize tuning pore apertures/channels to the ~4–7 Å range; high BET area alone may not substitute for optimal pore diameter.

## Evidence

> These two frameworks had nonlinear rectangular channels with an average size of 7 × 6 Å. ... another framework ... demonstrated 0.89 wt% of H2 at 298 K and P(H2) = 17.2 bar, which was explained by both the As value (1502 m2·g−1) and the average pore diameter (4.5 Å). ... these examples indicate that, even with a small As value, hydrogen adsorption can be significant and, most importantly, controlled by pore size (5–7 Å).

Evidence location: page 22, Section 4.3.2

## Links

- Source: [[sources/src_ff1b0c9d63]]