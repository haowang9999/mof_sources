---
title: "MIL-53-Al exhibits breathing/flexible pore phases; the high-temperature form (MIL-53-Al-ht) was used ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_fc58db74fa]
confidence: high
---


# MIL-53-Al exhibits breathing/flexible pore phases; the high-temperature form (MIL-53-Al-ht) was used ...[TRUNCATED]... 

## Mechanism claim

MIL-53-Al exhibits breathing/flexible pore phases; the high-temperature form (MIL-53-Al-ht) was used to represent 423 K screening conditions.

## Applicability

- Task: `pld`
- Mechanism type: `structural flexibility affecting pore size (breathing)`
- Condition scope: `{"gas": "general", "temperature_K": 423, "pressure_bar": null, "material_family": "MIL-53-Al", "method": "selection of structural phase for simulation"}`

## Positive design features

- breathing/tunable pore size (MIL-53-Al)

## Negative design features

- large changes in pore size require careful phase selection

## Agent design implication

For breathing MOFs (e.g., MIL-53-Al), select the structural phase that corresponds to the operating temperature (here MIL-53-Al-ht for 423 K) when predicting adsorption — failure to do so may misrepresent the effective PLD and adsorption behavior.

## Evidence

> “Considering the well-known breathing effect of MIL-53-Al, whose pore size was tunable and could undergo great changes, the high temperature form of MIL-53-Al (MIL-53-Al-ht) was used to conform to the high temperature environment of 423 K.”

Evidence location: STAR+METHODS, METHOD DETAILS (page ~11)

## Links

- Source: [[sources/src_fc58db74fa]]