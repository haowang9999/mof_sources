---
title: "BET surface area analysis (commonly from N2 isotherms at 77 K) can be inaccurate for supermicroporou ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_ff1b0c9d63]
confidence: high
---


# BET surface area analysis (commonly from N2 isotherms at 77 K) can be inaccurate for supermicroporou ...[TRUNCATED]... 

## Mechanism claim

BET surface area analysis (commonly from N2 isotherms at 77 K) can be inaccurate for supermicroporous and ultramicroporous MOFs unless the BET fit is carefully limited and validated (apply Llewellyn criteria: linear n(1−p/p0), positive C≥10, nm within linear region).

## Applicability

- Task: `pld`
- Mechanism type: `measurement / analysis limitation`
- Condition scope: `{"gas": "N2 (probe gas) / general approach", "temperature_K": 77, "pressure_bar": null, "material_family": "MOFs (supermicroporous, ultramicroporous)", "method": "experimental analysis / review"}`

## Positive design features

- BET useful when applied correctly

## Negative design features

- standard BET ranges (0.05–0.3 p/p0) are not generally valid for microporous MOFs
- surface tension effects and framework deformation can affect results

## Agent design implication

When characterizing MOF surface area, apply the Llewellyn criteria for BET range selection and consider alternative probe gases or complementary methods; interpret BET areas for microporous MOFs with caution.

## Evidence

> In the case of supermicroporous MOFs and ultramicroporous materials ... the BET calculation on the surface area is inaccurate. In 2007, Llewellyn et al. recommended consistent criteria... (1) the BET approach should be limited to the range in which the term n(1 −p/po) increases continuously ... (2) C... should be positive with a value of at least 10; and (3) the nm value corresponds to a certain value of p/po ... I. Senkovska and S. Kaskel concluded that strong surface tension effects during subcritical adsorption can cause deformation of adsorbent structure ... the BET equation to determine the surface area of MOFs should be adapted to a specific situation.

Evidence location: Section 2.2 Surface Area (page 3)

## Links

- Source: [[sources/src_ff1b0c9d63]]