---
title: "Two dominating factors determine gating properties in this rigid honeycomb MOF family: (1) adsorptio ...[TRUNCATED]... "
type: mechanism
tags: [mixed, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_a318a71841]
confidence: high
---


# Two dominating factors determine gating properties in this rigid honeycomb MOF family: (1) adsorptio ...[TRUNCATED]... 

## Mechanism claim

Two dominating factors determine gating properties in this rigid honeycomb MOF family: (1) adsorption site accessibility (steric/pore-aperture control) and (2) functionalization polarizability (electronic interactions). Both are tunable through linker side-chain functionalization.

## Applicability

- Task: `mixed`
- Mechanism type: `combined steric and electronic control of adsorptive gating`
- Condition scope: `{"gas": "C2H2 and CO2 (study case)", "temperature_K": null, "pressure_bar": null, "material_family": "rigid honeycomb-like MOF series (isoreticular derivatives with varied side chains)", "method": "experiment and simulation (correlation of sorption metrics with linker functionalization)"}`

## Positive design features

- increased polarizability at linker sites
- increased sorption site accessibility via linker design

## Negative design features

- reduced sorption site accessibility due to blocking side chains

## Agent design implication

Tune linker substituents to adjust local polarizability and to control sorption-site accessibility; use these knobs to shift gating pressures and relative adsorption strength between gases.

## Evidence

> "Two dominating factors that determine gating properties are identified: polarizability and sorption site accessibility. These factors are accessible through linker functionalization..."

Evidence location: PAGE 1 (Abstract); page 8 (Conclusions)

## Links

- Source: [[sources/src_a318a71841]]