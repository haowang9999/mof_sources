---
title: "Partial substitution of Zr by Ti in UiO-66 reduced crystallite size, increased adsorption enthalpies ...[TRUNCATED]... "
type: mechanism
tags: [co2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_a034d4944a]
confidence: medium
---


# Partial substitution of Zr by Ti in UiO-66 reduced crystallite size, increased adsorption enthalpies ...[TRUNCATED]... 

## Mechanism claim

Partial substitution of Zr by Ti in UiO-66 reduced crystallite size, increased adsorption enthalpies, and increased CO2 uptake at 273 K (reported values: UiO-66(Zr100) 2.2 mmol g-1; UiO-66(Ti32) 2.3 mmol g-1; UiO-66(Ti56) 4 mmol g-1 at 273 K).

## Applicability

- Task: `co2`
- Mechanism type: `node-substitution effect on adsorption enthalpy and capacity`
- Condition scope: `{"gas": "CO2", "temperature_K": 273, "pressure_bar": null, "material_family": "UiO-66 derivatives with partial Ti substitution", "method": "experimental (reported within review)"}`

## Positive design features

- Ti substitution at metal node
- smaller crystallite size
- higher adsorption enthalpy

## Negative design features

- Not specified

## Agent design implication

Consider partial substitution of metal nodes (e.g., Ti for Zr in UiO-66) to increase CO2 adsorption enthalpy and capacity under relevant temperatures (~273 K).

## Evidence

> Hill et al found that by substituting Ti for Zr in UiO-66, they were able to synthesis bimetallic UiO-66 which was characterized by the smaller crystallite size and greater adsorption enthalpies, resulting in improved CO2 uptake. ... UiO-66(Zr100), UiO-66(Ti32), and UiO-66(Ti56) absorb CO2 at 273 K was 2.2, 2.3, and 4 mmol g-1, respectively. (page 7)

Evidence location: page 7

## Links

- Source: [[sources/src_a034d4944a]]