---
title: "Henry's constants for spherical, nonpolar adsorbates can be efficiently calculated by summing exp(-β ...[TRUNCATED]... "
type: mechanism
tags: [h2|co2|pld|mixed, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_97052fb350]
confidence: high
---


# Henry's constants for spherical, nonpolar adsorbates can be efficiently calculated by summing exp(-β ...[TRUNCATED]... 

## Mechanism claim

Henry's constants for spherical, nonpolar adsorbates can be efficiently calculated by summing exp(-βUads) over grid points in a unit cell (considering points where maximum hard-sphere diameter exceeds threshold); this was applied to CH4 and H2 using united-atom Lennard-Jones models, avoiding per-MOF charge assignment.

## Applicability

- Task: `h2|co2|pld|mixed`
- Mechanism type: `adsorption affinity calculation (Henry's law regime)`
- Condition scope: `{"gas": "CH4, H2 (nonpolar spherical adsorbates)", "temperature_K": null, "pressure_bar": "low (Henry's regime)", "material_family": "MOFs", "method": "simulation (grid-summed exp(-βU) with LJ potentials)"}`

## Positive design features

- rapid evaluation across many structures
- does not require per-MOF charge assignment when applied to nonpolar adsorbates

## Negative design features

- limited to nonpolar spherical adsorbates (avoids polar/quadrupolar species and framework charges)
- assumes rigid framework and low loading

## Agent design implication

For screening nonpolar gases like H2 and CH4 under low-pressure conditions, compute KH via grid-summed exp(-βU) using LJ potentials to rank MOF adsorption affinities quickly; do not rely on this approach for polar adsorbates without adding electrostatics.

## Evidence

> The Henry’s constant was calculated for CH4 and H2 for all the examined structures using a united atom model for both adsorbates with Lennard-Jones parameters... We evaluate the summation that defines the Henry’s constant over the grid points for which the maximum hard sphere diameter is > 1.5 Å.

Evidence location: page 4, section 2.2

## Links

- Source: [[sources/src_97052fb350]]