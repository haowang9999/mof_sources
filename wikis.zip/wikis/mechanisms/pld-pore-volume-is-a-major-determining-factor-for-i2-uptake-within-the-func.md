---
title: "Pore volume is a major determining factor for I2 uptake within the functionalized MIL-53-Al (MIL-53- ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_fc58db74fa]
confidence: high
---


# Pore volume is a major determining factor for I2 uptake within the functionalized MIL-53-Al (MIL-53- ...[TRUNCATED]... 

## Mechanism claim

Pore volume is a major determining factor for I2 uptake within the functionalized MIL-53-Al (MIL-53-Al-X) series; moderate changes in isosteric heat of I2 (Qst) influenced selectivity but had a relatively minor effect on absolute I2 uptake compared with pore-volume/steric effects.

## Applicability

- Task: `pld`
- Mechanism type: `structural (pore-volume dependence / steric limitation)`
- Condition scope: `{"gas": "I2 (competitive, humid environment with H2O, N2, O2, CH3I)", "temperature_K": 423, "pressure_bar": 1, "material_family": "functionalized MIL-53-Al (MIL-53-Al-X) series", "method": "GCMC and DFT simulations (MIL-53-Al-X analysis)"}`

## Positive design features

- larger pore volume (example range 0.37–0.62 cm3/g in the series) correlates with higher I2 uptake

## Negative design features

- smaller pore volume and increased steric hindrance limit I2 uptake (examples: MIL-53-Al-Cl Vp=0.463 cm3/g and MIL-53-Al-Br Vp=0.369 cm3/g with lower I2 uptake)

## Agent design implication

For high I2 uptake in MIL-53-Al-type materials under humid competitive conditions, prioritize preserving or increasing pore volume when functionalizing because pore-volume/steric constraints can dominate over modest increases in binding energy.

## Evidence

> “Figure 4A illustrated that the pore volumes (0.37–0.62 cm3/g) were a major determining factor, whereas the Qst of I2 (59.4–71.9 kJ/mol) played a relatively minor role in influencing I2 uptake. For instance, MIL-53-Al-Cl and MIL-53-Al-Br ... their small pore volumes (0.463 cm3/g and 0.369 cm3/g) resulted in the lower I2 adsorption amounts of 44.96 cm3/g and 36.72 cm3/g, respectively. Conversely, MIL-53-Al-NH2 and MIL-53-Al-CH3 with relatively large pore volumes (0.509 cm3/g and 0.470 cm3/g) exhibited the top-two I2 uptake amounts of 50.65 cm3/g and 49.74 cm3/g, respectively.”

Evidence location: pages 6-7

## Links

- Source: [[sources/src_fc58db74fa]]