---
title: "Magnitude of functionalization effects observed: 'good' functionalization can increase CO2 loading o ...[TRUNCATED]... "
type: mechanism
tags: [co2|h2|mixed, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_c42cf01235]
confidence: high
---


# Magnitude of functionalization effects observed: 'good' functionalization can increase CO2 loading o ...[TRUNCATED]... 

## Mechanism claim

Magnitude of functionalization effects observed: 'good' functionalization can increase CO2 loading of the parent MOF by up to ∼1 mol/kg (CO2:N2 case) and ∼4 mol/kg (CO2:H2 case); 'bad' functionalization can decrease loadings by up to ∼0.8 mol/kg and ∼6 mol/kg respectively. CO2 selectivity improvements reached up to ∼6 units (CO2:N2) and ∼200 units (CO2:H2).

## Applicability

- Task: `co2|h2|mixed`
- Mechanism type: `quantitative impact of pore chemistry alteration`
- Condition scope: `{"gas": "CO2:N2 (15:85) at 1 bar; CO2:H2 (20:80) at 20 bar", "temperature_K": null, "pressure_bar": "1 (CO2:N2), 20 (CO2:H2)", "material_family": "31 parent MOFs functionalized (various topologies)", "method": "GCMC mixture adsorption simulations"}`

## Positive design features

- Not specified

## Negative design features

- Not specified

## Agent design implication

Expect functionalization to produce changes in loading/selectivity on the order reported; use these magnitudes when prioritizing synthetic efforts or setting targets for performance gains.

## Evidence

> “With 'good' functionalization, CO2 loadings ... can increase as much as ∼1 mol/kg and ∼4 mol/kg, respectively. However, with 'bad' functionalization, CO2 loadings can decrease as much as ∼0.8 mol/kg and ∼6 mol/kg, respectively. The selectivity for CO2 ... were improved up to ∼6 and ∼200 units for the adsorption of CO2:N2 and CO2:H2 mixtures, respectively."

Evidence location: page 5

## Links

- Source: [[sources/src_c42cf01235]]