---
title: "Conformationally flexible linker side chains fill pore volume and decrease the effective pore apertu ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_a318a71841]
confidence: high
---


# Conformationally flexible linker side chains fill pore volume and decrease the effective pore apertu ...[TRUNCATED]... 

## Mechanism claim

Conformationally flexible linker side chains fill pore volume and decrease the effective pore aperture, enabling steric gating (reduced limiting pore diameter).

## Applicability

- Task: `pld`
- Mechanism type: `steric gating / pore-aperture modulation`
- Condition scope: `{"gas": "general (probe used: inert spherical probe 1.3 Å for PSD in simulations)", "temperature_K": 298, "pressure_bar": null, "material_family": "Zn2(fu-bdc)2bipy isoreticular series (DE, DP, BA, BPY, DB) and related honeycomb-like zinc-dicarboxylate-bipyridine frameworks", "method": "molecular dynamics simulation (dynamic PSD) and experimental inference"}`

## Positive design features

- conformationally flexible side chains (linker functionalization)

## Negative design features

- reduced effective pore aperture (blocking by side chains)

## Agent design implication

Introduce conformationally flexible side chains to reduce limiting pore diameter and implement adsorptive gating via steric blockage; simulate dynamic PSDs at operating temperatures to estimate effects.

## Evidence

> "These side chains fill the pore volume and decrease the effective pore aperture."

Evidence location: PAGE 3 (Results and Discussion)

## Links

- Source: [[sources/src_a318a71841]]