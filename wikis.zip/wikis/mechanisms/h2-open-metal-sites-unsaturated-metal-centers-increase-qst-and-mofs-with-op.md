---
title: "Open metal sites (unsaturated metal centers) increase Qst and MOFs with open metal sites show higher ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_ff1b0c9d63]
confidence: high
---


# Open metal sites (unsaturated metal centers) increase Qst and MOFs with open metal sites show higher ...[TRUNCATED]... 

## Mechanism claim

Open metal sites (unsaturated metal centers) increase Qst and MOFs with open metal sites show higher H2 adsorption at 298 K than analogous MOFs without open sites; this effect is notable for some high-surface-area MOFs and specific SBU/linker metalation strategies.

## Applicability

- Task: `h2`
- Mechanism type: `specific adsorption site (open metal centers)`
- Condition scope: `{"gas": "H2", "temperature_K": 298, "pressure_bar": null, "material_family": "MOFs with open metal sites (SBUs, metalated linkers)", "method": "experiment"}`

## Positive design features

- higher Qst values
- higher measured H2 adsorption at 298 K

## Negative design features

- Not specified

## Agent design implication

Include open metal coordination sites (at SBUs or metalated linkers) to raise Qst and improve room-temperature H2 uptake, especially for high surface area MOFs.

## Evidence

> It was shown that metal centers unsaturated in coordination, often called “open” or “accessible” metal sites, may increase the Qst value. In practice, the H2 adsorption values measured at 298 K for MOFs with open metal sites are higher than those for MOFs without open metal sites. In addition, this tendency is pronounced for MOFs with a high As value (>3000 m2·g–1). Specific examples include desolvation-created Co2+ sites (SNU-15 → SNU-150′) yielding Qst ≈15 kJ·mol−1 at zero coverage, PCN-9 (Qst ≈10.1 kJ·mol−1), and Ni2(m-dobdc) showing strong polarizing open Ni2+ sites enabling high volumetric packing at 298 K.

Evidence location: pages 17-19; page 18 (SNU-15, PCN-9, Ni2(m-dobdc) examples)

## Links

- Source: [[sources/src_ff1b0c9d63]]