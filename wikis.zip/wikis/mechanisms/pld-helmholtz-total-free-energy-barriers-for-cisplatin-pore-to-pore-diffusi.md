---
title: "Helmholtz total free-energy barriers for cisplatin pore-to-pore diffusion in UiO-66 and UiO-66(NH2)  ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_8ce39338bc]
confidence: medium
---


# Helmholtz total free-energy barriers for cisplatin pore-to-pore diffusion in UiO-66 and UiO-66(NH2)  ...[TRUNCATED]... 

## Mechanism claim

Helmholtz total free-energy barriers for cisplatin pore-to-pore diffusion in UiO-66 and UiO-66(NH2) (umbrella sampling) are modest (~22 kJ/mol) and are dominated by bonded (framework deformation) energy contributions; nevertheless, bonded potential-energy contributions evaluated via SMD show large numerical differences influenced by functionalization (SMD bonded barriers reported as ~406 kJ/mol for UiO-66 vs ~184 kJ/mol for UiO-66(NH2)).

## Applicability

- Task: `pld`
- Mechanism type: `bonded energy-dominated barrier and functionalization effect`
- Condition scope: `{"gas": "", "temperature_K": 298, "pressure_bar": null, "material_family": "UiO-66 and UiO-66(NH2)", "method": "umbrella sampling (Helmholtz ΔA) and SMD bonded/non-bonded breakdown; GASP/ab initio comparisons"}`

## Positive design features

- bonded (framework deformation) contributions can dominate the free-energy barrier
- functionalization (e.g., -NH2) reduces bonded deformation energy cost compared to unfunctionalized linkers

## Negative design features

- high bonded energy costs (depending on metric) can make diffusion slow; reported numeric values differ by method (free energy vs potential energy decomposition)

## Agent design implication

Evaluate bonded deformation contributions and how functionalization alters them when engineering frameworks for controlled diffusion; polar/flexible linkers can lower bonded barriers but may also affect host–guest interactions.

## Evidence

> The calculated Helmholtz total free energy barriers are ΔAumbrella = 22 kJ/mol for UiO-66 and UiO-66(NH2), dominated by bonded energies. The SMD bonded potential energy barrier was higher in UiO-66 (ΔUbonded,SMD = 406 kJ/mol) compared to UiO-66(NH2) (ΔUbonded,SMD = 184 kJ/mol), consistent with polar functionalization lowering ligand-rotation barriers.

Evidence location: page 7

## Links

- Source: [[sources/src_8ce39338bc]]