---
title: "Cryogenic H2 adsorption (−196 °C, 77 K) at moderate pressures requires materials with very high acce ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_fa8cccd644]
confidence: high
---


# Cryogenic H2 adsorption (−196 °C, 77 K) at moderate pressures requires materials with very high acce ...[TRUNCATED]... 

## Mechanism claim

Cryogenic H2 adsorption (−196 °C, 77 K) at moderate pressures requires materials with very high accessible surface area, high micropore volume, a tuned pore size distribution, and sufficient bulk/particle density to be practically useful.

## Applicability

- Task: `h2`
- Mechanism type: `physisorption / materials requirement`
- Condition scope: `{"gas": "H2", "temperature_K": 77, "pressure_bar": null, "material_family": "MOFs, MOF hybrids, carbon-based materials", "method": "review / experimental literature"}`

## Positive design features

- high accessible surface area (ABET/SSA)
- high micropore volume
- tuned pore size distribution (narrow micropores beneficial)
- adequate bulk/particle density to preserve volumetric performance

## Negative design features

- Not specified

## Agent design implication

For cryo-adsorptive H2 storage design MOFs/MOF-hybrids to maximise accessible SSA and micropore volume while controlling PSD and preserving packing density; evaluate both gravimetric and volumetric uptake at target T/P.

## Evidence

> Adsorption of H2 at −196 °C ... enables H2 to be stored at moderate pressures, of the order of 5 MPa, but requires high-surface area materials with a suitable pore size distribution (PSD) and high bulk density. || "In general, micropore volume is directly related to the surface area of a material. Consequently, to enhance H2 adsorption capacity at −196 °C, it is necessary to increase both specific surface area (SSA) and micropore volume within the MOF."

Evidence location: page 1 (Introduction) || pages 5–6, section 3.1

## Links

- Source: [[sources/src_fa8cccd644]]