---
title: "Thermal conductivity of MOFs is generally low (<2 W m−1 K−1) due to high porosity and low density; t ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_fa8cccd644]
confidence: medium-high
---


# Thermal conductivity of MOFs is generally low (<2 W m−1 K−1) due to high porosity and low density; t ...[TRUNCATED]... 

## Mechanism claim

Thermal conductivity of MOFs is generally low (<2 W m−1 K−1) due to high porosity and low density; thermal conductivity increases with higher density (>1.0 g cm−3), smaller pores (<1 nm) and four-connected metal nodes, and poor heat dissipation can limit effective uptake during fast, exothermic filling.

## Applicability

- Task: `h2`
- Mechanism type: `material thermal transport → impact on adsorption heat dissipation and performance`
- Condition scope: `{"gas": "H2 (adsorptive storage)", "temperature_K": null, "pressure_bar": null, "material_family": "MOFs (general) and MOF monoliths/hybrids", "method": "review / experimental reports"}`

## Positive design features

- higher density/smaller pores/four-connected nodes improve thermal conductivity
- conductive fillers/graphite increase thermal transport in monoliths

## Negative design features

- low thermal conductivity can create hot spots and reduce uptake during fast filling

## Agent design implication

For fast filling or cyclic operation, prefer MOFs or hybrids with higher thermal conductivity (denser frameworks, small pores, structural motifs) or add conductive fillers (graphite flakes, carbon) while monitoring porosity trade-offs.

## Evidence

> Islamov et al. reported MOFs exhibit enhanced thermal conductivity when they have high densities (>1.0 g cm−3), small pores (<1 nm) and four-connected metal nodes. The highly porous nature and low density of MOFs prevent efficient phonon transport and result in low thermal conductivities (<2 W m−1 K−1). || Example: HKUST-1@graphite flake hybrid increased thermal conductivity (hybrid monolith 3.15 W m−1 K−1 vs pure 0.49 W m−1 K−1) and improved H2 uptake.

Evidence location: page 8 (section 3.4 Thermal conductivity) || page 14-15

## Links

- Source: [[sources/src_fa8cccd644]]