---
title: "Linker functionalization can change pore sizes and sometimes topology (e.g., PLD/LPD and void fracti ...[TRUNCATED]... "
type: mechanism
tags: [pld|co2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_c42cf01235]
confidence: high
---


# Linker functionalization can change pore sizes and sometimes topology (e.g., PLD/LPD and void fracti ...[TRUNCATED]... 

## Mechanism claim

Linker functionalization can change pore sizes and sometimes topology (e.g., PLD/LPD and void fraction), which directly affects CO2 sorption and can confound attempts to isolate pure chemical effects.

## Applicability

- Task: `pld|co2`
- Mechanism type: `geometric/pore-aperture influence on adsorption and topology coupling`
- Condition scope: `{"gas": "CO2", "temperature_K": null, "pressure_bar": null, "material_family": "MOFs (linker functionalization may change pore geometry/topology)", "method": "discussion / computational observation"}`

## Positive design features

- functional groups that add favorable chemistry without significantly reducing pore aperture

## Negative design features

- functionalization that reduces pore size or changes topology can counteract intended increases in CO2 uptake

## Agent design implication

When functionalizing linkers, recompute PLD/LPD, surface area and void fraction (e.g., Zeo++) and simulate adsorption to confirm net effect of chemistry versus geometry changes.

## Evidence

> “Another difficulty faced by experiments to isolate the role of functionalization is that the latter can alter variables such as pore size, which, in turn, also impact CO2 sorption.” || "Largest and limiting pore diameters (LPD and PLD, respectively) were calculated using Zeo++."

Evidence location: page 2 (Introduction); computational methods sections (Zeo++ usage)

## Links

- Source: [[sources/src_c42cf01235]]