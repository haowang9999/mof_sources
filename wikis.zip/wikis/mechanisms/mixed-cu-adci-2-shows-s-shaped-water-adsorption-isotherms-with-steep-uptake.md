---
title: "Cu(adci)-2 shows S-shaped water adsorption isotherms with steep uptake at P/P0 ≈ 0.35–0.40 (indicati ...[TRUNCATED]... "
type: mechanism
tags: [mixed, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_83cde498f9]
confidence: medium
---


# Cu(adci)-2 shows S-shaped water adsorption isotherms with steep uptake at P/P0 ≈ 0.35–0.40 (indicati ...[TRUNCATED]... 

## Mechanism claim

Cu(adci)-2 shows S-shaped water adsorption isotherms with steep uptake at P/P0 ≈ 0.35–0.40 (indicating relative hydrophobicity compared to some water adsorbents) and retains CO2 capture performance under moderate humidity (60% RH breakthrough), but prolonged or severe humidity (80% RH for 1 week) or liquid water exposure (1 day) degrade porosity and reduce CO2 capacity.

## Applicability

- Task: `mixed`
- Mechanism type: `hydrophobicity_vs_stability (humidity effects on adsorption)`
- Condition scope: `{"gas": "H2O vapor (and impact on CO2 adsorption)", "temperature_K": 298, "pressure_bar": null, "material_family": "Cu(adci)-2", "method": "experiment (water isotherms, PXRD, N2 sorption, CO2 isotherms, breakthrough tests)"}`

## Positive design features

- steep water uptake at P/P0 0.35–0.40 (S-shaped) -> more hydrophobic than SAPO-34, MOF-303, CAU-10
- breakthrough experiments show CO2 capture ability retained in presence of moisture (60% RH)

## Negative design features

- BET surface area and CO2 capacity drop after exposure to 80% RH for 1 week or to liquid water for 1 day
- less hydrolytically stable than some related MOFs (authors note irregular Cu(I) tetrahedral geometry may allow H2O access to metal atoms)

## Agent design implication

Aromatic amine ultramicroporous MOFs can tolerate moderate humidity for CO2 capture, but designs must guard against metal-site exposure or geometries that admit water; include long-term/high-RH exposure testing to define operational limits.

## Evidence

> Page 2: "The water adsorption of Cu(adci)-2 at 298 and 313 K is characterized by S-shaped isotherms with steep adsorption at P/P0 = 0.35−0.40..., implying that Cu(adci)-2 is hydrophobic compared to well-known water adsorbents..."; Page 1 (abstract): "breakthrough experiments under dry and 60% relative humidity conditions show that its CO2 capture ability is retained even in the presence of high amounts of moisture."; Page 3 / Page 5: "BET surface areas were ... 515, 300 ... after exposure to 80% relative humidity for 1 week, to liquid water for 1 day... Cu(adci)-2 exhibited good resistance to a moderate humidity condition... whereas it did not to a severe humidity condition and to liquid water..."; "The CO2 capacity at 298 K and 15 kPa was scarcely reduced after exposure to atmospheric conditions for one month or to liquid ethanol for 1 day..., although exposure to 80% RH for 1 week or to liquid water for 1 day reduced the CO2 capacity fairly well."

Evidence location: page 1 (abstract); page 2 (water isotherm); page 3 and page 5 (stability tests and post-exposure isotherms)

## Links

- Source: [[sources/src_83cde498f9]]