---
title: "Inconsistencies in adsorption properties and powder XRD data of MOF‑5 are rationalized by framework  ...[TRUNCATED]... "
type: mechanism
tags: [mixed, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_3b254ae858]
confidence: medium
---


# Inconsistencies in adsorption properties and powder XRD data of MOF‑5 are rationalized by framework  ...[TRUNCATED]... 

## Mechanism claim

Inconsistencies in adsorption properties and powder XRD data of MOF‑5 are rationalized by framework interpenetration and the presence of organic and inorganic species in the nanocavities (literature example).

## Applicability

- Task: `mixed`
- Mechanism type: `guest species/interpenetration → observed adsorption/XRD inconsistencies`
- Condition scope: `{"gas": "general adsorption measurements", "temperature_K": null, "pressure_bar": null, "material_family": "MOF-5 (Zn4O-based, cited study)", "method": "experimental analysis (cited literature)"}`

## Positive design features

- identifies interpenetration and confined species as explanatory factors for inconsistent adsorption/XRD

## Negative design features

- does not provide experimental thresholds or diagnostics in the title extract quoted here

## Agent design implication

When interpreting adsorption data or PXRD for MOF-5 (and related materials), explicitly check for framework interpenetration and occluded organic/inorganic species in cavities to avoid misinterpretation of porosity/adsorption metrics.

## Evidence

> "The inconsistency in adsorption properties and powder xrd data of MOF-5 is rationalized by framework interpenetration and the presence of organic and inorganic species in the nanocavities." (Hafizovic, J.; Bjørgen, M.; Olsbye, U.; Dietzel, P. D. C.; Bordiga, S.; Prestipino, C.; Lamberti, C.; Lillerud, K. P. J. Am. Chem. Soc. 2007, 129, 3612−3620.)

Evidence location: references (14), pages 6669-6670

## Links

- Source: [[sources/src_3b254ae858]]