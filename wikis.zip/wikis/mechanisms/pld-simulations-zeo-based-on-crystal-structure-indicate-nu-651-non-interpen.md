---
title: "Simulations (Zeo++) based on crystal structure indicate NU-651 (non-interpenetrated pcu Zn-MOF with  ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_3b254ae858]
confidence: medium
---


# Simulations (Zeo++) based on crystal structure indicate NU-651 (non-interpenetrated pcu Zn-MOF with  ...[TRUNCATED]... 

## Mechanism claim

Simulations (Zeo++) based on crystal structure indicate NU-651 (non-interpenetrated pcu Zn-MOF with n-butyl substituted clathrochelate ligands) has a uniform pore size of ~1.9 nm and a calculated porosity of 76.7%, higher than NU-650's calculated porosity of 67.3%.

## Applicability

- Task: `pld`
- Mechanism type: `simulated pore metrics (Zeo++ / crystal-structure-based porosity)`
- Condition scope: `{"gas": "", "temperature_K": null, "pressure_bar": null, "material_family": "NU-651 (Zn4O(L2)3, non-interpenetrated pcu)", "method": "simulation (Zeo++ on single-crystal structure)"}`

## Positive design features

- Simulated uniform pore size: 1.9 nm
- Calculated porosity: 76.7% (crystal-structure-based)

## Negative design features

- Porosity for NU-651 was not experimentally accessed after activation (no corroborating experimental adsorption data provided)

## Agent design implication

Non-interpenetrated pcu frameworks (here, NU-651) are predicted to possess larger, more uniform pores (~1.9 nm) and higher crystallographic porosity than interpenetrated analogs; use Zeo++/structure-based metrics as predictive guidance when experimental activation data are unavailable, but validate experimentally.

## Evidence

> The simulated pore size distribution from Zeo++ calculation revealed NU-651 has uniform pore size of 1.9 nm. The calculated porosity of NU-651 based on crystal structure is 76.7%, which is higher than that of NU-650, 67.3%. Unfortunately, we were not able to access the porosity of NU-651 after either supercritical CO2 activation or perfluoropentane exchange.

Evidence location: page 4 (Results: NU-651 simulations and porosity)

## Links

- Source: [[sources/src_3b254ae858]]