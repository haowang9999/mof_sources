---
title: "Principal component analysis (PCA) combined with machine learning models (decision tree, SVM, BPNN)  ...[TRUNCATED]... "
type: mechanism
tags: [mixed, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_90953381a0]
confidence: medium
---


# Principal component analysis (PCA) combined with machine learning models (decision tree, SVM, BPNN)  ...[TRUNCATED]... 

## Mechanism claim

Principal component analysis (PCA) combined with machine learning models (decision tree, SVM, BPNN) was applied to predict MOF membrane performance from principal components and predictions were compared to simulated results (supplementary figure S7).

## Applicability

- Task: `mixed`
- Mechanism type: `computational prediction method (dimensionality reduction + ML -> performance prediction)`
- Condition scope: `{"gas": "multiple gas mixtures evaluated (15 mixtures)", "temperature_K": null, "pressure_bar": null, "material_family": "CoRE-MOFMs / CoRE‑MOF membranes", "method": "PCA + ML applied to simulated metrics"}`

## Positive design features

- use of PCA to reduce dimensionality
- application of multiple ML models (DT, SVM, BPNN)

## Negative design features

- Not specified

## Agent design implication

Apply PCA to compress high-dimensional performance metrics into principal components and train ML models on those components to accelerate screening and predict membrane performance.

## Evidence

> Figure S7: Predicted performance of the first three principal components (PC1, PC2, PC3) by three machine learning algorithm model of DT, SVM, and BPNN versus the simulated results of CoRE‑MOFMs on the test set.

Evidence location: page 12 (Supplementary Materials list)

## Links

- Source: [[sources/src_90953381a0]]