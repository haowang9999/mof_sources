---
title: "Experimental observations: some studies report enhanced room-temperature H2 uptakes consistent with  ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_0abff73929]
confidence: high
---


# Experimental observations: some studies report enhanced room-temperature H2 uptakes consistent with  ...[TRUNCATED]... 

## Mechanism claim

Experimental observations: some studies report enhanced room-temperature H2 uptakes consistent with spillover when MOFs are defective or partially collapsed and contain supported metal catalysts (e.g., Li & Yang reported ∼4 wt% for IRMOF-8 and ∼3 wt% for IRMOF-1 at 100 bar and 298 K; Tsao et al. reported 4.7 wt% at 69 bar and 298 K for partially collapsed IRMOF-8).

## Applicability

- Task: `h2`
- Mechanism type: `experimental_observation`
- Condition scope: `{"gas": "H2", "temperature_K": 298, "pressure_bar": "100 (Li & Yang) / 69 (Tsao et al.)", "material_family": "IRMOF-1, IRMOF-8 (IRMOF family)", "method": "cited experiments (literature)"}`

## Positive design features

- Measured uptakes among highest reported for room-temperature H2 adsorption in cited studies

## Negative design features

- Enhancement in cited experiments associated with defective/collapsed MOF structures rather than ideal crystals

## Agent design implication

To reproduce or enhance reported room-temperature spillover uptakes, consider introducing controlled defects/collapsed regions in IRMOF-type materials and include supported metal catalysts (Pt/Pd) while monitoring for other defect-related artifacts.

## Evidence

> "Li and Yang...measured hydrogen uptakes close to 4 wt % for IRMOF-8 and close to 3 wt % for IRMOF-1 at 100 bar and 298 K." "Tsao et al. measured 4.7 wt % at 69 bar and 298 K for IRMOF-8 in which they had created a partially collapsed MOF network." "Furthermore, the experimental data so far show that defective MOF structures are necessary for spillover enhancement."

Evidence location: page 1 (Introduction)

## Links

- Source: [[sources/src_0abff73929]]