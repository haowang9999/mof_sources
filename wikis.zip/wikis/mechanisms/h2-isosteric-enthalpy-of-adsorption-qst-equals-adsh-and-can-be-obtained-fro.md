---
title: "Isosteric enthalpy of adsorption (Qst) equals −ΔadsH and can be obtained from adsorption isotherms a ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_ff1b0c9d63]
confidence: high
---


# Isosteric enthalpy of adsorption (Qst) equals −ΔadsH and can be obtained from adsorption isotherms a ...[TRUNCATED]... 

## Mechanism claim

Isosteric enthalpy of adsorption (Qst) equals −ΔadsH and can be obtained from adsorption isotherms at multiple temperatures via Clausius–Clapeyron; Qst versus loading reveals energetics of micropore filling.

## Applicability

- Task: `h2`
- Mechanism type: `energetics measurement / interpretation`
- Condition scope: `{"gas": "H2", "temperature_K": "multiple temperatures required", "pressure_bar": null, "material_family": "MOFs", "method": "analysis of experimental isotherms (review)"}`

## Positive design features

- provides direct measure of adsorption energetics
- useful to evaluate micropore-filling energetics

## Negative design features

- Not specified

## Agent design implication

Obtain adsorption isotherms at two or more temperatures and compute Qst to quantify binding strength and to guide modifications that increase adsorption enthalpy where needed.

## Evidence

> Using the differential energies/enthalpies of adsorption (∆adsU)/(∆adsH) versus the adsorbed total amount (na), the energetics of micropore filling can be estimated... By comparison, using adsorption isotherms obtained at different temperatures, the energetics data assessment leads to the isosteric heat of hydrogen adsorption (Qst). As a result, that Qst is equal to −∆adsH ... Using the Clausius-Clapeyron equation, it is possible to establish the 'isometric heat of adsorption'...

Evidence location: Section 2.4 Isosteric Enthalpy of Hydrogen Adsorption (page 4–5)

## Links

- Source: [[sources/src_ff1b0c9d63]]