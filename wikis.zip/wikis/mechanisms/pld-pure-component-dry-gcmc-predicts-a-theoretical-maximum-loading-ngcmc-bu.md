---
title: "Pure-component (dry) GCMC predicts a theoretical maximum loading (nGCMC) but experimental encapsulat ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_8ce39338bc]
confidence: high
---


# Pure-component (dry) GCMC predicts a theoretical maximum loading (nGCMC) but experimental encapsulat ...[TRUNCATED]... 

## Mechanism claim

Pure-component (dry) GCMC predicts a theoretical maximum loading (nGCMC) but experimental encapsulation from solution can be much lower (examples: ~10× lower for UiO-66/UiO-66(NH2)) because cisplatin thermodynamically favors its solvation shell over occupying an empty framework.

## Applicability

- Task: `pld`
- Mechanism type: `thermodynamic preference and solvation competition`
- Condition scope: `{"gas": "encapsulation from aqueous solution vs dry capacity estimates", "temperature_K": null, "pressure_bar": null, "material_family": "UiO-66, UiO-66(NH2)", "method": "nGCMC (dry) and BAR / MD (solvent-explicit) comparisons; comparison to experiment"}`

## Positive design features

- GCMC provides an upper-bound theoretical capacity for screening

## Negative design features

- practical encapsulation from solution may yield substantially lower loadings due to solvation preference

## Agent design implication

Use dry GCMC as a computationally efficient upper-bound screening metric but follow up with solvent-explicit free-energy methods (e.g., BAR) or experiments because solvent competition can drastically reduce realized uptake.

## Evidence

> The maximum uptake of cisplatin in UiO-66 and UiO-66(NH2) using pure-component GCMC simulations is 0.67:1 and 0.50:1 CPT:Zr, respectively... experimental loading via encapsulation yields uptakes of 0.06:1 CPT:Zr in both UiO-66 and UiO-66(NH2) (which is tenfold lower than nGCMC). Bennett’s acceptance ratio simulations show cisplatin favors its solvation shell to an empty framework.

Evidence location: pages 5-6; page 12

## Links

- Source: [[sources/src_8ce39338bc]]