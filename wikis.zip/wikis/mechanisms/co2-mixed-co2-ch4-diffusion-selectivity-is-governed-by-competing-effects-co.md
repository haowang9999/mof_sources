---
title: "CO2/CH4 diffusion selectivity is governed by competing effects: CO2's stronger affinity to MOFs tend ...[TRUNCATED]... "
type: mechanism
tags: [co2|mixed, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_90953381a0]
confidence: medium
---


# CO2/CH4 diffusion selectivity is governed by competing effects: CO2's stronger affinity to MOFs tend ...[TRUNCATED]... 

## Mechanism claim

CO2/CH4 diffusion selectivity is governed by competing effects: CO2's stronger affinity to MOFs tends to retard CO2 diffusion (Sdiff(CO2/CH4) < 1) while CO2's smaller molecular diameter compared to CH4 tends to favor faster CO2 diffusion (Sdiff(CO2/CH4) > 1).

## Applicability

- Task: `co2|mixed`
- Mechanism type: `competing adsorption–size effects on diffusion selectivity`
- Condition scope: `{"gas": "CO2/CH4", "temperature_K": null, "pressure_bar": null, "material_family": "CoRE-MOFMs / CoRE‑MOF membranes", "method": "simulation / analysis"}`

## Positive design features

- CO2 smaller diameter -> can increase diffusion selectivity

## Negative design features

- CO2 stronger affinity -> can retard diffusion and reduce diffusion selectivity

## Agent design implication

For CO2/CH4 separations, balance adsorption affinity and pore size: strong CO2 adsorption may help adsorption selectivity but can reduce CO2 mobility; pore designs that allow CO2 transport while maintaining adsorption contrast are needed.

## Evidence

> "Take for example, CO2/CH4: on the one hand, because CO2 has a stronger afﬁnity than CH4 with any MOF, CO2 diffusion is retarded, which causes Sdiff(CO2/CH4) < 1; on the other hand, CO2 has a smaller diameter than CH4, which causes Sdiff(CO2/CH4) > 1."

Evidence location: page 6

## Links

- Source: [[sources/src_90953381a0]]