---
title: "Linker-tethered multidentate phosphonate groups (e.g., NH-PAA) chemisorb lanthanides at the linker s ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_c88d608b3b]
confidence: medium
---


# Linker-tethered multidentate phosphonate groups (e.g., NH-PAA) chemisorb lanthanides at the linker s ...[TRUNCATED]... 

## Mechanism claim

Linker-tethered multidentate phosphonate groups (e.g., NH-PAA) chemisorb lanthanides at the linker site and can out-compete monodentate metal-oxo cluster binding, localizing lanthanides at linker phosphonate sites.

## Applicability

- Task: `pld`
- Mechanism type: `functionalization-driven site preference (multidentate chelation at linker)`
- Condition scope: `{"gas": "aqueous (experimental adsorption described); DFT comparisons performed in periodic 'dry' cell with a few waters", "temperature_K": null, "pressure_bar": null, "material_family": "UiO-66-NH-PAA (UiO-66 with linker-tethered phosphonoacetic acid)", "method": "experiment (XAFS, adsorption) + periodic DFT simulation"}`

## Positive design features

- experimental adsorption/XAFS shows UiO-66-NH-PAA has highest Ln uptake attributed to phosphonate affinity
- DFT comparison finds multidentate PAA binding (three PAA oxygens coordinating Gd3+) energetically much more favorable than a monodentate Zr-oxo binding site

## Negative design features

- DFT simulations used 'dry' cells with only a few explicit water molecules and no explicit bulk aqueous reservoir (methodological caveat)
- Absolute magnitudes from DFT may differ in bulk aqueous conditions

## Agent design implication

Graft multidentate phosphonate-containing moieties onto linkers to strongly and locally capture lanthanides and potentially outcompete cluster-based binding sites; validate performance in fully aqueous experiments.

## Evidence

> "MOF functionalization with phosphonate groups led to Ln chemisorption onto these groups, which out-compete metal cluster sites."; DFT details: "In case (a) [PAA]... In case (b) [monodentate Zr-oxo]... reprotonation of a POH group ... decreases the Gd3+ binding energy by 0.14 eV. This variation is noted as an error bar ... it is far less than the energy difference between cases (a) and (b)."; "The overall adsorption capacity was the highest for the UiO-66-NH-PAA MOF, which we attribute to the higher affinity of phosphonate groups for Ln in comparison to Zr−O and Cr−O groups at the metal oxo clusters."

Evidence location: page 1 Abstract; page 3 Molecular Simulations; pages 5-6 Sections 3.1-3.2

## Links

- Source: [[sources/src_c88d608b3b]]