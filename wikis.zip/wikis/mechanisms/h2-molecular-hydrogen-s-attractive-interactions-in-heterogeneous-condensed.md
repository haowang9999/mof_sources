---
title: "Molecular hydrogen’s attractive interactions in heterogeneous condensed-phase matrices (e.g., MOFs)  ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_532b708453]
confidence: high
---


# Molecular hydrogen’s attractive interactions in heterogeneous condensed-phase matrices (e.g., MOFs)  ...[TRUNCATED]... 

## Mechanism claim

Molecular hydrogen’s attractive interactions in heterogeneous condensed-phase matrices (e.g., MOFs) are governed by three principal contributions: van der Waals (Lennard-Jones), charge–quadrupole, and induction (many-body polarization).

## Applicability

- Task: `h2`
- Mechanism type: `interaction decomposition`
- Condition scope: `{"gas": "H2", "temperature_K": 78, "pressure_bar": 1.0, "material_family": "soc-MOF and similar heterogeneous condensed-phase matrices (MOFs, carbon nanostructures, zeolites)", "method": "simulation / theoretical"}`

## Positive design features

- identification of the three dominant interaction terms governing H2 physisorption

## Negative design features

- Not specified

## Agent design implication

Modeling or engineering H2 sorption sites should account for van der Waals, charge–quadrupole, and induction contributions; neglecting any of these may omit important binding physics.

## Evidence

> Molecular hydrogen’s attractive interactions in a heterogeneous condensed phase matrix (e.g., MOFs, carbon nanostructures, and zeolites) are dominated by three intermolecular contributions: Van der Waals, charge-quadrupole, and induction.

Evidence location: page 2

## Links

- Source: [[sources/src_532b708453]]