---
title: "DFT calculations (PBE + D3(BJ), VASP) were used to compute binding energies between MOF and guest mo ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_fc58db74fa]
confidence: high
---


# DFT calculations (PBE + D3(BJ), VASP) were used to compute binding energies between MOF and guest mo ...[TRUNCATED]... 

## Mechanism claim

DFT calculations (PBE + D3(BJ), VASP) were used to compute binding energies between MOF and guest molecules with binding energy defined as ΔE = E_coordinated − E_MOF − E_guest to quantify host–guest interaction strengths.

## Applicability

- Task: `pld`
- Mechanism type: `energetic host–guest binding (DFT quantification)`
- Condition scope: `{"gas": "guest molecules of interest (I2, CH3I, H2O, etc.)", "temperature_K": null, "pressure_bar": null, "material_family": "MOFs", "method": "DFT (VASP, PBE + D3(BJ))"}`

## Positive design features

- DFT-derived binding energies to quantify adsorption strength and validate GCMC sites

## Negative design features

- Not specified

## Agent design implication

Use DFT binding energies (with dispersion corrections) to rank specific host–guest interactions and validate or refine force-field-based adsorption predictions from GCMC.

## Evidence

> “DFT calculations were carried out ... DFT-D3(BJ) dispersion corrections were included... the binding energy between the MOF and guest gas molecule was determined through the following equation: ΔE = E_coordinated − E_MOF − E_guest”

Evidence location: STAR+METHODS, Density functional theory calculations (page ~12)

## Links

- Source: [[sources/src_fc58db74fa]]