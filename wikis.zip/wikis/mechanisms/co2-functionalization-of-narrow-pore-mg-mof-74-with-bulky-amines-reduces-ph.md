---
title: "Functionalization of narrow-pore Mg-MOF-74 with bulky amines reduces physisorptive CO2 uptake substa ...[TRUNCATED]... "
type: mechanism
tags: [co2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_20dae1036b]
confidence: high
---


# Functionalization of narrow-pore Mg-MOF-74 with bulky amines reduces physisorptive CO2 uptake substa ...[TRUNCATED]... 

## Mechanism claim

Functionalization of narrow-pore Mg-MOF-74 with bulky amines reduces physisorptive CO2 uptake substantially (reported ~50–60% lower uptake at 15 kPa) relative to the bare material because chemisorption occupies metal sites and bulky grafts reduce available void fraction.

## Applicability

- Task: `co2`
- Mechanism type: `site blocking / steric occupancy reducing physisorption`
- Condition scope: `{"gas": "CO2", "temperature_K": 313, "pressure_bar": 0.15, "material_family": "Mg-MOF-74 (bare vs amine-functionalized)", "method": "simulation"}`

## Positive design features

- functionalization introduces strong chemisorptive sites

## Negative design features

- reduced physisorption capacity due to occupation of metal sites and bulky amines; earlier saturation due to reduced void fraction

## Agent design implication

When functionalizing narrow-pore MOF-74 expect diminished physisorptive capacity from site occupation and steric blocking—consider expanded frameworks or partial functionalization to retain capacity.

## Evidence

> “At 15 kPa, the adsorption capacity of Mg-MOF-74 is 5.7 mmol·g−1... The adsorption uptake for the functionalized Mg-MOF-74 structures decreases about 50–60% at this condition, mostly due to lower interactions between CO2 molecules and the highly attractive metallic centers... saturation is reached at lower pressure due to the reduction of the available void fraction in the amine-containing frameworks.”

Evidence location: page 6

## Links

- Source: [[sources/src_20dae1036b]]