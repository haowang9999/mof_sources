---
title: "Molecular hydrogen’s attractive interactions in the heterogeneous condensed-phase matrix (e.g., MOFs ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_532b708453]
confidence: high
---


# Molecular hydrogen’s attractive interactions in the heterogeneous condensed-phase matrix (e.g., MOFs ...[TRUNCATED]... 

## Mechanism claim

Molecular hydrogen’s attractive interactions in the heterogeneous condensed-phase matrix (e.g., MOFs) are dominated by three principal contributions: Van der Waals, charge–quadrupole, and induction (polarization).

## Applicability

- Task: `h2`
- Mechanism type: `binding_contributions`
- Condition scope: `{"gas": "H2", "temperature_K": null, "pressure_bar": null, "material_family": "MOFs / heterogeneous condensed phase", "method": "simulation / conceptual"}`

## Positive design features

- van der Waals interactions
- charge–quadrupole interactions
- induction (polarization) interactions

## Negative design features

- Not specified

## Agent design implication

When evaluating or designing sorbents for H2 physisorption, consider all three interaction types; neglecting induction/polarization risks missing a major contributor to binding.

## Evidence

> Molecular hydrogen’s attractive interactions in a heterogeneous condensed phase matrix (e.g., MOFs, carbon nanostructures, and zeolites) are dominated by three intermolecular contributions: Van der Waals, charge-quadrupole, and induction.

Evidence location: PAGE 2

## Links

- Source: [[sources/src_532b708453]]