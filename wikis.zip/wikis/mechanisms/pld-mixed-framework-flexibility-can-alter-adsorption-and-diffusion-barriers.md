---
title: "Framework flexibility can alter adsorption and diffusion barriers; while geometric and energy-grid c ...[TRUNCATED]... "
type: mechanism
tags: [pld|mixed, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_97052fb350]
confidence: high
---


# Framework flexibility can alter adsorption and diffusion barriers; while geometric and energy-grid c ...[TRUNCATED]... 

## Mechanism claim

Framework flexibility can alter adsorption and diffusion barriers; while geometric and energy-grid calculations assume rigid frameworks, the methods are efficient enough that they can be applied across representative framework conformations to capture flexibility effects if required.

## Applicability

- Task: `pld|mixed`
- Mechanism type: `caveat about static-framework assumption and possible remedy`
- Condition scope: `{"gas": "general adsorbates", "temperature_K": null, "pressure_bar": null, "material_family": "MOFs (structures where flexibility may be important)", "method": "simulation (rigid-framework methods extendable to multiple configurations)"}`

## Positive design features

- Methods are sufficiently efficient to be applied to multiple framework geometries to capture flexibility effects
- Users can reduce geometric uncertainty by refining grid spacing

## Negative design features

- Primary calculations described use fixed framework positions and thus may miss flexibility-induced changes in PLD/LCD or adsorption behavior

## Agent design implication

For MOFs known or suspected to be flexible, run the PLD/LCD and adsorption/diffusion estimations across representative framework conformations (or as a function of framework coordinates) to capture flexibility effects before final experimental selection.

## Evidence

> There are, of course, many examples of MOFs in which framework flexibility plays an important role in molecular adsorption. Because of the efficiency of the methods described below, it would be straightforward to examine the characteristics of a MOF’s pore structure as its framework coordinates were varied to describe a flexible structure.

Evidence location: page 3 (section 2.1 Pore Size Characterization)

## Links

- Source: [[sources/src_97052fb350]]