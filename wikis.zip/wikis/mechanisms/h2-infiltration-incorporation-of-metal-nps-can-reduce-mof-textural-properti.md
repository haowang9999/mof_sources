---
title: "Infiltration/incorporation of metal NPs can reduce MOF textural properties (As and Va) and thereby r ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_ff1b0c9d63]
confidence: high
---


# Infiltration/incorporation of metal NPs can reduce MOF textural properties (As and Va) and thereby r ...[TRUNCATED]... 

## Mechanism claim

Infiltration/incorporation of metal NPs can reduce MOF textural properties (As and Va) and thereby reduce hydrogen uptake at cryogenic conditions if pore blocking or framework damage occurs.

## Applicability

- Task: `h2`
- Mechanism type: `reduction of accessible physisorption surface/volume due to pore occupation or framework damage`
- Condition scope: `{"gas": "H2", "temperature_K": 77, "pressure_bar": 40, "material_family": "MIL-100(Al) with Pd NPs; MOF-5 with Pt NPs; DUT-5 example", "method": "experiment (impregnation, infiltration)"}`

## Positive design features

- Not specified

## Negative design features

- decrease in BET area (As) and pore volume (Va)
- partial framework destruction during infiltration can lower uptake

## Agent design implication

When adding NPs, ensure methods that avoid pore blockage or framework degradation (prefer encapsulation that preserves cavity integrity) and verify post-incorporation As and Va to avoid losses in cryogenic uptake.

## Evidence

> As a result of Pd impregnation, the reduction in the nσ value at 77 K and 40 bar of H2 was directly related to the decrease in the As and Va values ... The measured H2 adsorption of the carbon-bridged MOF-5 with Pt NPs was even less than that of Pt NPs on activated carbon. ... The structure of DUT-5 was partially destroyed because of acid treatment during Pd NP infiltration, and this was the main reason for lower H2 adsorption compared with pristine DUT-5.

Evidence location: pages 21-22, Section 4.3.1

## Links

- Source: [[sources/src_ff1b0c9d63]]