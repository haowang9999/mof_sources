---
title: "CO2 binding to functionalized MOF building blocks is dominated by electrostatic interactions: the CO ...[TRUNCATED]... "
type: mechanism
tags: [co2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_c42cf01235]
confidence: high
---


# CO2 binding to functionalized MOF building blocks is dominated by electrostatic interactions: the CO ...[TRUNCATED]... 

## Mechanism claim

CO2 binding to functionalized MOF building blocks is dominated by electrostatic interactions: the CO2 carbon (positive) aligns toward the most negatively charged atom of functional groups while CO2 oxygens (negative) align toward positively charged atoms of the functionalities.

## Applicability

- Task: `co2`
- Mechanism type: `electrostatic adsorption at specific functional sites / directional alignment`
- Condition scope: `{"gas": "CO2 (single-molecule and ensemble adsorption contexts evaluated in simulations)", "temperature_K": null, "pressure_bar": null, "material_family": "functionalized MOF building blocks / linkers", "method": "DFT + GCMC (simulation)"}`

## Positive design features

- functional groups containing strongly negative atoms (e.g., O, N, S, halogens) positioned pore-facing
- arrangement of polar moieties that create electrostatic pockets

## Negative design features

- Not specified

## Agent design implication

Place negatively charged atoms or polar moieties in pore-facing positions and design electrostatic pockets in pores to enhance CO2 physisorption.

## Evidence

> “Optimal binding configurations for CO2 with the functionalities of the building blocks ... are consistent with interactions that are primarily electrostatic. This is indicated by how the CO2 molecule aligns with its positively charged C atom close to the most negatively charged atom of each functionality. Meanwhile, the negatively charged O atoms of the molecule aligns with the positively charged atoms of the functionalities.” || "This alignment pattern suggests more importance for the interactions between the positively charged C atom of CO2 and the negatively charged atoms of the functionalities such as S, O, N (in -NH2 and -(CN)x), F and Br."

Evidence location: page 4 (Results and Discussion: Inherent Adsorbate−Adsorbent Interactions); pages 4-5

## Links

- Source: [[sources/src_c42cf01235]]