---
title: "Linker conformation during modulated synthesis can be used to control interpenetration in MOFs (literature example)."
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_3b254ae858]
confidence: medium
---


# Linker conformation during modulated synthesis can be used to control interpenetration in MOFs (literature example).

## Mechanism claim

Linker conformation during modulated synthesis can be used to control interpenetration in MOFs (literature example).

## Applicability

- Task: `pld`
- Mechanism type: `linker conformation → interpenetration control during synthesis`
- Condition scope: `{"gas": "", "temperature_K": null, "pressure_bar": null, "material_family": "scandium-based MOFs (example cited) / generalizable to MOFs", "method": "modulated synthesis (experimental, cited study)"}`

## Positive design features

- modulated synthesis + linker conformation as a tunable synthesis parameter (reported in cited work)

## Negative design features

- specific conformations or modulation conditions are not provided in the title citation quoted

## Agent design implication

During synthesis planning, consider controlling linker conformation (e.g., via modulation conditions) to achieve desired interpenetration state and hence target PLD and porosity.

## Evidence

> "Controlling interpenetration through linker conformation in the modulated synthesis of sc metal−organic frameworks." (Marshall, R. J.; Lennon, C. T.; Tao, A.; Senn, H. M.; Wilson, C.; Fairen-Jimenez, D.; Forgan, R. S. J. Mater. Chem. A 2018, 6, 1181−1187.)

Evidence location: references (21), pages 6669-6670

## Links

- Source: [[sources/src_3b254ae858]]