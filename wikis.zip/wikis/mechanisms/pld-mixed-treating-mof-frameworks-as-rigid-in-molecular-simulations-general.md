---
title: "Treating MOF frameworks as rigid in molecular simulations generally does not significantly change ga ...[TRUNCATED]... "
type: mechanism
tags: [pld|mixed, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_1fa85425f9]
confidence: high
---


# Treating MOF frameworks as rigid in molecular simulations generally does not significantly change ga ...[TRUNCATED]... 

## Mechanism claim

Treating MOF frameworks as rigid in molecular simulations generally does not significantly change gas adsorption results for MOFs whose pore sizes are larger than the gas molecules, but framework flexibility can be important for diffusion/permeation in narrow-window MOFs (dynamic gating) and for membrane MD simulations.

## Applicability

- Task: `pld|mixed`
- Mechanism type: `structure–adsorption relation / framework flexibility / diffusion`
- Condition scope: `{"gas": "general gases; large molecules for diffusion context", "temperature_K": null, "pressure_bar": null, "material_family": "MOFs (large-pore vs narrow-window materials)", "method": "simulation (rigid vs flexible MD/GCMC)"}`

## Positive design features

- Rigid-framework approximation saves computational time while preserving adsorption results for large-pore MOFs
- Accounting for flexibility captures important diffusion effects in narrow-window MOFs

## Negative design features

- Approximation may be invalid when pores are comparable to or smaller than gas molecule sizes
- Rigid models may miss pronounced permeability changes in narrow-pore materials

## Agent design implication

For high-throughput adsorption screenings of MOFs with pore sizes clearly larger than target gas molecules, using rigid frameworks is an acceptable computational shortcut; however, promising candidates and materials with narrow windows should be re-assessed with flexible-framework simulations to capture gating and dynamic effects on permeability and selectivity.

## Evidence

> "Studies showed that including lattice flexibility does not make any important change in the gas adsorption results of MOFs that have pore sizes larger than the gas molecules (Greathouse and Allendorf, 2008; Perez-Pellitero et al., 2010; Haldoupis et al., 2012a,b)." and "MOF flexibility can be important for diffusion of large gas molecules in the MOFs having narrow windows (Chokbunpiam et al., 2013; Verploegh et al., 2015). It was recently shown that flexibility has an important role in MD simulations of MOF membranes ... flexibility had negligible effect on permeability/selectivity for large-pore MOFs but caused pronounced changes for narrow-pore materials." (page 5).

Evidence location: page 5

## Links

- Source: [[sources/src_1fa85425f9]]