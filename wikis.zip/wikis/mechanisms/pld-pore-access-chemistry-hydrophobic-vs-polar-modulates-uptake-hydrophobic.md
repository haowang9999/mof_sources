---
title: "Pore-access chemistry (hydrophobic vs polar) modulates uptake: hydrophobic frameworks like ZIF-8 can ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_8ce39338bc]
confidence: high
---


# Pore-access chemistry (hydrophobic vs polar) modulates uptake: hydrophobic frameworks like ZIF-8 can ...[TRUNCATED]... 

## Mechanism claim

Pore-access chemistry (hydrophobic vs polar) modulates uptake: hydrophobic frameworks like ZIF-8 can have large pore volumes but weak MOF–cisplatin interactions that favor cisplatin remaining in bulk water, and small pore windows that impose high bonded diffusion barriers hindering encapsulation from solution.

## Applicability

- Task: `pld`
- Mechanism type: `combined geometric and chemical effects on uptake`
- Condition scope: `{"gas": "cisplatin in aqueous simulation/experiment", "temperature_K": null, "pressure_bar": null, "material_family": "ZIF-8 and hydrophobic frameworks", "method": "simulation screening and comparative analysis"}`

## Positive design features

- large pore volume supports high theoretical loading

## Negative design features

- hydrophobic pore surfaces reduce favorable host–guest interactions
- small pore windows can block post-synthesis encapsulation

## Agent design implication

Do not rely solely on pore volume; ensure pore surface chemistry affords favorable interactions for uptake from solution and that windows are accessible for the intended encapsulation route.

## Evidence

> ZIF-8 exhibits the second-highest loading attributed to its large pore volume. However, ZIF-8’s weak interaction energies with cisplatin (hydrophobic nature) mean cisplatin favors bulk water, and its small pore windows create high bonded diffusion barriers that hinder uptake from solution.

Evidence location: page 12

## Links

- Source: [[sources/src_8ce39338bc]]