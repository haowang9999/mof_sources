---
title: "Rate-limiting considerations: gas-phase or physisorbed atomic H diffusion within pores is very fast, ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_0abff73929]
confidence: medium
---


# Rate-limiting considerations: gas-phase or physisorbed atomic H diffusion within pores is very fast, ...[TRUNCATED]... 

## Mechanism claim

Rate-limiting considerations: gas-phase or physisorbed atomic H diffusion within pores is very fast, therefore the rate-limiting step for achieving internal MOF hydrogenation by spillover may be the generation and supply/emission of airborne atomic H from the catalyst (and/or access via entrance pores), not intracrystallite diffusion per se.

## Applicability

- Task: `h2`
- Mechanism type: `kinetics / rate_limiting_step`
- Condition scope: `{"gas": "H2 → atomic H", "temperature_K": null, "pressure_bar": null, "material_family": "MOFs (general discussion)", "method": "DFT-based arguments and literature references"}`

## Positive design features

- Shifts focus to catalyst activity and placement as key determinants of overall hydrogenation rate
- Explains why pore-network improvements only help if atomic-H supply/access are sufficient

## Negative design features

- If entrance access is poor or nanoparticles block pores, fast internal diffusion is moot
- Generation/supply of atomic H may still be rate-limiting even with good pore connectivity

## Agent design implication

Focus on improving catalyst H2-dissociation activity and proximity/distribution relative to MOF crystals (or embedding catalysts without blocking pores) to increase emission/supply of atomic H into pore volumes.

## Evidence

> "As gas-phase (or physisorbed) H atom diffusion is very fast, the rate-limiting step in the overall process would be the generation of airborne atomic H and its supply from the catalyst to the MOF crystal."

Evidence location: page 6-7

## Links

- Source: [[sources/src_0abff73929]]