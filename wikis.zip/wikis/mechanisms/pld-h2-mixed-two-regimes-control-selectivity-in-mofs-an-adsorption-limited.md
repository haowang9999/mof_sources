---
title: "Two regimes control selectivity in MOFs: an adsorption-limited regime where CH4 (the larger molecule ...[TRUNCATED]... "
type: mechanism
tags: [pld|h2|mixed, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_97052fb350]
confidence: high
---


# Two regimes control selectivity in MOFs: an adsorption-limited regime where CH4 (the larger molecule ...[TRUNCATED]... 

## Mechanism claim

Two regimes control selectivity in MOFs: an adsorption-limited regime where CH4 (the larger molecule) is favored due to stronger dispersion interactions (maximal near cavity sizes ~5 Å), and a diffusion-limited regime where the smaller molecule (H2) is favored as PLD is reduced and diffusion barriers for larger molecules rise (potentially producing extremely large kinetic selectivities).

## Applicability

- Task: `pld|h2|mixed`
- Mechanism type: `adsorption vs diffusion competition`
- Condition scope: `{"gas": "H2 and CH4", "temperature_K": 298, "pressure_bar": null, "material_family": "MOFs", "method": "simulation (Henry-regime estimates combining KH and ΔEdiff)"}`

## Positive design features

- small PLD that raises diffusion barrier for larger molecules (favors H2 in diffusion-limited regime)
- strong dispersion interactions favoring adsorption of CH4 (in adsorption-limited regime)

## Negative design features

- PLDs that permit larger molecule to maximize contacts (favoring CH4)
- material microstructural defects can mask intrinsic behavior

## Agent design implication

Decide whether to design for adsorption-based selectivity (target cavities ~5 Å to favor CH4) or kinetic/diffusion-based selectivity (reduce PLD to raise CH4 barrier to favor H2).

## Evidence

> Two distinct regimes can be identified ... one limited by adsorption and one by diffusion. In the adsorption limited regime the selectivity favors CH4 due to the stronger dispersion interactions with the framework... maximum selectivity toward CH4 is observed for pore sizes around 5 Å... In the diffusion limited regime, the selectivity favors the smaller molecule (H2). In this regime, the estimated selectivity becomes extremely large as the pore-limiting diameter is reduced and the diffusion energy barrier for CH4 increases.

Evidence location: page 9

## Links

- Source: [[sources/src_97052fb350]]