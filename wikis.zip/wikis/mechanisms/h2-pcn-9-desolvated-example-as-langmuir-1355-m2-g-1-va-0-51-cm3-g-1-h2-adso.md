---
title: "PCN-9 (desolvated) example: As (Langmuir) = 1355 m2·g–1, Va = 0.51 cm3·g–1, H2 adsorption at 77 K an ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_ff1b0c9d63]
confidence: high
---


# PCN-9 (desolvated) example: As (Langmuir) = 1355 m2·g–1, Va = 0.51 cm3·g–1, H2 adsorption at 77 K an ...[TRUNCATED]... 

## Mechanism claim

PCN-9 (desolvated) example: As (Langmuir) = 1355 m2·g–1, Va = 0.51 cm3·g–1, H2 adsorption at 77 K and 1 bar = 1.53 wt%, and Qst ≈ 10.1 kJ·mol−1.

## Applicability

- Task: `h2`
- Mechanism type: `example of open-site MOF performance metrics`
- Condition scope: `{"gas": "H2", "temperature_K": 77, "pressure_bar": 1, "material_family": "PCN-9 (Co4 O-based SBU)", "method": "experiment"}`

## Positive design features

- moderate surface area and Qst ~10 kJ·mol−1
- measured cryogenic uptake

## Negative design features

- Va relatively small (0.51 cm3·g–1) limiting absolute uptake

## Agent design implication

PCN-9 demonstrates that coordinatively unsaturated metal SBUs can achieve Qst ~10 kJ·mol−1 and measurable cryogenic uptake; use as a reference for designing similar SBUs.

## Evidence

> The As value, obtained by the Langmuir method, of 1355 m2·g–1, and the Va value of 0.51 cm3·g–1 were found for the desolvated PCN-9. Hydrogen adsorption at 77 K and 1 bar of H2 and the Qst values for the PCN-9 were 1.53 wt% and 10.1 kJ·mol–1, respectively.

Evidence location: page 18

## Links

- Source: [[sources/src_ff1b0c9d63]]