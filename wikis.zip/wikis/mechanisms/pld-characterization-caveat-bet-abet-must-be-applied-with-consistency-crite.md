---
title: "Characterization caveat: BET/ABET must be applied with consistency criteria and used alongside pore- ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_fa8cccd644]
confidence: high
---


# Characterization caveat: BET/ABET must be applied with consistency criteria and used alongside pore- ...[TRUNCATED]... 

## Mechanism claim

Characterization caveat: BET/ABET must be applied with consistency criteria and used alongside pore-size distribution and direct gas isotherms because BET can conflate SSA and pore volume (particularly at very high ABET) and mislead H2 uptake expectations (Chahine's rule not universally valid for MOFs).

## Applicability

- Task: `pld`
- Mechanism type: `measurement methodology caveat`
- Condition scope: `{"gas": null, "temperature_K": null, "pressure_bar": null, "material_family": "micro- and mesoporous MOFs", "method": "BET / IUPAC physisorption and isotherm analysis"}`

## Positive design features

- BET area can be a useful first-order predictor within typical ranges

## Negative design features

- for very high ABET, BET may reflect pore volume more than true SSA; Chahine's 1 wt% per 500 m2 g−1 heuristic fails across many MOFs

## Agent design implication

Do not rely on ABET alone for screening; apply BET consistency criteria, compute PSD and micropore volume, measure H2 isotherms at target T/P and estimate Qst to select candidates robustly.

## Evidence

> Due to limitations of the BET method, very high ABET values are more indicative of pore volume than actual surface area. When excess H2 storage capacities at −196 °C are plotted vs ABET for many MOFs, the trend does not follow Chahine's 1 wt% per 500 m2 g−1 rule. Use BET with consistency criteria and IUPAC physisorption evaluation.

Evidence location: page 2 (Discussion of BET limitations and Chahine rule) || pages 19-20 (refs. 99, 103)

## Links

- Source: [[sources/src_fa8cccd644]]