---
title: "Alkali-metal doping correlates with increased BET surface area and (in most analyses) increased micr ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_b0ea8c70ab]
confidence: high
---


# Alkali-metal doping correlates with increased BET surface area and (in most analyses) increased micr ...[TRUNCATED]... 

## Mechanism claim

Alkali-metal doping correlates with increased BET surface area and (in most analyses) increased micropore-accessible surface area; the ordering of BET areas (1 < 1·Li < 1·K < 1·Na) matches the ordering for hydrogen adsorption, supporting a pore-structure (increased internal surface area via displacement of interwoven networks) mechanism for enhanced uptake.

## Applicability

- Task: `pld`
- Mechanism type: `pore-structure modification correlated with uptake (experimental observation)`
- Condition scope: `{"gas": "N2 (BET probe) and H2 (uptake correlation)", "temperature_K": 77, "pressure_bar": null, "material_family": "1 and 1·M (M = Li, Na, K)", "method": "experiment (N2 isotherms, BET and t-plot analyses)"}`

## Positive design features

- BET surface areas for 1·M significantly exceed undoped 1
- ordering of surface areas matches H2 uptake ordering

## Negative design features

- t-plot derived micropore surface areas give slightly different order but still show enhanced microporosity for doped samples
- assignment of mechanism ('presumably' displacement) is inferential rather than directly proven

## Agent design implication

Use controlled low-level alkali-metal doping to alter interpenetrated MOF packing and increase accessible surface area (BET/micropore) as a viable route to improve cryogenic H2 uptake; monitor N2-accessible metrics to support the attribution.

## Evidence

> As shown in Table 2, the BET surface areas for the various 1·M materials significantly exceed those for the undoped parent material. Furthermore, the ordering of surface areas (1 < 1·Li < 1·K < 1·Na) matches the ordering for hydrogen adsorption. Nitrogen isotherms suggest that the key role of dopant cations and/or partial framework reduction in improving hydrogen uptake instead is to enhance the microporous surface area, presumably by facilitating the displacement of interwoven networks.

Evidence location: Results and Discussion (sections 3.3), Table 2; Conclusions

## Links

- Source: [[sources/src_b0ea8c70ab]]