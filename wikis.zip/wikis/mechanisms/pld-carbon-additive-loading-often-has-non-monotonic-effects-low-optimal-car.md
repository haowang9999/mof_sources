---
title: "Carbon additive loading often has non-monotonic effects: low/optimal carbon amounts can create new s ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_fa8cccd644]
confidence: high
---


# Carbon additive loading often has non-monotonic effects: low/optimal carbon amounts can create new s ...[TRUNCATED]... 

## Mechanism claim

Carbon additive loading often has non-monotonic effects: low/optimal carbon amounts can create new small pores and increase micropore volume and H2 uptake, whereas excessive carbon loading can reduce uptake by blocking pores or lowering accessible MOF porosity.

## Applicability

- Task: `pld`
- Mechanism type: `dose-dependent structural modification affecting adsorption`
- Condition scope: `{"gas": "H2", "temperature_K": null, "pressure_bar": null, "material_family": "MOF@carbon hybrids (HKUST-1@GO, MIL-101@SWCNTs, MOF-5@MWCNTs, etc.)", "method": "in situ growth / physical mixing experiments"}`

## Positive design features

- small carbon loadings can increase micropore fraction and uptake

## Negative design features

- high carbon loadings can reduce uptake (example HKUST-1@GO 18 wt% lower uptake than 5 wt% sample)

## Agent design implication

Optimize carbon additive type and loading to balance increased microporosity and avoid pore blockage; measure PSD and H2 isotherms to confirm benefit.

## Evidence

> Petit et al. showed HKUST-1@GO (5 wt%) H2 uptake slightly higher than pristine, while 18 wt% GO lowered uptake. Prasanth et al. incorporated 8 wt% SWCNTs into MIL-101 leading to increased H2 capacities attributed to reduced pore size and increased micropore volume despite slight SSA decrease.

Evidence location: Section 4.2.2 / pages ~13-14

## Links

- Source: [[sources/src_fa8cccd644]]