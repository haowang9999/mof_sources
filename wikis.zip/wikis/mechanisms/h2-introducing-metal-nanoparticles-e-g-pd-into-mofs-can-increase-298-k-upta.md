---
title: "Introducing metal nanoparticles (e.g., Pd) into MOFs can increase 298 K uptake (due to hydride forma ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_b1552d4a9d]
confidence: medium
---


# Introducing metal nanoparticles (e.g., Pd) into MOFs can increase 298 K uptake (due to hydride forma ...[TRUNCATED]... 

## Mechanism claim

Introducing metal nanoparticles (e.g., Pd) into MOFs can increase 298 K uptake (due to hydride formation or spillover) but often reduces 77 K uptake because of decreases in BET surface area and pore volume and the added mass of metal.

## Applicability

- Task: `h2`
- Mechanism type: `catalytic nanoparticles / spillover with morphological tradeoffs`
- Condition scope: `{"gas": "H2", "temperature_K": [77, 298], "pressure_bar": [40, "other reported pressures"], "material_family": "MIL-100(Al) with Pd NPs; general MOF + NP composites", "method": "experiment"}`

## Positive design features

- possible Pd hydride formation increases 298 K uptake; spillover mechanisms considered

## Negative design features

- NP incorporation can reduce A (BET) and V (pore volume), lowering cryogenic uptake and gravimetric capacity

## Agent design implication

If adding metal NPs to leverage spillover or hydride formation, carefully balance NP loading and dispersion to avoid excessive loss of surface area/pore volume and weigh mass penalties.

## Evidence

> Pd NPs infused in MIL-100(Al) reduced n at 77 K and 40 bar related to decreases in A and V, whereas at 298 K, n increased likely due to Pd hydride formation; formation of PdHx was experimentally confirmed and spillover was considered.

Evidence location: page 10

## Links

- Source: [[sources/src_b1552d4a9d]]