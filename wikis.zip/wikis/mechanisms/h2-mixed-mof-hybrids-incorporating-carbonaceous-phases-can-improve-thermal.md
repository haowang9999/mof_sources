---
title: "MOF hybrids incorporating carbonaceous phases can improve thermal conductivity, increase accessible  ...[TRUNCATED]... "
type: mechanism
tags: [h2|mixed, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_fa8cccd644]
confidence: medium
---


# MOF hybrids incorporating carbonaceous phases can improve thermal conductivity, increase accessible  ...[TRUNCATED]... 

## Mechanism claim

MOF hybrids incorporating carbonaceous phases can improve thermal conductivity, increase accessible surface area or micropore volume, and tune chemical composition to enhance selectivity or kinetics for H2 adsorption.

## Applicability

- Task: `h2|mixed`
- Mechanism type: `hybrid material property modification`
- Condition scope: `{"gas": "H2 (and competing gases implicitly)", "temperature_K": null, "pressure_bar": null, "material_family": "MOF–carbon hybrids (CNTs, MWCNTs, GO, AC, ZTC, graphite flakes, graphenic layers)", "method": "review / experiments"}`

## Positive design features

- improved thermal conductivity (via graphite flakes, conductive carbon)
- increased specific surface area or micropore volume (in many hybrids)
- improved hydrostability in some composites
- possibility to tune chemical composition / heterogeneity

## Negative design features

- carbon loading can reduce SSA or block pores depending on method and loading
- morphology/crystallinity changes possible

## Agent design implication

Combine MOFs with carbonaceous materials to enhance heat transfer, kinetics and cryogenic uptake; optimize type and loading of carbon to increase micropore fraction without blocking access and check both gravimetric and volumetric metrics.

## Evidence

> The addition of carbon-based materials to produce MOF hybrids can improve thermal conductivity and allow tuning of the chemical composition to provide greater selectivity for H2 adsorption compared with other gases. || Examples: MIL-101(Cr)@ZTC increased BET and H2 uptake; MOF-5@MWCNT increased Langmuir area (2160 → 3550 m2 g−1) and H2 storage; HKUST-1@graphite flake hybrids increased thermal conductivity and H2 uptake.

Evidence location: page 2 (MOF hybrids discussion) || Section 4.2 / pages ~12-15 || page 14-15

## Links

- Source: [[sources/src_fa8cccd644]]