---
title: "Incorporation of lithium cations into MOFs can enhance CO2/CH4 selectivity (literature example)."
type: mechanism
tags: [co2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_3b254ae858]
confidence: medium
---


# Incorporation of lithium cations into MOFs can enhance CO2/CH4 selectivity (literature example).

## Mechanism claim

Incorporation of lithium cations into MOFs can enhance CO2/CH4 selectivity (literature example).

## Applicability

- Task: `co2`
- Mechanism type: `metal cation incorporation → gas selectivity (electrostatic/interaction enhancement)`
- Condition scope: `{"gas": "CO2 vs CH4", "temperature_K": null, "pressure_bar": null, "material_family": "metal‑organic frameworks containing lithium cations (general / cited studies)", "method": "experimental adsorption/separation studies (cited literature)"}`

## Positive design features

- adding Li+ can improve CO2/CH4 selectivity (reported in cited study)

## Negative design features

- extent of enhancement, optimal loading, or effect on PLD not specified in the citation title quoted here

## Agent design implication

To increase CO2/CH4 selectivity in MOFs, consider post-synthetic or synthetic incorporation of lithium (or other Lewis‑acidic) cations as interaction sites for CO2; characterize selectivity experimentally.

## Evidence

> "Enhancement of CO2/CH4 selectivity in metal-organic frameworks containing lithium cations." (Bae, Y.-S.; Hauser, B. G.; Farha, O. K.; Hupp, J. T.; Snurr, R. Q. Microporous Mesoporous Mater. 2011, 141, 231−235.)

Evidence location: references (28), pages 6669-6670

## Links

- Source: [[sources/src_3b254ae858]]