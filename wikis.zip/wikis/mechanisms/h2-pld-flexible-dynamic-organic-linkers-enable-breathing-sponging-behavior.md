---
title: "Flexible (dynamic) organic linkers enable breathing/sponging behavior and reversible expansion/contr ...[TRUNCATED]... "
type: mechanism
tags: [h2|pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_ff1b0c9d63]
confidence: medium
---


# Flexible (dynamic) organic linkers enable breathing/sponging behavior and reversible expansion/contr ...[TRUNCATED]... 

## Mechanism claim

Flexible (dynamic) organic linkers enable breathing/sponging behavior and reversible expansion/contraction of pore channels, altering pore size and cell volume and thereby affecting uptake (example: ~9% cell volume change reported).

## Applicability

- Task: `h2|pld`
- Mechanism type: `framework flexibility → reversible pore modulation → adsorption tuning`
- Condition scope: `{"gas": "general (guest insertion/removal)", "temperature_K": null, "pressure_bar": null, "material_family": "dynamic/flexible MOFs (pillared-layer, expanding/shrinking MOFs)", "method": "experiment"}`

## Positive design features

- reversible transformation between expanded (lp) and contracted (np) phases
- ability to modulate pore size via solvent/guest insertion or thermal/chemical stimulus

## Negative design features

- potential complexity in predicting performance due to dynamic behavior

## Agent design implication

Consider flexible linkers to create MOFs with switchable pore sizes to tune adsorption/desorption behavior for target gases; expect reversible changes in accessible pore volume and transport.

## Evidence

> Dynamic MOFs can respond to external conditions ... and reversibly change their channels by a large magnitude ... For example, ... the reversible extension and shortening of pillars were estimated to result in a 9% difference in the cell volume... The decrease in the interlayer distance ... was attributed to the rotation of the C–C single bonds of the flexible etbipy ligands, resulting in the relative gliding between the neighboring layers.

Evidence location: section 4.1.4 and Figures 7-9 (pages 15-16)

## Links

- Source: [[sources/src_ff1b0c9d63]]