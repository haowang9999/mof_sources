---
title: "In less polar, large-pore frameworks (example: IRMOF-1 / MOF-5) including many-body polarization did ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_532b708453]
confidence: high
---


# In less polar, large-pore frameworks (example: IRMOF-1 / MOF-5) including many-body polarization did ...[TRUNCATED]... 

## Mechanism claim

In less polar, large-pore frameworks (example: IRMOF-1 / MOF-5) including many-body polarization did not significantly change hydrogen radial distribution functions and such frameworks sorb substantially less H2 than soc-MOF due to lack of open coordination sites and weaker polarizing fields.

## Applicability

- Task: `h2`
- Mechanism type: `comparative material property -> reduced induction`
- Condition scope: `{"gas": "H2", "temperature_K": 78, "pressure_bar": null, "material_family": "IRMOF-1 (MOF-5)", "method": "simulation (polarizable vs nonpolarizable comparison)"}`

## Positive design features

- Not specified

## Negative design features

- lack of open metal coordination sites and narrow channels reduces induction effects
- open large voids allow gas to behave like neat hydrogen with negligible induced dipoles

## Agent design implication

Avoid large-pore, nonpolar frameworks like MOF-5 when targeting strong hydrogen sorption driven by induced dipoles; instead include polar SBUs and smaller channels.

## Evidence

> Simulations including many-body polarization for IRMOF-1 reveal no significant change in radial distribution functions for the hydrogen to the metal-centered SBU when compared to simulations neglecting induction. MOF-5, which sorbs substantially less hydrogen than the new material studied here under like conditions, also does not possess an open coordination site on its zinc SBU and thus produces a more weakly polarizing field in comparison with soc-MOF. Most importantly, MOF-5 does not possess narrow channels or a highly polar framework, but rather has an open topology with larger void spaces.

Evidence location: page 8 (Results and Discussion)

## Links

- Source: [[sources/src_532b708453]]