---
title: "Limiting pore diameter (PLD) and the pore size distribution (PSD) are key factors affecting CO2 perm ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_1fa85425f9]
confidence: high
---


# Limiting pore diameter (PLD) and the pore size distribution (PSD) are key factors affecting CO2 perm ...[TRUNCATED]... 

## Mechanism claim

Limiting pore diameter (PLD) and the pore size distribution (PSD) are key factors affecting CO2 permeation through hMOF membranes.

## Applicability

- Task: `pld`
- Mechanism type: `diffusion / membrane permeation (size exclusion and transport)`
- Condition scope: `{"gas": "CO2 (membrane separations, e.g., CO2/CH4)", "temperature_K": null, "pressure_bar": "studies used single‑gas infinite dilution and for some cases mixture at 10 bar (subset)", "material_family": "hypothetical MOFs (hMOF membranes) and MOF membranes", "method": "simulation (MD for membrane permeation; combined GCMC+MD reported)"}`

## Positive design features

- appropriate limiting pore diameter
- controlled/narrow pore size distribution

## Negative design features

- inappropriate PLD (too large or too small)
- broad PSD (heterogeneous apertures)

## Agent design implication

When designing MOF membranes for CO2 permeation, tune the limiting pore diameter and engineer a narrow pore size distribution to control CO2 transport and selectivity.

## Evidence

> "The limiting pore diameter and pore size distribution were reported as the key factors that affect CO2 permeation of hMOF membranes (Qiao et al., 2016b)." (page 3).

Evidence location: page 3 (Large-scale screening / membrane studies)

## Links

- Source: [[sources/src_1fa85425f9]]