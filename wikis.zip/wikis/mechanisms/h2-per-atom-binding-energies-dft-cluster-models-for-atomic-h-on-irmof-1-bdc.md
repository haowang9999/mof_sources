---
title: "Per-atom binding energies (DFT cluster models) for atomic H on IRMOF-1 BDC linker sites: approximate ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_0abff73929]
confidence: high
---


# Per-atom binding energies (DFT cluster models) for atomic H on IRMOF-1 BDC linker sites: approximate ...[TRUNCATED]... 

## Mechanism claim

Per-atom binding energies (DFT cluster models) for atomic H on IRMOF-1 BDC linker sites: approximate values are Ha ≈ -2.0 eV, Hb ≈ -4.0 to -4.4 eV, Hc ≈ -2.6 to -2.7 eV, Hd ≈ -0.9 to -1.0 eV (negative = bound). O-bound (Hd) sites are the weakest and thus most prone to abstraction.

## Applicability

- Task: `h2`
- Mechanism type: `thermodynamics / binding_energy`
- Condition scope: `{"gas": "atomic H (chemisorbed)", "temperature_K": null, "pressure_bar": null, "material_family": "IRMOF-1 linker (BDC), small (S) and large (L) cluster models", "method": "DFT (reported Table 1 values)"}`

## Positive design features

- Strong-binding carbocycle sites (Hb) provide particularly stable chemisorption centers
- Intermediate-binding ring/carboxylate carbon sites (Ha, Hc) also contribute to retention

## Negative design features

- O-bound Hd sites are relatively weak and susceptible to ER abstraction

## Agent design implication

Target linkers or functionalizations that create more binding motifs analogous to Hb/Hc and avoid producing many weak O–H sites to improve thermodynamic retention of atomic H.

## Evidence

> Table 1 shows: Ha energy per H (small model) -2.0 eV; Hb -4.4 eV; Hd -1.0 eV; Hc -2.7 eV. (Table reported energies for large and small models with negative numbers representing binding.)

Evidence location: page 3 (Table 1)

## Links

- Source: [[sources/src_0abff73929]]