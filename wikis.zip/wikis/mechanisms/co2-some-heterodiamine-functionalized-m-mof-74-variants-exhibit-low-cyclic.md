---
title: "Some heterodiamine-functionalized M-MOF-74 variants exhibit low cyclic working capacity because the  ...[TRUNCATED]... "
type: mechanism
tags: [co2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_20dae1036b]
confidence: medium
---


# Some heterodiamine-functionalized M-MOF-74 variants exhibit low cyclic working capacity because the  ...[TRUNCATED]... 

## Mechanism claim

Some heterodiamine-functionalized M-MOF-74 variants exhibit low cyclic working capacity because the heterodiamine reduces interaction strength with CO2; available void space left by appended amines and the specific amine chemistry are critical determinants of capture performance.

## Applicability

- Task: `co2`
- Mechanism type: `amine identity/sterics → reduced chemisorption and lower working capacity`
- Condition scope: `{"gas": "CO2 (cyclic adsorption/desorption)", "temperature_K": null, "pressure_bar": null, "material_family": "heterodiamine-functionalized M-MOF-74 and other amine-grafted MOFs", "method": "simulation (screening) and literature citations"}`

## Positive design features

- some amines produce desirable cooperative binding and high capacity

## Negative design features

- heterodiamines in some cases reduced interactions with CO2 leading to low cyclic working capacity
- available void space after grafting strongly affects performance

## Agent design implication

Avoid heterodiamine grafts that are predicted or shown to reduce CO2–amine interaction strength when high cyclic working capacity is a requirement; always consider the void space remaining after grafting and test candidate amines experimentally or in simulation.

## Evidence

> “the left bottom section is mostly composed of the amine-functionalized M-MOF-74 structures, with a low cyclic working capacity due to reduced interactions between the heterodiamine and CO2.” | “Simulations have shown that the available void space left by the amine and the type of amine functional group plays a crucial role in achieving optimal CO2 capture properties...”

Evidence location: page 8 (Results/Conclusions); page 8 (Conclusions)

## Links

- Source: [[sources/src_20dae1036b]]