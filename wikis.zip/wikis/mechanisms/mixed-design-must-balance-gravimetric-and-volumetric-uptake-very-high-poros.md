---
title: "Design must balance gravimetric and volumetric uptake: very high porosity benefits gravimetric capac ...[TRUNCATED]... "
type: mechanism
tags: [mixed, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_b1552d4a9d]
confidence: medium
---


# Design must balance gravimetric and volumetric uptake: very high porosity benefits gravimetric capac ...[TRUNCATED]... 

## Mechanism claim

Design must balance gravimetric and volumetric uptake: very high porosity benefits gravimetric capacity but can reduce volumetric density; practical hydrogen storage requires optimizing both.

## Applicability

- Task: `mixed`
- Mechanism type: `tradeoff between pore volume/surface area and bulk packing density`
- Condition scope: `{"gas": "H2 (implied among clean-energy gases)", "temperature_K": null, "pressure_bar": null, "material_family": "highly porous materials / MOFs", "method": "review / analysis"}`

## Positive design features

- high porosity increases gravimetric uptake

## Negative design features

- very high porosity can reduce volumetric uptake; tradeoffs exist

## Agent design implication

When designing MOFs for hydrogen storage, evaluate and optimize both gravimetric and volumetric performance and consider framework density and packing rather than maximizing surface area alone.

## Evidence

> "Balancing volumetric and gravimetric uptake in highly porous materials for clean energy." (reference cited in review).

Evidence location: page 13 (reference 9)

## Links

- Source: [[sources/src_b1552d4a9d]]