---
title: "Pore size classification dictates adsorption behavior: ultramicropores (<7 Å) are filled at very low ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_ff1b0c9d63]
confidence: high
---


# Pore size classification dictates adsorption behavior: ultramicropores (<7 Å) are filled at very low ...[TRUNCATED]... 

## Mechanism claim

Pore size classification dictates adsorption behavior: ultramicropores (<7 Å) are filled at very low relative pressures (p/p0) driven by strong gas–solid interactions, whereas supermicropores (≈7–20 Å) can exhibit cooperative (pore-filling) behavior that leads to low-p/p0 filling.

## Applicability

- Task: `pld`
- Mechanism type: `pore-size-dependent pore filling / adsorption regime`
- Condition scope: `{"gas": "general adsorbates (including H2)", "temperature_K": null, "pressure_bar": null, "material_family": "MOFs (microporous, supermicroporous, ultramicroporous)", "method": "review / conceptual"}`

## Positive design features

- ultramicropores favor adsorption at very low relative pressures
- supermicropores can show cooperative filling enhancing uptake at low p/p0

## Negative design features

- adsorption rates and behavior strongly temperature-dependent in ultramicropores

## Agent design implication

Tuning pore sizes to the ultramicropore regime (<7 Å) can maximize uptake at very low pressures; designing supermicropores (7–20 Å) can exploit cooperative pore-filling to improve uptake at modest relative pressures.

## Evidence

> Ultramicropores are filled at very low relative pressures p/po ... directed by gas–solid interactions, and the rates of adsorption highly depend on temperature. In supermicropores, in addition to gas–solid interactions, a cooperation effect (when pore filling occurs at a relatively low p/po value) takes place.

Evidence location: Section 2.2 Surface Area (page 2–3)

## Links

- Source: [[sources/src_ff1b0c9d63]]