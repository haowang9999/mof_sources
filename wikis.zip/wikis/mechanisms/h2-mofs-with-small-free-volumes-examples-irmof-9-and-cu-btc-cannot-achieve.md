---
title: "MOFs with small free volumes (examples: IRMOF-9 and Cu-BTC) cannot achieve the 2010 DOE deliverable  ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_8d4a290e19]
confidence: high
---


# MOFs with small free volumes (examples: IRMOF-9 and Cu-BTC) cannot achieve the 2010 DOE deliverable  ...[TRUNCATED]... 

## Mechanism claim

MOFs with small free volumes (examples: IRMOF-9 and Cu-BTC) cannot achieve the 2010 DOE deliverable target even if Qst is increased up to 50 kJ/mol (simulation result).

## Applicability

- Task: `h2`
- Mechanism type: `structural limitation`
- Condition scope: `{"gas": "H2", "temperature_K": 298, "pressure_bar": {"storage_pressure": 120, "discharge_pressure": 1.5}, "material_family": "IRMOF-9, Cu-BTC", "method": "simulation"}`

## Positive design features

- Not specified

## Negative design features

- Small free volume limits maximum achievable deliverable capacity even with very large Qst

## Agent design implication

Avoid MOFs with very small free volumes when aiming for high deliverable H2 capacity, since increasing Qst alone may not be sufficient to meet targets.

## Evidence

> "Remarkably, MOFs with small free volumes (IRMOF-9 and Cu-BTC) cannot achieve the 2010 target in view point of the deliverable capacity even if Qost is increased to 50 kJ/mol."

Evidence location: page 3 (Results and discussion)

## Links

- Source: [[sources/src_8d4a290e19]]