---
title: "Decision-tree analysis (ML) identifies the highest bond dipole moment (HBDM) of the introduced funct ...[TRUNCATED]... "
type: mechanism
tags: [co2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_c42cf01235]
confidence: medium
---


# Decision-tree analysis (ML) identifies the highest bond dipole moment (HBDM) of the introduced funct ...[TRUNCATED]... 

## Mechanism claim

Decision-tree analysis (ML) identifies the highest bond dipole moment (HBDM) of the introduced functional group as the top predictor for whether CO2 selectivity over N2 will improve: if HBDM > 0.319 e·Å, functionalization improves selectivity in >90% of cases; when HBDM ≤ 0.319 e·Å other descriptors (topology, most-negative-charge, void fraction) determine outcome.

## Applicability

- Task: `co2`
- Mechanism type: `predictive descriptor importance (ML-derived rule / conditional inference tree)`
- Condition scope: `{"gas": "CO2:N2 mixture at 1 bar", "temperature_K": null, "pressure_bar": 1, "material_family": "parent MOFs functionalized (various topologies)", "method": "machine learning (decision trees trained on simulation data)"}`

## Positive design features

- HBDM of functional group > 0.319 e·Å
- presence of an atom with very negative charge (most-negative-charge < -0.89) in certain topologies
- parent MOF void fraction > 0.579 combined with HBDM > 0.043 for some topologies

## Negative design features

- Not specified

## Agent design implication

Use HBDM as a first-pass descriptor to decide whether to pursue functionalization for improving CO2/N2 selectivity; if HBDM is low, consult topology and charge descriptors before investing in synthesis.

## Evidence

> “The first split of the tree is made on the basis of the HBDM of the functional group ... If the HBDM is larger than 0.319 e.Å, the functionalization does improve the parent in more than 90% of the cases. If the HBDM ... smaller than 0.319 e.Å, then the topology is the next most significant factor ... for bcs, bcu, fcu, flu, ftw, reo, rht, and ssb ... improvement upon functionalization occurs if the functionality has an atom more negatively charged than −0.89. ... for acs, lvt, nbo, nia, pcu, pyr, rhr, and stp ... improvement ... occurs in 95% of the cases when the HBDM is not so low (>0.043 eÅ) provided that the void fraction ... is large enough (>0.579)."

Evidence location: pages 6-7

## Links

- Source: [[sources/src_c42cf01235]]