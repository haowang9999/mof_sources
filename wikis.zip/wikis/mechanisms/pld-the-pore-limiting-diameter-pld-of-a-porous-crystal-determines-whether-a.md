---
title: "The pore-limiting diameter (PLD) of a porous crystal determines whether a spherical probe (represent ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_97052fb350]
confidence: high
---


# The pore-limiting diameter (PLD) of a porous crystal determines whether a spherical probe (represent ...[TRUNCATED]... 

## Mechanism claim

The pore-limiting diameter (PLD) of a porous crystal determines whether a spherical probe (representing a gas molecule) can diffuse through the material: molecules significantly smaller than the PLD will be able to diffuse freely, while molecules larger than the PLD will have at most very slow diffusion.

## Applicability

- Task: `pld`
- Mechanism type: `geometric / steric exclusion controlling diffusion`
- Condition scope: `{"gas": "general spherical adsorbates (probe spheres)", "temperature_K": null, "pressure_bar": null, "material_family": "MOFs and zeolites (crystalline porous materials)", "method": "geometric simulation (grid-based)"}`

## Positive design features

- PLD smaller than target larger species while larger than smaller species enables kinetic separation
- PLD identifies the maximum sphere that can percolate through the structure (spanning cluster)

## Negative design features

- If PLD is larger than both species, there will be limited kinetic selectivity based on size
- If PLD is smaller than both species, neither will diffuse appreciably

## Agent design implication

Design or select materials with a PLD between the effective sizes of two gas species to create transport-rate-based (kinetic) separation: the larger species will be kinetically hindered while the smaller one diffuses more rapidly.

## Evidence

> The pore-limiting diameter is defined such that it is impossible for any sphere with a diameter larger than the pore-limiting diameter of a structure to travel through this structure without overlapping one or more framework atoms. ... gas molecules that are significantly smaller (larger) than the pore-limiting diameter of a porous material will be able to diffuse freely (will have at most very slow diffusion) through the material.

Evidence location: page 2 (section 2.1 Pore Size Characterization)

## Links

- Source: [[sources/src_97052fb350]]