---
title: "Volumetric surface area (VSA) and density (ρ) show no clear, consistent effect on permselectivity in ...[TRUNCATED]... "
type: mechanism
tags: [co2|mixed, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_90953381a0]
confidence: high
---


# Volumetric surface area (VSA) and density (ρ) show no clear, consistent effect on permselectivity in ...[TRUNCATED]... 

## Mechanism claim

Volumetric surface area (VSA) and density (ρ) show no clear, consistent effect on permselectivity in simple (1D) analyses; VSA was measured using an N2 probe (3.64 Å), so materials with near-zero N2-VSA may still permit smaller gases like CO2 (3.3 Å) and H2S (3.6 Å) to pass.

## Applicability

- Task: `co2|mixed`
- Mechanism type: `probe-size dependence of VSA and limited predictive value of bulk descriptors`
- Condition scope: `{"gas": "CO2, H2S (examples); general statement across gases", "temperature_K": null, "pressure_bar": null, "material_family": "CoRE-MOFMs / CoRE‑MOF membranes", "method": "simulation-derived descriptor analysis"}`

## Positive design features

- Small N2-VSA does not necessarily block gases smaller than the N2 probe (3.64 Å)

## Negative design features

- VSA and ρ are not clear predictors of permselectivity in 1D plots

## Agent design implication

Do not rely solely on N2-based VSA or bulk density to predict permselectivity; consider probe-size dependence and directly evaluate accessibility for the target gas size via gas-sized probes or permeability simulations/experiments.

## Evidence

> "Upon analyzing the VSA and ρ, they showed no clear effect on the permselectivity of each gas component... since the VSA was determined using N2 as a probe with a diameter of 3.64 Å, thus, when the VSA of a MOF is zero or small, the smaller gas could pass the MOF such as CO2 (3.3 Å) and H2S (3.6 Å)."

Evidence location: page 6

## Links

- Source: [[sources/src_90953381a0]]