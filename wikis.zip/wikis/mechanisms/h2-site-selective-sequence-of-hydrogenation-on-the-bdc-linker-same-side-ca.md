---
title: "Site-selective sequence of hydrogenation on the BDC linker: same-side Ca ring atoms are hydrogenated ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_0abff73929]
confidence: high
---


# Site-selective sequence of hydrogenation on the BDC linker: same-side Ca ring atoms are hydrogenated ...[TRUNCATED]... 

## Mechanism claim

Site-selective sequence of hydrogenation on the BDC linker: same-side Ca ring atoms are hydrogenated first; Cb atoms are hydrogenated third and sixth; one carboxylate Od atom is hydrogenated later (seventh), which enables hydrogenation of Cc (eighth) due to favorable tetrahedral geometry from O-H formation.

## Applicability

- Task: `h2`
- Mechanism type: `mechanistic_sequence / site_selectivity`
- Condition scope: `{"gas": "atomic H", "temperature_K": null, "pressure_bar": null, "material_family": "IRMOF-1 BDC linker", "method": "DFT optimizations and reaction path analysis"}`

## Positive design features

- Predictable sequential hydrogenation pathway informs which sites will be occupied first and how geometry changes enable subsequent additions

## Negative design features

- Hydrogenation of carboxylate groups introduces structural changes that can affect subsequent binding energetics

## Agent design implication

Design linkers or catalytic environments that stabilize early-occupied ring sites (Ca/Cb) and account for sequence-dependent geometric effects when aiming to increase hydrogen uptake.

## Evidence

> "The order of hydrogenation of the BDC linker, as predicted by DFT optimizations... Same-side Ca ring atoms are hydrogenated first. Cb atoms are hydrogenated third and sixth in sequence.... One carboxylate Od atom is hydrogenated and then the seventh, which is necessary for H sticking on the Cc atom (eighth). The existence of the O-H bond turns the Cc-H bond formation from endothermic to highly exothermic as the Cc atom adopts a geometry that is favorable for tetrahedral coordination."

Evidence location: page 3 (Thermodynamics of Hydrogen Addition / Figure 2 description)

## Links

- Source: [[sources/src_0abff73929]]