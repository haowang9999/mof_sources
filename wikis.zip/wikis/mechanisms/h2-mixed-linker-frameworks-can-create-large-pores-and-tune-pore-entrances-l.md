---
title: "Mixed-linker frameworks can create large pores and tune pore entrances; large pores may yield low lo ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_b1552d4a9d]
confidence: high
---


# Mixed-linker frameworks can create large pores and tune pore entrances; large pores may yield low lo ...[TRUNCATED]... 

## Mechanism claim

Mixed-linker frameworks can create large pores and tune pore entrances; large pores may yield low low-pressure uptake but high high-pressure capacity (example: SNU-6 shows low 1 bar uptake at 77 K but high capacity at 70 bar).

## Applicability

- Task: `h2`
- Mechanism type: `linker-mixing / pore entrance tuning`
- Condition scope: `{"gas": "H2", "temperature_K": 77, "pressure_bar": [1, 70], "material_family": "SNU-6 (mixed-linker Cu-based MOF)", "method": "reported experimental"}`

## Positive design features

- mixed-linker approach enables engineering of pore entrances and internal architecture for gas sieving and transport

## Negative design features

- large pores do not guarantee high low-pressure uptake

## Agent design implication

Use mixed-linker frameworks to precisely control pore entrances and internal pore architecture to favor intended pressure regimes; ensure presence of favorable binding sites for low-pressure targets.

## Evidence

> The SNU-6 framework ... pore diameter of 18.2 Å ... As (BET) = 2590 m2·g−1. The hydrogen adsorption capacity at 77 K and 1 bar was relatively low (1.68 wt%); however, at 77 K and 70 bar n_excess and n_total values were 10.0 and 4.87 wt%, respectively.

Evidence location: page 7

## Links

- Source: [[sources/src_b1552d4a9d]]