---
title: "Interwoven / interpenetrated MOF topologies can produce extra-large pores in some designs (literature example)."
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_3b254ae858]
confidence: medium
---


# Interwoven / interpenetrated MOF topologies can produce extra-large pores in some designs (literature example).

## Mechanism claim

Interwoven / interpenetrated MOF topologies can produce extra-large pores in some designs (literature example).

## Applicability

- Task: `pld`
- Mechanism type: `topology → pore size`
- Condition scope: `{"gas": "", "temperature_K": null, "pressure_bar": null, "material_family": "interwoven/interpenetrated MOFs (general; cited example)", "method": "experimental crystallographic design (cited literature)"}`

## Positive design features

- certain interwoven/net topologies yield very large pore cavities (reported in cited study)

## Negative design features

- interpenetration can also reduce accessible porosity in other cases; specific topology-dependent outcomes vary

## Agent design implication

Consider designing interwoven or deliberately interpenetrated topologies when aiming for very large pore cavities, but verify accessible porosity since interpenetration can also reduce accessible pore volume depending on packing.

## Evidence

> "Interwoven metal-organic framework on a periodic minimal surface with extra-large pores." (Chen, B.; Eddaoudi, M.; Hyde, S. T.; Keeffe, M.; Yaghi, O. M. Science 2001, 291, 1021.)

Evidence location: references (17), page 6669

## Links

- Source: [[sources/src_3b254ae858]]