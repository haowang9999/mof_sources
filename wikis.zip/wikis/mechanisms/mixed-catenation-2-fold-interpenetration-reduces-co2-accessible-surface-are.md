---
title: "Catenation (2-fold interpenetration) reduces CO2-accessible surface area compared to noncatenated an ...[TRUNCATED]... "
type: mechanism
tags: [mixed, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_90ad344e79]
confidence: high
---


# Catenation (2-fold interpenetration) reduces CO2-accessible surface area compared to noncatenated an ...[TRUNCATED]... 

## Mechanism claim

Catenation (2-fold interpenetration) reduces CO2-accessible surface area compared to noncatenated analogues; e.g., compound 1 (catenated) has 535 m2/g while compound 2 (noncatenated) has 980 m2/g (CO2, 273 K, NLDFT analysis).

## Applicability

- Task: `mixed`
- Mechanism type: `catenation -> reduced_accessible_porosity`
- Condition scope: `{"gas": "CO2", "temperature_K": 273, "pressure_bar": null, "material_family": "compounds 1 (catenated) and 2 (noncatenated) from Zn paddlewheel pillared MOFs", "method": "experiment; NLDFT analysis of CO2 isotherms"}`

## Positive design features

- noncatenated framework (compound 2) — higher CO2-accessible surface area (980 m2/g)

## Negative design features

- 2-fold catenated framework (compound 1) — lower CO2-accessible surface area (535 m2/g)

## Agent design implication

To maximize CO2-accessible surface area in this family, design frameworks that avoid catenation/interpenetration (e.g., via ligand steric blocking).

## Evidence

> “The porosity of 1-8 was examined using CO2 at 273 K... For example, compounds 1 and 2 gave CO2 accessible surface areas of 535 and 980 m2/g respectively (see Figure 3b). This shows that porosity and sorption properties can be different for the two cases.”

Evidence location: page 3

## Links

- Source: [[sources/src_90ad344e79]]