---
title: "Cisplatin release (inter-pore diffusion) can be slowed either by decreasing pore-limiting diameters  ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_8ce39338bc]
confidence: high
---


# Cisplatin release (inter-pore diffusion) can be slowed either by decreasing pore-limiting diameters  ...[TRUNCATED]... 

## Mechanism claim

Cisplatin release (inter-pore diffusion) can be slowed either by decreasing pore-limiting diameters (increasing the pore-hop / gate-opening energy barrier) or by creating strong, spatially distributed adsorption sites (increasing non-bonded interaction energy barriers); however, narrowing windows hinders uptake from solution, so when post-synthesis encapsulation is required, enhancing MOF–drug adsorption is preferable.

## Applicability

- Task: `pld`
- Mechanism type: `diffusion-limiting (pore-limiting diameter/gating) and adsorption-energy controlled retention`
- Condition scope: `{"gas": "cisplatin in aqueous (loading from solution) or dry contexts", "temperature_K": null, "pressure_bar": null, "material_family": "ZIFs and other porous MOFs", "method": "simulation (GCMC, MD, umbrella sampling, SMD)"}`

## Positive design features

- smaller pore/window diameters (raise pore-hop barrier, slow release)
- strong, dispersed adsorption hotspots (trap/anchor guest and slow inter-pore movement)

## Negative design features

- smaller windows reduce accessibility for encapsulation from solution (may require in situ loading or bond breaking)
- overly strong binding may also impede desired release

## Agent design implication

If loading is performed from solution into a pre-synthesized framework, favor engineering strong adsorption sites (functionalization) rather than simply narrowing windows. If in-situ encapsulation is feasible, narrow windows can be used to trap drug until a triggered degradation event releases it.

## Evidence

> Both solvated and non-solvated simulations show that cisplatin release rates can be controlled by either decreasing the pore limiting diameters or by manipulating framework–cisplatin interaction energies to create strong, dispersed adsorption sites. The latter method is preferable if cisplatin loading is performed from solution into a pre-synthesized framework as weak interaction energies and small pore window diameters will hinder cisplatin uptake.

Evidence location: abstract / page 2; page 12-13

## Links

- Source: [[sources/src_8ce39338bc]]