---
title: "The set of modeled gases in the supplementary material explicitly includes CO2 and H2 (and other gas ...[TRUNCATED]... "
type: mechanism
tags: [co2|h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_90953381a0]
confidence: high
---


# The set of modeled gases in the supplementary material explicitly includes CO2 and H2 (and other gas ...[TRUNCATED]... 

## Mechanism claim

The set of modeled gases in the supplementary material explicitly includes CO2 and H2 (and other gases CH4, N2, H2S, O2, He).

## Applicability

- Task: `co2|h2`
- Mechanism type: `simulation scope (which gases were modeled)`
- Condition scope: `{"gas": "CO2, H2 (among others)", "temperature_K": null, "pressure_bar": null, "material_family": "CoRE-MOFMs / CoRE‑MOF membranes", "method": "molecular simulation (molecular models listed in supplement)"}`

## Positive design features

- Not specified

## Negative design features

- Not specified

## Agent design implication

The screening and descriptor–performance analyses in this work are directly relevant to CO2 and H2 separations because those gases were included among the modeled adsorbates.

## Evidence

> Figure S1: Models of CH4, N2, H2S, O2, CO2, H2 and He.

Evidence location: page 12 (Supplementary Materials list)

## Links

- Source: [[sources/src_90953381a0]]