---
title: "Maximum cisplatin uptake is predominantly governed by the framework's accessible pore volume (geometric capacity)."
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_8ce39338bc]
confidence: high
---


# Maximum cisplatin uptake is predominantly governed by the framework's accessible pore volume (geometric capacity).

## Mechanism claim

Maximum cisplatin uptake is predominantly governed by the framework's accessible pore volume (geometric capacity).

## Applicability

- Task: `pld`
- Mechanism type: `pore-volume (capacity) effect`
- Condition scope: `{"gas": "", "temperature_K": null, "pressure_bar": null, "material_family": "MOFs (tested on UiO-66 family and various ZIFs)", "method": "simulation (pure-component GCMC and complementary methods)"}`

## Positive design features

- larger accessible pore volume enables higher theoretical maximum loading

## Negative design features

- small pore volume limits maximum payload

## Agent design implication

To maximize theoretical loading capacity for cisplatin, prioritize frameworks with large accessible pore volumes (but verify host–guest chemistry and solvent effects as they can reduce realized uptake).

## Evidence

> Pure-component GCMC simulations show that the maximum cisplatin loading depends on the pore volume. (Pages/abstract: multiple references across the manuscript: nGCMC predicts large loadings for frameworks with large pore volumes.)

Evidence location: abstract / page 2; page 12; page 13

## Links

- Source: [[sources/src_8ce39338bc]]