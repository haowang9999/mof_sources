---
title: "Non-bonded energy barriers quantify how dispersed adsorption hotspots impede inter-site movement; bo ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_8ce39338bc]
confidence: high
---


# Non-bonded energy barriers quantify how dispersed adsorption hotspots impede inter-site movement; bo ...[TRUNCATED]... 

## Mechanism claim

Non-bonded energy barriers quantify how dispersed adsorption hotspots impede inter-site movement; bonded energy barriers quantify the framework-deformation cost and whether passage is feasible without bond breaking—both should be considered to understand and engineer release behavior.

## Applicability

- Task: `pld`
- Mechanism type: `decomposition: non-bonded vs bonded contributions to diffusion barriers`
- Condition scope: `{"gas": "cisplatin", "temperature_K": null, "pressure_bar": null, "material_family": "general MOFs (UiO and ZIF examples)", "method": "SMD, umbrella sampling, energy decomposition"}`

## Positive design features

- dispersed adsorption hotspots increase non-bonded barriers and retention
- low bonded barriers indicate passage without bond breakage

## Negative design features

- high bonded barriers can prevent encapsulation or make diffusion impractically slow even if adsorption hotspots are modest

## Agent design implication

When designing carriers, evaluate both non-bonded (adsorption hotspot distribution) and bonded (framework deformation) contributions to diffusion barriers to choose appropriate geometric and chemical strategies for retention and uptake.

## Evidence

> Non-bonded energy barriers provide a measure for the distribution of adsorption hotspots and hence the difficulty for cisplatin to pass between them. Bonded potential energy barriers can be used to determine whether cisplatin can physically pass through the MOF without breaking framework bonds.

Evidence location: page 12; page 7

## Links

- Source: [[sources/src_8ce39338bc]]