---
title: "Hydrogen adsorption (weight %) at 100 bar and 243 K for the MOFs in this dataset is related to MOF t ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_71bcf59437]
confidence: high
---


# Hydrogen adsorption (weight %) at 100 bar and 243 K for the MOFs in this dataset is related to MOF t ...[TRUNCATED]... 

## Mechanism claim

Hydrogen adsorption (weight %) at 100 bar and 243 K for the MOFs in this dataset is related to MOF textural properties (volumetric surface area, void fraction, pore limiting diameter, gravimetric surface area, largest cavity diameter) as captured by PCA; clusters occupy different regions of this decomposed feature space and these regions have differing H2 performance.

## Applicability

- Task: `h2`
- Mechanism type: `correlation (structure-property via textural features)`
- Condition scope: `{"gas": "H2", "temperature_K": 243, "pressure_bar": 100, "material_family": "ToBaCCo-generated MOFs / computational MOFs dataset (~13,000 structures)", "method": "simulation (GCMC) + PCA/clustering"}`

## Positive design features

- volumetric surface area
- void fraction
- pore limiting diameter (PLD)
- gravimetric surface area
- largest cavity diameter (LCD)

## Negative design features

- Not specified

## Agent design implication

Include these textural descriptors when building ML models or selecting MOFs for H2 uptake prediction; use PCA/clustering of these features to identify regions with differing H2 performance.

## Evidence

> The textural properties of the structures were also determined ... GCMC simulations were performed to determine ... hydrogen (243 K and 77 K, 100 bar) adsorption. ... We use the topology of the structures and the textural properties (void fraction, volumetric surface area, gravimetric surface area, limiting pore diameter, largest cavity diameter) for clustering ... PCA generated two components that contained 87.7% of the variance ... Figure 3 shows how adsorption performance, hydrogen at 100 bar and 243 K, is related to the PCs and how the various clusters occupy the space. The differences observed in the MOF textural properties ... drive their performance in various adsorption tasks.

Evidence location: pages 5-8 (Figure 3 referenced)

## Links

- Source: [[sources/src_71bcf59437]]