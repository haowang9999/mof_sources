---
title: "CO2 adsorption at 273 K combined with NLDFT analysis was used as the experimental method to assess p ...[TRUNCATED]... "
type: mechanism
tags: [co2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_90ad344e79]
confidence: high
---


# CO2 adsorption at 273 K combined with NLDFT analysis was used as the experimental method to assess p ...[TRUNCATED]... 

## Mechanism claim

CO2 adsorption at 273 K combined with NLDFT analysis was used as the experimental method to assess porosity (CO2-accessible surface area) of these MOFs.

## Applicability

- Task: `co2`
- Mechanism type: `characterization_protocol`
- Condition scope: `{"gas": "CO2", "temperature_K": 273, "pressure_bar": null, "material_family": "compounds 1-8 (Zn paddlewheel pillared MOFs)", "method": "experiment (CO2 isotherms) and NLDFT"}`

## Positive design features

- NLDFT analysis of CO2 isotherms provides CO2-accessible surface area values reported

## Negative design features

- CO2-based NLDFT analysis is specific to CO2 probing and may not reflect N2-accessible surface area (not discussed here)

## Agent design implication

Use CO2 adsorption at 273 K and analyze isotherms with NLDFT to obtain CO2-accessible surface areas for similar Zn paddlewheel MOFs; be aware results are gas- and temperature-specific.

## Evidence

> “The porosity of 1-8 was examined using CO2 at 273 K... Based on nonlocal density functional theory (NLDFT) analysis (see Table SI-1), all of these compounds have moderate surface areas.”

Evidence location: page 3

## Links

- Source: [[sources/src_90ad344e79]]