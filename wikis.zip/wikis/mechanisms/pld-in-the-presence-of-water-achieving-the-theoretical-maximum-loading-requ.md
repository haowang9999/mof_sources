---
title: "In the presence of water, achieving the theoretical maximum loading requires either pores large enou ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_8ce39338bc]
confidence: high
---


# In the presence of water, achieving the theoretical maximum loading requires either pores large enou ...[TRUNCATED]... 

## Mechanism claim

In the presence of water, achieving the theoretical maximum loading requires either pores large enough to accommodate cisplatin plus its solvation shell (wider cavities, cited as >~8 Å for octahedral cavities) or MOF–cisplatin interactions that are more favorable than cisplatin–solvation interactions.

## Applicability

- Task: `pld`
- Mechanism type: `solvation-driven steric and energetic competition`
- Condition scope: `{"gas": "aqueous environment / solvated cisplatin", "temperature_K": null, "pressure_bar": null, "material_family": "UiO-66 family and ZIFs (simulated examples)", "method": "GCMC (nGCMC) for dry screening; MD and BAR for solvent-explicit evaluation"}`

## Positive design features

- cavities/wider pores (> ~8 Å octahedral cavities reported beneficial)
- strong MOF–cisplatin interaction energies (polar groups/adsorption hotspots)

## Negative design features

- tetrahedral pores (~8 Å) are too small to host cisplatin with its solvation shell
- weak MOF–cisplatin interactions relative to the cisplatin–solvation shell (favoring remaining solvated)

## Agent design implication

When loading from aqueous solution, ensure pore cavities/windows accommodate the drug+solvation shell (prefer wider cavities) or engineer stronger adsorption sites to outcompete solvation.

## Evidence

> To achieve this maximum loading in the presence of water, either the pore size needs to be large enough to occupy both cisplatin and its solvation shell or the MOF–cisplatin interaction must be more favorable than the cisplatin–shell interaction. The authors also note wider cavities (>8 Å) are beneficial because tetrahedral pores (~8 Å) are too small to accommodate cisplatin plus its solvation shell.

Evidence location: abstract / pages 5-6 / page 12

## Links

- Source: [[sources/src_8ce39338bc]]