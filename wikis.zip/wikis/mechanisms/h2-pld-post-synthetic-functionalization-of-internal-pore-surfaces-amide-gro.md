---
title: "Post-synthetic functionalization of internal pore surfaces (amide groups, phenyl substituents, fluor ...[TRUNCATED]... "
type: mechanism
tags: [h2|pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_ff1b0c9d63]
confidence: medium
---


# Post-synthetic functionalization of internal pore surfaces (amide groups, phenyl substituents, fluor ...[TRUNCATED]... 

## Mechanism claim

Post-synthetic functionalization of internal pore surfaces (amide groups, phenyl substituents, fluorination) has been reported to increase H2 adsorption in some MOFs.

## Applicability

- Task: `h2|pld`
- Mechanism type: `enhanced physisorption via modified pore chemistry / electrostatic interactions`
- Condition scope: `{"gas": "H2", "temperature_K": 77, "pressure_bar": null, "material_family": "functionalized MOFs (IRMOF-3 derivatives, DMOF-1-NH2, UMCM-1-NH2, TKL fluorinated MOFs)", "method": "experiment, post-synthetic modification"}`

## Positive design features

- amide functionalization with phenyl rings
- fluorinated pore surfaces
- aromatic ring substituents

## Negative design features

- Not specified

## Agent design implication

Use pore-wall functional groups (e.g., amide-phenyl, aromatic rings, fluorination) to boost H2-framework interactions; consider fluorination to tune micropore diameter and electrostatic interactions for higher uptake.

## Evidence

> Post-synthetic modification resulted in higher H2 adsorption, especially when pore functionalization was undertaken with phenyl ring substituents. ... All of the fluorinated MOFs with different numbers and positions of substituted F-atoms demonstrated high values of As and H2 adsorption. At 65 bar of H2 and 77 K, hydrogen adsorption for TKL-106 and TKL-107 was estimated to be 6.24 and 4.00 wt%, respectively.

Evidence location: page 23-24, Section 4.3.2

## Links

- Source: [[sources/src_ff1b0c9d63]]