---
title: "Guest molecular kinetic diameters and explicit molecular models were specified and used (I2: 3.34 Å  ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_fc58db74fa]
confidence: medium
---


# Guest molecular kinetic diameters and explicit molecular models were specified and used (I2: 3.34 Å  ...[TRUNCATED]... 

## Mechanism claim

Guest molecular kinetic diameters and explicit molecular models were specified and used (I2: 3.34 Å spherical; CH3I: 4.23 Å all-atom; H2O: TIP3P 2.64 Å; N2: 3.04 Å; O2: 3.10 Å), informing size-accessibility and modeling.

## Applicability

- Task: `pld`
- Mechanism type: `molecular size (kinetic diameter) influencing adsorption modelling`
- Condition scope: `{"gas": "I2, CH3I, H2O, N2, O2", "temperature_K": null, "pressure_bar": null, "material_family": "MOFs", "method": "GCMC simulation / force-field modelling"}`

## Positive design features

- explicit kinetic diameter values and force-field models for guests

## Negative design features

- Not specified

## Agent design implication

Compare guest kinetic diameters to MOF PLD/LCD when screening materials: molecules with kinetic diameters near or below PLD are likely accessible; larger molecules may be excluded or strongly size-constrained.

## Evidence

> “The guest I2 molecules had a kinetic diameter of 3.34 Å and were modeled as spherical... The CH3I molecules with a kinetic diameter of 4.23 Å were represented by an explicit all-atom model... The H2O molecules (kinetic diameter of 2.64 Å) were mimicked by the transferable intermolecular potential (TIP3P) model... Both N2 and O2 molecules (kinetic diameter of 3.04 Å and 3.10 Å, respectively) were modeled by a three-site model...”

Evidence location: STAR+METHODS, METHOD DETAILS (page ~11)

## Links

- Source: [[sources/src_fc58db74fa]]