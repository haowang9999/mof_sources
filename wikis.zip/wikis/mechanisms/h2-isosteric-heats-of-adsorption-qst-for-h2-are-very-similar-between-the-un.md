---
title: "Isosteric heats of adsorption (Qst) for H2 are very similar between the undoped and doped frameworks ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_b0ea8c70ab]
confidence: medium
---


# Isosteric heats of adsorption (Qst) for H2 are very similar between the undoped and doped frameworks ...[TRUNCATED]... 

## Mechanism claim

Isosteric heats of adsorption (Qst) for H2 are very similar between the undoped and doped frameworks over the measured loading range (from fits to 77 and 87 K isotherms), indicating that enhanced uptake is not due to stronger H2 binding at dopant cation sites.

## Applicability

- Task: `h2`
- Mechanism type: `adsorption energetics inference (experimental)`
- Condition scope: `{"gas": "H2", "temperature_K": "derived from 77 and 87 K isotherms (Qst obtained by virial fits across that range)", "pressure_bar": null, "material_family": "1 and 1·M (M = Li, Na, K)", "method": "experiment (isosteric heats from 77 and 87 K isotherms via virial fit)"}`

## Positive design features

- enhanced uptake without higher Qst

## Negative design features

- absence of dramatically higher Qst upon doping (suggests dopants are not acting as exposed strong binding sites)

## Agent design implication

Do not assume that alkali-metal doping of reducible ligands in catenated MOFs will increase H2 binding energy; enhanced uptake may arise from structural/porosity changes rather than stronger site-specific binding.

## Evidence

> Values were obtained by fitting a virial-type equation to the 77 and 87 K H2 adsorption isotherms... the more striking observation (Figure 4) is just how closely isosteric heats agree for 1, 1·Li, 1·Na, and 1·K over the entire range of H2 pressures examined. We conclude from the above that direct hydrogen/dopant-cation interactions are not responsible for the enhanced H2 uptake illustrated in Figure 3.

Evidence location: Results and Discussion (section 3.3), Figure 4

## Links

- Source: [[sources/src_b0ea8c70ab]]