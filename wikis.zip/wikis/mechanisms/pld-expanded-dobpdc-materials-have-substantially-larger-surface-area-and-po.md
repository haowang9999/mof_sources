---
title: "Expanded DOBPDC materials have substantially larger surface area and pore diameters than MOF-74 (exa ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_20dae1036b]
confidence: high
---


# Expanded DOBPDC materials have substantially larger surface area and pore diameters than MOF-74 (exa ...[TRUNCATED]... 

## Mechanism claim

Expanded DOBPDC materials have substantially larger surface area and pore diameters than MOF-74 (example cited: Mg/DOBPDC SBET ≈ 2,451 m2·g−1 and average pore diameter ≈ 21 Å vs Mg-MOF-74 SBET ≈ 816 m2·g−1), enabling accommodation of longer/bulkier alkyl- or diamine functional groups and enabling cooperative adsorption with less steric loss of capacity than in narrow pores.

## Applicability

- Task: `pld`
- Mechanism type: `pore-size enabled accommodation of larger functional groups (steric/accessibility effect)`
- Condition scope: `{"gas": "", "temperature_K": null, "pressure_bar": null, "material_family": "Mg/DOBPDC vs Mg-MOF-74 (expanded vs original MOF-74)", "method": "experiment (reported surface areas) and simulation considerations"}`

## Positive design features

- larger pores allow grafting of longer alkyl/diamines and can restore or enhance low-pressure uptake after functionalization
- enables cooperative chain mechanisms without as large a loss of accessible void fraction as in narrower MOF-74

## Negative design features

- expanded pores may alter bare-framework capacity (bare DOBPDC can have lower capacity than narrow MOF-74) and outcomes depend on exact amine loading and steric packing

## Agent design implication

Select expanded-linker DOBPDC analogues when planning to attach longer alkyl- or diamine functional groups to exploit cooperative adsorption mechanisms; verify pore diameter and surface area metrics and model partial/full functionalization cases.

## Evidence

> “For instance, Mg/DOBPDC has a surface area (SBET) of 2,451 m2·g−1 greater than the 816 m2·g−1 for Mg-MOF-74... The enlarged pores provide enough space to accommodate longer alkylamines onto the open metal sites of the framework compared to M-MOF-74 materials.” | “As shown... the capacities of the bare materials at typical flue gas conditions are reduced by using the expanded hexagonal version (M/DOBPDC), however... -en and -mmen versions of Mg/DOBPDC present a capacity of ∼3.6 mmol·g−1 at 15 kPa, 15% higher than the one achieved with the bare material.”

Evidence location: page 3 (Adsorbent Structures / Introduction); page 6 (Results)

## Links

- Source: [[sources/src_20dae1036b]]