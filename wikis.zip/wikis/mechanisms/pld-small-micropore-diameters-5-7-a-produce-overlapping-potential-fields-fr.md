---
title: "Small micropore diameters (~5–7 Å) produce overlapping potential fields from opposing pore walls, in ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_b1552d4a9d]
confidence: high
---


# Small micropore diameters (~5–7 Å) produce overlapping potential fields from opposing pore walls, in ...[TRUNCATED]... 

## Mechanism claim

Small micropore diameters (~5–7 Å) produce overlapping potential fields from opposing pore walls, increasing H2 interaction energy and enabling significant adsorption even when BET surface area is modest.

## Applicability

- Task: `pld`
- Mechanism type: `pore-size-dependent physisorption (potential overlap)`
- Condition scope: `{"gas": "H2", "temperature_K": [77, 298], "pressure_bar": [1, "examples up to tens of bar"], "material_family": "various MOFs with small channels (examples cited include frameworks with ~7×6 Å channels or average 4.5 Å pores)", "method": "experiment"}`

## Positive design features

- higher interaction energy due to potential overlap; can boost RT performance
- examples show notable uptake with modest A if pore diameter in ~5–7 Å range

## Negative design features

- very small pores may limit total storage if free volume becomes too low

## Agent design implication

Design micropores with diameters in the ~5–7 Å range (control linker length, interpenetration and pillar selection) to exploit potential overlap and improve room-temperature uptake, while monitoring free volume.

## Evidence

> Small diameter pores enable energy potentials to overlap between opposing walls, resulting in higher interaction energy with H2. Examples: frameworks with ~7×6 Å channels and another with average pore diameter 4.5 Å showed notable uptake despite modest BET area.

Evidence location: page 10

## Links

- Source: [[sources/src_b1552d4a9d]]