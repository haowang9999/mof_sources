---
title: "Numerical resolution: with a grid spacing of 0.1 Å the upper bound on uncertainty in calculated diam ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_97052fb350]
confidence: high
---


# Numerical resolution: with a grid spacing of 0.1 Å the upper bound on uncertainty in calculated diam ...[TRUNCATED]... 

## Mechanism claim

Numerical resolution: with a grid spacing of 0.1 Å the upper bound on uncertainty in calculated diameters is ~0.17 Å; the grid-based algorithm is efficient (large unit cells minutes on single processor).

## Applicability

- Task: `pld`
- Mechanism type: `computational method detail (numerical resolution / uncertainty)`
- Condition scope: `{"gas": "geometric probe spheres", "temperature_K": null, "pressure_bar": null, "material_family": "MOFs and crystalline porous materials", "method": "simulation (grid-based geometric algorithm)"}`

## Positive design features

- Efficient: large unit cells analyzed in minutes on a single processor; small unit cells in seconds
- Uncertainty quantifiable and reducible by decreasing grid spacing

## Negative design features

- Finite grid spacing introduces well-defined uncertainty (upper bound ≈±3·d for orthogonal cells; 0.17 Å stated for d=0.1 Å)
- Assumes fixed framework atomic positions (does not inherently capture flexibility)

## Agent design implication

When implementing PLD/LCD calculations for screening, use grid spacing ≈0.1 Å for fast analysis (expect ±0.17 Å uncertainty) and refine grid spacing for materials of particular interest; use CSD/Bondi/Pauling vdW radii for consistent framework atom sizing.

## Evidence

> Our calculation begins by dividing a crystallographic unit cell into discrete grid points ... We use the van der Waals (vdW) radii defined by the Cambridge Structural Database (CSD) to assign a size to each framework atom. ... The upper bound on the uncertainty in the calculated diameters can be estimated, for an orthogonal unit cell, to be ±3·d, where d is the grid spacing. Use of a grid spacing of 0.1 Å, as we do for the MOF calculations reported below, is therefore associated with an uncertainty of 0.17 Å.

Evidence location: page 2-3 (section 2.1 Pore Size Characterization)

## Links

- Source: [[sources/src_97052fb350]]