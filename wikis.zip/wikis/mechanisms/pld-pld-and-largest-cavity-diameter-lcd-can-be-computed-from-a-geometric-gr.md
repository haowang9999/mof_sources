---
title: "PLD and largest cavity diameter (LCD) can be computed from a geometric grid analysis of rigid MOF fr ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_97052fb350]
confidence: high
---


# PLD and largest cavity diameter (LCD) can be computed from a geometric grid analysis of rigid MOF fr ...[TRUNCATED]... 

## Mechanism claim

PLD and largest cavity diameter (LCD) can be computed from a geometric grid analysis of rigid MOF frameworks; the authors' algorithm places spherical probes on a discrete grid, uses van der Waals radii and Hoshen-Kopelman labeling to identify spanning clusters and topologies.

## Applicability

- Task: `pld`
- Mechanism type: `computational geometric pore-mapping / accessibility`
- Condition scope: `{"gas": "geometric probe spheres (used to represent adsorbates)", "temperature_K": null, "pressure_bar": null, "material_family": "MOFs and crystalline porous materials", "method": "simulation (grid-based geometric algorithm + Hoshen-Kopelman)"}`

## Positive design features

- identifies PLD and LCD for large collections of MOFs
- captures cases where accessibility differs from previously reported values

## Negative design features

- assumes rigid framework
- requires cleaned crystal structures (solvent removed; disordered/missing-atom structures excluded)

## Agent design implication

Use automated geometric grid analysis (PLD and LCD) as an initial filter to classify MOF pore architectures and identify materials with pore apertures in target size ranges for kinetic sieving.

## Evidence

> To demonstrate the value of our methods for characterizing MOFs, we examined the collection of 774 MOFs... The calculated pore-limiting diameter and largest cavity size for the 504 MOFs we have considered are summarized in Figure 4. A large number of these materials are seen to be essentially nonporous, with pore-limiting diameters smaller than 2 Å... ∼86% of the MOFs have largest cavity sizes that are e2.5 Å larger than the pore-limiting diameter.

Evidence location: page 5-6, section 3.2

## Links

- Source: [[sources/src_97052fb350]]