---
title: "Lanthanide cations immobilized within Cr(III)- and Zr(IV)-based MOFs commonly adsorb as inner-sphere ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_c88d608b3b]
confidence: high
---


# Lanthanide cations immobilized within Cr(III)- and Zr(IV)-based MOFs commonly adsorb as inner-sphere ...[TRUNCATED]... 

## Mechanism claim

Lanthanide cations immobilized within Cr(III)- and Zr(IV)-based MOFs commonly adsorb as inner-sphere complexes at metal-oxo cluster sites (shared oxygens at Cr oxo-trimers and Zr hexanuclear clusters), and this inner-sphere cluster binding occurs irrespective of simple −NH2 linker functionalization.

## Applicability

- Task: `pld`
- Mechanism type: `site-binding (inner-sphere coordination to metal-oxo clusters)`
- Condition scope: `{"gas": "aqueous (Ln3+ in buffered solution, e.g., pH 6.6, 100 mM HEPES where specified)", "temperature_K": null, "pressure_bar": null, "material_family": "Cr-MIL-101; UiO-66; UiO-68 and -NH2 derivatives", "method": "experiment (XAFS, adsorption, TGA)"}`

## Positive design features

- presence of metal-oxo clusters (Cr(III) oxo-trimers, Zr(IV) hexanuclear clusters) provides inner-sphere binding sites
- XAFS evidence indicates identical first Lu−O shell across UiO-66/UiO-68 variants and inner-sphere Lu binding at cluster oxygens
- Thermogravimetric analysis and XAFS show Lu3+ binding at bridging oxygens in Cr-MIL-101 even when defect signatures are similar

## Negative design features

- simple −NH2 functionalization does not appear to directly coordinate Ln (per XAFS) and therefore does not prevent cluster-site coordination

## Agent design implication

Ensure metal-oxo cluster oxygens are exposed/accessible when designing MOFs to promote inner-sphere lanthanide binding; do not assume simple amine linker functionalization will block cluster-site adsorption.

## Evidence

> "In the Cr(III)- and Zr(IV)-based MOFs, Ln adsorb as inner-sphere complexes at the metal oxo clusters, regardless of whether the organic linkers are decorated with amino groups."; "The first Lu−O shell is identical for the four MOFs: UiO-66, UiO-66-NH2-ideal, UiO-66-NH2-defective, and UiO-68-NH2... This indicates that the decrease in the window apertures and pore diameters in UiO-66 vs UiO-68 has no impact on the first coordination shell of Lu3+, at least at a level that could be detected spectroscopically."; "thermogravimetric characterization indicates that the defect characteristics of Cr-MIL-101 and Cr-MIL-101-NH2 is similar. This indicates that Lu3+ adsorption does not require a defect site (missing linker), and Lu3+ can bind at the bridging oxygen sites, as well as defect sites."

Evidence location: page 1 Abstract; pages 6-7 Section 3.4; page 6 Section 3.3

## Links

- Source: [[sources/src_c88d608b3b]]