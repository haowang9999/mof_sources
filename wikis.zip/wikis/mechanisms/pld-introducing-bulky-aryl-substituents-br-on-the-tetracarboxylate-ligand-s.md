---
title: "Introducing bulky aryl substituents (Br) on the tetracarboxylate ligand suppresses catenation (inter ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_90ad344e79]
confidence: high
---


# Introducing bulky aryl substituents (Br) on the tetracarboxylate ligand suppresses catenation (inter ...[TRUNCATED]... 

## Mechanism claim

Introducing bulky aryl substituents (Br) on the tetracarboxylate ligand suppresses catenation (interpenetration) in these Zn paddlewheel pillared MOFs.

## Applicability

- Task: `pld`
- Mechanism type: `steric_blocking -> suppression_of_catenation`
- Condition scope: `{"gas": "", "temperature_K": null, "pressure_bar": null, "material_family": "Zn2(Lbp)(Lta) pillared paddlewheel MOFs assembled from tetraacid ligands L5 (aryl-H) or L6 (aryl-Br) and dipyridyl pillars", "method": "experiment"}`

## Positive design features

- L6 (tetracarboxylate bearing aryl-Br substituents) — noncatenated products reported

## Negative design features

- L5 (tetracarboxylate bearing aryl-H substituents) — 2-fold catenated products reported

## Agent design implication

For Zn paddlewheel pillared MOFs using tetratopic carboxylate ligands, substitute aryl-H positions with bulky groups (e.g., Br) on the tetraacid to sterically block formation of interpenetrated networks and favor noncatenated frameworks with larger accessible cavities.

## Evidence

> “We therefore redesigned ligand L5, expecting to suppress catenation by introducing additional steric blockage in the xy-plane. We reasoned that ligand L6, bearing two large bromine atoms instead of hydrogen atoms (as in L5), would suppress the formation of interpenetrated structures... Indeed, the approach using L6 produced only noncatenated materials, where under the identical conditions L5 produced 2-fold catenated structures... Thus a change from aryl-H moieties to aryl-Br furnished on the tetraacid ligand is sufficient to suppress an undesired catenation by contracting the diamond shaped opening (Scheme 2).”

Evidence location: page 2

## Links

- Source: [[sources/src_90ad344e79]]