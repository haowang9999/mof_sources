---
title: "Flexible linkers can produce gate-opening (stepwise) adsorption at low pressures and tend to give lo ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_ff1b0c9d63]
confidence: high
---


# Flexible linkers can produce gate-opening (stepwise) adsorption at low pressures and tend to give lo ...[TRUNCATED]... 

## Mechanism claim

Flexible linkers can produce gate-opening (stepwise) adsorption at low pressures and tend to give low H2 capacities at ambient temperature despite measurable gating behavior (examples: M-URJC-n series).

## Applicability

- Task: `h2`
- Mechanism type: `flexibility-induced gate-opening/breathing`
- Condition scope: `{"gas": "H2", "temperature_K": [77, 298], "pressure_bar": ["up to 18 bar at 77 K", "up to 170 bar at 298 K (measurements reported)"], "material_family": "flexible/dynamic linker MOFs (M-URJC-n)", "method": "experiment; review"}`

## Positive design features

- gate-opening adsorption at low pressures
- dynamic/breathing behavior shifts adsorption to higher pressures

## Negative design features

- low absolute H2 capacities at 298 K (e.g., 0.12–0.14 wt% at 298 K and 170 bar for M-URJC-n)

## Agent design implication

Use flexible/dynamic linkers when you want pressure-triggered (gate-opening) adsorption behavior to target adsorption at specific pressures; expect gating to shift uptake to higher pressures but verify actual deliverable capacity at target temperature/pressure.

## Evidence

> The hydrogen adsorption analysis of three flexible sulfur-containing MOF materials named M-URJC-n ... showed that these compounds display a gate-opening type adsorption mechanism at low pressures, attributed to the flexible nature of the ligand. The hydrogen adsorption capacities ... were 2.81, 2.21, and 1.99 wt% ... at 77 K and up to 18 bar, and 0.12, 0.14, and 0.13 wt% at 298 K and 170 bar, due to the presence of flexible ligands.

Evidence location: page 17

## Links

- Source: [[sources/src_ff1b0c9d63]]