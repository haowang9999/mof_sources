---
title: "Eley–Rideal abstraction (gas-phase H + adsorbed H → H2) has very small or zero barriers (reported 0– ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_0abff73929]
confidence: high
---


# Eley–Rideal abstraction (gas-phase H + adsorbed H → H2) has very small or zero barriers (reported 0– ...[TRUNCATED]... 

## Mechanism claim

Eley–Rideal abstraction (gas-phase H + adsorbed H → H2) has very small or zero barriers (reported 0–0.11 eV depending on hydrogenation state), making recombination effectively instantaneous at room temperature for many configurations; this limits penetration depth and reverts overhydrogenated linkers toward the thermodynamic minimum.

## Applicability

- Task: `h2`
- Mechanism type: `kinetics / recombination`
- Condition scope: `{"gas": "atomic H (gas-phase) + adsorbed H", "temperature_K": 300, "pressure_bar": null, "material_family": "IRMOF-1 linker (BDC)", "method": "DFT internal reaction coordinate calculations"}`

## Positive design features

- Quantifies very small ER barriers (0–0.11 eV) and identifies their functional consequences

## Negative design features

- Fast ER recombination near pore entrances can prevent deep penetration of atomic H into pores
- ER reactions will undo overhydrogenation and limit achievable filling depth

## Agent design implication

Mitigate ER recombination (for example by reducing labile O–H site population, increasing H2 pressure, altering flux/distribution of atomic H, or creating alternate diffusion paths) to increase net spillover storage and penetration depth.

## Evidence

> "The abstraction reactions of the structures with one, three, and five H atoms were found to be completely barrierless, while the barriers of the structures with two, four, and six H atoms were 0.04, 0.11, and 0.06 eV, respectively. Such energy barriers are negligible at room temperature.... (a) This mechanism may be responsible for decreased penetration of atomic H into the MOF pores.... (b) The ER abstraction reactions would be responsible for quickly reverting overhydrogenated linkers (linkers with more that six adsorbed H atoms for IRMOF-1 linkers) back to the thermodynamic minimum with respect to H2."

Evidence location: page 6

## Links

- Source: [[sources/src_0abff73929]]