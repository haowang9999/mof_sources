---
title: "A Cu-rich bimetallic MxM1−x(BDC)TED0.5 composition (specifically Cu0.625Ni0.375(BDC)TED0.5) exhibits ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_340141308b]
confidence: high
---


# A Cu-rich bimetallic MxM1−x(BDC)TED0.5 composition (specifically Cu0.625Ni0.375(BDC)TED0.5) exhibits ...[TRUNCATED]... 

## Mechanism claim

A Cu-rich bimetallic MxM1−x(BDC)TED0.5 composition (specifically Cu0.625Ni0.375(BDC)TED0.5) exhibits very high specific surface area (reported 1952 m2/g) and the highest measured hydrogen uptake of 2.04 wt% at 77 K and 1 bar — 22% higher than monometallic Ni(BDC)TED0.5.

## Applicability

- Task: `h2`
- Mechanism type: `empirical measurement / composition-driven performance`
- Condition scope: `{"gas": "H2", "temperature_K": 77, "pressure_bar": 1, "material_family": "MxM1−x(BDC)TED0.5 (example: Cu0.625Ni0.375(BDC)TED0.5)", "method": "experiment (gas adsorption, BET)"}`

## Positive design features

- Cu0.625Ni0.375 composition
- very high specific surface area (1952 m2/g) as reported for that composition

## Negative design features

- monometallic Ni(BDC)TED0.5 has lower uptake (baseline)

## Agent design implication

On the M(BDC)TED0.5 platform, testing Cu/Ni bimetallic ratios (especially Cu-rich compositions) is a promising route to increase SSA and measured H2 uptake at 77 K / 1 bar.

## Evidence

> Typically, among the bimetal MOFs, Cu0.625Ni0.375(BDC)-TED0.5 shows the largest specific surface area of 1952 m2/g and the highest hydrogen adsorption capacity of 2.04 wt%, which is 22% higher than that of Ni(BDC)TED0.5.

Evidence location: page 10-11 (Results/Discussion); page 1 (Abstract)

## Links

- Source: [[sources/src_340141308b]]