---
title: "O2/N2 permselectivity decreases with increasing PLD and approaches an equilibrium (low permselectivi ...[TRUNCATED]... "
type: mechanism
tags: [pld|mixed, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_90953381a0]
confidence: high
---


# O2/N2 permselectivity decreases with increasing PLD and approaches an equilibrium (low permselectivi ...[TRUNCATED]... 

## Mechanism claim

O2/N2 permselectivity decreases with increasing PLD and approaches an equilibrium (low permselectivity) for large PLD (size similarity reduces selectivity).

## Applicability

- Task: `pld|mixed`
- Mechanism type: `size-similarity leading to decreased selectivity at larger pores`
- Condition scope: `{"gas": "O2/N2", "temperature_K": null, "pressure_bar": null, "material_family": "CoRE-MOFMs / CoRE‑MOF membranes", "method": "simulation"}`

## Positive design features

- Not specified

## Negative design features

- Increasing PLD reduces O2/N2 permselectivity; large PLD -> low selectivity

## Agent design implication

To preserve O2/N2 selectivity, keep PLD relatively small; large apertures reduce the ability to differentiate similarly sized gases like O2 and N2.

## Evidence

> "The permselectivity of O2/N2 decreased with increasing PLD, and ﬁnally approached equilibrium... The results demonstrated that gas molecules reached a stable state exhibiting low permselectivity when PLD increased."

Evidence location: page 6

## Links

- Source: [[sources/src_90953381a0]]