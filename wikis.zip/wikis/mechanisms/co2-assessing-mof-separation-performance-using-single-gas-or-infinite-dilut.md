---
title: "Assessing MOF separation performance using single‑gas or infinite‑dilution adsorption data can be mi ...[TRUNCATED]... "
type: mechanism
tags: [co2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_1fa85425f9]
confidence: high
---


# Assessing MOF separation performance using single‑gas or infinite‑dilution adsorption data can be mi ...[TRUNCATED]... 

## Mechanism claim

Assessing MOF separation performance using single‑gas or infinite‑dilution adsorption data can be misleading: materials suggested to be promising based on pure‑gas data are likely to underperform in real applications under the presence of gas mixtures because interactions between multiple gases strongly change the adsorbent’s behavior; industrial operating pressures are generally well above 1 bar.

## Applicability

- Task: `co2`
- Mechanism type: `adsorption / competitive adsorption`
- Condition scope: `{"gas": "gas mixtures (e.g., CO2/N2, CO2/CH4), realistic/humid streams", "temperature_K": null, "pressure_bar": "often much greater than infinite dilution; industry generally >1 bar", "material_family": "MOFs (real and hMOFs)", "method": "simulation (mixture GCMC advised)"}`

## Positive design features

- Not specified

## Negative design features

- single‑gas adsorption data
- infinite‑dilution condition

## Agent design implication

Do not rely solely on single‑component or infinite‑dilution adsorption data when screening MOFs for CO2 separations. Include mixture adsorption simulations at pressures representative of the target process (e.g., >1 bar) to capture competitive adsorption effects.

## Evidence

> "Assessing mixture separation performance of MOFs using pure gas adsorption data can be misleading because materials suggested to be promising based on pure gas data are likely to underperform in real applications under the presence of gas mixtures since interactions between multiple gases strongly change the adsorbent’s behavior (Basdogan et al., 2015)." and "operating condition pressure of CO2 separation applications in industry are generally well above 1 bar." (page 3).

Evidence location: page 3 (Large-scale screening of MOFs)

## Links

- Source: [[sources/src_1fa85425f9]]