---
title: "DFT calculations (periodic, 'dry' cells with limited explicit water) for UiO-66 models indicate that ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_c88d608b3b]
confidence: medium
---


# DFT calculations (periodic, 'dry' cells with limited explicit water) for UiO-66 models indicate that ...[TRUNCATED]... 

## Mechanism claim

DFT calculations (periodic, 'dry' cells with limited explicit water) for UiO-66 models indicate that multidentate PAA coordination to a lanthanide (Gd3+ in the model) is much more favorable than monodentate coordination to a Zr-oxo cluster; variation in protonation of a POH altered binding energy by ~0.14 eV, which is small relative to the computed site-to-site energy difference.

## Applicability

- Task: `pld`
- Mechanism type: `computed binding-energy comparison (functional group vs cluster site)`
- Condition scope: `{"gas": "modeling context (periodic DFT under low explicit-solvent conditions)", "temperature_K": null, "pressure_bar": null, "material_family": "UiO-66 model (periodic DFT)", "method": "DFT simulation (periodic VASP, PBE), 'dry' cell with a few waters"}`

## Positive design features

- multidentate phosphonate linker sites can be substantially stronger binders than monodentate oxo-cluster sites in the model
- minor protonation-state changes (reprotonation of POH) had only ~0.14 eV effect on computed binding energy

## Negative design features

- simulations omit an explicit bulk aqueous reservoir and use limited explicit waters — quantitative aqueous energetics may differ
- DFT results are thus best viewed as qualitative ranking guidance rather than absolute aqueous binding energies

## Agent design implication

Use DFT as qualitative guidance that multidentate chelating linker chemistries (e.g., phosphonates) can outcompete monodentate cluster sites; always validate predicted energetic orderings in full aqueous experiments.

## Evidence

> "In case (a), we have tested two different protonation states and have found that reprotonation of a POH group from one of the added H2O molecules decreases the Gd3+ binding energy by 0.14 eV. This variation is noted as an error bar in Section 3.5; it is far less than the energy difference between cases (a) and (b)."; "The current approach instead aims to conduct relatively computationally inexpensive DFT calculations under 'dry' conditions, with a few water molecules added..."

Evidence location: page 3 Molecular Simulations (Section 3.5 notes)

## Links

- Source: [[sources/src_c88d608b3b]]