---
title: "Pore geometry metrics (PLD, LCD) were computed using Zeo++ and used as structural descriptors for the MOFs in screening."
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_fc58db74fa]
confidence: high
---


# Pore geometry metrics (PLD, LCD) were computed using Zeo++ and used as structural descriptors for the MOFs in screening.

## Mechanism claim

Pore geometry metrics (PLD, LCD) were computed using Zeo++ and used as structural descriptors for the MOFs in screening.

## Applicability

- Task: `pld`
- Mechanism type: `geometric / pore-metric descriptor`
- Condition scope: `{"gas": "general (structure property independent of specific gas)", "temperature_K": null, "pressure_bar": null, "material_family": "MOFs (set of studied MOFs)", "method": "Zeo++ pore analysis"}`

## Positive design features

- PLD and LCD computed and used as primary structural descriptors

## Negative design features

- Not specified

## Agent design implication

Use computed PLD and LCD (e.g., from Zeo++) as primary screening descriptors for candidate MOFs when considering molecular accessibility and pore-size-dependent adsorption.

## Evidence

> “The structure features of the aforementioned MOFs, including pore limiting diameter (PLD) and largest cavity diameter (LCD), were calculated using the open-source package Zeo++.49”

Evidence location: STAR+METHODS, METHOD DETAILS (page ~11)

## Links

- Source: [[sources/src_fc58db74fa]]