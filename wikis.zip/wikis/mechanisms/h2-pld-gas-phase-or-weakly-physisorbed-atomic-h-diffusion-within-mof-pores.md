---
title: "Gas-phase or weakly physisorbed atomic H diffusion within MOF pores is a plausible and likely transp ...[TRUNCATED]... "
type: mechanism
tags: [h2|pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_0abff73929]
confidence: medium
---


# Gas-phase or weakly physisorbed atomic H diffusion within MOF pores is a plausible and likely transp ...[TRUNCATED]... 

## Mechanism claim

Gas-phase or weakly physisorbed atomic H diffusion within MOF pores is a plausible and likely transport route for spillover (especially in defective/mesoporous structures) and qualitatively explains the necessity of pore defects/entrances for deep penetration.

## Applicability

- Task: `h2|pld`
- Mechanism type: `transport_mechanism_gas_phase`
- Condition scope: `{"gas": "atomic H (gas-phase or weakly physisorbed)", "temperature_K": null, "pressure_bar": null, "material_family": "MOFs (discussion centered on IRMOF-1 and defective networks)", "method": "DFT barrier analysis + argumentation; references to MD and experiments"}`

## Positive design features

- Can transfer H atoms between dissimilar surfaces without encountering very high chemisorbed diffusion barriers
- Explains enhanced uptake in partially collapsed / mesoporous MOF structures

## Negative design features

- Requires generation and supply of airborne atomic H from catalysts (may be rate-limiting)
- Relies on sufficient pore entrances/defects to admit gas-phase H

## Agent design implication

Enable gas-phase or weakly physisorbed H transport by creating entrance channels/mesopores and distributing catalysts to allow atomic H to be emitted into pore volumes; do not assume chemisorbed diffusion will achieve long-range transfer.

## Evidence

> "During hydrogen spillover, atomic hydrogen cannot migrate in the chemisorbed state in the pore network but rather diffuses in the gas phase." "Diﬀusion of atomic H in the MOF is greatly assisted by pore defects, and spillover would be plugged in ideal MOF structures." "The gas-phase H spillover can naturally explain the transfer of H atoms between dissimilar surfaces, which would require very high energy barriers if H diffuses between them in chemisorbed form."

Evidence location: page 1 (abstract); page 3 (H Diffusion discussion); page 5-6 (discussion)

## Links

- Source: [[sources/src_0abff73929]]