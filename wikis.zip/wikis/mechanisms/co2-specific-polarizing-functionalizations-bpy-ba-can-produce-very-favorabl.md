---
title: "Specific polarizing functionalizations (BPY, BA) can produce very favorable CO2 interactions giving  ...[TRUNCATED]... "
type: mechanism
tags: [co2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_a318a71841]
confidence: high
---


# Specific polarizing functionalizations (BPY, BA) can produce very favorable CO2 interactions giving  ...[TRUNCATED]... 

## Mechanism claim

Specific polarizing functionalizations (BPY, BA) can produce very favorable CO2 interactions giving high CO2 working capacity but simultaneously increase rigidity/multibonding that hinders diffusion and reduces CO2 productivity.

## Applicability

- Task: `co2`
- Mechanism type: `functional-group specific enthalpy and kinetic effects (interaction strength vs diffusion)`
- Condition scope: `{"gas": "CO2 (and C2H2 in competition)", "temperature_K": null, "pressure_bar": null, "material_family": "BPY and BA functionalizations within the studied MOF series", "method": "isosteric enthalpy fits, breakthrough experiments"}`

## Positive design features

- BPY: favorable CO2 interaction -> higher CO2 working capacity

## Negative design features

- BPY/BA: multibonds and increased rigidity -> low diffusion and diffusion-limited separation (short/less-distinct breakthrough plateaus)

## Agent design implication

Use BPY-like polarizing functional groups to boost CO2 capacity if capacity is prioritized, but expect diffusion limitations; verify productivity with breakthrough tests and consider complementary structural changes to mitigate kinetic penalties.

## Evidence

> the low αAC can be attributed to the very favorable interaction of the BPY functionalization with CO2, resulting in significantly lower ΔH differences of the adsorptives, along with a small increase in the available pore volume and low diffusion. These factors also lead to the highest observed CO2 working capacity. ... multibonds in BA and BPY and the accompanying increased rigidity and diffusion hinderance have a pronounced effect on high-purity CO2 productivity on both materials. They have short and less-distinct CO2 breakthrough plateaus, meaning diffusion-limited separation efficiencies

Evidence location: page 7 (first and second paragraphs)

## Links

- Source: [[sources/src_a318a71841]]