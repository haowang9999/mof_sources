---
title: "Secondary building units (SBUs), nets and bonding/topology provide a modular basis for designing por ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_71bcf59437]
confidence: medium
---


# Secondary building units (SBUs), nets and bonding/topology provide a modular basis for designing por ...[TRUNCATED]... 

## Mechanism claim

Secondary building units (SBUs), nets and bonding/topology provide a modular basis for designing porosity (PLD/LCD) and robust MOFs; isoreticular/reticular approaches allow systematic control of pore size and functionality (literature-cited).

## Applicability

- Task: `pld`
- Mechanism type: `building-block / topological design enabling pore architecture control (literature-cited)`
- Condition scope: `{"gas": null, "temperature_K": null, "pressure_bar": null, "material_family": "MOFs (reticular synthesis literature)", "method": "modular synthetic design / reticular chemistry (cited)"}`

## Positive design features

- use of secondary building units (SBUs)
- choice of nets/topology
- isoreticular linker/functionality tuning

## Negative design features

- Not specified

## Agent design implication

Design MOF pore apertures and PLD/LCD by selecting SBUs and nets (topology) and by isoreticular changes (linker length/functionalization) to achieve target porosity and robustness; use computational screening to predict effects.

## Evidence

> "Modular chemistry: secondary building units as a basis for the design of highly porous and robust metal-organic carboxylate frameworks."; "Systematic design of pore size and functionality in isoreticular MOFs and their application in methane storage."; "Secondary building units, nets and bonding in the chemistry of metal-organic frameworks." (cited references in paper)

Evidence location: page 16-17, references (16), (18), (30)

## Links

- Source: [[sources/src_71bcf59437]]