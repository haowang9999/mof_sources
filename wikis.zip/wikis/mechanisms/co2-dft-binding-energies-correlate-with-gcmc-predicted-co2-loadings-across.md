---
title: "DFT binding energies correlate with GCMC-predicted CO2 loadings across functional groups when accura ...[TRUNCATED]... "
type: mechanism
tags: [co2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_c42cf01235]
confidence: high
---


# DFT binding energies correlate with GCMC-predicted CO2 loadings across functional groups when accura ...[TRUNCATED]... 

## Mechanism claim

DFT binding energies correlate with GCMC-predicted CO2 loadings across functional groups when accurate atomic charges (MBBB) are used (Spearman rank CC = 0.610 at 1 bar); the correlation disappears when Coulomb charges are set to zero (SRCC = 0.022), demonstrating electrostatics are critical to connect molecular-scale binding to macroscopic loading.

## Applicability

- Task: `co2`
- Mechanism type: `multiscale correlation between molecular binding and macroscopic loading (electrostatics-driven)`
- Condition scope: `{"gas": "CO2", "temperature_K": null, "pressure_bar": 1, "material_family": "MOFs functionalized with various building blocks (averaged by functional group)", "method": "DFT + GCMC simulation"}`

## Positive design features

- use of reliable Coulomb charge models (MBBB) in simulations to capture electrostatic effects

## Negative design features

- neglecting Coulomb charges (zero charges) destroys the correlation

## Agent design implication

When screening or predicting CO2 loadings from DFT binding energies, ensure electrostatic contributions are included (accurate charge models) to obtain meaningful correlations to simulated loadings.

## Evidence

> “we plotted the normalized averaged CO2 loading at 1 bar for all materials featuring the same functionalized building block versus the normalized DFT-calculated binding energy ... the expected correlation is evident ... indicated by a SRCC of 0.610. ... when zero charges are used in our adsorption simulations, the correlation notably worsens (SRCC becomes 0.022)."

Evidence location: pages 4-5

## Links

- Source: [[sources/src_c42cf01235]]