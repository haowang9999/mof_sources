---
title: "Pore limiting diameter (PLD) smaller than the kinetic diameter of CH3I (4.23 Å) prevents CH3I adsorp ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_fc58db74fa]
confidence: high
---


# Pore limiting diameter (PLD) smaller than the kinetic diameter of CH3I (4.23 Å) prevents CH3I adsorp ...[TRUNCATED]... 

## Mechanism claim

Pore limiting diameter (PLD) smaller than the kinetic diameter of CH3I (4.23 Å) prevents CH3I adsorption; PLD therefore acts as a size-exclusion filter for CH3I.

## Applicability

- Task: `pld`
- Mechanism type: `steric/size-exclusion`
- Condition scope: `{"gas": "CH3I (mixed stream with I2/H2O/N2/O2 in screening)", "temperature_K": 423, "pressure_bar": 1, "material_family": "MOFs (screened set of chemically stable MOFs; specific examples: UiO-66, UiO-66-NH2, JUC-110 noted as having too-small PLD)", "method": "GCMC simulation"}`

## Positive design features

- PLD >= kinetic diameter of CH3I (~4.23 Å) allows CH3I to access pores

## Negative design features

- PLD < 4.23 Å renders MOF unsuitable for CH3I adsorption (molecule cannot enter)

## Agent design implication

When designing or selecting MOFs to capture CH3I under the studied conditions (423 K, 1 bar, humid mixed gas), ensure the PLD is at least ~4.23 Å (the kinetic diameter of CH3I) to permit pore access; otherwise exclude the material by size or consider pore-expanding modifications.

## Evidence

> “for certain selected MOFs (e.g., UiO-66, UiO-66-NH2, JUC-110, etc.), the PLD was smaller than the kinetic diameter of CH3I molecules (4.23 Å), rendering them unsuitable for evaluating CH3I adsorption performance.”

Evidence location: page 3

## Links

- Source: [[sources/src_fc58db74fa]]