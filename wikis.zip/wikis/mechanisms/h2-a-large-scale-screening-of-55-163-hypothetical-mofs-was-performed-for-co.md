---
title: "A large-scale screening of 55,163 hypothetical MOFs was performed for CO2/H2 separation (mixture, 20 ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_1fa85425f9]
confidence: medium
---


# A large-scale screening of 55,163 hypothetical MOFs was performed for CO2/H2 separation (mixture, 20 ...[TRUNCATED]... 

## Mechanism claim

A large-scale screening of 55,163 hypothetical MOFs was performed for CO2/H2 separation (mixture, 20 bar), and a genetic algorithm was used to identify the optimum physical properties of hMOFs which showed the highest separation performance.

## Applicability

- Task: `h2`
- Mechanism type: `structure–property optimization / adsorption`
- Condition scope: `{"gas": "CO2/H2 mixture", "temperature_K": null, "pressure_bar": 20, "material_family": "hypothetical MOFs (hMOFs)", "method": "simulation (high-throughput GCMC + genetic algorithm optimization)"}`

## Positive design features

- use of genetic algorithm to find optimum physical properties

## Negative design features

- Not specified

## Agent design implication

Employ optimization algorithms (e.g., genetic algorithms) over large hMOF libraries to discover target ranges of physical properties (e.g., pore metrics) that maximize CO2/H2 separation performance; then prioritize synthesizability of identified top regions.

## Evidence

> "Molecular simulations were recently performed to screen 55,163 hMOFs for CO2/H2 separation and a genetic algorithm including optimization methods was used to identify the optimum physical properties of hMOFs which showed the highest separation performance (Chung et al., 2016)." (page 3).

Evidence location: page 3 (Large-scale screening / Table 1 summary)

## Links

- Source: [[sources/src_1fa85425f9]]