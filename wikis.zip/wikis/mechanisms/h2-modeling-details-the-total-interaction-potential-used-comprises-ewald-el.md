---
title: "Modeling details: the total interaction potential used comprises Ewald electrostatics, the many-body ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_532b708453]
confidence: high
---


# Modeling details: the total interaction potential used comprises Ewald electrostatics, the many-body ...[TRUNCATED]... 

## Mechanism claim

Modeling details: the total interaction potential used comprises Ewald electrostatics, the many-body polarization energy (Thole-Applequist), and Lennard-Jones pair potentials; H2 was modeled as a rigid three-point electrostatic model reproducing its quadrupole (H–H = 0.741 Å); ab initio-derived MOF point charges were used (MOF–MOF self-polarization disallowed to avoid double counting); atomic/site polarizabilities were fitted for H2 sites and estimated for In2+ (~2.0 Å3).

## Applicability

- Task: `h2`
- Mechanism type: `interaction_decomposition / modeling_details / parameterization`
- Condition scope: `{"gas": "H2", "temperature_K": 78, "pressure_bar": null, "material_family": "soc-MOF (In-containing SBU)", "method": "ab initio-derived charges + Thole polarizable Monte Carlo"}`

## Positive design features

- explicit electrostatics (Ewald), explicit many-body polarization (Thole), and LJ dispersion/repulsion included
- H2 quadrupole reproduced by rigid three-point model
- ab initio-derived point charges used to represent framework electrostatics

## Negative design features

- if ab initio charges implicitly include condensed-phase polarization, MOF–MOF self-polarization must be suppressed to avoid double counting
- some parameters (e.g., In2+ polarizability) are estimated and provisional

## Agent design implication

When building potentials for H2 adsorption in polar/charged MOFs, include Ewald electrostatics, explicit many-body polarization (Thole), and LJ terms; use ab initio fragment charges but disallow MOF–MOF self-polarization if those charges already include condensed-phase polarization. Fit site polarizabilities to reproduce known molecular polarizabilities and treat estimated metal polarizabilities as provisional pending more rigorous parametrization.

## Evidence

> "The total potential for the system is described by [equation] where Uelect is the electrostatic potential energy calculated from the Ewald field, Upol is the polarization energy calculated from eq 12, and ULJ is the Lennard-Jones potential." ... "Partial charges for hydrogen were chosen to reproduce the quadrupole moment of the molecule ... The hydrogen is also treated as rigid ..." ... "Since the atomic point charges of the MOF were calculated by ab initio to implicitly include polarization, MOF-MOF self-polarization was disallowed by excluding MOF-MOF electric field interactions, and only the induced field interactions between the H2 and MOF atoms were calculated." ... "The values that best satisfied both criteria were found to be 0.2658 Å3 for H and 0.5865 Å3 for the center of mass site." ... "Thus an estimate of 2.0 Å3 for In2+ was determined ..."

Evidence location: page 4-6 (methodology); page 5-6 (parameters)

## Links

- Source: [[sources/src_532b708453]]