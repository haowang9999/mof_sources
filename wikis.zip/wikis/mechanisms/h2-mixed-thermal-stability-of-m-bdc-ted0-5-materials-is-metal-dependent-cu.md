---
title: "Thermal stability of M(BDC)TED0.5 materials is metal-dependent: Cu(BDC)TED0.5 begins to decompose ar ...[TRUNCATED]... "
type: mechanism
tags: [h2|mixed, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_340141308b]
confidence: medium
---


# Thermal stability of M(BDC)TED0.5 materials is metal-dependent: Cu(BDC)TED0.5 begins to decompose ar ...[TRUNCATED]... 

## Mechanism claim

Thermal stability of M(BDC)TED0.5 materials is metal-dependent: Cu(BDC)TED0.5 begins to decompose around 300 °C, Ni(BDC)TED0.5 around 400 °C; some bimetallic combinations (e.g., Cu0.5Ni0.5) show intermediate/improved stability (reported stable to ~350 °C). Overall, bimetal introduction can either increase or decrease thermal stability depending on metals/ratio.

## Applicability

- Task: `h2|mixed`
- Mechanism type: `thermal stability (composition-dependent; TGA evidence)`
- Condition scope: `{"gas": "relevance to hydrogen storage (thermal stability under heating)", "temperature_K": null, "pressure_bar": null, "material_family": "M(BDC)TED0.5 (M = Cu, Ni) and bimetallic variants", "method": "experiment (TGA)"}`

## Positive design features

- inclusion of more thermally robust metals (e.g., Ni) can raise decomposition temperature
- some bimetallic combinations improve stability relative to weaker monometal

## Negative design features

- introduction of bimetals may also lead to a decrease in thermal stability in some cases

## Agent design implication

Do not assume bimetal substitution will uniformly increase stability; perform TGA screening across candidate compositions to ensure acceptable decomposition temperatures for intended use.

## Evidence

> Among the monometallic MOFs, Cu(BDC)TED0.5 has the worst thermal stability and begins to decompose at 300 °C while Ni(BDC)TED0.5 has the best thermal stability, which can reach up 400 °C. ... the thermal stability of Cu0.5Ni0.5(BDC)TED0.5 has improved compared to that of Cu(BDC)TED0.5, and the structure can remain stable at 350 °C. All in all, although the introduction of bimetals may lead to a decrease in the thermal stability of MOFs, the MOFs still maintain a high stability and satisfy the usage conditions for hydrogen storage.

Evidence location: page 4 (TGA discussion)

## Links

- Source: [[sources/src_340141308b]]