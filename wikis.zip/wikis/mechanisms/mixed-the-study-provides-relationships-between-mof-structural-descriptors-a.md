---
title: "The study provides relationships between MOF structural descriptors and transport/separation metrics ...[TRUNCATED]... "
type: mechanism
tags: [mixed, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_90953381a0]
confidence: medium
---


# The study provides relationships between MOF structural descriptors and transport/separation metrics ...[TRUNCATED]... 

## Mechanism claim

The study provides relationships between MOF structural descriptors and transport/separation metrics (diffusivity D, diffusion selectivity Sdiff, permeability P, permselectivity Sperm) in the supplementary materials (figures S2–S5).

## Applicability

- Task: `mixed`
- Mechanism type: `structure–transport relation (descriptors -> diffusion/permeation metrics)`
- Condition scope: `{"gas": "various gases used in the study (supplement includes models for CO2, H2, CH4, N2, H2S, O2, He)", "temperature_K": null, "pressure_bar": null, "material_family": "CoRE-MOFMs / CoRE‑MOF membranes", "method": "simulation; supplemental descriptor–property plots"}`

## Positive design features

- Not specified

## Negative design features

- Not specified

## Agent design implication

Use the descriptor–property relationships provided in the supplemental figures to guide screening for favorable diffusivity, diffusion selectivity, permeability, and permselectivity.

## Evidence

> Figure S2: Relationships between diffusivity D and MOF descriptors. Figure S3: Relationships between diffusion selectivities Sdiff and MOF descriptors. Figure S4: Relationships between permeability P and MOF descriptors. Figure S5: Relationships between permselectivity Sperm and MOF descriptors.

Evidence location: page 12 (Supplementary Materials list)

## Links

- Source: [[sources/src_90953381a0]]