---
title: "Amine grafting/functionalization of MOF frameworks increases CO2 affinity and selectivity (often imp ...[TRUNCATED]... "
type: mechanism
tags: [co2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_20dae1036b]
confidence: high
---


# Amine grafting/functionalization of MOF frameworks increases CO2 affinity and selectivity (often imp ...[TRUNCATED]... 

## Mechanism claim

Amine grafting/functionalization of MOF frameworks increases CO2 affinity and selectivity (often improving low-pressure uptake, kinetics and enabling chemisorptive mechanisms) but also increases hydrophilicity such that water can compete with CO2 and impair performance unless addressed.

## Applicability

- Task: `co2`
- Mechanism type: `chemisorption / cooperative chemisorption with tradeoff vs water affinity`
- Condition scope: `{"gas": "CO2 (pure and post-combustion flue mixtures; commonly 5–15% CO2 in N2)", "temperature_K": null, "pressure_bar": null, "material_family": "amine-functionalized MOFs (MOF-74 family, DOBPDC variants, and other amine-grafted frameworks)", "method": "experiment|simulation (explicit chemisorption modeling cited and used)"}`

## Positive design features

- amine groups enable stronger binding via chemisorption (e.g., carbamate/ammonium carbamate species) and can produce large low-pressure uptake and high CO2/N2 selectivity
- can improve cyclic working capacity when chemisorption step is appropriately positioned relative to process conditions

## Negative design features

- higher affinity often correlates with increased hydrophilicity → water competes with CO2 and can require drying or humidity-tolerant chemistries
- strong chemisorption can increase regeneration energy if not tuned

## Agent design implication

Use amine grafting to raise low-pressure CO2 capture and selectivity, but explicitly include humidity/oxidation considerations in screening or use oxidation-resistant chemistries; tune amine identity and loading to balance uptake and regenerability.

## Evidence

> “Therefore, amine-functionalized MOFs are attracting great attention, as they are more effective than the corresponding original solid adsorbents... Studies have shown that amine-functionalized MOFs have potential for greater adsorption capacity, higher selectivity, faster CO2 adsorption kinetics, and lower regeneration temperatures…” | “...the use of the most promising MOFs require partial or complete drying of the gas stream because high affinity for CO2 entails hydrophilicity, and thus water can competitively adsorb with CO2.” | “Since it is known that the amine groups chemically react with CO2 and enable adsorption enhancement at very low pressures, chemisorption was explicitly considered...”

Evidence location: pages 1-3 (Abstract & Introduction); pages 3-5 (Introduction & Results)

## Links

- Source: [[sources/src_20dae1036b]]