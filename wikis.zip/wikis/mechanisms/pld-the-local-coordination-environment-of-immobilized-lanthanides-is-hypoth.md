---
title: "The local coordination environment of immobilized lanthanides is hypothesized to be influenced by (i ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_c88d608b3b]
confidence: low
---


# The local coordination environment of immobilized lanthanides is hypothesized to be influenced by (i ...[TRUNCATED]... 

## Mechanism claim

The local coordination environment of immobilized lanthanides is hypothesized to be influenced by (i) available binding sites at metal-oxo clusters and organic linkers, (ii) the hydration energy of the lanthanide, and (iii) the limiting pore diameter of the hosting MOF; this is presented as a guiding hypothesis for experiments rather than a fully established general rule.

## Applicability

- Task: `pld`
- Mechanism type: `hypothesized multi-factor control (binding-site chemistry, hydration energetics, steric confinement)`
- Condition scope: `{"gas": "aqueous (context of experiments reported)", "temperature_K": null, "pressure_bar": null, "material_family": "Cr- and Zr-based MOFs studied (Cr-MIL-101, UiO-66, UiO-68)", "method": "experimental hypothesis guiding XAFS and adsorption interpretation"}`

## Positive design features

- explicitly acknowledges multiple interacting factors including pore size/limiting diameter as potential controls on lanthanide speciation/coordination

## Negative design features

- framed as a hypothesis; not quantitatively proven across systems in the provided text

## Agent design implication

Consider hydration energy and steric constraints (limiting pore diameter) together with available chemical binding sites when designing MOFs for lanthanide capture; experimentally validate which factors dominate for a given MOF–Ln pair.

## Evidence

> "Our experiments address the hypothesis: the local coordination environment of Nd3+, Gd3+, and Lu3+ immobilized within MOFs is defined by the available binding sites at the metal oxo clusters and at the organic linkers, the hydration energy of lanthanide, and the limiting pore diameter of the hosting MOF."

Evidence location: page 2 end of Introduction

## Links

- Source: [[sources/src_c88d608b3b]]