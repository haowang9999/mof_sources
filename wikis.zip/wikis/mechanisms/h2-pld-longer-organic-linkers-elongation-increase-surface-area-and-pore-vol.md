---
title: "Longer organic linkers (elongation) increase surface area and pore volume, which increases H2 uptake ...[TRUNCATED]... "
type: mechanism
tags: [h2|pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_ff1b0c9d63]
confidence: high
---


# Longer organic linkers (elongation) increase surface area and pore volume, which increases H2 uptake ...[TRUNCATED]... 

## Mechanism claim

Longer organic linkers (elongation) increase surface area and pore volume, which increases H2 uptake (examples: UiO-67 vs UiO-66; IRMOF family observations), though excessive elongation can induce flexibility, collapse or interpenetration.

## Applicability

- Task: `h2|pld`
- Mechanism type: `linker-length → pore geometry → adsorption`
- Condition scope: `{"gas": "H2", "temperature_K": 77, "pressure_bar": 38, "material_family": "isostructural MOFs (UiO-66 vs UiO-67), IRMOF family", "method": "experiment"}`

## Positive design features

- longer organic linkers
- increased BET/Langmuir surface area
- increased pore volume

## Negative design features

- excessive linker elongation can lead to framework flexibility, collapse or interpenetration

## Agent design implication

Use longer organic linkers to increase surface area and pore volume to raise H2 uptake under cryogenic/high-pressure conditions, but limit linker length or stabilize framework to avoid collapse/interpenetration.

## Evidence

> Previous research has shown that, for a given crystal structure of MOFs, the As value can be increased using longer ligands... For UiO-67 (longer linker) the value of As (Langmuir) was 2483 m2·g–1… hydrogen adsorption measured at 77 K and 38 bar of H2 was almost twice as high for UiO-67 (4.6 wt%) as for UiO-66 (2.4 wt%). ... The results obtained for IRMOFs confirmed that the organic linker geometry, particularly the length, has a direct influence on the pore size, and hence the surface area of MOFs.

Evidence location: section 4.1.1 and Table 2 (pages 12-13)

## Links

- Source: [[sources/src_ff1b0c9d63]]