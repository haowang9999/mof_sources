---
title: "CH3I uptake and selectivity in the MIL-53-Al-X series are positively correlated with the isosteric h ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_fc58db74fa]
confidence: high
---


# CH3I uptake and selectivity in the MIL-53-Al-X series are positively correlated with the isosteric h ...[TRUNCATED]... 

## Mechanism claim

CH3I uptake and selectivity in the MIL-53-Al-X series are positively correlated with the isosteric heat of adsorption (Qst) for CH3I; affinity (Qst) is the dominant factor for CH3I uptake and small reductions in pore volume from functionalization have negligible impact.

## Applicability

- Task: `pld`
- Mechanism type: `affinity-driven adsorption (binding energy dominates uptake)`
- Condition scope: `{"gas": "CH3I (competitive, humid environment)", "temperature_K": 423, "pressure_bar": 1, "material_family": "functionalized MIL-53-Al (MIL-53-Al-X) series", "method": "GCMC and DFT simulations"}`

## Positive design features

- higher Qst for CH3I correlates with higher CH3I uptake (example: MIL-53-Al-CH3 Qst 71.95 kJ/mol -> CH3I uptake 2.8 cm3/g)
- functional groups (e.g., -CH3, -NH2) can substantially increase CH3I uptake via increased affinity

## Negative design features

- functionalization-induced pore volume reduction has nearly negligible effect on CH3I uptake (per the authors' analysis), though excessive blocking remains a risk

## Agent design implication

To maximize CH3I capture in MIL-53-Al-type materials under humid competitive conditions, focus on surface functionalization that increases CH3I binding energy (Qst), since affinity more strongly determines CH3I uptake than modest pore-volume loss in the studied series.

## Evidence

> “the CH3I uptake amounts and selectivity were positively correlated with the Qst of CH3I, indicating the affinity for CH3I played a major role in CH3I uptake in MIL-53-Al-X series. The impact of the functionalization-induced reduction in pore volume was nearly negligible (Figure S5). MIL-53-Al-CH3, exhibiting the highest Qst for CH3I of 71.95 kJ/mol, achieved the highest CH3I uptake amount of 2.8 cm3/g, which was more than twice that of the pristine MIL-53-Al (1.19 cm3/g); followed by the MIL-53-Al-NH2 with the CH3I uptake amount of 1.81 cm3/g.”

Evidence location: pages 6-7

## Links

- Source: [[sources/src_fc58db74fa]]