---
title: "Surface area and pore volume are primary factors impacting hydrogen adsorption; MOFs with very large ...[TRUNCATED]... "
type: mechanism
tags: [h2|pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_ff1b0c9d63]
confidence: high
---


# Surface area and pore volume are primary factors impacting hydrogen adsorption; MOFs with very large ...[TRUNCATED]... 

## Mechanism claim

Surface area and pore volume are primary factors impacting hydrogen adsorption; MOFs with very large surface areas typically show the highest hydrogen gravimetric capacities, though volumetric vs gravimetric trade-offs exist.

## Applicability

- Task: `h2|pld`
- Mechanism type: `adsorption scaling with pore metrics`
- Condition scope: `{"gas": "H2", "temperature_K": null, "pressure_bar": null, "material_family": "general MOFs", "method": "review of experimental/survey data"}`

## Positive design features

- very large BET surface area
- large pore volume

## Negative design features

- need to balance volumetric vs gravimetric uptake

## Agent design implication

Target high BET surface area and pore volume for materials intended to maximize gravimetric H2 uptake, but consider trade-offs for volumetric capacity.

## Evidence

> The factors of surface area and pore volume are well recognized to have an impact on hydrogen adsorption. MOFs with very large surface areas usually show the highest hydrogen adsorption capacities. Typically, MOF materials with high BET areas, e.g., MOF-210 and DUT-60, show very high gravimetric adsorption capacities. Alternatively, balancing volumetric and gravimetric uptake must be considered for the development of ideal hydrogen adsorbents.

Evidence location: page 11-12

## Links

- Source: [[sources/src_ff1b0c9d63]]