---
title: "Isoreticular MOF series (e.g., MOF-5 / IRMOFs) preserve framework topology and surface environment w ...[TRUNCATED]... "
type: mechanism
tags: [pld|mixed, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_ff1b0c9d63]
confidence: high
---


# Isoreticular MOF series (e.g., MOF-5 / IRMOFs) preserve framework topology and surface environment w ...[TRUNCATED]... 

## Mechanism claim

Isoreticular MOF series (e.g., MOF-5 / IRMOFs) preserve framework topology and surface environment while varying pore sizes, making them suitable model systems to study pore-size effects on hydrogen adsorption.

## Applicability

- Task: `pld|mixed`
- Mechanism type: `structural design strategy to isolate pore size variable`
- Condition scope: `{"gas": "H2 (context: hydrogen adsorption studies)", "temperature_K": null, "pressure_bar": null, "material_family": "MOF-5 / IRMOFs", "method": "review / conceptual"}`

## Positive design features

- control over pore size while keeping chemistry/topology constant

## Negative design features

- Not specified

## Agent design implication

Use isoreticular series (MOF-5 / IRMOFs) when isolating pore-size effects on H2 uptake to minimize confounding variations in surface chemistry.

## Evidence

> The focus is on the MOF-5 and its isorecticular MOF series (IRMOFs), that have the same framework topology and surface environment, but different pore sizes.

Evidence location: End of Introduction (page 2)

## Links

- Source: [[sources/src_ff1b0c9d63]]