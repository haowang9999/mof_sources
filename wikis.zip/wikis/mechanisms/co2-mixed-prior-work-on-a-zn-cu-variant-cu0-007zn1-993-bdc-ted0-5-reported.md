---
title: "Prior work on a Zn/Cu variant (Cu0.007Zn1.993(BDC)TED0.5) reported that for several investigated gas ...[TRUNCATED]... "
type: mechanism
tags: [co2|mixed, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_340141308b]
confidence: low
---


# Prior work on a Zn/Cu variant (Cu0.007Zn1.993(BDC)TED0.5) reported that for several investigated gas ...[TRUNCATED]... 

## Mechanism claim

Prior work on a Zn/Cu variant (Cu0.007Zn1.993(BDC)TED0.5) reported that for several investigated gases most of the gas resides in the centers of the cavities in M(BDC)TED0.5.

## Applicability

- Task: `co2|mixed`
- Mechanism type: `adsorption site localization (literature-cited)`
- Condition scope: `{"gas": "several small gases (not fully specified in this paper; original study by Poryvaev et al. is cited)", "temperature_K": null, "pressure_bar": null, "material_family": "Cu0.007Zn1.993(BDC)TED0.5 (prior study)", "method": "prior computational/experimental adsorption-site mapping (citation)"}`

## Positive design features

- cavity centers act as primary adsorption sites in that prior study

## Negative design features

- Not specified

## Agent design implication

When modeling or mapping adsorption in M(BDC)TED0.5 frameworks include cavity-center sites as likely adsorption loci, but verify for each specific guest because the cited result covered 'several gases' without specificity.

## Evidence

> Poryvaev et al. tried to synthesize Cu0.007Zn1.993(BDC)TED0.5 and studied the adsorption sites of several kinds of gases on the MOFs, elucidating that most of the gas resides in the centers of the cavities.

Evidence location: page 2 (literature citation)

## Links

- Source: [[sources/src_340141308b]]