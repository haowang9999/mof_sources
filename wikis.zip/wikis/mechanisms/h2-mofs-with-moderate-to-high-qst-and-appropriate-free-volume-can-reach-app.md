---
title: "MOFs with moderate-to-high Qst and appropriate free volume can reach appreciable gravimetric uptake; ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_b1552d4a9d]
confidence: medium
---


# MOFs with moderate-to-high Qst and appropriate free volume can reach appreciable gravimetric uptake; ...[TRUNCATED]... 

## Mechanism claim

MOFs with moderate-to-high Qst and appropriate free volume can reach appreciable gravimetric uptake; reported targets include Qst ≈ 10–15 kJ·mol−1 with free volume 1.6–2.4 cm3·g−1 or Qst >20 kJ·mol−1 with free volume <1.5 cm3·g−1 to approach ~6 wt% H2.

## Applicability

- Task: `h2`
- Mechanism type: `quantitative energetic–porosity relationship`
- Condition scope: `{"gas": "H2", "temperature_K": null, "pressure_bar": null, "material_family": "general MOFs (design guideline)", "method": "review / synthesized from literature"}`

## Positive design features

- provides concrete Qst and free-volume target ranges correlated with increased gravimetric uptake

## Negative design features

- these are approximate targets and may be challenging to realize practically

## Agent design implication

As a design goal, tune porosity and binding strength toward either (Qst 10–15 kJ·mol−1 with free volume 1.6–2.4 cm3·g−1) or (Qst >20 kJ·mol−1 with smaller free volume) to approach ~6 wt% H2.

## Evidence

> It was concluded that MOFs can reach approximately 6 wt% H2 when they are characterized by a Qst value of 10–15 kJ·mol−1 and a free volume within the range of 1.6–2.4 cm3·g−1, or Qst > 20 kJ·mol−1 and a free volume smaller than 1.5 cm3·g−1.

Evidence location: page 8

## Links

- Source: [[sources/src_b1552d4a9d]]