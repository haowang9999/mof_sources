---
title: "Surface area appears more important than free volume for achieving maximum deliverable H2 capacity;  ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_8d4a290e19]
confidence: medium
---


# Surface area appears more important than free volume for achieving maximum deliverable H2 capacity;  ...[TRUNCATED]... 

## Mechanism claim

Surface area appears more important than free volume for achieving maximum deliverable H2 capacity; MOFs with very large surface areas (>~4800 m2/g) are recommended starting points for efforts to increase Qst.

## Applicability

- Task: `pld`
- Mechanism type: `pore/structural design guideline`
- Condition scope: `{"gas": "H2", "temperature_K": 298, "pressure_bar": {"storage_pressure": 120, "discharge_pressure": 1.5}, "material_family": "the eight MOFs studied", "method": "simulation/analysis"}`

## Positive design features

- High surface area correlates with higher maximum deliverable capacity when Qst is increased
- MOF-177 (surface area ~4823 m2/g) is cited as an approximate guideline material

## Negative design features

- High free volume alone is not sufficient; some MOFs with larger free volume failed to reach targets compared to those with higher surface area
- Increasing Qst in practice may reduce free volume or add heavy atoms, reducing gravimetric capacity

## Agent design implication

When prioritizing MOF candidates for modification to increase Qst, favor frameworks with very large surface areas (on the order of ≥~4800 m2/g) rather than solely targeting large free volumes.

## Evidence

> "This suggests that the surface area is more important than free volume to achieve the maximum deliverable capacity for hydrogen storage... For MOF-177, the maximum deliverable capacity is close to the 2015 target. Hence, the surface area of MOF-177 (4823 m2/g) can be an approximate guideline to select a starting material for increasing the heat of adsorption."

Evidence location: page 3 (Results and discussion)

## Links

- Source: [[sources/src_8d4a290e19]]