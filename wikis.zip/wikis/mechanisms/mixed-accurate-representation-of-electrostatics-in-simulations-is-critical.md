---
title: "Accurate representation of electrostatics in simulations is critical: inexpensive electronegativity- ...[TRUNCATED]... "
type: mechanism
tags: [mixed, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_c42cf01235]
confidence: high
---


# Accurate representation of electrostatics in simulations is critical: inexpensive electronegativity- ...[TRUNCATED]... 

## Mechanism claim

Accurate representation of electrostatics in simulations is critical: inexpensive electronegativity-equalization charge assignment methods can overestimate halogen charges and produce artefactual top performers; DFT-fitted MBBB or unit-cell-fitted charges (e.g., REPEAT) are more reliable for adsorption predictions.

## Applicability

- Task: `mixed`
- Mechanism type: `simulation accuracy / electrostatics representation affecting predicted adsorption`
- Condition scope: `{"gas": "CO2 (and other polar gases)", "temperature_K": null, "pressure_bar": null, "material_family": "MOFs (especially halogenated MOFs)", "method": "simulation (HTCS) / charge assignment methods comparison"}`

## Positive design features

- DFT-fitted MBBB charges or REPEAT charges that capture electrostatic potential more accurately

## Negative design features

- electronegativity equalization methods that can overestimate halogen charges and lead to false positives in HTCS

## Agent design implication

For computational screening and mechanistic interpretation, use DFT-derived charge methods (MBBB or REPEAT) or validated charge equilibration parameterizations rather than inexpensive electronegativity-equalization methods to avoid artefactual promotion of halogenated MOFs.

## Evidence

> “Electrostatic interactions are critical for CO2 sorption, so their accurate description by Coulomb interactions is necessary for meaningful simulations...issues with computational cost have motivated the use of inexpensive 'electronegativity equalization' methods...Such processes overestimate charges of, for instance, halogens...Thus, in previous HTCS studies, halogenated MOFs were consistently found as top performers for CO2 capture...Recently, several groups have made efforts to develop inexpensive (HTCS-compatible) methods to assign Coulomb charges that agree well with charges obtained from expensive density functional theory (DFT) calculations...we have demonstrated that the use of molecular building block-based (MBBB) charges that fit the DFT-calculated electrostatic potential...result in sorption loadings and mechanisms consistent with those obtained with charges that fit the DFT-calculated ESP in the MOF unit cell (e.g., REPEAT charges)."

Evidence location: page 2 (Introduction) and references cited for charge methods

## Links

- Source: [[sources/src_c42cf01235]]