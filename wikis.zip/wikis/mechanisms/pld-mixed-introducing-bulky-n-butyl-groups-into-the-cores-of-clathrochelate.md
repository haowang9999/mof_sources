---
title: "Introducing bulky n-butyl groups into the cores of clathrochelate-based ditopic ligands prevents for ...[TRUNCATED]... "
type: mechanism
tags: [pld|mixed, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_3b254ae858]
confidence: high
---


# Introducing bulky n-butyl groups into the cores of clathrochelate-based ditopic ligands prevents for ...[TRUNCATED]... 

## Mechanism claim

Introducing bulky n-butyl groups into the cores of clathrochelate-based ditopic ligands prevents formation of twofold interpenetrated networks under similar synthetic conditions and yields a non-interpenetrated pcu MOF (NU-651), whereas less bulky cores produce a twofold interpenetrated pcu MOF (NU-650).

## Applicability

- Task: `pld|mixed`
- Mechanism type: `structure–topology control by steric ligand modification (experimental SCXRD comparison)`
- Condition scope: `{"gas": "", "temperature_K": 393, "pressure_bar": null, "material_family": "Zn4O-based IRMOFs assembled from clathrochelate ditopic ligands", "method": "experiment (SCXRD; synthesis under comparable solvothermal conditions)"}`

## Positive design features

- Bulky n-butyl substitution on ligand core leads to non-interpenetrated NU-651 (SCXRD: cubic Pm3̅m)
- NU-651 synthesized under conditions similar to NU-650 but is non-interpenetrated

## Negative design features

- Exact porosity/accessibility after activation for NU-651 was not experimentally confirmed
- Interpenetration can still be influenced by other factors (solvent, conditions) though here conditions were similar

## Agent design implication

To avoid interpenetration in pcu Zn4O-based frameworks and increase crystallographic pore size/porosity, introduce sterically bulky substituents (e.g., n-butyl) in clathrochelate ligand cores; synthesize under comparable conditions to favor non-catenated networks.

## Evidence

> The use of clathrochelate-based carboxylate ligands with bulky cores of n-butyl groups led to the synthesis of a Zn-MOF with the pcu net, while clathrochelate linkers with relatively fewer bulky cores give a twofold interpenetrated Zn-MOF structure under similar conditions... Single crystal X-ray diffraction (SCXRD) investigation revealed the use of tris(dioxime)clathrochelate (L2) with bulky cores of n-butyl groups leads to the synthesis of a non-interpenetrated Zn-MOF—NU-651, while the combination of clathrochelate-based ligand (L1) with relatively less bulky cores and Zn salts gives a twofold interpenetrated Zn-MOF, NU-650, under similar conditions.

Evidence location: page 1 (Abstract) and pages 2-4 (Results: SCXRD and discussion)

## Links

- Source: [[sources/src_3b254ae858]]