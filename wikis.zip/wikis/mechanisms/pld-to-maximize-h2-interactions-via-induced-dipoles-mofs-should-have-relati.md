---
title: "To maximize H2 interactions via induced dipoles, MOFs should have relatively small, interconnected p ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_532b708453]
confidence: medium-high
---


# To maximize H2 interactions via induced dipoles, MOFs should have relatively small, interconnected p ...[TRUNCATED]... 

## Mechanism claim

To maximize H2 interactions via induced dipoles, MOFs should have relatively small, interconnected pores with high surface area and a locally polar surface (large charge separations spaced to allow H2 sensitivity); excessively large voids reduce induced dipoles for central pore H2 and reduce storage performance, though there is a tradeoff with framework mass per unit volume.

## Applicability

- Task: `pld`
- Mechanism type: `pore geometry / surface electrostatics design guideline`
- Condition scope: `{"gas": "H2 (general gas storage guidance)", "temperature_K": 78, "pressure_bar": null, "material_family": "MOFs (general recommendation)", "method": "derived from simulation results and analysis"}`

## Positive design features

- small, interconnected pores increase surface-area-to-volume and keep adsorbates in strong field regions
- local polarity and spaced charge separations enhance induced dipoles in adsorbates

## Negative design features

- large pores lead to interior regions where adsorbates behave like neat gas with weak interactions
- tradeoff: nanostructuring increases framework mass per unit volume

## Agent design implication

Design MOF pore networks with narrow, interconnected channels and engineered local charge separations; avoid oversized voids that place molecules far from the charged surface.

## Evidence

> This study suggests that MOFs should have relatively small pores and interconnected pores with high surface area to create strong MOF-H2 interactions and, thus, indirectly H2-H2 attractions. To promote these interactions, the MOF also needs to be locally polar with large charge separations on its surface sufficiently far apart to allow hydrogen molecules to be sensitive to the dipolar interface. Further, while the surface area needs to be large, the open spatial network should not be so expansive that hydrogen molecules farthest from the MOF surface do not possess significant induced dipoles ... There is, however, a tradeoff between having larger voids that produce a lower molecular weight material ... versus having a highly nanostructed pore system ... but strong scaffold-H2 interactions.

Evidence location: page 9 (IV. Conclusions)

## Links

- Source: [[sources/src_532b708453]]