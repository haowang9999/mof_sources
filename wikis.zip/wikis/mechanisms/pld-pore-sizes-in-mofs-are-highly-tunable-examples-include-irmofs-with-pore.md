---
title: "Pore sizes in MOFs are highly tunable; examples include IRMOFs with pore sizes from 3.8 to 28.8 Å, M ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_b1552d4a9d]
confidence: high
---


# Pore sizes in MOFs are highly tunable; examples include IRMOFs with pore sizes from 3.8 to 28.8 Å, M ...[TRUNCATED]... 

## Mechanism claim

Pore sizes in MOFs are highly tunable; examples include IRMOFs with pore sizes from 3.8 to 28.8 Å, MOF-5 with cavities 15.1 Å and 11.0 Å, PCN-610/NU-100 with voids of 26.0, 18.6, 12.0 Å, and NU-1501 with ~2.2 nm hexagonal channels.

## Applicability

- Task: `pld`
- Mechanism type: `structural characterization (pore size / geometry)`
- Condition scope: `{"gas": "n/a (structural)", "temperature_K": null, "pressure_bar": null, "material_family": "IRMOFs, MOF-5, PCN-610/NU-100, NU-1501", "method": "review / reported crystallography"}`

## Positive design features

- demonstrates tunability of pore diameters and presence of multi-scale voids in specific MOFs

## Negative design features

- Not specified

## Agent design implication

Pore diameters in MOFs can be targeted via linker choice and topology to match desired storage regimes or to create hierarchical voids.

## Evidence

> Pore size in IRMOFs can be incrementally varied from 3.8 to 28.8 Å ... overall structure of MOF-5 is composed of larger cavities (15.1 Å) and smaller cavities (11.0 Å) ... PCN-610/NU-100 ... three types of voids ... sizes 26.0, 18.6, and 12.0 Å ... NU-1501 ... open hexagonal channel with a pore size of ~2.2 nm.

Evidence location: pages 3-4

## Links

- Source: [[sources/src_b1552d4a9d]]