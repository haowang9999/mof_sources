---
title: "Framework flexibility analysis (GASP) indicates the deformations required for cisplatin passage lie  ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_8ce39338bc]
confidence: high
---


# Framework flexibility analysis (GASP) indicates the deformations required for cisplatin passage lie  ...[TRUNCATED]... 

## Mechanism claim

Framework flexibility analysis (GASP) indicates the deformations required for cisplatin passage lie within the flexibility window for UiO-66 variants, so guest passage does not require covalent bond breaking (though it may incur energetic cost).

## Applicability

- Task: `pld`
- Mechanism type: `structural flexibility enabling passage without bond breaking`
- Condition scope: `{"gas": "", "temperature_K": null, "pressure_bar": null, "material_family": "UiO-66 and UiO-66(NH2)", "method": "GASP flexibility window analysis combined with SMD/ab initio checks"}`

## Positive design features

- required framework deformations for passage are within allowable flexibility range

## Negative design features

- passage may still incur significant bonded energetic cost even if bonds are not broken

## Agent design implication

Use flexibility-window analysis (GASP) to ensure the required pore-window deformations for guest passage are feasible without bond rupture; if deformations exceed the window, passage may be impossible without chemical change.

## Evidence

> The extent of deformation from SMD simulations was found to be within the flexibility window of both UiO-66 and UiO-66(NH2), meaning cisplatin can move through the pore windows without breaking framework bonds.

Evidence location: page 7

## Links

- Source: [[sources/src_8ce39338bc]]