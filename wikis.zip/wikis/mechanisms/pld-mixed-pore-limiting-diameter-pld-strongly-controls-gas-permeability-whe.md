---
title: "Pore limiting diameter (PLD) strongly controls gas permeability: when PLD is between 2.5–3.5 Å, PO2  ...[TRUNCATED]... "
type: mechanism
tags: [pld|mixed, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_90953381a0]
confidence: high
---


# Pore limiting diameter (PLD) strongly controls gas permeability: when PLD is between 2.5–3.5 Å, PO2  ...[TRUNCATED]... 

## Mechanism claim

Pore limiting diameter (PLD) strongly controls gas permeability: when PLD is between 2.5–3.5 Å, PO2 and PH2 increase significantly with PLD; when PLD > 3.5 Å, PO2 and PH2 tend toward an equilibrium (above ~100 Barrer).

## Applicability

- Task: `pld|mixed`
- Mechanism type: `steric / size-exclusion influence on permeability`
- Condition scope: `{"gas": "O2, H2 (examples); trends observed across multiple gases", "temperature_K": null, "pressure_bar": null, "material_family": "CoRE-MOFMs / CoRE‑MOF membranes (computational dataset of thousands of entries)", "method": "molecular simulation / high-throughput computational screening"}`

## Positive design features

- PLD in 2.5–3.5 Å increases PO2 and PH2 significantly

## Negative design features

- PLD > 3.5 Å leads to permeability equilibrium (reduced sensitivity to PLD)

## Agent design implication

Tuning PLD into the 2.5–3.5 Å range can enhance O2 and H2 permeabilities relative to much larger PLDs; avoid relying on PLD changes >3.5 Å to further increase permeability for small gases.

## Evidence

> "When the PLD is between 2.5–3.5 Å, PO2 and PH2 increase signiﬁcantly with the increase of PLD. However, when PLD > 3.5 Å, PO2 and PH2 tend to be in equilibrium above 100 Barrer."

Evidence location: page 6

## Links

- Source: [[sources/src_90953381a0]]