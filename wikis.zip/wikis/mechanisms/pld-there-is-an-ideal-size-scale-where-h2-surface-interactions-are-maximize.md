---
title: "There is an ideal size scale where H2–surface interactions are maximized (near the H2 kinetic diamet ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_fa8cccd644]
confidence: medium
---


# There is an ideal size scale where H2–surface interactions are maximized (near the H2 kinetic diamet ...[TRUNCATED]... 

## Mechanism claim

There is an ideal size scale where H2–surface interactions are maximized (near the H2 kinetic diameter ≈0.289 nm), but synthesizing materials with a unimodal PSD around ~0.3 nm and high surface area is challenging.

## Applicability

- Task: `pld`
- Mechanism type: `molecular sieving / size-matching`
- Condition scope: `{"gas": "H2", "temperature_K": null, "pressure_bar": null, "material_family": "porous materials / MOFs", "method": "review"}`

## Positive design features

- pore sizes near 0.29 nm maximize contact

## Negative design features

- synthetic difficulty achieving unimodal ~0.3 nm PSD with high SSA

## Agent design implication

Aim for narrow pore apertures approaching the H2 kinetic diameter to maximize adsorbate–surface interaction, but recognize synthetic challenges and potential losses in accessible area.

## Evidence

> H2 interactions with MOFs can be enhanced by reducing pore size, with the optimum size corresponding to the kinetic diameter of the H2 molecule (0.289 nm), although porous materials with a unimodal PSD of around 0.3 nm and high surface areas are difficult to obtain.

Evidence location: page 6, section 3.1

## Links

- Source: [[sources/src_fa8cccd644]]