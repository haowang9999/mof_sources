---
title: "Incorporation of metal nanoparticles into MOFs can lead to hydride formation (chemisorption) and/or  ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_ff1b0c9d63]
confidence: medium
---


# Incorporation of metal nanoparticles into MOFs can lead to hydride formation (chemisorption) and/or  ...[TRUNCATED]... 

## Mechanism claim

Incorporation of metal nanoparticles into MOFs can lead to hydride formation (chemisorption) and/or enable spillover, altering H2 uptake and kinetics; examples include Pd hydride formation in MIL-100(Al) and faster kinetics attributed to spillover in Pd@HKUST-1.

## Applicability

- Task: `h2`
- Mechanism type: `chemisorption (hydride formation) and/or spillover-mediated adsorption enhancement`
- Condition scope: `{"gas": "H2", "temperature_K": [77, 298], "pressure_bar": [40, "various"], "material_family": "MOFs with incorporated metal nanoparticles (Pd, Pt examples)", "method": "experiment (impregnation, encapsulation)"}`

## Positive design features

- Pd NP incorporation can increase H2 uptake at 298 K (Pd hydride formation)
- faster kinetics observed (reported as spillover)

## Negative design features

- textural property reductions (As, Va) upon NP incorporation can reduce low-temperature uptake
- mechanism (hydride vs spillover) not universally established

## Agent design implication

Embedding metal NPs can increase room-temperature H2 uptake via hydride formation and potentially improve kinetics via spillover, but monitor and minimize loss of accessible surface area; design experiments to distinguish hydride formation from spillover.

## Evidence

> Pd NPs were infiltrated in MIL-100(Al) ... As a result of Pd impregnation, reduction in the nσ value at 77 K and 40 bar of H2 was directly related to the decrease in As and Va ... whereas at 298 K, the nσ value increased, most probably because of Pd hydride formation. Formation of PdH0.6 was experimentally confirmed for the Pd NPs incorporated in MIL-100(Al). As a result of the spill-over effect, faster kinetics was experimentally observed for Pd NPs encapsulated in HKUST-1.

Evidence location: page 21-22, Section 4.3.1

## Links

- Source: [[sources/src_ff1b0c9d63]]