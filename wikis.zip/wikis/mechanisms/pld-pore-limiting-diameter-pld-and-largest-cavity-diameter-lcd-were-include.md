---
title: "Pore limiting diameter (PLD) and largest cavity diameter (LCD) were included among the core textural ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_71bcf59437]
confidence: high
---


# Pore limiting diameter (PLD) and largest cavity diameter (LCD) were included among the core textural ...[TRUNCATED]... 

## Mechanism claim

Pore limiting diameter (PLD) and largest cavity diameter (LCD) were included among the core textural descriptors used for PCA and clustering; two principal components derived from the set of textural features captured ≈87.7% of the variance and were used for clustering.

## Applicability

- Task: `pld`
- Mechanism type: `feature-importance / dimensionality reduction note`
- Condition scope: `{"gas": "not gas-specific", "temperature_K": null, "pressure_bar": null, "material_family": "MOFs (dataset)", "method": "PCA on computed textural features"}`

## Positive design features

- pore limiting diameter (PLD)
- largest cavity diameter (LCD)
- volumetric surface area
- gravimetric surface area
- void fraction

## Negative design features

- Not specified

## Agent design implication

When designing ML pipelines for MOF adsorption prediction or clustering, include PLD and LCD along with surface areas and void fraction; two principal components from these features captured ≈87.7% of variance and were sufficient for k-means clustering in this study.

## Evidence

> We use the ... textural properties (void fraction, volumetric surface area, gravimetric surface area, limiting pore diameter, largest cavity diameter) for clustering ... PCA generated two components that contained 87.7% of the variance and were subsequently used to cluster MOFs.

Evidence location: pages 5-6

## Links

- Source: [[sources/src_71bcf59437]]