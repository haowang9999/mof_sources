---
title: "Introducing polar functional groups increases iodine (I2 and CH3I) adsorption selectivity by raising ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_fc58db74fa]
confidence: medium
---


# Introducing polar functional groups increases iodine (I2 and CH3I) adsorption selectivity by raising ...[TRUNCATED]... 

## Mechanism claim

Introducing polar functional groups increases iodine (I2 and CH3I) adsorption selectivity by raising affinity (Qst), but often reduces pore volume; the pore-volume reduction particularly reduces I2 uptake while having a smaller effect on CH3I uptake.

## Applicability

- Task: `pld`
- Mechanism type: `chemical functionality / hydrophilicity vs steric trade-off`
- Condition scope: `{"gas": "I2 and CH3I in humid competitive gas mixtures (with H2O, N2, O2)", "temperature_K": 423, "pressure_bar": 1, "material_family": "functionalized MIL-53-Al (MIL-53-Al-X) series", "method": "GCMC and DFT simulations"}`

## Positive design features

- polar functionalization enhances adsorption selectivity by increasing affinity (Qst) for iodine species

## Negative design features

- functionalization can reduce pore volume and increase steric hindrance, which decreases I2 uptake
- increased hydrophilicity can further influence competitive adsorption with water

## Agent design implication

When tuning MIL-53-Al for iodine capture under humid conditions, use polar functional groups to raise selectivity/affinity but monitor and limit pore-volume loss; for I2 maximize pore volume retention, while for CH3I prioritize increasing affinity since uptake is affinity-driven in this series.

## Evidence

> “the functionalization of the polarized functional groups did enhance the I2 selectivity (except the MIL-53-Al-PYDC), but the I2 adsorption amounts did not have the obvious enhancement. ... it was attributed to the smaller pore volume and bigger steric hindrance that limited the I2 uptake in functionalized MIL-53-Al-X series, despite the enhanced the I2 selectivity. ... The introduction of polar functional groups proved to substantially enhance the iodine adsorption selectivity by promoting the adsorption affinity. However, this enhancement came at the cost of reduced pore volume, particularly affecting the uptake capacity for I2 adsorption. ... hydrophilicity had a more pronounced impact on I2 adsorption behaviors compared to CH3I.”

Evidence location: pages 6-8

## Links

- Source: [[sources/src_fc58db74fa]]