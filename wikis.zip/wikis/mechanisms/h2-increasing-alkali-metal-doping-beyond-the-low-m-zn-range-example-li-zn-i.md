---
title: "Increasing alkali-metal doping beyond the low M/Zn range (example: Li/Zn increased from ≈0.05 to 0.3 ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_b0ea8c70ab]
confidence: high
---


# Increasing alkali-metal doping beyond the low M/Zn range (example: Li/Zn increased from ≈0.05 to 0.3 ...[TRUNCATED]... 

## Mechanism claim

Increasing alkali-metal doping beyond the low M/Zn range (example: Li/Zn increased from ≈0.05 to 0.35) diminishes H2 uptake and reduces micropore-accessible surface area/micropore volume (e.g., 1·Li* has ~50% of the micropore volume and H2 uptake of 1).

## Applicability

- Task: `h2`
- Mechanism type: `dosing dependence causing pore blocking / loss of accessible microporosity (experimental observation)`
- Condition scope: `{"gas": "H2 (uptake) and N2 (for micropore/ surface area estimation)", "temperature_K": "77 and 87 (examples and summary reported at these cryogenic temperatures)", "pressure_bar": 1.0, "material_family": "1 and higher-loaded doped variants (e.g., 1·Li*)", "method": "experiment (H2 isotherms, N2 isotherms, t-plot analyses)"}`

## Positive design features

- low-level doping beneficial

## Negative design features

- higher-level doping detrimental (example Li/Zn ≈0.35 reduces H2 loading by ~50% relative and 1·Li* micropore volume ~50% of 1)

## Agent design implication

Avoid over-doping; optimize alkali-metal loading (target M/Zn ≈0.05–0.10) because higher dopant concentrations can reduce micropore volume and H2 uptake (monitor micropore volume/BET during tuning).

## Evidence

> Further doping (which was not explored in detail) leads to less effective H2 uptake. (For example, increasing Li/Zn from 0.05 to 0.35 caused the H2 loading at 77 K and 1 atm to drop by ca. (relatively) 50%; see Table 2 and Supporting Information.) Notably, the micropore volume for 1·Li* is about half that of 1, as is the H2 uptake at 1 atm.

Evidence location: Results and Discussion (section 3.2–3.3), Table 2; Conclusions

## Links

- Source: [[sources/src_b0ea8c70ab]]