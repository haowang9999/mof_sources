---
title: "Post-synthetic covalent modifications, activation (to create open metal sites), and ion/particle dop ...[TRUNCATED]... "
type: mechanism
tags: [h2|pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_fa8cccd644]
confidence: high
---


# Post-synthetic covalent modifications, activation (to create open metal sites), and ion/particle dop ...[TRUNCATED]... 

## Mechanism claim

Post-synthetic covalent modifications, activation (to create open metal sites), and ion/particle doping are effective at increasing adsorption enthalpy and/or introducing new adsorption sites that can improve H2 uptake, sometimes substantially.

## Applicability

- Task: `h2|pld`
- Mechanism type: `chemical modification / activation / doping`
- Condition scope: `{"gas": "H2", "temperature_K": null, "pressure_bar": null, "material_family": "MOFs and MOF hybrids (various examples: UiO-66 derivatives, NU-2100, MOF-5@Ni/Co, MIL-101@AC-Li, Pd/Pt-loaded MOFs)", "method": "post-synthetic modification, activation, ion exchange, nanoparticle incorporation"}`

## Positive design features

- post-synthetic covalent modifications increase sorption affinity
- activation exposes unsaturated metal sites (example NU-2100 Qst ~30 kJ mol−1)
- metal ion doping and metal nanoparticle embedding can raise Qst and ambient uptake

## Negative design features

- these modifications can reduce measured SSA or crystallinity
- doped/low-valent metal sites can be air- or moisture-sensitive

## Agent design implication

Use post-synthetic modification, activation and dopants/nanoparticles to raise Qst and introduce active adsorption sites, but measure actual H2 isotherms and Qst since BET may decrease and site stability can be an issue.

## Evidence

> Post-synthetic covalent modifications can greatly enhance the sorption affinity of MOFs for H2. || "Another way to strengthen the interaction ... is through the introduction of unsaturated metal sites ... the activated MOF exhibited a high enthalpy of adsorption of 30 kJ mol−1." || Examples: MOF-5@Ni/Co slightly higher uptake; MIL-101@AC-Li gave very high uptakes (14.4 wt% at −196 °C and 100 bar); Pd/Pt loading increased uptake even when BET decreased.

Evidence location: page 7 (section preceding 3.3) || page 7 (end of section preceding 3.3) || Section 4.2.1 / pages ~12-14

## Links

- Source: [[sources/src_fa8cccd644]]