---
title: "Isosteric enthalpy of adsorption decreases with increasing average pore diameter: narrower pores (ov ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_fa8cccd644]
confidence: high
---


# Isosteric enthalpy of adsorption decreases with increasing average pore diameter: narrower pores (ov ...[TRUNCATED]... 

## Mechanism claim

Isosteric enthalpy of adsorption decreases with increasing average pore diameter: narrower pores (overlapping van der Waals fields) increase (−ΔH)ads and strengthen H2 binding.

## Applicability

- Task: `pld`
- Mechanism type: `pore-confinement / energetic overlap`
- Condition scope: `{"gas": "H2", "temperature_K": null, "pressure_bar": null, "material_family": "MOFs (general)", "method": "review / literature analysis"}`

## Positive design features

- narrow pore diameters increase adsorption enthalpy

## Negative design features

- larger pore diameters reduce (−ΔH)ads

## Agent design implication

To enhance adsorption enthalpy and H2 binding, design MOFs with smaller average pore diameters (narrow micropores) to exploit overlapping van der Waals interactions.

## Evidence

> The isosteric enthalpy of adsorption ((–ΔH)ads) exhibits a linear decrease with increasing average pore diameter. This is attributed to stronger adsorption forces in narrow pores due to overlapping van der Waals forces.

Evidence location: page 6, section 3.1 (Fig. 3b referenced)

## Links

- Source: [[sources/src_fa8cccd644]]