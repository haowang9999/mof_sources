---
title: "No hydrogen (H2) adsorption or H2-specific performance data are reported in the provided text; the p ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_36df794947]
confidence: high
---


# No hydrogen (H2) adsorption or H2-specific performance data are reported in the provided text; the p ...[TRUNCATED]... 

## Mechanism claim

No hydrogen (H2) adsorption or H2-specific performance data are reported in the provided text; the paper instead reports that NbOFFIVE-1-Ni does not adsorb N2 at 77 K and uses CO2 adsorption to probe porosity.

## Applicability

- Task: `h2`
- Mechanism type: `absence_of_data`
- Condition scope: `{"gas": "H2 (no data); N2 reference: 77 K measurement", "temperature_K": 77, "pressure_bar": null, "material_family": "NbOFFIVE-1-Ni", "method": "experiment (N2 adsorption at 77 K reported; no H2 data)"}`

## Positive design features

- Not specified

## Negative design features

- no H2 adsorption data available in provided pages

## Agent design implication

Do not assume H2 adsorption behavior from this text; additional experiments would be required to assess H2 storage/separation performance.

## Evidence

> It is of note that N2 adsorption studies performed at 77 K on the activated material indicated as expected that NbOFFIVE-1-Ni does not adsorb N2 at this cryogenic temperature. Conversely, NbOFFIVE-1-Ni adsorbs CO2; accordingly, this probe was employed to evaluate the porosity properties of this adsorbent.

Evidence location: page 3

## Links

- Source: [[sources/src_36df794947]]