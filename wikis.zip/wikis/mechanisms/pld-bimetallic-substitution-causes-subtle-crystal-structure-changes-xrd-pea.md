---
title: "Bimetallic substitution causes subtle crystal-structure changes (XRD peak shifts, changes in intensi ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_340141308b]
confidence: medium
---


# Bimetallic substitution causes subtle crystal-structure changes (XRD peak shifts, changes in intensi ...[TRUNCATED]... 

## Mechanism claim

Bimetallic substitution causes subtle crystal-structure changes (XRD peak shifts, changes in intensity of specific peaks) that depend on metal atomic radius and composition; this implies metal choice and ratio can tune lattice parameters and which crystal planes are exposed — thereby affecting pore/aperture geometry.

## Applicability

- Task: `pld`
- Mechanism type: `crystal-lattice tuning affecting pore/aperture geometry`
- Condition scope: `{"gas": "not gas-specific", "temperature_K": null, "pressure_bar": null, "material_family": "M(BDC)TED0.5 and MxM1−x(BDC)TED0.5", "method": "experiment (XRD observations)"}`

## Positive design features

- isostructural substitution is possible for divalent metals with similar coordination
- observed XRD peak position/intensity changes with different metals and ratios

## Negative design features

- Not specified

## Agent design implication

Vary metal species and atomic ratio in M(BDC)TED0.5 to intentionally tune lattice parameters and exposed planes as a route to adjust pore geometry and aperture exposure.

## Evidence

> The diffraction peak of Ni(BDC)TED0.5 at 9.2° almost disappeared, and the diffraction peak of Co(BDC)TED0.5 at 9.2° appeared red-shifted. This may be attributed to the effect of different metal atomic radius... The crystal structure of bimetallic MOFs is jointly affected by the metal species and the bimetallic atomic ratio... the position and relative intensity of diffraction peaks of the three copper-containing M0.5M0.5(BDC)TED0.5 and CuxNi1−x(BDC)TED0.5 series materials ... have no obvious change, indicating that the introduction of an appropriate amount of copper ions into M(BDC)TED0.5 will not change the crystal structure.

Evidence location: pages 3-4 (XRD discussion)

## Links

- Source: [[sources/src_340141308b]]