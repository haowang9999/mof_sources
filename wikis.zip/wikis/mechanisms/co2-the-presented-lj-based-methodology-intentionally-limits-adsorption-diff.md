---
title: "The presented LJ-based methodology intentionally limits adsorption/diffusion calculations to nonpola ...[TRUNCATED]... "
type: mechanism
tags: [co2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_97052fb350]
confidence: high
---


# The presented LJ-based methodology intentionally limits adsorption/diffusion calculations to nonpola ...[TRUNCATED]... 

## Mechanism claim

The presented LJ-based methodology intentionally limits adsorption/diffusion calculations to nonpolar adsorbates (to avoid per-MOF charge assignment); thus these calculations exclude Coulombic interactions important for polar/quadrupolar gases such as CO2 and are not reliable for such species without adding charges and electrostatics.

## Applicability

- Task: `co2`
- Mechanism type: `method limitation regarding electrostatics`
- Condition scope: `{"gas": "polar/quadrupolar gases (e.g., CO2) — not treated adequately by presented method", "temperature_K": null, "pressure_bar": null, "material_family": "MOFs", "method": "simulation (LJ only, no charges)"}`

## Positive design features

- Not specified

## Negative design features

- inapplicability to gases where electrostatics are significant
- avoids per-MOF charge assignment

## Agent design implication

Do not rely on the LJ-only, nonpolar-adsorbate KH and ΔEdiff values for CO2; include framework partial charges and electrostatic interactions (and possibly explicit CO2 models) when screening/designing MOFs for CO2 adsorption or diffusion.

## Evidence

> We further limit our attention to nonpolar adsorbates, since this removes the necessity of assigning charges to each MOF framework atom, a time-consuming task that currently requires quantum chemistry calculations for each MOF that is considered.

Evidence location: page 4, section 2.2

## Links

- Source: [[sources/src_97052fb350]]