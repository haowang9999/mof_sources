---
title: "Topology encodes pore shape and polydispersity; certain topologies (those that produce relatively la ...[TRUNCATED]... "
type: mechanism
tags: [co2|h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_c42cf01235]
confidence: medium
---


# Topology encodes pore shape and polydispersity; certain topologies (those that produce relatively la ...[TRUNCATED]... 

## Mechanism claim

Topology encodes pore shape and polydispersity; certain topologies (those that produce relatively larger pores for the same linker length, e.g., rht, stp, rhr, ssb) show little improvement in CO2 selectivity over H2 upon functionalization, while smaller/confined-pore topologies are more responsive.

## Applicability

- Task: `co2|h2`
- Mechanism type: `pore topology effect on adsorption/selectivity`
- Condition scope: `{"gas": "CO2:H2 mixtures (precombustion conditions)", "temperature_K": null, "pressure_bar": 20, "material_family": "parent MOFs across multiple topologies", "method": "GCMC mixture adsorption simulations and comparative analysis"}`

## Positive design features

- topologies that produce smaller/more confined pores for the same linker length may be more responsive to functionalization

## Negative design features

- topologies with relatively larger pores (rht, stp, rhr, ssb) are less susceptible to improvement in CO2:H2 selectivity

## Agent design implication

When aiming to improve CO2:H2 selectivity via functionalization, target MOF topologies with smaller pores or those historically responsive to functionalization rather than large-pore topologies like rht/stp/rhr/ssb.

## Evidence

> “for CO2 selectivity over H2 ... topologies associated with relatively larger pores for the same connecting building block length (e.g., rht, stp, rhr, ssb) are the ones that experience little improvement."

Evidence location: page 6

## Links

- Source: [[sources/src_c42cf01235]]