---
title: "At 298 K, gravimetric adsorption (na) correlates mainly with pore volume (Va) at low H2 pressure and ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_ff1b0c9d63]
confidence: medium
---


# At 298 K, gravimetric adsorption (na) correlates mainly with pore volume (Va) at low H2 pressure and ...[TRUNCATED]... 

## Mechanism claim

At 298 K, gravimetric adsorption (na) correlates mainly with pore volume (Va) at low H2 pressure and with BET surface area (As) at high H2 pressure; design targets (from calculations) for high gravimetric storage include Qst ~15–25 kJ·mol−1, Va ~2.5 cm3·g−1 and porosity ~85% to approach multi-wt% targets.

## Applicability

- Task: `h2`
- Mechanism type: `adsorption capacity scaling with textural properties and isosteric enthalpy`
- Condition scope: `{"gas": "H2", "temperature_K": 298, "pressure_bar": "low and high regimes", "material_family": "pure MOFs", "method": "review / analysis"}`

## Positive design features

- higher Va benefits low-pressure na
- higher As benefits high-pressure na
- Qst 15–25 kJ·mol–1 cited as desirable

## Negative design features

- Not specified

## Agent design implication

For room-temperature H2 storage, aim to maximize pore volume for low-pressure uptake and surface area for high-pressure uptake, while increasing Qst modestly (15–25 kJ·mol−1) via OMS or electrostatic fields to approach targets.

## Evidence

> At 298 K, the na value correlates mainly with the Va value at low P(H2) and the As value at high P(H2). ... Numerous calculations suggest with values of Qst within the range of 15–25 kJ·mol–1, with a Va value of ~2.5 cm3·g–1 and porosity of ~85%, would be desirable for an MOF as a successful candidate for hydrogen storage with 9 wt% of H2.

Evidence location: pages 24-25, Section 5

## Links

- Source: [[sources/src_ff1b0c9d63]]