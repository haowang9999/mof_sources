---
title: "Simulations that include explicit many-body polarization predict a bimodal distribution of induced H ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_532b708453]
confidence: medium
---


# Simulations that include explicit many-body polarization predict a bimodal distribution of induced H ...[TRUNCATED]... 

## Mechanism claim

Simulations that include explicit many-body polarization predict a bimodal distribution of induced H2 dipoles in soc-MOF: a dominant low-dipole population (~0.18 D, ~78% of molecules) localized near open coordination sites, and a higher-dipole population (~0.33 D, ~22%) localized in linker-formed windows; these induced dipoles produce mutual dipolar attractions that help make H2 in the pores nearly condensed at 78 K.

## Applicability

- Task: `h2`
- Mechanism type: `induced dipolar attraction / many-body polarization`
- Condition scope: `{"gas": "H2", "temperature_K": 78, "pressure_bar": null, "material_family": "soc-MOF", "method": "classical Monte Carlo simulation with explicit many-body polarization"}`

## Positive design features

- bimodal induced dipole populations
- spatial localization of induced dipoles near SBUs and linker windows
- mutual dipolar attractions among adsorbed H2

## Negative design features

- neat hydrogen at 78 K shows negligible induced dipole absent MOF fields

## Agent design implication

Design pore surfaces and local charge distributions that induce dipoles of order 0.1–0.3 Debye in H2 to create mutual dipolar attractions and raise the effective condensation tendency of adsorbed H2 at cryogenic temperatures.

## Evidence

> Figure 5 plots the distribution of induced dipoles that is approximately a bimodal Gaussian distribution with a dominant low dipolar (78% of the population with a mean dipole 0.18 Debye) and high dipolar species (22% of the population with a mean dipole 0.33 Debye). ... The low dipolar population corresponds to spatial regions localized in the vicinity of the open coordination sites of the SBUs ... while the high dipolar population is localized in the middle of the window formed by the azobenzene linkers. ... thus, while neat hydrogen at 78 K has a negligible induced dipole ... the hydrogen in the MOF experiences mutual, many-body, dipolar attractions. Thus, it is reasonable that it is nearly condensed in the MOF pores at the conditions considered here and in the experiment at 78 K.

Evidence location: pages 7-8 (Figures 5-6 and accompanying text)

## Links

- Source: [[sources/src_532b708453]]