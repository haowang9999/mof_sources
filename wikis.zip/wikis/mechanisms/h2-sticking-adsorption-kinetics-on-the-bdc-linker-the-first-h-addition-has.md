---
title: "Sticking (adsorption) kinetics on the BDC linker: the first H addition has a small barrier (~0.08 eV ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_0abff73929]
confidence: high
---


# Sticking (adsorption) kinetics on the BDC linker: the first H addition has a small barrier (~0.08 eV ...[TRUNCATED]... 

## Mechanism claim

Sticking (adsorption) kinetics on the BDC linker: the first H addition has a small barrier (~0.08 eV) while subsequent additions up to the six-H thermodynamic sink are barrierless; generally, atomic H sticking to linker sites is kinetically facile.

## Applicability

- Task: `h2`
- Mechanism type: `kinetics / sticking`
- Condition scope: `{"gas": "atomic H", "temperature_K": null, "pressure_bar": null, "material_family": "IRMOF-1 linker (BDC)", "method": "DFT internal reaction coordinate calculations"}`

## Positive design features

- First H sticking barrier is small (0.08 eV) and subsequent additions are barrierless, so hydrogenation proceeds rapidly if atomic H contacts linkers

## Negative design features

- Facile sticking combined with mobile gas-phase H enables Eley–Rideal recombination losses

## Agent design implication

Prioritize enabling atomic-H access to linkers (catalyst proximity, pore entrances) rather than improving intrinsic sticking kinetics; account for competing ER recombination.

## Evidence

> "it was observed that only the first hydrogen addition, that has the smallest adsorption energy, has a small energy barrier (0.08 eV), which is easily overcome at very low temperatures. ... All other H additions were completely barrierless. Thus, the thermodynamic driving force for formation of the hydrogenated structure would be quickly realized if the linker is brought into contact with H atoms." "During diffusion, atomic hydrogen can stick on all available binding sites on the linkers with negligible energy barriers."

Evidence location: page 6; page 1 (abstract)

## Links

- Source: [[sources/src_0abff73929]]