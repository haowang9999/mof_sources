---
title: "Pore morphology (geometry: width and volume, wall roughness) is a main characteristic affecting hydr ...[TRUNCATED]... "
type: mechanism
tags: [pld|h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_ff1b0c9d63]
confidence: high
---


# Pore morphology (geometry: width and volume, wall roughness) is a main characteristic affecting hydr ...[TRUNCATED]... 

## Mechanism claim

Pore morphology (geometry: width and volume, wall roughness) is a main characteristic affecting hydrogen adsorption; small pore diameter (approx. 4–7 Å) is important for achieving higher H2 adsorption at room temperature because overlapping wall potentials increase interaction energy.

## Applicability

- Task: `pld|h2`
- Mechanism type: `pore geometry effect on adsorption (size/shape/roughness)`
- Condition scope: `{"gas": "H2", "temperature_K": 298, "pressure_bar": null, "material_family": "microporous MOFs (general)", "method": "review / conceptual"}`

## Positive design features

- small pore diameter helps room-temperature adsorption
- morphology influences adsorption kinetics and capacity

## Negative design features

- Not specified

## Agent design implication

When targeting room-temperature H2 uptake, design for small micropore diameters (~4–7 Å) and appropriate pore wall characteristics (roughness, functionalization) rather than only maximizing surface area.

## Evidence

> In the case of microporous MOFs, the morphology of the pores represents their main characteristics, including the geometrical shape (pore width and pore volume) and roughness of the pore walls. A small pore diameter was found to be an important factor for the achievement of a high value of hydrogen adsorption capacity at room temperature. ... the small diameter of pores enables energy potentials to overlap between the opposing walls, resulting in higher interaction energy with H2 molecules [185].

Evidence location: pages 21-23, Section 4.3 and 4.3.2

## Links

- Source: [[sources/src_ff1b0c9d63]]