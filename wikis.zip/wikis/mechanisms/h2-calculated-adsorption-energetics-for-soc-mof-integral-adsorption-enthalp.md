---
title: "Calculated adsorption energetics for soc-MOF: integral adsorption enthalpies of approximately −14.35 ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_532b708453]
confidence: medium
---


# Calculated adsorption energetics for soc-MOF: integral adsorption enthalpies of approximately −14.35 ...[TRUNCATED]... 

## Mechanism claim

Calculated adsorption energetics for soc-MOF: integral adsorption enthalpies of approximately −14.35 kJ mol^-1 at the zero-loading (unsaturated) limit and −10.65 kJ mol^-1 at saturation; polarization contributes roughly 23–27% of the total potential energy depending on loading; simulated enthalpies are larger than an experimentally measured isosteric heat (~6.5 kJ mol^-1).

## Applicability

- Task: `h2`
- Mechanism type: `thermodynamic adsorption energetics`
- Condition scope: `{"gas": "H2", "temperature_K": 78, "pressure_bar": null, "material_family": "soc-MOF", "method": "simulation (polarizable Monte Carlo)"}`

## Positive design features

- substantial polarization contribution to adsorption enthalpy (~23–27%)

## Negative design features

- simulated enthalpies exceed experimentally measured isosteric heats (~6.5 kJ mol^-1) indicating discrepancy

## Agent design implication

Including many-body polarization in energetics calculations can reveal larger adsorption enthalpies and quantify the percent contribution of induction; however, validate energetics against experimental isotherms since simulated integral enthalpies here exceed reported experimental values.

## Evidence

> ΔHsat_a was found to be -10.645 ( 0.188 kJ mol-1, while the unsaturated state yielded ΔHunsat_a of -14.354 ( 1.685 kJ mol-1; ... Polarization contributed 23% of the total potential energy at saturation and 27% when unsaturated. ... These enthalpies appear large compared to the experimental measurements that give a relatively constant isosteric heat of sorption of about 6.5 kJ mol-1.

Evidence location: page 8-9 (Results and Discussion / Energetics)

## Links

- Source: [[sources/src_532b708453]]