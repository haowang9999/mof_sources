---
title: "CO2 generally interacts more strongly with MOF functional groups than N2 and H2; H2 interacts the we ...[TRUNCATED]... "
type: mechanism
tags: [co2|h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_c42cf01235]
confidence: high
---


# CO2 generally interacts more strongly with MOF functional groups than N2 and H2; H2 interacts the we ...[TRUNCATED]... 

## Mechanism claim

CO2 generally interacts more strongly with MOF functional groups than N2 and H2; H2 interacts the weakest (on average ∼2 kJ/mol weaker than N2), so CO2 selectivities over H2 are typically higher than over N2.

## Applicability

- Task: `co2|h2`
- Mechanism type: `relative adsorbate–adsorbent interaction strengths`
- Condition scope: `{"gas": "CO2, N2, H2", "temperature_K": null, "pressure_bar": null, "material_family": "functionalized MOFs (DFT binding energies)", "method": "DFT calculations"}`

## Positive design features

- functional groups with larger bond dipole moments increase the CO2 vs N2/H2 binding contrast

## Negative design features

- Not specified

## Agent design implication

To maximize CO2 over H2 (precombustion) or CO2 over N2 (postcombustion) selectivities, introduce functional groups that enhance electrostatic binding to CO2 because CO2 benefits more from electrostatics than N2 or H2.

## Evidence

> “CO2 is generally found to interact with the functional groups more strongly than N2 and H2 (Table 1), particularly for groups with larger HBDMs. H2 generally interacts more weakly (by ∼2 kJ/mol on average) with the functionalities than N2 does, so the difference in binding strength between CO2 and H2 is generally more pronounced (by ∼2 kJ/mol on average) than the difference in binding strength between CO2 and N2. Not surprisingly, CO2 selectivities over H2 are known to be higher than over N2."

Evidence location: page 4

## Links

- Source: [[sources/src_c42cf01235]]