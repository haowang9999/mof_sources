---
title: "At 298 K the observed amount adsorbed correlates mainly with pore volume at low H2 pressure and with ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_b1552d4a9d]
confidence: high
---


# At 298 K the observed amount adsorbed correlates mainly with pore volume at low H2 pressure and with ...[TRUNCATED]... 

## Mechanism claim

At 298 K the observed amount adsorbed correlates mainly with pore volume at low H2 pressure and with surface area at high H2 pressure; thus the dominant textural target depends on the charging pressure.

## Applicability

- Task: `pld`
- Mechanism type: `pressure-dependent role of pore volume vs surface area`
- Condition scope: `{"gas": "H2", "temperature_K": 298, "pressure_bar": "low vs high P(H2) regimes (general statement)", "material_family": "general MOFs", "method": "review"}`

## Positive design features

- gives operational guidance on which textural parameter to optimize depending on charging pressure

## Negative design features

- Not specified

## Agent design implication

For low-pressure/near-ambient charging prioritize maximizing pore volume; for high-pressure storage prioritize maximizing surface area.

## Evidence

> At 298 K, the n value correlates mainly with the V value at low P(H2) and the A value at high P(H2).

Evidence location: page 11

## Links

- Source: [[sources/src_b1552d4a9d]]