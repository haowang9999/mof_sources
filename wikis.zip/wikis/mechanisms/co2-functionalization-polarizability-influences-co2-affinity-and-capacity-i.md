---
title: "Functionalization polarizability influences CO2 affinity and capacity in a nonlinear manner and can  ...[TRUNCATED]... "
type: mechanism
tags: [co2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_a318a71841]
confidence: high
---


# Functionalization polarizability influences CO2 affinity and capacity in a nonlinear manner and can  ...[TRUNCATED]... 

## Mechanism claim

Functionalization polarizability influences CO2 affinity and capacity in a nonlinear manner and can also limit CO2 diffusivity (trade-off between increased affinity and reduced kinetics).

## Applicability

- Task: `co2`
- Mechanism type: `chemical/polarizability effect on adsorption energetics and diffusion`
- Condition scope: `{"gas": "CO2 (in competition with C2H2)", "temperature_K": null, "pressure_bar": null, "material_family": "rigid honeycomb-like MOF with varied side-chain polarizability (BA, BPY examples)", "method": "experiment (isosteric enthalpy fits, breakthrough measurements)"}`

## Positive design features

- more polarizable side chains can increase CO2 affinity/capacity

## Negative design features

- increased polarizability may reduce CO2 diffusivity and productivity

## Agent design implication

Selecting more polarizable side-chain functionalizations can raise CO2 affinity and working capacity, but anticipate and measure diffusion/kinetic penalties and balance polarizability against diffusivity.

## Evidence

> the latter influences CO2 affinity and capacity nonlinearly as well as limits CO2 diffusivity.

Evidence location: page 8 (Conclusions)

## Links

- Source: [[sources/src_a318a71841]]