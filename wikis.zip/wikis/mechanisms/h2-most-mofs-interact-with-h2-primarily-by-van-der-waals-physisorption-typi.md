---
title: "Most MOFs interact with H2 primarily by van der Waals physisorption; typical (−ΔH)ads values are 5–1 ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_fa8cccd644]
confidence: high
---


# Most MOFs interact with H2 primarily by van der Waals physisorption; typical (−ΔH)ads values are 5–1 ...[TRUNCATED]... 

## Mechanism claim

Most MOFs interact with H2 primarily by van der Waals physisorption; typical (−ΔH)ads values are 5–12 kJ mol−1, which are generally too low for practical ambient-temperature storage where ~15–25 kJ mol−1 is desirable.

## Applicability

- Task: `h2`
- Mechanism type: `thermodynamic binding strength`
- Condition scope: `{"gas": "H2", "temperature_K": 298, "pressure_bar": null, "material_family": "MOFs (general)", "method": "review and simulations"}`

## Positive design features

- physisorption allows reversible adsorption/desorption

## Negative design features

- most MOFs' binding enthalpies (5–12 kJ mol−1) insufficient for ambient retention

## Agent design implication

For room-temperature H2 storage, increase binding enthalpy into ~15–25 kJ mol−1 via chemistry (linker functionalization, open metal sites, dopants) while monitoring reversibility.

## Evidence

> Van der Waals forces ... are the main gas–adsorbent interaction. For optimum hydrogen storage and release cycles at room temperature, an adsorbent should have a (–ΔH)ads between 15 and 25 kJ mol−1. Unfortunately, the majority of MOFs exhibit (–ΔH)ads values between 5 and 12 kJ mol−1. Simulations (Bae and Snurr) indicate an optimum near 20 kJ mol−1.

Evidence location: pages 6–7, section 3.2

## Links

- Source: [[sources/src_fa8cccd644]]