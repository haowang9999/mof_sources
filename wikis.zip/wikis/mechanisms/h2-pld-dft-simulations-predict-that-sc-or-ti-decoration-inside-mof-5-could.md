---
title: "DFT simulations predict that Sc- or Ti-decoration inside MOF-5 could (theoretically) bind multiple H ...[TRUNCATED]... "
type: mechanism
tags: [h2|pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_ff1b0c9d63]
confidence: medium
---


# DFT simulations predict that Sc- or Ti-decoration inside MOF-5 could (theoretically) bind multiple H ...[TRUNCATED]... 

## Mechanism claim

DFT simulations predict that Sc- or Ti-decoration inside MOF-5 could (theoretically) bind multiple H2 per metal atom (up to five), giving high theoretical gravimetric capacities (~5.7–5.8 wt%) and Qst in the 20–40 kJ·mol−1 range, though clustering (especially Ti) may limit realization.

## Applicability

- Task: `h2|pld`
- Mechanism type: `theoretical chemisorption/coordination-enhanced adsorption (DFT prediction)`
- Condition scope: `{"gas": "H2", "temperature_K": null, "pressure_bar": null, "material_family": "Sc- or Ti-decorated MOF-5 (theoretical)", "method": "ab initio DFT simulation"}`

## Positive design features

- 5 H2 molecules per metal atom predicted
- Qst predicted 20–40 kJ·mol−1

## Negative design features

- clustering of Ti atoms predicted (may complicate uniform decoration)

## Agent design implication

Consider light transition metal decoration (Sc, Ti) in MOF-5 as a theoretical route to high gravimetric H2 capacity; however, watch for clustering effects that may reduce realized benefit.

## Evidence

> The calculations predicted that Ti atoms may undergo clustering, whereas Sc atoms preferred the full metal decoration of MOF-5. Both Sc- and Ti-decorated MOF-5 may adsorb the 5H2 molecules per metal atom, resulting in a theoretical hydrogen adsorption capacity of 5.81 and 5.72 wt%, respectively. The calculated Qst value was predicted within the range of 20–40 kJ·mol–1 and additional improvement ... may be achieved with boron substitution.

Evidence location: page 22-23, Section 4.3.1 (DFT results)

## Links

- Source: [[sources/src_ff1b0c9d63]]