---
title: "Large-scale hierarchical screening (PLD/LCD geometric filters coupled with Henry's-constant and diff ...[TRUNCATED]... "
type: mechanism
tags: [mixed, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_97052fb350]
confidence: medium
---


# Large-scale hierarchical screening (PLD/LCD geometric filters coupled with Henry's-constant and diff ...[TRUNCATED]... 

## Mechanism claim

Large-scale hierarchical screening (PLD/LCD geometric filters coupled with Henry's-constant and diffusion-activation estimates) applied to >500 MOFs and >160 silica zeolites shows many large-pore MOFs are of limited interest for kinetic separations but identifies a subset of materials predicted to have extraordinary properties for separations (e.g., some ZIF-8 and Cu(hfipbb) variants).

## Applicability

- Task: `mixed`
- Mechanism type: `database-scale computational screening outcome (geometry + molecular modeling)`
- Condition scope: `{"gas": "CO2, CH4, H2 (as targeted separations in the reported screening)", "temperature_K": null, "pressure_bar": null, "material_family": "MOFs and silica zeolites (structures from experimental crystal data)", "method": "simulation (hierarchical geometric and molecular modeling applied to databases)"}`

## Positive design features

- Screening identifies candidate MOFs with large differences in diffusion coefficients between species
- Method is computationally efficient and applicable to hundreds of structures

## Negative design features

- Many large-pore MOFs lack strong kinetic selectivity (limited interest for kinetic separations)
- Predictions depend on fixed-framework assumptions unless additional flexibility analysis is performed

## Agent design implication

Use the described hierarchical screening (PLD/LCD geometric filters plus estimated Henry's constants and diffusion activation energies) to triage large materials databases: deprioritize many large-pore MOFs for kinetic separations and focus experimental follow-up on the subset predicted to have strong diffusion-based selectivity for CO2, H2, or CH4.

## Evidence

> We demonstrate our approach for >500 MOFs and >160 silica zeolites. Our results indicate that many large pore MOFs will be of limited interest for separations based on kinetic effects, but we identify a significant number of materials that are predicted to have extraordinary properties for separation of gases such as CO2, CH4, and H2.

Evidence location: page 1 (Abstract) and page 2 (end of section 1)

## Links

- Source: [[sources/src_97052fb350]]