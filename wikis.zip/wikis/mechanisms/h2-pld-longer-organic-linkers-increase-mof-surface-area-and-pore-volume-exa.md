---
title: "Longer organic linkers increase MOF surface area and pore volume (example: UiO-67 vs UiO-66), leadin ...[TRUNCATED]... "
type: mechanism
tags: [h2|pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_b1552d4a9d]
confidence: high
---


# Longer organic linkers increase MOF surface area and pore volume (example: UiO-67 vs UiO-66), leadin ...[TRUNCATED]... 

## Mechanism claim

Longer organic linkers increase MOF surface area and pore volume (example: UiO-67 vs UiO-66), leading to higher high-pressure H2 uptake, but longer linkers can increase risk of catenation/interpenetration which reduces accessible porosity.

## Applicability

- Task: `h2|pld`
- Mechanism type: `linker-length -> surface area/volume effect`
- Condition scope: `{"gas": "H2", "temperature_K": 77, "pressure_bar": 38, "material_family": "UiO-66 vs UiO-67 (Zr-based MOFs)", "method": "reported experimental comparison (reviewed)"}`

## Positive design features

- longer linkers enable higher As and V leading to higher high-pressure uptake

## Negative design features

- long linkers may promote framework interpenetration (catenation) unless synthesis is controlled

## Agent design implication

Use longer organic linkers to increase surface area and pore volume for higher-pressure H2 storage, but apply synthesis controls to avoid catenation that reduces accessible sites.

## Evidence

> The longer linker in UiO-67 produced As = 2483 m2·g−1 vs 1281 m2·g−1 for UiO-66, V = 0.85 vs 0.43 cm3·g−1, and H2 uptake at 77 K and 38 bar of 4.6 wt% vs 2.4 wt%, respectively.

Evidence location: page 6

## Links

- Source: [[sources/src_b1552d4a9d]]