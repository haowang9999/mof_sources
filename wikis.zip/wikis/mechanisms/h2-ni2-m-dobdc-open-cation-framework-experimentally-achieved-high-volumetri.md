---
title: "Ni2(m-dobdc) (open cation framework) experimentally achieved high volumetric H2 storage at near-ambi ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_ff1b0c9d63]
confidence: high
---


# Ni2(m-dobdc) (open cation framework) experimentally achieved high volumetric H2 storage at near-ambi ...[TRUNCATED]... 

## Mechanism claim

Ni2(m-dobdc) (open cation framework) experimentally achieved high volumetric H2 storage at near-ambient temperatures (11.0 g H2·L−1 at 298 K within 5–100 bar) attributed to highly polarizing open Ni2+ sites enabling dense packing.

## Applicability

- Task: `h2`
- Mechanism type: `open, highly polarizing metal cation sites increase volumetric packing/density`
- Condition scope: `{"gas": "H2", "temperature_K": 298, "pressure_bar": "5–100", "material_family": "Ni2(m-dobdc)", "method": "experiment"}`

## Positive design features

- high volumetric hydrogen capacity at near-ambient temperature/pressures
- strong polarizing Ni2+ open sites

## Negative design features

- Not specified

## Agent design implication

To increase volumetric H2 storage at near-ambient temperatures, use frameworks with highly polarizing open metal cation sites (e.g., Ni2+) to promote dense H2 packing.

## Evidence

> At 298 K, hydrogen storage of 11.0 g H2·L–1 and 23.0 g/L with a temperature change between 198 and 298 K were experimentally confirmed for Ni2(m-dobdc) within the range of 5–100 bar of H2. These results were explained by the presence of open metal cation sites (highly polarizing Ni2+), which strongly interacted with H2 molecules, thus providing their dense packing within Ni2(m-dobdc).

Evidence location: page 18

## Links

- Source: [[sources/src_ff1b0c9d63]]