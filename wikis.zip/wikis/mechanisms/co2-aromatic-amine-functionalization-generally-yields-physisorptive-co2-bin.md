---
title: "Aromatic amine functionalization generally yields physisorptive CO2 binding (Qst ~25–50 kJ mol−1) wh ...[TRUNCATED]... "
type: mechanism
tags: [co2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_83cde498f9]
confidence: high
---


# Aromatic amine functionalization generally yields physisorptive CO2 binding (Qst ~25–50 kJ mol−1) wh ...[TRUNCATED]... 

## Mechanism claim

Aromatic amine functionalization generally yields physisorptive CO2 binding (Qst ~25–50 kJ mol−1) while alkylamine appendage at open metal sites typically produces chemisorption with much higher Qst (e.g., ~71 kJ mol−1 for mmen-Mg2(dobpdc)); Cu(adci)-2 follows the aromatic-amine physisorption behavior.

## Applicability

- Task: `co2`
- Mechanism type: `functional_group_type_effect (alkylamine vs aromatic amine)`
- Condition scope: `{"gas": "CO2", "temperature_K": null, "pressure_bar": null, "material_family": "amine-appended and amine-functionalized MOFs (comparison)", "method": "literature comparison + experiment (Cu(adci)-2 Qst)"}`

## Positive design features

- aromatic amine approach yields lower Qst (easier regeneration) while retaining physisorptive capacity

## Negative design features

- alkylamine-appended OMS approaches increase Qst and regeneration energy

## Agent design implication

Prefer aromatic amine ligand functionalization over alkylamine grafting to OMSs when aiming for lower regeneration energy and physisorptive CO2 capture at low pressures.

## Evidence

> Page 1: "Alkylamines appended to open metal sites (OMSs) are identified as able to chemisorb CO2... the isosteric heat of adsorption (Qst)... becomes quite high for the alkylamine-appended MOFs, e.g., 71 kJ mol−1 for mmen-Mg2(dobpdc)... Meanwhile, aromatic amines... physisorb CO2 with Qst values generally in the range of 25 to 50 kJ mol−1."; Page 2: Cu(adci)-2 Qst = 27.5 kJ mol−1.

Evidence location: page 1 (intro); page 2 (Qst measurement)

## Links

- Source: [[sources/src_83cde498f9]]