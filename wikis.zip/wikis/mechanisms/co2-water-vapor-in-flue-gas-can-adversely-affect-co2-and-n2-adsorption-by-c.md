---
title: "Water vapor in flue gas can adversely affect CO2 and N2 adsorption by competing for adsorption sites ...[TRUNCATED]... "
type: mechanism
tags: [co2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_1fa85425f9]
confidence: high
---


# Water vapor in flue gas can adversely affect CO2 and N2 adsorption by competing for adsorption sites ...[TRUNCATED]... 

## Mechanism claim

Water vapor in flue gas can adversely affect CO2 and N2 adsorption by competing for adsorption sites and can affect MOF stability; therefore presence of water must be considered in studies focusing on CO2/N2 separation.

## Applicability

- Task: `co2`
- Mechanism type: `competitive adsorption / stability`
- Condition scope: `{"gas": "CO2, N2, and H2O vapor (humid/flue gas conditions)", "temperature_K": null, "pressure_bar": null, "material_family": "MOFs", "method": "simulation and experimental consideration (review)"}`

## Positive design features

- Not specified

## Negative design features

- Water competes for adsorption sites and may reduce CO2/N2 uptake; may affect MOF stability

## Agent design implication

Include water vapor and examine MOF stability under humid conditions when screening MOFs for CO2/N2 separations; single-gas, dry-condition screening can miss deleterious competition and stability effects.

## Evidence

> Presence of water vapor in the flue gas stream must be considered in studies focusing of CO2/N2 separation because water can adversely affect the adsorption of CO2 and N2 by competing for adsorption sites and even by affecting the MOF’s stability. (pages 5-6).

Evidence location: page 5-6

## Links

- Source: [[sources/src_1fa85425f9]]