---
title: "Combining aromatic amine functionalization with ultramicroporosity enhances low-pressure CO2 adsorpt ...[TRUNCATED]... "
type: mechanism
tags: [co2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_83cde498f9]
confidence: high
---


# Combining aromatic amine functionalization with ultramicroporosity enhances low-pressure CO2 adsorpt ...[TRUNCATED]... 

## Mechanism claim

Combining aromatic amine functionalization with ultramicroporosity enhances low-pressure CO2 adsorption via increased Lewis base–acid interactions (amine–CO2) and intensified London dispersion from confinement.

## Applicability

- Task: `co2`
- Mechanism type: `functional_group_interaction + pore_confinement (host–guest interactions)`
- Condition scope: `{"gas": "CO2", "temperature_K": null, "pressure_bar": 0.15, "material_family": "Cu(adci)-2 (amine-functionalized ultramicroporous MOF)", "method": "experiment + simulation"}`

## Positive design features

- aromatic NH2 groups on linker (Lewis base sites)
- ultramicroporosity (LCD 3.65 Å, PLD 3.27 Å) leading to strong dispersion interactions

## Negative design features

- Not specified

## Agent design implication

Design MOFs that colocate aromatic amine groups inside ultramicropores (<~7 Å, here PLD ~3.3 Å) to combine Lewis base–acid interactions and enhanced London dispersion for improved low-pressure CO2 uptake while keeping adsorption physisorptive.

## Evidence

> Abstract: "combining two strategies to design MOF physisorbents for enhanced CO2 capturing, i.e., aromatic amine functionalization and the introduction of ultramicroporosity (pore size <7 Å)"; Abstract/discussion: "preferential CO2 binding site of Cu(adci)-2 was predicted to be between two ligands... implying that its CO2 adsorption properties originate from the enhancement of Lewis base-acid and London dispersion interactions due to the amino groups and ultramicroporosity, respectively."

Evidence location: page 1 (Abstract); page 2 (intro / discussion)

## Links

- Source: [[sources/src_83cde498f9]]