---
title: "The chemical nature and number of aromatic rings in IRMOF linkers influences H2 sorption (reported I ...[TRUNCATED]... "
type: mechanism
tags: [h2|pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_ff1b0c9d63]
confidence: high
---


# The chemical nature and number of aromatic rings in IRMOF linkers influences H2 sorption (reported I ...[TRUNCATED]... 

## Mechanism claim

The chemical nature and number of aromatic rings in IRMOF linkers influences H2 sorption (reported IRMOF uptakes at 77 K and 1 bar ranged ~0.89–1.73 wt% across linkers).

## Applicability

- Task: `h2|pld`
- Mechanism type: `linker chemistry → adsorption`
- Condition scope: `{"gas": "H2", "temperature_K": 77, "pressure_bar": 1, "material_family": "IRMOF family", "method": "experiment"}`

## Positive design features

- certain linker chemistries/longer linkers correlated with higher H2 uptake

## Negative design features

- some linkers give lower uptake depending on geometry

## Agent design implication

Select linker chemistries (aromatic motif and ring count) in IRMOF-type frameworks to tune pore size/surface area and H2 uptake at cryogenic conditions.

## Evidence

> The number of aromatic benzene rings may also influence the hydrogen sorption, as determined from the study of IRMOFs... The hydrogen sorption changed within the range of 0.89–1.73 wt% H2 [89]. ... The results obtained for IRMOFs confirmed that the organic linker geometry, particularly the length, has a direct influence on the pore size, and hence the surface area of MOFs.

Evidence location: Table 2 and associated text (pages 12-13)

## Links

- Source: [[sources/src_ff1b0c9d63]]