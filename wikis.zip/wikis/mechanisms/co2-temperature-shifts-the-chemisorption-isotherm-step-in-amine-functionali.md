---
title: "Temperature shifts the chemisorption isotherm step in amine-functionalized materials to higher press ...[TRUNCATED]... "
type: mechanism
tags: [co2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_20dae1036b]
confidence: high
---


# Temperature shifts the chemisorption isotherm step in amine-functionalized materials to higher press ...[TRUNCATED]... 

## Mechanism claim

Temperature shifts the chemisorption isotherm step in amine-functionalized materials to higher pressures as temperature increases; this temperature dependence can be exploited to obtain large working capacities and high regenerability for TSA processes provided the binding strength is correctly tuned.

## Applicability

- Task: `co2`
- Mechanism type: `temperature-dependent cooperative chemisorption affecting working capacity and regenerability`
- Condition scope: `{"gas": "CO2 (15% CO2 / 85% N2 mixture feed typical of flue gas)", "temperature_K": {"adsorption": null, "regeneration": 373}, "pressure_bar": 1.0, "material_family": "amine-functionalized MOF-74 and DOBPDC", "method": "simulation (TSA process evaluation using GCMC isotherms)"}`

## Positive design features

- isotherm step position is temperature-sensitive enabling control of working capacity with regeneration temperature
- can enable almost complete regenerability under specific temperature swings

## Negative design features

- adsorbents that bind CO2 too strongly require high regeneration temperature (higher energy penalty)

## Agent design implication

Choose amine/metal combinations such that the chemisorption isotherm step shifts into the desired pressure range at the intended adsorption and regeneration temperatures (e.g., regeneration around 373 K) to maximize working capacity while limiting regeneration energy.

## Evidence

> “In the functionalized ones, with the explicit chemisorption analyzed in this study, it is observed that as the temperature increases the position of the isotherm step shifts to higher pressures... allowing large working capacities and almost complete regenerability under specific conditions. However, using an adsorbent that binds CO2 too strongly would increase the temperature (energy) required to break the framework–CO2 interactions...”

Evidence location: page 7

## Links

- Source: [[sources/src_20dae1036b]]