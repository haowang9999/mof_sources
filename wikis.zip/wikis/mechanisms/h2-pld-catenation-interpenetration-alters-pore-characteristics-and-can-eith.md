---
title: "Catenation/interpenetration alters pore characteristics and can either increase H2 adsorption (via s ...[TRUNCATED]... "
type: mechanism
tags: [h2|pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_ff1b0c9d63]
confidence: medium
---


# Catenation/interpenetration alters pore characteristics and can either increase H2 adsorption (via s ...[TRUNCATED]... 

## Mechanism claim

Catenation/interpenetration alters pore characteristics and can either increase H2 adsorption (via smaller pores and stronger host–guest interactions at higher pressures) or decrease it (by blocking open metal sites or reducing surface area), depending on degree and conditions.

## Applicability

- Task: `h2|pld`
- Mechanism type: `framework interpenetration → pore size/OMS accessibility → pressure-dependent adsorption`
- Condition scope: `{"gas": "H2", "temperature_K": [77, 298], "pressure_bar": [1, 50], "material_family": "catenated vs non-catenated PCN frameworks and other interpenetrated MOFs", "method": "experiment (including inelastic neutron scattering)"}`

## Positive design features

- moderate catenation/interpenetration → smaller pores → stronger host–guest interactions → higher adsorption at higher pressures

## Negative design features

- catenation that blocks open metal sites → reduced low-pressure adsorption
- excessive interpenetration → low surface area and low H2 uptake

## Agent design implication

Tune catenation/interpenetration to reduce pore sizes moderately if the target is high-pressure H2 storage (benefit: stronger host–guest interactions and framework strength); avoid excessive interpenetration which reduces BET area and blocks OMS, hurting low-pressure uptake.

## Evidence

> It is obvious that catenation directly affects the H2 adsorption in MOFs... after sample activation at 323 K, the hydrogen adsorption capacity at 77 K and 1 bar of H2 was 1.74 and 1.35 wt% for PCN-6 and PCN-60... INS experiments suggested that in these MOFs, the open metal sites are most favorable for the H2 molecules, and at higher P values, the interaction between the H2 molecules and the organic linkers becomes stronger in the catenated PCN-6. ... at 77 K and 50 bar, na = 8.7 wt% (PCN-6) vs 5.5 wt% (PCN-60). ... When MOFs are catenated too much, they show very low H2 adsorption.

Evidence location: section 4.1.2 and Table 3 (pages 13-14)

## Links

- Source: [[sources/src_ff1b0c9d63]]