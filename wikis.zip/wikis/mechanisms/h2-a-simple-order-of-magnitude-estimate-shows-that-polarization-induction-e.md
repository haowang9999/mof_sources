---
title: "A simple order-of-magnitude estimate shows that polarization (induction) energy can be substantially ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_532b708453]
confidence: high
---


# A simple order-of-magnitude estimate shows that polarization (induction) energy can be substantially ...[TRUNCATED]... 

## Mechanism claim

A simple order-of-magnitude estimate shows that polarization (induction) energy can be substantially larger than the quadrupolar interaction for H2 near a charged center (e.g., ~4× larger at 0.30 nm from a doubly charged cation), implying induction is not negligible and is always attractive in such geometries.

## Applicability

- Task: `h2`
- Mechanism type: `quantitative_estimate / interaction_strength`
- Condition scope: `{"gas": "H2", "temperature_K": null, "pressure_bar": null, "material_family": "model of H2 near a doubly charged cation (representing indium)", "method": "order-of-magnitude theoretical estimate"}`

## Positive design features

- polarization energy >> quadrupolar energy in close proximity to charged centers

## Negative design features

- Not specified

## Agent design implication

Prioritize inclusion of polarizable sites in models and design strategies for MOFs with proximate charged cations (within ~0.3 nm) since induction can dominate binding.

## Evidence

> As an estimate of the relative importance of quadrupole ... consider a polarizable site with a point quadrupole, both of the magnitude appropriate for molecular hydrogen placed 0.30 nm distant from a double-charged cation ... the polarization energy is a factor of 4 larger and is always attractive.

Evidence location: PAGE 2

## Links

- Source: [[sources/src_532b708453]]