---
title: "For heavily functionalized frameworks, IAST predictions can deviate substantially from experimental  ...[TRUNCATED]... "
type: mechanism
tags: [co2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_a318a71841]
confidence: high
---


# For heavily functionalized frameworks, IAST predictions can deviate substantially from experimental  ...[TRUNCATED]... 

## Mechanism claim

For heavily functionalized frameworks, IAST predictions can deviate substantially from experimental breakthrough behavior; kinetic/nonideal effects make experimental validation necessary.

## Applicability

- Task: `co2`
- Mechanism type: `methodological limitation (IAST vs experiment)`
- Condition scope: `{"gas": "CO2 and C2H2 (competitive)", "temperature_K": null, "pressure_bar": null, "material_family": "heavily functionalized MOFs (as in study)", "method": "comparison of IAST predictions and breakthrough experiments"}`

## Positive design features

- Not specified

## Negative design features

- IAST may mispredict performance for heavily functionalized frameworks

## Agent design implication

Do not rely solely on IAST for heavily functionalized MOFs; use experimental breakthrough testing to capture nonideal energetic and kinetic effects.

## Evidence

> It is notable that the pronounced nonideality of the MOF functionalizations highlights the importance of experimental breakthrough measurements for heavily functionalized frameworks to complement IAST selectivities in sorption studies.

Evidence location: page 8 (Conclusions)

## Links

- Source: [[sources/src_a318a71841]]