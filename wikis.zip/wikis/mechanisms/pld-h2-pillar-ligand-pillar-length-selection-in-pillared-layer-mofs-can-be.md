---
title: "Pillar ligand (pillar length) selection in pillared-layer MOFs can be used to adjust pore design and ...[TRUNCATED]... "
type: mechanism
tags: [pld|h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_ff1b0c9d63]
confidence: medium
---


# Pillar ligand (pillar length) selection in pillared-layer MOFs can be used to adjust pore design and ...[TRUNCATED]... 

## Mechanism claim

Pillar ligand (pillar length) selection in pillared-layer MOFs can be used to adjust pore design and hydrogen adsorption properties; activation (desolvation) can affect Qst.

## Applicability

- Task: `pld|h2`
- Mechanism type: `pore-design influence on adsorption`
- Condition scope: `{"gas": "H2", "temperature_K": null, "pressure_bar": null, "material_family": "pillared-layer MOFs (e.g., [Zn4(bpta)2(H2O)2] series)", "method": "experiment"}`

## Positive design features

- tunable pillar length to create open frameworks
- systematic variation of pillar to control pores

## Negative design features

- Not specified

## Agent design implication

When designing pillared-layer MOFs for hydrogen adsorption, select pillar ligands to tune pore size/shape; include activation/desolvation in testing because activation can change Qst.

## Evidence

> The authors developed a synthetic strategy that allowed systematic variation of the pillar to construct open frameworks with a similar structure. It was concluded that pore design could be adjusted by the selection of pillar ligands, hence leading to different hydrogen adsorption properties. The results obtained indicated that the activation process of these MOFs could affect the Qst value.

Evidence location: page 16

## Links

- Source: [[sources/src_ff1b0c9d63]]