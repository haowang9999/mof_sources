---
title: "Transfer learning (TL) performance for adsorption tasks across MOF clusters depends on the Euclidean ...[TRUNCATED]... "
type: mechanism
tags: [mixed, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_71bcf59437]
confidence: high
---


# Transfer learning (TL) performance for adsorption tasks across MOF clusters depends on the Euclidean ...[TRUNCATED]... 

## Mechanism claim

Transfer learning (TL) performance for adsorption tasks across MOF clusters depends on the Euclidean (PCA) distance between source and target clusters: as PC distance increases, predictive performance (R2) generally decreases while model variance and the amount of information/data required increase.

## Applicability

- Task: `mixed`
- Mechanism type: `empirical ML relationship (distance in feature space -> TL performance)`
- Condition scope: `{"gas": "H2 and CH4 (observed across adsorption tasks)", "temperature_K": null, "pressure_bar": null, "material_family": "MOFs clustered by PCA of textural features or by topology", "method": "simulation + machine learning (neural network TL)"}`

## Positive design features

- small PCA distance between clusters
- clusters near central/information-rich regions

## Negative design features

- large PCA distance between clusters
- clusters at extremes of PC space (e.g., cluster 0)

## Agent design implication

Prefer sources that are close in PCA feature space to the target and/or use central/information-rich source clusters to reduce required training data and lower variance in TL models.

## Evidence

> We find TL performance depends on the Euclidean distance in the decomposed feature space between the clusters involved. Though performance is high in all clusters, the general trend is that the model performance resulting from transfer learning is inversely correlated with distance in the PC space. We also observe the standard deviation is positively correlated with PCA distance. The left panel shows the information needed to achieve a good model increases with increasing PC distance. The right panel of figure 6 shows how variable the model was depending on the distance from the base cluster.

Evidence location: abstract, pages 3 and 6-11 (figures and discussion)

## Links

- Source: [[sources/src_71bcf59437]]