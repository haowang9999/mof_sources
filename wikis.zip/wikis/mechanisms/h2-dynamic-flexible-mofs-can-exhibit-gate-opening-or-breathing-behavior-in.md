---
title: "Dynamic/flexible MOFs can exhibit gate-opening or breathing behavior in response to stimuli (T, P, g ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_b1552d4a9d]
confidence: medium
---


# Dynamic/flexible MOFs can exhibit gate-opening or breathing behavior in response to stimuli (T, P, g ...[TRUNCATED]... 

## Mechanism claim

Dynamic/flexible MOFs can exhibit gate-opening or breathing behavior in response to stimuli (T, P, guest insertion) which alters channel sizes and adsorption behavior; such flexibility can enable selective adsorption but often shows low RT gravimetric capacity.

## Applicability

- Task: `h2`
- Mechanism type: `dynamic structural response / stimuli-responsive adsorption`
- Condition scope: `{"gas": "H2 (general and mixtures)", "temperature_K": [77, 298], "pressure_bar": ["low pressures (gate-opening observed)", "up to reported high pressures in examples"], "material_family": "flexible MOFs including sulfur-containing M-URJC-n and pillared-layer frameworks", "method": "experiment / review"}`

## Positive design features

- channels can expand/contract to modulate uptake and selectivity; useful for molecular sieving and gas separation

## Negative design features

- measured gravimetric capacities can be low at ambient temperature (examples: ~0.12–0.14 wt% at 298 K and 170 bar)
- complex hysteresis and operational control needed; deliverable capacity may be limited

## Agent design implication

Consider flexible-linker strategies if gate-opening/selective adsorption is desired (e.g., H2/CO2 separation), but characterize hysteresis and expect tradeoffs with ambient-temperature gravimetric capacity.

## Evidence

> Dynamic MOFs ... reversibly change their channels by a large magnitude ... The hydrogen adsorption analysis of flexible sulfur-containing MOFs M-URJC-n showed gate-opening at low pressures with capacities 2.81, 2.21, 1.99 wt% at 77 K up to 18 bar, but only ~0.12–0.14 wt% at 298 K and 170 bar due to flexible ligands.

Evidence location: page 7-8

## Links

- Source: [[sources/src_b1552d4a9d]]