---
title: "Partial framework reduction followed by low-level alkali-metal (Li+, Na+, K+) doping of the triply i ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_b0ea8c70ab]
confidence: high
---


# Partial framework reduction followed by low-level alkali-metal (Li+, Na+, K+) doping of the triply i ...[TRUNCATED]... 

## Mechanism claim

Partial framework reduction followed by low-level alkali-metal (Li+, Na+, K+) doping of the triply interwoven MOF increases cryogenic H2 uptake (measured at 77 K and 87 K, 1 atm) relative to the undoped parent material; the largest enhancements occur at M/Zn ≈ 0.05–0.10.

## Applicability

- Task: `h2`
- Mechanism type: `adsorption capacity change via framework modification (experimental observation)`
- Condition scope: `{"gas": "H2", "temperature_K": "77 and 87 (measurements reported at both temperatures; specific uptake examples cited at 77 K and conclusions summarized at 87 K)", "pressure_bar": 1.0, "material_family": "Zn2(NDC)2(diPyTz) triply interwoven MOF (1) partially reduced and doped with Li, Na, K to form 1·M (low M/Zn ≈0.05–0.10)", "method": "experiment (H2 isotherms, BET/t-plot, NMR, PXRD)"}`

## Positive design features

- partial framework reduction
- low-level alkali-metal doping (M/Zn ≈0.05–0.10)
- triply interwoven (catenated) framework that can be displaced to increase accessible surface area

## Negative design features

- over-doping can negate benefits (see separate card on high loading)
- catenation can shield dopant ions from direct gas access

## Agent design implication

Introduce substoichiometric reduction and low-level alkali-metal doping (target M/Zn ≈0.05–0.10) to increase gravimetric H2 uptake at cryogenic conditions in similar interpenetrated MOFs, while monitoring dopant level carefully to remain within the enhancement window.

## Evidence

> We find that improved adsorption performance for these materials is obtained at doping levels that are much lower than 1 cation per dipyridyl ligand; the greatest enhancements are found for M/Zn ≈0.05 to 0.10 ... H2 uptake by the three reduced materials, 1·M, considerably exceeds that for the neutral MOF. Partial framework reduction and doping of a triply interwoven MOF with lithium, sodium, or potassium cations enhance the cryogenic uptake of H2 by between 30 and 43% at 1 atm.

Evidence location: Results and Discussion (sections 3.2–3.3), Table 2; Conclusions

## Links

- Source: [[sources/src_b0ea8c70ab]]