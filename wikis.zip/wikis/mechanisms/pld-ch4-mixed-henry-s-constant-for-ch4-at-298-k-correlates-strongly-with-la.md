---
title: "Henry's constant for CH4 at 298 K correlates strongly with largest cavity diameter for cavities up t ...[TRUNCATED]... "
type: mechanism
tags: [pld|ch4|mixed, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_97052fb350]
confidence: medium
---


# Henry's constant for CH4 at 298 K correlates strongly with largest cavity diameter for cavities up t ...[TRUNCATED]... 

## Mechanism claim

Henry's constant for CH4 at 298 K correlates strongly with largest cavity diameter for cavities up to roughly 4 Å and peaks around ~5 Å where CH4 can maximize interactions with surrounding framework atoms; for cavities larger than ~5 Å the correlation weakens.

## Applicability

- Task: `pld|ch4|mixed`
- Mechanism type: `adsorption energetics dominated by repulsive/attractive balance in cavities`
- Condition scope: `{"gas": "CH4", "temperature_K": 298, "pressure_bar": "Henry's law regime (low-pressure)", "material_family": "MOFs", "method": "Henry's constant calculations via simulation"}`

## Positive design features

- largest cavity diameter ~5 Å maximizes CH4 Henry's constant

## Negative design features

- very large cavities reduce the strong size-dependence of KH

## Agent design implication

For adsorption-based capture or selectivity of CH4, target cavity sizes around 4–5 Å to maximize Henry's constant; for larger cavities the benefit diminishes.

## Evidence

> For MOFs with largest cavity sizes up to the size of a CH4 molecule, roughly 4 Å, a strong correlation exists between the cavity size and the Henry’s constant... The largest Henry’s constant we observe are for structures with a largest cavity diameter of approximately 5 Å... For MOFs with cavities larger than this, the overall Henry’s constant is not well correlated with the largest cavity size.

Evidence location: page 8

## Links

- Source: [[sources/src_97052fb350]]