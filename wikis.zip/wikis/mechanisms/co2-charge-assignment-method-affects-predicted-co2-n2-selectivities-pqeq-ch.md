---
title: "Charge assignment method affects predicted CO2/N2 selectivities: PQeq charges can give a quick estim ...[TRUNCATED]... "
type: mechanism
tags: [co2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_1fa85425f9]
confidence: high
---


# Charge assignment method affects predicted CO2/N2 selectivities: PQeq charges can give a quick estim ...[TRUNCATED]... 

## Mechanism claim

Charge assignment method affects predicted CO2/N2 selectivities: PQeq charges can give a quick estimate but can considerably disagree with high‑quality quantum-derived point charges for top performing materials; however, for CO2/H2O separations a recent study found that the majority of top MOFs are identical regardless of the charge method.

## Applicability

- Task: `co2`
- Mechanism type: `simulation accuracy / electrostatics`
- Condition scope: `{"gas": "CO2/N2 and CO2/H2O (humid conditions)", "temperature_K": null, "pressure_bar": null, "material_family": "MOFs", "method": "simulation (charge assignment impacting GCMC results)"}`

## Positive design features

- PQeq and other approximate methods provide fast charge estimates
- ranking robustness observed for some separations (CO2/H2O) in cited work

## Negative design features

- possible considerable disagreement in selectivity predictions when compared to high-quality point charges (notably reported for CO2/N2)

## Agent design implication

For high-throughput scans, approximate charge methods (e.g., PQeq) are acceptable to triage materials, but re-evaluate top candidates with higher-fidelity charges (DFT-derived) to ensure accurate selectivity predictions, especially for CO2/N2; the impact of charge method depends on the gas pair and framework.

## Evidence

> "Comparison between PQeq and high quality point charges derived from quantum chemistry for the top performing materials showed a considerable disagreement in the calculated CO2/N2 selectivities although the PQeq charges were shown to give a quick estimate about the potential of the material (Haldoupis et al., 2012a,b)." (page 4) || "A recent study ... found that majority of the top MOFs ranked based on CO2 selectivities are identical regardless of the charge assignment method (Wei et al., 2017)." (page 5). Note: evidence locations in chunks vary (page 4 and page 5).

Evidence location: page 4 and page 5 (Charge Assignment Methods)

## Links

- Source: [[sources/src_1fa85425f9]]