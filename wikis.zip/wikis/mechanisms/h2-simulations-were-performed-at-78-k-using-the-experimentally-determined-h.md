---
title: "Simulations were performed at 78 K using the experimentally determined hydrogen density of 113 molec ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_532b708453]
confidence: high
---


# Simulations were performed at 78 K using the experimentally determined hydrogen density of 113 molec ...[TRUNCATED]... 

## Mechanism claim

Simulations were performed at 78 K using the experimentally determined hydrogen density of 113 molecules per unit cell with periodic boundary conditions (NVT ensemble).

## Applicability

- Task: `h2`
- Mechanism type: `simulation condition`
- Condition scope: `{"gas": "H2", "temperature_K": 78, "pressure_bar": null, "material_family": "soc-MOF", "method": "NVT Monte Carlo"}`

## Positive design features

- Not specified

## Negative design features

- Not specified

## Agent design implication

To reproduce the study conditions, run NVT Monte Carlo at 78 K with H2 density set to the experimental value (113 molecules/unit cell) and periodic boundary conditions.

## Evidence

> Monte Carlo simulations were performed on the H2-MOF system at 78 K and with the experimentally determined hydrogen density of 113 molecules per unit cell,11 with periodic boundary conditions applied.

Evidence location: page 6 (NVT Monte Carlo setup)

## Links

- Source: [[sources/src_532b708453]]