---
title: "Simulation protocol specifics: canonical/NVT Monte Carlo at 78 K using the experimentally observed l ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_532b708453]
confidence: high
---


# Simulation protocol specifics: canonical/NVT Monte Carlo at 78 K using the experimentally observed l ...[TRUNCATED]... 

## Mechanism claim

Simulation protocol specifics: canonical/NVT Monte Carlo at 78 K using the experimentally observed loading of 113 H2 molecules per unit cell with periodic boundary conditions; induced dipoles converged to 1e-4 Debye and subject to a spherical cutoff of 11.2 Å (half unit cell); dipole calculation dominated CPU cost.

## Applicability

- Task: `h2`
- Mechanism type: `simulation_parameters`
- Condition scope: `{"gas": "H2", "temperature_K": 78, "pressure_bar": null, "material_family": "soc-MOF", "method": "NVT Monte Carlo with explicit induced-dipole solution"}`

## Positive design features

- use of experimentally determined loading and periodic boundaries
- explicit convergence criteria and cutoff for induced dipoles

## Negative design features

- dipole calculation is computationally expensive and slows sampling

## Agent design implication

Use experimentally relevant loadings and periodic boundaries; in polarizable simulations set convergence criteria for dipoles (e.g., 1e-4 Debye) and apply a physically consistent cutoff (here 11.2 Å = half unit cell) for induced-dipole interactions, while anticipating heavy CPU cost for dipole solves.

## Evidence

> "Monte Carlo simulations were performed on the H2-MOF system at 78 K and with the experimentally determined hydrogen density of 113 molecules per unit cell ... with periodic boundary conditions applied." ... "Dipoles were calculated to a precision of 10^-4 Debye and were subject to a 11.2 Å (half the unit cell length) spherical cutoff." ... "The calculation of the system dipoles consumes approximately 95% of the total CPU time."

Evidence location: page 6; Results discussion

## Links

- Source: [[sources/src_532b708453]]