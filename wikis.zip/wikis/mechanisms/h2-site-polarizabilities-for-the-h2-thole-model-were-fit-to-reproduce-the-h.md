---
title: "Site polarizabilities for the H2 Thole model were fit to reproduce the HF polarizability tensor and  ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_532b708453]
confidence: high
---


# Site polarizabilities for the H2 Thole model were fit to reproduce the HF polarizability tensor and  ...[TRUNCATED]... 

## Mechanism claim

Site polarizabilities for the H2 Thole model were fit to reproduce the HF polarizability tensor and the experimental trace, yielding site values of ~0.2658 Å^3 for each H atom and ~0.5865 Å^3 for the center-of-mass site (sum reproduces molecular polarizability ~0.787 Å^3).

## Applicability

- Task: `h2`
- Mechanism type: `induction / parameterization`
- Condition scope: `{"gas": "H2", "temperature_K": 78, "pressure_bar": null, "material_family": "soc-MOF", "method": "ab initio fitting / simulation"}`

## Positive design features

- site polarizabilities calibrated to HF polarizability tensor and experiment

## Negative design features

- Not specified

## Agent design implication

For Thole-model simulations of H2 in similar MOF contexts, consider using site polarizabilities near 0.2658 Å^3 (H atoms) and 0.5865 Å^3 (center-of-mass) to reproduce the molecular polarizability.

## Evidence

> The atomic Thole polarizabilities for molecular hydrogen were then determined by fitting Rmol to the HF polarizability tensor form while at the same time yielding one-third of the trace equal to the experimentally measured H2 polarizability of 0.787 Å3; the values that best satisfied both criteria were found to be 0.2658 Å3 for H and 0.5865 Å3 for the center of mass site.

Evidence location: page 6 (H2 polarizability parametrization)

## Links

- Source: [[sources/src_532b708453]]