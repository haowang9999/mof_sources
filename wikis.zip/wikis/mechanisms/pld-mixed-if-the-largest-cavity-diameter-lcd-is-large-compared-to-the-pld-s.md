---
title: "If the largest cavity diameter (LCD) is large compared to the PLD, slowly diffusing species trapped  ...[TRUNCATED]... "
type: mechanism
tags: [pld|mixed, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_97052fb350]
confidence: high
---


# If the largest cavity diameter (LCD) is large compared to the PLD, slowly diffusing species trapped  ...[TRUNCATED]... 

## Mechanism claim

If the largest cavity diameter (LCD) is large compared to the PLD, slowly diffusing species trapped in cavities can block or dominate diffusion of smaller species (single-file or blocking effects), reducing the effectiveness of kinetic separations unless connectivity permits bypassing/mixing.

## Applicability

- Task: `pld|mixed`
- Mechanism type: `steric trapping and single-file diffusion / crowding effects influencing mixture transport`
- Condition scope: `{"gas": "general adsorbed species in pore networks", "temperature_K": null, "pressure_bar": null, "material_family": "MOFs and zeolites (crystalline porous materials)", "method": "conceptual argument supported by geometric characterization"}`

## Positive design features

- Large cavities (LCD > PLD) can permit intracrystalline mixing if connected appropriately
- Knowledge of LCD helps anticipate blocking/mixing behavior

## Negative design features

- Large LCD combined with narrow PLD can lead to slow species blocking transport of faster species (undesirable for kinetic separations)
- Single-file diffusion regimes exacerbate blocking effects

## Agent design implication

For effective kinetic separations, target structures where the PLD creates differential transport rates but the LCD is large enough to allow molecules to pass or mix within cavities (avoid geometries that promote irreversible blocking or single-file diffusion of the slower species).

## Evidence

> Another quantity of interest ... the largest cavity diameter ... The importance of the largest cavity diameter to kinetic separations can be understood by considering ... If the smaller molecules are unable to readily pass the larger molecules within some portion of the pores, then the diffusion rate of the smaller molecules in the adsorbed mixture will be dominated by the slowly diffusing species. ... Single-file diffusion in mixtures inside one-dimensional pores offers an extreme example of this phenomenon.

Evidence location: page 2 (section 2.1 Pore Size Characterization)

## Links

- Source: [[sources/src_97052fb350]]