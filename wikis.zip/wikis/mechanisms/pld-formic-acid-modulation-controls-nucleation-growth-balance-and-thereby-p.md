---
title: "Formic-acid modulation controls nucleation/growth balance and thereby particle size: increasing form ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_20cacd73e1]
confidence: high
---


# Formic-acid modulation controls nucleation/growth balance and thereby particle size: increasing form ...[TRUNCATED]... 

## Mechanism claim

Formic-acid modulation controls nucleation/growth balance and thereby particle size: increasing formic acid strengthens competition with linkers, slows nucleation relative to growth, and increases crystallite/particle size (e.g., Ce-MOF-801-50eq ≈ 110 nm; Ce-MOF-801-200eq ≈ 800 nm in reported series).

## Applicability

- Task: `pld`
- Mechanism type: `modulator-mediated nucleation/growth control affecting particle size and textural properties`
- Condition scope: `{"gas": null, "temperature_K": null, "pressure_bar": null, "material_family": "Ce-MOF-801-neq series (synthesized with varying formic acid)", "method": "experiment (synthesis + SEM imaging)"}`

## Positive design features

- Particle size is tunable via formic acid dosage; moderate-to-high modulator doses produce larger, more uniform crystals

## Negative design features

- Larger particle sizes at very high modulator loadings may correlate with reduced SSA or altered pore outcomes

## Agent design implication

Tune formic acid concentration to control nucleation vs growth: lower modulator leads to faster nucleation and smaller/irregular particles; moderate-to-high modulator slows nucleation, promoting larger crystals (reported ~110 nm at 50eq vs ~800 nm at 200eq).

## Evidence

> The particle size of Ce-MOF-801-neq showed a gradual increase with the increasing dosage of formic acid. For example, the average particle size of Ce-MOF-801-50eq is about 110 nm, while the average particle size of Ce-MOF-801-200eq is close to 800 nm. As the concentration of formic acid increased, the competitive coordination mechanism between formic acid and trans-butyleneglutaric acid was strengthened, which effectively slowed down the reaction rate and promoted the growth of crystals.

Evidence location: Page 6 (SEM and particle-size discussion)

## Links

- Source: [[sources/src_20cacd73e1]]