---
title: "Precombustion CO2 capture metrics in this study were computed by simulating adsorption of a 20:80 CO ...[TRUNCATED]... "
type: mechanism
tags: [h2|co2|mixed, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_c42cf01235]
confidence: high
---


# Precombustion CO2 capture metrics in this study were computed by simulating adsorption of a 20:80 CO ...[TRUNCATED]... 

## Mechanism claim

Precombustion CO2 capture metrics in this study were computed by simulating adsorption of a 20:80 CO2:H2 mixture at 20 bar and desorption using pure CO2 at 1 bar; postcombustion performance used 15:85 CO2:N2 at 1 bar (adsorption) and 90:10 CO2:N2 at 0.1 bar (desorption). Working capacity is adsorption minus desorption loading; the desorption composition assumption can give negative working capacity when selectivity is insufficient.

## Applicability

- Task: `h2|co2|mixed`
- Mechanism type: `operational protocol affecting metric calculation and interpretation`
- Condition scope: `{"gas": "CO2/H2 mixtures (precombustion) and CO2/N2 mixtures (postcombustion)", "temperature_K": 313, "pressure_bar": null, "material_family": "MOFs (simulated population)", "method": "GCMC simulation"}`

## Positive design features

- high selectivity during adsorption to justify desorption gas-phase assumption

## Negative design features

- materials with low selectivity can yield negative working capacity due to desorption gas-phase assumption

## Agent design implication

When evaluating precombustion CO2 capture, simulate adsorption at 20 bar (20:80 CO2:H2) and desorption at 1 bar (pure CO2) at 313 K to compute WC and selectivity, but inspect selectivity carefully because desorption gas-phase approximations can give misleading negative WCs for poorly selective materials.

## Evidence

> “MOF CO2 capture metrics relevant to precombustion carbon capture were evaluated by simulating adsorption for a 20:80 CO2:H2 mixture at 20 bar (adsorption conditions) and pure CO2 at 1 bar (desorption conditions)...MOF CO2 capture metrics relevant to postcombustion carbon capture were evaluating by simulating adsorption for a 15:85 CO2:N2 mixture at 1 bar (adsorption conditions) and a 90:10 CO2:N2 mixture at 0.1 bar (desorption conditions). Note that the gas-phase compositions during desorption conditions is an approximation based on the assumption of high CO2/N2 selectivity during adsorption stage. This assumption breaks down when a given material is not selective enough, which is manifested in a negative working capacity."

Evidence location: page 3 (Computational Methods: Adsorption in MOFs)

## Links

- Source: [[sources/src_c42cf01235]]