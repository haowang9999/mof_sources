---
title: "Open-metal identity (Mg vs Zn) strongly influences CO2 binding strength and regenerability: Mg provi ...[TRUNCATED]... "
type: mechanism
tags: [co2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_20dae1036b]
confidence: high
---


# Open-metal identity (Mg vs Zn) strongly influences CO2 binding strength and regenerability: Mg provi ...[TRUNCATED]... 

## Mechanism claim

Open-metal identity (Mg vs Zn) strongly influences CO2 binding strength and regenerability: Mg provides stronger adsorption and higher selectivity but increases regeneration difficulty; Zn weakens binding (reducing isotherm steepness) and can improve regenerability at expense of some affinity.

## Applicability

- Task: `co2`
- Mechanism type: `metal-center tuning of adsorbent–gas interaction strength`
- Condition scope: `{"gas": "CO2", "temperature_K": null, "pressure_bar": null, "material_family": "MOF-74 and DOBPDC variants with Mg or Zn open metal sites", "method": "simulation and comparison to experimental literature"}`

## Positive design features

- Mg yields higher CO2 affinity/selectivity
- Zn yields weaker binding that can assist regeneration and reduce isotherm steepness

## Negative design features

- Mg-based materials may require higher desorption temperatures (energy penalty); Zn may reduce low-pressure uptake if too weak

## Agent design implication

Select Zn (weaker-binding) when regenerability and low desorption energy are priorities; select Mg when maximizing affinity/selectivity is required and higher regeneration energy is acceptable—model the trade-off for the intended process.

## Evidence

> “most of the structures that have been experimentally explored use Magnesium as the open metal site... Therefore, stronger interactions are achieved but the regeneration will be more difficult... simulated structures using a less attractive metal, such as Zinc, were also performed... as it is expected that the steepness of the isotherms gradually diminish as the temperature increases in these materials.”

Evidence location: pages 5-7

## Links

- Source: [[sources/src_20dae1036b]]