---
title: "Formic acid functions as a competitive coordinator/proton source during synthesis creating missing-l ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_20cacd73e1]
confidence: high
---


# Formic acid functions as a competitive coordinator/proton source during synthesis creating missing-l ...[TRUNCATED]... 

## Mechanism claim

Formic acid functions as a competitive coordinator/proton source during synthesis creating missing-linker (ligand) defects; defect density follows a non-monotonic dependence on modulator concentration with a maximum at moderate loading (observed at ~50 equiv for Ce in this work) and a decline at higher loadings due to inhibited nucleation and framework self-repair.

## Applicability

- Task: `pld`
- Mechanism type: `chemical modulation of coordination equilibrium (competitive coordination / proton-mediated nucleation/growth / self-repair)`
- Condition scope: `{"gas": "not applicable", "temperature_K": null, "pressure_bar": null, "material_family": "Ce-MOF-801-neq series (n = 0, 50, 100, 150, 200)", "method": "experiment (TG, XPS, compositional analysis)"}`

## Positive design features

- Formic acid competes with organic linkers for coordination to metal centers creating ligand vacancies (missing-linker defects)
- Quantified missing-ligand counts show Ce-MOF-801-50eq has the highest average missing ligands (~3.14 per metal center in this series)

## Negative design features

- Excessive modulator/proton concentrations can inhibit crystal nucleation and promote self-repair, decreasing persistent exposure of defects and reducing measured missing-ligand content at high loadings

## Agent design implication

To introduce missing-linker defects in Ce-MOF-801 use a carboxylic-acid modulator (formic acid) at controlled equivalence and screen across a range because defect density may peak at an intermediate modulator level rather than increase monotonically with modulator amount.

## Evidence

> The addition of carboxylic acid modulators, such as formic acid, can enable these species to coordinate with the metal centers, effectively competing with the organic linkers for coordination sites. The Ce-MOF-801-50eq sample exhibited the most severe ligand deficiency, with an average of up to 3.14 missing ligands per metal center. As the dosage of the formic acid modulator was increased beyond this optimal level, the extent of missing ligands gradually decreased. When the modulator concentration exceeds a certain threshold, the high proton content in the solution can lead to increased competition between the modulator and the organic linkers for coordination, potentially inhibiting crystal nucleation and promoting crystal growth (self-repair).

Evidence location: Pages 3–5 (TG analysis; discussion of missing-ligand quantification and synthesis behavior)

## Links

- Source: [[sources/src_20cacd73e1]]