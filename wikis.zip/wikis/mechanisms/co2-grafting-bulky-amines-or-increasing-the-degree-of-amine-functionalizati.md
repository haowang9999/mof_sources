---
title: "Grafting bulky amines or increasing the degree of amine functionalization to full coverage can reduc ...[TRUNCATED]... "
type: mechanism
tags: [co2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_20dae1036b]
confidence: high
---


# Grafting bulky amines or increasing the degree of amine functionalization to full coverage can reduc ...[TRUNCATED]... 

## Mechanism claim

Grafting bulky amines or increasing the degree of amine functionalization to full coverage can reduce CO2 uptake due to steric hindrance / site blocking; partial functionalization (sub-100%) often provides a better balance of chemisorptive sites and accessible void space.

## Applicability

- Task: `co2`
- Mechanism type: `steric hindrance limiting adsorption (site blocking / reduced accessible void fraction)`
- Condition scope: `{"gas": "CO2 (pure and mixtures)", "temperature_K": 313, "pressure_bar": 0.15, "material_family": "MOF-74 and DOBPDC functionalized with various amines (including larger diamines)", "method": "simulation (functionalization degree studies) and literature"}`

## Positive design features

- partial functionalization balances availability of chemisorption sites with retained pore volume
- reported functionalization degrees for some systems (e.g., ~72% for Mg/DOBPDC and ~61% for Zn/DOBPDC) indicate partial coverage in practice

## Negative design features

- full functionalization or high loading with bulky amines can block pores, reduce physisorption, and lower working capacity

## Agent design implication

Treat functionalization degree as an optimization variable; include partial-coverage cases (e.g., ~60–75%) in screening and avoid assuming 100% coverage is best—especially with bulky grafts.

## Evidence

> “Furthermore, it is shown that more amine functional groups grafted on the MOFs and/or full functionalization of the metal centers do not lead to better CO2 separation capabilities due to steric hindrances.” | “The degree of functionalization in MOF-74 structures show that amine substitution below 100% provide better performance than the fully substituted material... It was found that the functionalization degree for Mg/DOBPDC and Zn/DOBPDC with the studied diamine-appended molecules is typically 72 and 61%, respectively.”

Evidence location: page 1 (Abstract); page 6 (Results)

## Links

- Source: [[sources/src_20dae1036b]]