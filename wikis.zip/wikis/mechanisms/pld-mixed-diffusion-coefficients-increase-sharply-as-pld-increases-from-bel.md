---
title: "Diffusion coefficients increase sharply as PLD increases from below ~3.5 Å and reach a stable value  ...[TRUNCATED]... "
type: mechanism
tags: [pld|mixed, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_90953381a0]
confidence: high
---


# Diffusion coefficients increase sharply as PLD increases from below ~3.5 Å and reach a stable value  ...[TRUNCATED]... 

## Mechanism claim

Diffusion coefficients increase sharply as PLD increases from below ~3.5 Å and reach a stable value when PLD > ~6.0 Å; strong steric hindrance occurs when gas diameter is close to pore size.

## Applicability

- Task: `pld|mixed`
- Mechanism type: `steric hindrance controlling diffusion`
- Condition scope: `{"gas": "multiple gases (general diffusion trends reported)", "temperature_K": null, "pressure_bar": null, "material_family": "CoRE-MOFMs / CoRE‑MOF membranes", "method": "molecular simulation"}`

## Positive design features

- PLD increasing from <3.5 Å -> sharp rise in D
- PLD > 6.0 Å -> diffusivity stabilizes

## Negative design features

- When gas diameter ≈ pore size -> strong steric hindrance, low D

## Agent design implication

To increase diffusivity, design PLD to exceed the steric-hindrance regime (i.e., move above ~3.5 Å), but recognize that above ~6 Å further PLD increases yield diminishing returns for diffusion.

## Evidence

> "The diffusion coefﬁcient rises sharply when PLD < 3.5 Å, and ﬁnally reaches stability when PLD > 6.0 Å. The main reason is strong steric hindrance when the gas diameter is close to the pore size of the MOFs."

Evidence location: page 6

## Links

- Source: [[sources/src_90953381a0]]