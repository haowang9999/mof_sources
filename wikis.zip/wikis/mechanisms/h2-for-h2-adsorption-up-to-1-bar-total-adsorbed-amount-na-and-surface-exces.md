---
title: "For H2 adsorption up to ~1 bar, total adsorbed amount (na) and surface excess (nσ) are nearly identi ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_ff1b0c9d63]
confidence: high
---


# For H2 adsorption up to ~1 bar, total adsorbed amount (na) and surface excess (nσ) are nearly identi ...[TRUNCATED]... 

## Mechanism claim

For H2 adsorption up to ~1 bar, total adsorbed amount (na) and surface excess (nσ) are nearly identical if the Gibbs dividing surface is close to the adsorbent surface; at pressures >1 bar the difference becomes significant and requires accounting for adsorption space volume Va to convert nσ to na.

## Applicability

- Task: `h2`
- Mechanism type: `adsorption quantity definition / high-pressure correction`
- Condition scope: `{"gas": "H2", "temperature_K": null, "pressure_bar": "<=1 bar (near identical), >1 bar (differences significant)", "material_family": "MOFs", "method": "review / measurement discussion"}`

## Positive design features

- allows simple comparison at low pressures

## Negative design features

- requires conversion/volume knowledge at higher pressures

## Agent design implication

When reporting or designing for high-pressure H2 storage (>1 bar), convert surface excess to total adsorbed amount using skeletal/bulk density or measured adsorption space volume to avoid under/overestimation.

## Evidence

> In the case of H2 gas adsorption up to 1 bar, the na and nσ values are nearly identical, provided the latter is calculated with the GDS very close to the adsorbent surface. When the H2 pressure >1 bar, the difference between the value of na and nσ is clear.

Evidence location: Section 2.3 Surface Excess and the Total Adsorbed Amount of Hydrogen (page 4)

## Links

- Source: [[sources/src_ff1b0c9d63]]