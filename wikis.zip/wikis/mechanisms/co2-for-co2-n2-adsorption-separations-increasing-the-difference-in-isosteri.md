---
title: "For CO2/N2 adsorption separations, increasing the difference in isosteric heat of adsorption between ...[TRUNCATED]... "
type: mechanism
tags: [co2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_1fa85425f9]
confidence: medium
---


# For CO2/N2 adsorption separations, increasing the difference in isosteric heat of adsorption between ...[TRUNCATED]... 

## Mechanism claim

For CO2/N2 adsorption separations, increasing the difference in isosteric heat of adsorption between gases while decreasing porosity is a useful approach to improve CO2/N2 selectivity (QSPR result from 105 MOFs).

## Applicability

- Task: `co2`
- Mechanism type: `adsorption energetics / thermodynamic selectivity`
- Condition scope: `{"gas": "CO2/N2", "temperature_K": null, "pressure_bar": 1, "material_family": "real MOFs (105 MOFs used in QSPR)", "method": "QSPR / adsorption simulations"}`

## Positive design features

- larger difference in isosteric heat of adsorption (CO2 vs N2)
- lower porosity (decreasing porosity)

## Negative design features

- high porosity (may reduce CO2/N2 selectivity)

## Agent design implication

Target MOF chemistries and pore environments that increase CO2 binding strength relative to N2 while avoiding excessively high porosity; i.e., design frameworks with sites that raise CO2 isosteric heat more than N2 and moderate porosity to enhance CO2/N2 selectivity.

## Evidence

> "The first QSPR model was established for adsorption-based CO2/N2 separation using 105 MOFs and results showed that increasing the difference of isosteric heat of adsorption of gases with decreasing porosity is a useful approach to improve CO2/N2 selectivities of MOFs (Wu et al., 2012)." (page 3).

Evidence location: page 3 (Large-scale screening / QSPR results)

## Links

- Source: [[sources/src_1fa85425f9]]