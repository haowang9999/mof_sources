---
title: "The calculated pore-limiting diameter (PLD = 3.27 Å) and largest cavity diameter (LCD = 3.65 Å) of C ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_83cde498f9]
confidence: high
---


# The calculated pore-limiting diameter (PLD = 3.27 Å) and largest cavity diameter (LCD = 3.65 Å) of C ...[TRUNCATED]... 

## Mechanism claim

The calculated pore-limiting diameter (PLD = 3.27 Å) and largest cavity diameter (LCD = 3.65 Å) of Cu(adci)-2 make it ultramicroporous and are appropriate for kinetic discrimination between CO2 (kinetic diameter ~3.3 Å) and N2 (~3.64 Å), favoring CO2 uptake in the 1D square channels.

## Applicability

- Task: `pld`
- Mechanism type: `pore_aperture_size / kinetic_sieving`
- Condition scope: `{"gas": "CO2 vs N2", "temperature_K": null, "pressure_bar": null, "material_family": "Cu(adci)-2", "method": "Zeo++ / pore analysis + discussion referencing kinetic diameters"}`

## Positive design features

- PLD 3.27 Å close to CO2 kinetic diameter
- LCD 3.65 Å provides ultramicroporous confinement in 1D channels

## Negative design features

- N2 kinetic diameter (3.64 Å) is close to LCD and may limit N2 access/diffusion, which underlies the discrimination

## Agent design implication

Target PLD ~3.2–3.3 Å with small LCD (~3.6 Å) in 1D channels to kinetically favor CO2 over N2 at low pressure for postcombustion separations.

## Evidence

> Page 3: "the largest cavity diameter (LCD) and pore limiting diameter (PLD) of Cu(adci)-2 were calculated to be 3.65 and 3.27 Å, respectively, with the Zeo++ program... These values are suitable for selective CO2 adsorption given the kinetic diameters of CO2 and N2 (3.3 and 3.64 Å, respectively)."

Evidence location: page 3 (pore metrics discussion)

## Links

- Source: [[sources/src_83cde498f9]]