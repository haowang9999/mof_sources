---
title: "Among structural descriptors, PLD has the highest relative importance for explaining variance in per ...[TRUNCATED]... "
type: mechanism
tags: [pld|mixed, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_90953381a0]
confidence: high
---


# Among structural descriptors, PLD has the highest relative importance for explaining variance in per ...[TRUNCATED]... 

## Mechanism claim

Among structural descriptors, PLD has the highest relative importance for explaining variance in performance metrics (reported PLD relative importances: 0.33, 0.41, 0.25 across principal components); porosity (ϕ) and LCD are also important when considering multiple principal components and the top 10 PCs (top descriptors: PLD, ϕ, VSA, LCD).

## Applicability

- Task: `pld|mixed`
- Mechanism type: `statistical / feature importance from PCA + machine learning (random forest)`
- Condition scope: `{"gas": "15 binary gas mixtures (including CO2- and H2-containing separations)", "temperature_K": null, "pressure_bar": null, "material_family": "CoRE-MOFMs / CoRE‑MOF membranes", "method": "PCA + random forest feature importance (Gini) and other ML methods"}`

## Positive design features

- PLD identified as top descriptor by RF/PCA
- ϕ and LCD emerge as important descriptors when considering multiple PCs

## Negative design features

- Not specified

## Agent design implication

Prioritize PLD control in MOF membrane design workflows as the first-order descriptor for mixed-gas separation performance, while treating porosity (ϕ), VSA, and LCD as important secondary descriptors to include in multivariate screening.

## Evidence

> "Figure 4 shows that the PLD had the largest weight for PC1 and PC2... The relative importance of PLD was as follows: 0.33, 0.41, and 0.25. The results showed that PLD was the main factor affecting the separation performance of 15 mixed gases by CoRE-MOFMs... When considering only the first three principal components... the relative importance of descriptors was as follows: PLD, ϕ, and ρ. When considering the top 10 principal components... the top four most important descriptors were as follows: PLD, ϕ, VSA, and LCD."

Evidence location: pages 7-9; page 12

## Links

- Source: [[sources/src_90953381a0]]