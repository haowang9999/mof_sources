---
title: "DFT-calculated CO2 binding strengths vary substantially across functional groups and follow an order ...[TRUNCATED]... "
type: mechanism
tags: [co2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_c42cf01235]
confidence: high
---


# DFT-calculated CO2 binding strengths vary substantially across functional groups and follow an order ...[TRUNCATED]... 

## Mechanism claim

DFT-calculated CO2 binding strengths vary substantially across functional groups and follow an order (strongest to weakest) reported for the examined set: -(NH2)2 > -(CN)4 > -(SH)2 > -(NO)2 > -(OH)2 > -(CN)2 > -(F)4 > -(Br)2 > -(CF)3 > -(F)2 > -(CH)3 > -(H)4 > -(Br)4.

## Applicability

- Task: `co2`
- Mechanism type: `relative binding strength (chemical specificity from DFT)`
- Condition scope: `{"gas": "CO2", "temperature_K": null, "pressure_bar": null, "material_family": "functionalized MOF building block groups (DFT binding energies)", "method": "DFT calculations"}`

## Positive design features

- -(NH2)2
- -(CN)4
- -(SH)2
- -(NO)2
- -(OH)2

## Negative design features

- -(CH)3
- -(H)4
- -(Br)4
- -(CF)3

## Agent design implication

Prefer functional groups ranked toward the strong end of the list (e.g., -(NH2)2, -(CN)4, -(OH)2) when aiming to increase intrinsic CO2 binding; nonetheless validate in the full framework context because topology and pore geometry modulate outcomes.

## Evidence

> “The binding strength of CO2 with the various chemical functionalities (Table S1) follows the order -(NH2)2 > -(CN)4 > -(SH)2 > -(NO)2 > -(OH)2 > -(CN)2 > -(F)4 > -(Br)2 > -(CF)3 > -(F)2 > -(CH)3 > -(H)4 > -(Br)4."

Evidence location: page 4, Table S1

## Links

- Source: [[sources/src_c42cf01235]]