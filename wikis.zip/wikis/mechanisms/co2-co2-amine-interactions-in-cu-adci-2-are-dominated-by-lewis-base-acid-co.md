---
title: "CO2–amine interactions in Cu(adci)-2 are dominated by Lewis base–acid contacts rather than direction ...[TRUNCATED]... "
type: mechanism
tags: [co2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_83cde498f9]
confidence: high
---


# CO2–amine interactions in Cu(adci)-2 are dominated by Lewis base–acid contacts rather than direction ...[TRUNCATED]... 

## Mechanism claim

CO2–amine interactions in Cu(adci)-2 are dominated by Lewis base–acid contacts rather than directional hydrogen bonding, with characteristic CCO2–N and OCO2–H RDF peaks around ~3.4 Å; additionally, intense London dispersion interactions between CO2 and ligand C atoms (RDF peaks ~3.3–4.0 Å) contribute significantly to binding.

## Applicability

- Task: `co2`
- Mechanism type: `host–guest_interaction_type + dispersion`
- Condition scope: `{"gas": "CO2", "temperature_K": 298, "pressure_bar": 0.15, "material_family": "Cu(adci)-2", "method": "GCMC (RDF) analysis"}`

## Positive design features

- CCO2–N3 and OCO2–H1 RDF first peaks around 3.4 Å indicating Lewis acid–base contacts
- CCO2–C3 and OCO2–C3 RDF peaks at 3.3 and 3.4 Å and other framework atom RDFs first peaks near 4 Å indicating significant London dispersion

## Negative design features

- Not specified

## Agent design implication

Incorporate Lewis-basic amine functionalities positioned to provide ~3.3–3.5 Å contact distances to CO2 and design ultramicropores with closely spaced aromatic ligand surfaces (≈3.3–4.0 Å from adsorbate) to exploit both acid–base physisorption and dispersion.

## Evidence

> Page 5 (RDF analysis): "Both CCO2-N3 and OCO2-H1 RDFs ... are characterized by each first peak being around 3.4 Å, implying the major contribution of Lewis base-acid interaction between the amine and CO2 as opposed to hydrogen bonding."; "the RDFs between CO2 and ... the other framework atoms mostly show first peaks at a distance of 4 Å, which suggests intense London dispersion interactions between CO2 and the ligands. Particularly, ... CCO2-C3 and OCO2-C3 RDFs ... are 3.3 and 3.4 Å, respectively."

Evidence location: page 5 (RDF discussion)

## Links

- Source: [[sources/src_83cde498f9]]