---
title: "Machine learning models (decision trees and ensemble/regression methods) trained on simulated adsorp ...[TRUNCATED]... "
type: mechanism
tags: [mixed, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_c42cf01235]
confidence: medium
---


# Machine learning models (decision trees and ensemble/regression methods) trained on simulated adsorp ...[TRUNCATED]... 

## Mechanism claim

Machine learning models (decision trees and ensemble/regression methods) trained on simulated adsorption data can (i) predict whether functionalization will improve or decline CO2 capture metrics and (ii) predict absolute metrics, enabling recovery of feature importance and interpretable rules (e.g., HBDM thresholds) from the data.

## Applicability

- Task: `mixed`
- Mechanism type: `data-driven prediction and descriptor discovery`
- Condition scope: `{"gas": "CO2 (pure and mixtures)", "temperature_K": 313, "pressure_bar": null, "material_family": "computational MOF population (topology-functionality combinations)", "method": "machine learning trained on simulation outputs (decision trees, RF, SVM, NN, GBM, MLR)"}`

## Positive design features

- decision trees for classification of improvement/decline upon functionalization
- ensemble/regression models for absolute metric prediction

## Negative design features

- Not specified

## Agent design implication

Use ML trained on high-fidelity simulation data to prioritize functionalization/topology combinations and to estimate relative importance of pore chemistry and topology for CO2 capture.

## Evidence

> “Decision trees were trained to predict the improvement or decline of CO2 capture metrics upon functionalization of parent MOFs, whereas five additional machine learning algorithms were trained to predict absolute metrics for all MOFs. The training of these algorithms allowed us to determine, without human bias, the relative importance of various pore chemical and structural/topological factors on the CO2 capture capabilities of MOFs."

Evidence location: page 1 (Abstract); page 3 (Training of Machine-Learning Algorithms)

## Links

- Source: [[sources/src_c42cf01235]]