---
title: "In the simulations, Qst was increased parametrically by scaling Lennard–Jones epsilon parameters for ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_8d4a290e19]
confidence: high
---


# In the simulations, Qst was increased parametrically by scaling Lennard–Jones epsilon parameters for ...[TRUNCATED]... 

## Mechanism claim

In the simulations, Qst was increased parametrically by scaling Lennard–Jones epsilon parameters for H2/MOF interactions (multiplying epsilon by factors 2–10) while keeping other variables constant to probe the effect of increased interaction strength.

## Applicability

- Task: `pld`
- Mechanism type: `modeling method`
- Condition scope: `{"gas": "H2", "temperature_K": 298, "pressure_bar": "up to 120 bar", "material_family": "the eight MOFs", "method": "simulation (LJ parameter scaling)"}`

## Positive design features

- Provides a general, structure-independent way to assess impact of increased Qst

## Negative design features

- This approach does not capture specific chemical changes (e.g., added atoms) that in reality may alter free volume and other properties

## Agent design implication

Use parametric scaling of interaction parameters to screen sensitivity of deliverable capacity to increased adsorption strength, but follow up with material-specific modeling/experiments to capture structural tradeoffs.

## Evidence

>  "to model the increase in Qst in a general way the Lennard–Jones (L–J) epsilon parameters (e) for H2/MOF interactions were systematically increased in eight MOFs. The e parameters were multiplied by 2, 3, 4, 5, 6, 7, 8, 9, and 10 times their original values... Using these 10 different parameter sets... H2 isotherms and Qst were predicted up to 120 bar at 298 K."

Evidence location: page 2 (Simulations)

## Links

- Source: [[sources/src_8d4a290e19]]