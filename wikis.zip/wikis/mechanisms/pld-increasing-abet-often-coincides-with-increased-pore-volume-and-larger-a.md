---
title: "Increasing ABET often coincides with increased pore volume and larger average pore diameter, which t ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_fa8cccd644]
confidence: medium
---


# Increasing ABET often coincides with increased pore volume and larger average pore diameter, which t ...[TRUNCATED]... 

## Mechanism claim

Increasing ABET often coincides with increased pore volume and larger average pore diameter, which tends to reduce adsorbent–sorbate interaction strength (lower isosteric enthalpy of adsorption).

## Applicability

- Task: `pld`
- Mechanism type: `structure–property relationship (pore volume → interaction strength)`
- Condition scope: `{"gas": "H2", "temperature_K": 77, "pressure_bar": null, "material_family": "MOFs (general)", "method": "review / comparative data analysis"}`

## Positive design features

- larger pore volume and higher ABET can increase absolute gravimetric uptake potential

## Negative design features

- decreased adsorbent–sorbate interactions
- lower isosteric enthalpy of adsorption (Qst)

## Agent design implication

When increasing surface area/pore volume to raise gravimetric storage, expect reduced binding strength; compensate via linker functionalization or open metal sites if stronger adsorption is required for higher-temperature operation.

## Evidence

> Moreover, increasing ABET leads to an increase in average pore volume and thus to a decrease in adsorbent–sorbate interactions and isosteric enthalpy of adsorption. || "The ability of any adsorbent to store H2 (wt%) is closely linked to its SSA. ... for very high ABET, Chahine’s heuristic rule is not valid, as the BET method accounts for pore volume more than SSA."

Evidence location: page 2 (Discussion of BET and pore volume effects) || pages 5–6, section 3.1

## Links

- Source: [[sources/src_fa8cccd644]]