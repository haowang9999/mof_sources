---
title: "Partial substitution (doping) of framework metal ions (e.g., Co-doped MOF-5) can modestly increase Q ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_ff1b0c9d63]
confidence: medium
---


# Partial substitution (doping) of framework metal ions (e.g., Co-doped MOF-5) can modestly increase Q ...[TRUNCATED]... 

## Mechanism claim

Partial substitution (doping) of framework metal ions (e.g., Co-doped MOF-5) can modestly increase Qst and cryogenic uptake, though substitution levels and site accessibility matter.

## Applicability

- Task: `h2`
- Mechanism type: `metal doping effect on adsorption energetics and uptake`
- Condition scope: `{"gas": "H2", "temperature_K": 77, "pressure_bar": 10, "material_family": "Co-doped MOF-5 (Zn/Co mixed nodes)", "method": "experiment (ICP, XRD, adsorption)"}`

## Positive design features

- measurable increase in uptake correlated with doping level
- increase in Qst

## Negative design features

- difficulty substituting more than one Co2+ per Zn4 node
- metal sites may be less accessible

## Agent design implication

Partial substitution of framework metal ions (doping) can modestly increase Qst and cryogenic uptake; quantify substitution level and accessibility when interpreting adsorption improvements.

## Evidence

> The values of the hydrogen adsorption capacity at 77 K and 10 bar of H2 were in the order of Co21-MOF-5 > Co8-MOF-5 > MOF-5. A small increase in the Qst value was experimentally found for Co21-MOF-5 (∼7 kJ·mol–1 vs. 5.5 kJ·mol–1 for MOF-5). The results obtained suggested that the Co2+ ions incorporated into MOF-5 played an important role in the hydrogen adsorption process, even being incorporated into the “protected” metal sites that were less accessible to H2 molecules.

Evidence location: page 19-20

## Links

- Source: [[sources/src_ff1b0c9d63]]