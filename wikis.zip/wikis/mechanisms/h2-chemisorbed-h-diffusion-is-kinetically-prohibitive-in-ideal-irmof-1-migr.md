---
title: "Chemisorbed-H diffusion is kinetically prohibitive in ideal IRMOF-1: migration barriers for many ele ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_0abff73929]
confidence: high
---


# Chemisorbed-H diffusion is kinetically prohibitive in ideal IRMOF-1: migration barriers for many ele ...[TRUNCATED]... 

## Mechanism claim

Chemisorbed-H diffusion is kinetically prohibitive in ideal IRMOF-1: migration barriers for many elementary chemisorbed diffusion steps are very high (most between ∼1.3 and 1.6 eV), and for some transitions the transition state requires unrealistic framework deformation; desorption is generally easier than chemisorbed diffusion.

## Applicability

- Task: `h2`
- Mechanism type: `kinetic_barrier_to_chemisorbed_diffusion`
- Condition scope: `{"gas": "atomic H (chemisorbed state)", "temperature_K": 300, "pressure_bar": null, "material_family": "IRMOF-1 (ideal crystal)", "method": "DFT transition-state / barrier calculations"}`

## Positive design features

- Not specified

## Negative design features

- High energy barriers (up to ~1.6 eV) prevent long-range chemisorbed migration at room temperature
- Chemisorbed H tends to desorb rather than diffuse

## Agent design implication

Do not rely on long-range chemisorbed-H surface diffusion for spillover in ideal narrow-pore MOFs; enable alternative transport pathways (gas-phase/physisorbed H, defects, mesopores) or embed catalysts appropriately.

## Evidence

> "Diffusion in the chemisorbed state is very unlikely.... For the migration of chemisorbed H between two O atoms, the transition state required large deformation of the structure (unrealistic in the rigid MOF framework), and even then the energy barrier to diffusion was larger than the desorption energy.... The energy barriers for many of the elementary diffusion steps are very high (up to about 1.60 eV). (b) H atoms in all binding sites can desorb easier than diffuse in chemisorbed state. Most energy barriers are between 1.3 and 1.6 eV."

Evidence location: page 5

## Links

- Source: [[sources/src_0abff73929]]