---
title: "On the basis of computed permeability and permselectivity, the screening identified 30 optimal CoRE‑ ...[TRUNCATED]... "
type: mechanism
tags: [mixed, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_90953381a0]
confidence: high
---


# On the basis of computed permeability and permselectivity, the screening identified 30 optimal CoRE‑ ...[TRUNCATED]... 

## Mechanism claim

On the basis of computed permeability and permselectivity, the screening identified 30 optimal CoRE‑MOF membranes suitable for different gas mixtures.

## Applicability

- Task: `mixed`
- Mechanism type: `computational selection (performance ranking -> candidate materials)`
- Condition scope: `{"gas": "different binary gas mixtures (15 mixtures screened)", "temperature_K": null, "pressure_bar": null, "material_family": "CoRE-MOFMs / CoRE‑MOF membranes", "method": "high-throughput simulation and ranking"}`

## Positive design features

- Not specified

## Negative design features

- Not specified

## Agent design implication

Use high-throughput permeability and permselectivity screening to shortlist top MOF membrane candidates (study produced a list of 30 optimal candidates).

## Evidence

> Finally, on the basis of the permeability and permselectivity, 30 optimal CoRE‑MOFMs are identified as being suitable for the separation of different gas mixtures.

Evidence location: page 12

## Links

- Source: [[sources/src_90953381a0]]