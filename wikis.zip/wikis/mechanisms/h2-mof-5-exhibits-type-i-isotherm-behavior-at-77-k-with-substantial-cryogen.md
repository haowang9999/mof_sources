---
title: "MOF-5 exhibits type I isotherm behavior at 77 K with substantial cryogenic uptake (4.7 wt% at 50 bar ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_b1552d4a9d]
confidence: high
---


# MOF-5 exhibits type I isotherm behavior at 77 K with substantial cryogenic uptake (4.7 wt% at 50 bar ...[TRUNCATED]... 

## Mechanism claim

MOF-5 exhibits type I isotherm behavior at 77 K with substantial cryogenic uptake (4.7 wt% at 50 bar) but shows weak, nearly linear adsorption at 298 K (under-saturated in the 5–20 bar range).

## Applicability

- Task: `h2`
- Mechanism type: `experimental uptake / temperature dependence`
- Condition scope: `{"gas": "H2", "temperature_K": [77, 298], "pressure_bar": [50, "5–20 (298 K observational range)"], "material_family": "MOF-5 (IRMOF family)", "method": "experiment (reported)"}`

## Positive design features

- rapid adsorption at low pressure and cryogenic temperature

## Negative design features

- weak adsorption at room temperature leading to low usable uptake in moderate pressures

## Agent design implication

High-surface-area MOFs like MOF-5 can deliver substantial gravimetric capacity at cryogenic temperatures; for room-temperature applications, focus on increasing binding strength or using cryogenic/pressure-swing operation.

## Evidence

> For MOF-5, the measured adsorption isotherm at 77 K showed type I behavior with H2 adsorption capacity of 4.7 wt% of H2 at P(H2) = 50 bar. ... The hydrogen adsorption isotherm at 298 K was approximately linear because the MOF-5 framework was under-saturated with gas within the range of 5–20 bar of H2.

Evidence location: page 3

## Links

- Source: [[sources/src_b1552d4a9d]]