---
title: "Missing-linker (linker-defect) creation increases available coordination sites at metal-oxo clusters ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_c88d608b3b]
confidence: high
---


# Missing-linker (linker-defect) creation increases available coordination sites at metal-oxo clusters ...[TRUNCATED]... 

## Mechanism claim

Missing-linker (linker-defect) creation increases available coordination sites at metal-oxo clusters and modifies pore size, surface area, and water stability — thereby often enhancing lanthanide adsorption — but inner-sphere chemisorption can also occur at intrinsic bridging oxygens even without increased defect signatures (defects beneficial but not strictly necessary).

## Applicability

- Task: `pld`
- Mechanism type: `defect-enabled site exposure and pore-property modification`
- Condition scope: `{"gas": "aqueous (lanthanide adsorption experiments)", "temperature_K": null, "pressure_bar": null, "material_family": "UiO-66 family and Cr-MIL-101; general Cr- and Zr-based MOFs", "method": "experiment (synthesis variants, XAFS, adsorption, TGA)"}`

## Positive design features

- missing linkers produce additional available coordination sites at metal-oxo clusters where Ln may adsorb
- defect density controls pore size, surface area, and water stability
- prior work shows engineered linker-defects can boost lanthanide adsorption in MIL-101 series

## Negative design features

- excessive defects can reduce stability or collapse framework
- defects are not the only route to chemisorption because bridging oxygens can bind Ln even when defect signatures are similar

## Agent design implication

Use controlled missing-linker defect engineering to increase oxo-cluster binding-site density and tune porosity, but verify bridging-oxygen accessibility and balance defect concentration against stability.

## Evidence

> "Missing linkers result in favorable Ln binding sites at oxo clusters; however, Ln can coordinate to metal sites even with linkers in place."; "The density of the missing linker defects controls a MOF’s properties: pore size, surface area, and stability in water. Importantly, missing linkers result in additional available coordination sites at metal oxo clusters, where Ln may adsorb."; "thermogravimetric characterization indicates that the defect characteristics of Cr-MIL-101 and Cr-MIL-101-NH2 is similar. This indicates that Lu3+ adsorption does not require a defect site (missing linker), and Lu3+ can bind at the bridging oxygen sites, as well as defect sites."; referenced titles: "Engineering linker-defects of MIL-101 series ... for boosted Yb (III) adsorption."

Evidence location: page 1 Abstract; page 5 Section 3.1; page 6 Section 3.3; references pages 10-11

## Links

- Source: [[sources/src_c88d608b3b]]