---
title: "Compositeing CuBTC (Cu3(BTC)2) with carbon-based materials such as graphene oxide (GO) or CNTs can i ...[TRUNCATED]... "
type: mechanism
tags: [co2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_a034d4944a]
confidence: medium
---


# Compositeing CuBTC (Cu3(BTC)2) with carbon-based materials such as graphene oxide (GO) or CNTs can i ...[TRUNCATED]... 

## Mechanism claim

Compositeing CuBTC (Cu3(BTC)2) with carbon-based materials such as graphene oxide (GO) or CNTs can increase BET surface area and in some reported examples enhance CO2 uptake.

## Applicability

- Task: `co2`
- Mechanism type: `composite-induced surface area / uptake enhancement`
- Condition scope: `{"gas": "CO2", "temperature_K": 273, "pressure_bar": 1, "material_family": "CuBTC and CuBTC-carbon composites", "method": "experimental (adsorption data compiled in review table)"}`

## Positive design features

- increased surface area (BET) in composite samples reported
- increased CO2 adsorption in some composite examples

## Negative design features

- improvements are sample- and composition-dependent

## Agent design implication

Form composites of MOFs with carbonaceous additives (GO, CNT) to potentially increase surface area and CO2 uptake, but validate for specific compositions and operating conditions.

## Evidence

> Table 1: ... CuBTC 1760 (m2/g) 5.33 mmol/g 25 ◦C, 1 bar ... CuBTC@1%GO 1772 (m2/g) 8.90 mmol/g 273 K, 1 bar ... CNT@Cu3(BTC)2 1458 (m2/g) 595 mg/g 298 K, 18 bar. (pages 3-4, Table 1)

Evidence location: pages 3-4 (Table 1)

## Links

- Source: [[sources/src_a034d4944a]]