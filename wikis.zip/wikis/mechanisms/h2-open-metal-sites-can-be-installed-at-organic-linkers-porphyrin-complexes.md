---
title: "Open metal sites can be installed at organic linkers (porphyrin complexes, Schiff-base complexes, po ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_ff1b0c9d63]
confidence: medium
---


# Open metal sites can be installed at organic linkers (porphyrin complexes, Schiff-base complexes, po ...[TRUNCATED]... 

## Mechanism claim

Open metal sites can be installed at organic linkers (porphyrin complexes, Schiff-base complexes, postsynthetic metalation) to increase Qst and allow binding of multiple H2 molecules per site, though activation can risk framework collapse or metal aggregation.

## Applicability

- Task: `h2`
- Mechanism type: `site-specific functionalization (metalated linkers)`
- Condition scope: `{"gas": "H2", "temperature_K": null, "pressure_bar": null, "material_family": "porphyrin-based MOFs, metalated-linker MOFs (IRMOF-77, MOF-253 etc.)", "method": "experiment / synthesis / postsynthetic modification"}`

## Positive design features

- open metal coordination at linkers
- ability to post-synthetically metalate or attach organometallic complexes

## Negative design features

- framework collapse during activation can reduce surface area
- possible metal aggregation reducing site accessibility

## Agent design implication

Consider covalent functionalization of linkers followed by metalation or incorporation of organometallic complexes to create additional open metal adsorption sites; monitor framework stability during activation to avoid loss of porosity.

## Evidence

> The open metal sites at organic linkers are also a highly popular approach used to increase the Qst value. For example, porphyrin-based MOFs ... contain open metal sites ... The approach in which metal fragments are attached to the organic linkers involves covalent functionalization, followed by metalation and attachment of organometallic complexes to the aromatic components of the linkers. ... MOFs with open metal sites at secondary building units and organic linkers are capable of binding several H2 molecules at a given binding site.

Evidence location: page 18-19

## Links

- Source: [[sources/src_ff1b0c9d63]]