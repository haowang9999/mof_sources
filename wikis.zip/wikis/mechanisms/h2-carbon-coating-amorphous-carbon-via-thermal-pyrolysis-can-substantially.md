---
title: "Carbon-coating (amorphous carbon via thermal pyrolysis) can substantially improve moisture stability ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_fa8cccd644]
confidence: high
---


# Carbon-coating (amorphous carbon via thermal pyrolysis) can substantially improve moisture stability ...[TRUNCATED]... 

## Mechanism claim

Carbon-coating (amorphous carbon via thermal pyrolysis) can substantially improve moisture stability/hydrophobicity but often reduces measured BET surface area (example: MOF-5 decreased from 3450 to 1740 m2 g−1).

## Applicability

- Task: `h2`
- Mechanism type: `surface coating → decreased accessible area but increased stability/hydrophobicity`
- Condition scope: `{"gas": "not gas-specific (stability/hydrophobicity context)", "temperature_K": null, "pressure_bar": null, "material_family": "MOF-5 (amorphous carbon-coated)", "method": "thermal carbon-coating / pyrolysis under N2"}`

## Positive design features

- improved water stability and hydrophobic behaviour

## Negative design features

- reduced BET surface area and potential loss of accessible porosity

## Agent design implication

Use carbon coatings when water stability is a priority, but expect and quantify loss in accessible surface area and potential impact on adsorption capacity.

## Evidence

> Amorphous carbon-coated MOF-5 prepared by thermal modification under N2 (480–530 °C) had reduced BET areas (1740 vs. 3450 m2 g−1) but displayed better water stability compared with pristine MOF-5.

Evidence location: page 14

## Links

- Source: [[sources/src_fa8cccd644]]