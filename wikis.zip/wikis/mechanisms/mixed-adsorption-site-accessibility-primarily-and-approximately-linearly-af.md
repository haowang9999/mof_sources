---
title: "Adsorption site accessibility primarily and (approximately) linearly affects C2H2 sorption preferenc ...[TRUNCATED]... "
type: mechanism
tags: [mixed, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_a318a71841]
confidence: high
---


# Adsorption site accessibility primarily and (approximately) linearly affects C2H2 sorption preferenc ...[TRUNCATED]... 

## Mechanism claim

Adsorption site accessibility primarily and (approximately) linearly affects C2H2 sorption preference; in this study manipulating accessibility produced up to ~10× increase in C2H2 preference over CO2.

## Applicability

- Task: `mixed`
- Mechanism type: `adsorption-site accessibility affecting sorption strength/selectivity`
- Condition scope: `{"gas": "C2H2 (in competition with CO2)", "temperature_K": null, "pressure_bar": null, "material_family": "rigid honeycomb-like MOF (side-chain functionalization series)", "method": "experiment (equilibrium adsorption capacities and breakthrough)"}`

## Positive design features

- increased adsorption site accessibility increases C2H2 preference

## Negative design features

- reducing accessible pore volume can prevent use of C2H2-preferring sites

## Agent design implication

To enhance acetylene preference over CO2, increase accessibility of C2H2-preferring adsorption sites via side-chain functionalization; expect up to ~10× change in selectivity in similar systems.

## Evidence

> The former primarily affects C2H2 sorption preference linearly and is, within this study, manipulated to increase preference by factor ten.

Evidence location: page 8 (Conclusions)

## Links

- Source: [[sources/src_a318a71841]]