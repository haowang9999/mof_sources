---
title: "Literature examples across other MOF chemistries show that introducing bimetallic structures can inc ...[TRUNCATED]... "
type: mechanism
tags: [h2|mixed, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_340141308b]
confidence: medium
---


# Literature examples across other MOF chemistries show that introducing bimetallic structures can inc ...[TRUNCATED]... 

## Mechanism claim

Literature examples across other MOF chemistries show that introducing bimetallic structures can increase H2 uptake by increasing specific surface area/pore volume or by strengthening guest–framework interactions (examples cited: Ni-Cu-BTC and Zn-Cu-BTC increased H2 uptake relative to Cu-BTC; Co-Zn-ZIF-8 increased SSA/pore volume vs Zn-ZIF-8).

## Applicability

- Task: `h2|mixed`
- Mechanism type: `literature-backed composition → pore/interaction enhancement`
- Condition scope: `{"gas": "H2", "temperature_K": 77, "pressure_bar": 1, "material_family": "other MOFs cited (BTC, ZIF-8) used as precedents", "method": "experimental literature examples cited in Introduction"}`

## Positive design features

- bimetallic substitution associated with increased SSA and pore volume in cited examples
- reported improved H2 uptake in those cited systems

## Negative design features

- Not specified

## Agent design implication

Precedents suggest trying bimetallic substitution (e.g., Cu/Ni, Co/Zn) as a strategy to increase SSA/pore volume or guest–framework interaction in order to boost cryogenic H2 uptake, but system-specific testing is required.

## Evidence

> The hydrogen adsorption capacity of Ni-Cu-BTC ... and Zn-Cu-BTC ... reached 1.60 and 1.63 wt% at 77 K and 1 bar, which was 60% higher than that of Cu-BTC (1.02 wt%)... introduction of bimetallic structures may be beneficial to expand the pore structure of MOFs. For example... the specific surface area and pore volume of Co-Zn-ZIF-8 ... increased by 40 and 33%, which improved the hydrogen adsorption performance ... from 1.26 to 1.55 wt%.

Evidence location: page 1 (Introduction; literature citations)

## Links

- Source: [[sources/src_340141308b]]