---
title: "Adsorptive separations in porous materials operate by three principal mechanisms — molecular sieving ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_a034d4944a]
confidence: high
---


# Adsorptive separations in porous materials operate by three principal mechanisms — molecular sieving ...[TRUNCATED]... 

## Mechanism claim

Adsorptive separations in porous materials operate by three principal mechanisms — molecular sieving (steric/size exclusion), equilibrium (thermodynamic) separation, and kinetics (diffusion-based) separation — and pore size/topology helps determine which mechanism dominates for a given gas mixture.

## Applicability

- Task: `pld`
- Mechanism type: `pore-aperture / PLD mechanism classification`
- Condition scope: `{"gas": "general gas mixtures (CO2, N2, CH4, etc.)", "temperature_K": null, "pressure_bar": null, "material_family": "porous adsorbents / MOFs", "method": "review"}`

## Positive design features

- uniform, fine-tuned pore topologies enable molecular sieving
- large pores with interaction sites enable equilibrium separations
- differing pore sizes/shapes can tune diffusion rates for kinetic separations

## Negative design features

- precise adjustment of pore dimensions is difficult in many solid-state materials

## Agent design implication

Select pore aperture and topology according to target separation: make apertures smaller than unwanted species for molecular sieving; create large pores with strong interaction areas for equilibrium selectivity; exploit pore-dimension/diffusivity contrasts for kinetic separations.

## Evidence

> Adsorptive separation mechanisms can be divided into three categories: including 1) the molecular sieving effect also called size exclusion separation, 2) equilibrium separation and 3) kinetics separation. The difference in diffusion is determined by the relative pore size. ... The steric mechanism ... is based on the incompatibility of the substrate pores' shape and size with those of the adsorbate gas molecules. ... In kinetics separation, adsorption of porous materials is determined by the diffusivity of each gas component. ... The thermodynamic equilibrium effect occurs when specific components preferentially adsorb on the surface of an adsorbent due to various adsorbate surface and/or adsorbate packing interactions. (pages 5-6)

Evidence location: pages 5-6

## Links

- Source: [[sources/src_a034d4944a]]