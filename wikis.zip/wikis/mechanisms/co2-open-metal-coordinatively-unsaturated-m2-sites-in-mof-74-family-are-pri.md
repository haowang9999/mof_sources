---
title: "Open metal (coordinatively unsaturated) M2+ sites in MOF-74 family are prime adsorption locations fo ...[TRUNCATED]... "
type: mechanism
tags: [co2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_20dae1036b]
confidence: high
---


# Open metal (coordinatively unsaturated) M2+ sites in MOF-74 family are prime adsorption locations fo ...[TRUNCATED]... 

## Mechanism claim

Open metal (coordinatively unsaturated) M2+ sites in MOF-74 family are prime adsorption locations for CO2 at low pressures and can be used as anchoring points for amine grafting, converting physisorption into chemisorption.

## Applicability

- Task: `co2`
- Mechanism type: `open-metal-site adsorption and post-synthetic coordination`
- Condition scope: `{"gas": "CO2 at low partial pressures (flue-gas-like)", "temperature_K": null, "pressure_bar": "low pressures (relevant to flue-gas capture)", "material_family": "M-MOF-74 family (M2(dobdc))", "method": "literature & simulation"}`

## Positive design features

- open metal sites give high physisorptive performance and serve as anchors for amine coordination
- coordination of amines to open metals enables chemisorption mechanisms

## Negative design features

- occupying these sites with amines converts mechanism to chemisorption and can change water affinity and regeneration behavior

## Agent design implication

Target open metal sites for amine grafting when seeking chemisorption-based low-pressure CO2 capture; account for the resulting change in mechanism and water sensitivity.

## Evidence

> “M-MOF-74 possess a high density of exposed M2+... Such bare metal sites are the preferred location for adsorption of CO2 molecules at lower pressures. ... Moreover, such unsaturated sites can be occupied by amines via coordination for improving the adsorption capabilities.”

Evidence location: page 3 (Adsorbent Structures / Methodology)

## Links

- Source: [[sources/src_20dae1036b]]