---
title: "Both O2 and H2 can enter MOF membranes when PLD > 3.5 Å because the molecular sizes of O2 and H2 are ...[TRUNCATED]... "
type: mechanism
tags: [pld|mixed, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_90953381a0]
confidence: high
---


# Both O2 and H2 can enter MOF membranes when PLD > 3.5 Å because the molecular sizes of O2 and H2 are ...[TRUNCATED]... 

## Mechanism claim

Both O2 and H2 can enter MOF membranes when PLD > 3.5 Å because the molecular sizes of O2 and H2 are < 3.5 Å (access threshold behavior).

## Applicability

- Task: `pld|mixed`
- Mechanism type: `size-exclusion / access threshold`
- Condition scope: `{"gas": "O2, H2", "temperature_K": null, "pressure_bar": null, "material_family": "CoRE-MOFMs / CoRE‑MOF membranes", "method": "molecular simulation"}`

## Positive design features

- PLD > 3.5 Å permits entry of O2 and H2

## Negative design features

- Not specified

## Agent design implication

If the goal is to allow O2 or H2 permeation, ensure PLD exceeds the ≈3.5 Å threshold; conversely, PLD ≤ ~3.5 Å may exclude or strongly hinder these small gases.

## Evidence

> "The study showed that when PLD > 3.5 Å, both O2 and H2 could enter the MOFMs, because the pore sizes of O2 and H2 are <3.5 Å."

Evidence location: page 6

## Links

- Source: [[sources/src_90953381a0]]