---
title: "Amine identity and substitution pattern affect uptake order and accessibility: diamines with two act ...[TRUNCATED]... "
type: mechanism
tags: [co2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_20dae1036b]
confidence: high
---


# Amine identity and substitution pattern affect uptake order and accessibility: diamines with two act ...[TRUNCATED]... 

## Mechanism claim

Amine identity and substitution pattern affect uptake order and accessibility: diamines with two active amine groups (e.g., en, mda) produced higher uptake than mmen, which in turn outperformed dmen in the simulations; larger/bulkier substituents reduce CO2 accessibility via steric hindrance.

## Applicability

- Task: `co2`
- Mechanism type: `chemical functionality and steric effects on adsorption strength and capacity`
- Condition scope: `{"gas": "CO2", "temperature_K": 313, "pressure_bar": null, "material_family": "amine-functionalized MOF-74 and DOBPDC (–en, –mda, –mmen, –dmen)", "method": "simulation"}`

## Positive design features

- two-active-amine diamines (en, mda) provide multiple interaction sites and higher uptake

## Negative design features

- methylation and bulkier groups reduce accessible void fraction and can lower uptake

## Agent design implication

Prefer diamines with two reactive amine groups for stronger interactions when capacity is primary objective, but consider methylated or less bulky amines (e.g., mmen) when easier desorption/regenerability is prioritized.

## Evidence

> “According to the results... the performance order for the adsorption uptake of the different studied amine functional groups was found to be –en, –mda > -mmen > -dmen. Two main reasons for this behavior are: -mda and –en have two active amine functional groups... The other reason is due to steric hindrance... since bigger and bulkier molecules reduce the CO2 accessibility.”

Evidence location: page 6

## Links

- Source: [[sources/src_20dae1036b]]