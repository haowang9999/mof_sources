---
title: "The heat (isosteric enthalpy, Qst) of hydrogen adsorption for many nanoporous materials (including m ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_ff1b0c9d63]
confidence: high
---


# The heat (isosteric enthalpy, Qst) of hydrogen adsorption for many nanoporous materials (including m ...[TRUNCATED]... 

## Mechanism claim

The heat (isosteric enthalpy, Qst) of hydrogen adsorption for many nanoporous materials (including many MOFs) is relatively low, often reported in literature in ranges such as ~4–7 kJ·mol−1 or modestly higher (5–10 kJ·mol−1) depending on material and measurement conditions.

## Applicability

- Task: `h2`
- Mechanism type: `adsorption energetics (physisorption weak binding)`
- Condition scope: `{"gas": "H2", "temperature_K": null, "pressure_bar": null, "material_family": "nanoporous materials including MOFs", "method": "review / literature summary"}`

## Positive design features

- consistent, quantifiable weak physisorption enthalpy in many MOFs

## Negative design features

- relatively low binding energy insufficient for strong room-temperature adsorption

## Agent design implication

Because typical Qst values are low, improving room-temperature H2 uptake requires increasing the isosteric enthalpy (e.g., via stronger adsorption sites, exposed metal sites, or functionalization).

## Evidence

> The heat values of hydrogen adsorption for most nanoporous materials, including MOFs, crosslinked polymers, or porous carbons, are within the range of 4–7 kJ·mol–1 [24]. Additionally, reviews note that Qst values in many porous MOFs are reported in the range of 5–10 kJ·mol−1 and that uptake at moderate temperatures falls by an order of magnitude relative to 77 K.

Evidence location: Section 2.1 (page 2); page 17

## Links

- Source: [[sources/src_ff1b0c9d63]]