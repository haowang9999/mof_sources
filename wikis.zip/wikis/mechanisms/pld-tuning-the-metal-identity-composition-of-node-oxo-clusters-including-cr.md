---
title: "Tuning the metal identity/composition of node oxo-clusters (including creating mixed-metal clusters) ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_c88d608b3b]
confidence: medium
---


# Tuning the metal identity/composition of node oxo-clusters (including creating mixed-metal clusters) ...[TRUNCATED]... 

## Mechanism claim

Tuning the metal identity/composition of node oxo-clusters (including creating mixed-metal clusters) and maximizing shared-oxygen interactions can bias metal–lanthanide interactions and is a potential route to ion-selective lanthanide adsorption.

## Applicability

- Task: `pld`
- Mechanism type: `cluster-composition tuning for selectivity`
- Condition scope: `{"gas": "aqueous (general conclusion from experimental observations)", "temperature_K": null, "pressure_bar": null, "material_family": "Cr- and Zr-based MOFs; generalizable to MOFs with tunable oxo-cluster composition", "method": "interpretation of experimental XAFS and authors' design recommendations"}`

## Positive design features

- shared oxygens at oxo-clusters enable strong metal-lanthanide interactions
- mixed-metal clusters may create site-specific preferences across the lanthanide series

## Negative design features

- mixed-metal clusters may alter stability or pore structure; selectivity may be modest and context-dependent

## Agent design implication

Consider substituting or mixing node metals to tune binding energies and pursue ion-selectivity among closely related lanthanides; validate selectivity experimentally.

## Evidence

> "We conclude that MOFs for ion-selective Ln capture can be designed by a combination of (1) maximizing metal-lanthanide interactions via shared O atoms at the metal oxo cluster sites, where mixed oxo clusters can lead to ion-selective Ln adsorption..."

Evidence location: page 1 Abstract

## Links

- Source: [[sources/src_c88d608b3b]]