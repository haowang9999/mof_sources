---
title: "In IRMOF-1 (MOF-5), including many-body polarization does not significantly change H2 radial distrib ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_532b708453]
confidence: medium-high
---


# In IRMOF-1 (MOF-5), including many-body polarization does not significantly change H2 radial distrib ...[TRUNCATED]... 

## Mechanism claim

In IRMOF-1 (MOF-5), including many-body polarization does not significantly change H2 radial distribution functions to the metal-centered SBU; MOF-5 lacks open coordination sites on its zinc SBU, has larger voids and an open topology, and sorbs substantially less hydrogen than soc-MOF under similar conditions, suggesting large-pore MOFs are poorer targets for super-hydrogen-storage that aims to exploit induced dipoles.

## Applicability

- Task: `h2`
- Mechanism type: `pore size / local field effect`
- Condition scope: `{"gas": "H2", "temperature_K": 78, "pressure_bar": null, "material_family": "IRMOF-1 (MOF-5)", "method": "simulation (polarizable potential) comparison"}`

## Positive design features

- open topology (larger void space) reduces polarizing field impact

## Negative design features

- absence of open metal coordination sites reduces framework polarizability
- large pores produce H2 far from surfaces with weak induced dipoles

## Agent design implication

Avoid designing MOFs with very large, open voids if the goal is super-hydrogen-storage at cryogenic conditions; prioritize features that create strong local fields (open metal sites, polar linkers, narrow channels).

## Evidence

> Simulations including many-body polarization for IRMOF-1 reveal no significant change in radial distribution functions for the hydrogen to the metal-centered SBU when compared to simulations neglecting induction. MOF-5 ... does not possess an open coordination site on its zinc SBU and thus produces a more weakly polarizing field ... Most importantly, MOF-5 does not possess narrow channels or a highly polar framework, but rather has an open topology with larger void spaces. This comparison strongly suggests that MOFs, like MOF-5, with large pores are not the best target materials for super-hydrogen-storage.

Evidence location: pages 8-9 (IRMOF-1 comparison)

## Links

- Source: [[sources/src_532b708453]]