---
title: "The experimental soc-MOF material sorbs hydrogen in its pores at 78 K and 1.0 atm to a density near  ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_532b708453]
confidence: high
---


# The experimental soc-MOF material sorbs hydrogen in its pores at 78 K and 1.0 atm to a density near  ...[TRUNCATED]... 

## Mechanism claim

The experimental soc-MOF material sorbs hydrogen in its pores at 78 K and 1.0 atm to a density near that of liquid hydrogen (20 K, 1.0 atm).

## Applicability

- Task: `h2`
- Mechanism type: `experimental uptake`
- Condition scope: `{"gas": "H2", "temperature_K": 78, "pressure_bar": 1.0, "material_family": "soc-MOF (specific synthesized MOF with ionic framework and narrow channels)", "method": "experiment"}`

## Positive design features

- near-liquid H2 density in pores at 78 K/1.0 atm
- reversible sorption

## Negative design features

- Not specified

## Agent design implication

Materials that can achieve similar pore environments (high extraframework volume and appropriate topology) can reach very high H2 densities at cryogenic temperatures; use soc-MOF as a benchmark for evaluating sorption capacity at 78 K/1 atm.

## Evidence

> Hydrogen uptake studies on soc-MOF show a large storage capacity with reversible sorption. For example, at 78 K and 1.0 atm, the density of H2 in the pores is approximately 0.05 g cm-3, while liquid hydrogen at its boiling point of 20 K has a density of 0.07 g cm-3. The MOF approached saturation at 1.0 atm, indicative of the near liquid density of the sorbed hydrogen.

Evidence location: page 2

## Links

- Source: [[sources/src_532b708453]]