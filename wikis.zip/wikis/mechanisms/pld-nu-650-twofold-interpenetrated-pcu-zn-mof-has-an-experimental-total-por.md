---
title: "NU-650 (twofold-interpenetrated pcu Zn-MOF) has an experimental total pore volume of 0.36 cm3 g−1 (a ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_3b254ae858]
confidence: high
---


# NU-650 (twofold-interpenetrated pcu Zn-MOF) has an experimental total pore volume of 0.36 cm3 g−1 (a ...[TRUNCATED]... 

## Mechanism claim

NU-650 (twofold-interpenetrated pcu Zn-MOF) has an experimental total pore volume of 0.36 cm3 g−1 (at P/P0 = 0.9, N2 adsorption at 77 K) and an apparent BET area of ~710 m2 g−1; DFT pore-size distribution shows two main pores centered at ~1.06 and 1.26 nm.

## Applicability

- Task: `pld`
- Mechanism type: `measured pore metrics (adsorption + DFT)`
- Condition scope: `{"gas": "N2", "temperature_K": 77, "pressure_bar": null, "material_family": "NU-650 (Zn4O(L1)3, twofold interpenetrated pcu)", "method": "experiment (N2 adsorption after supercritical CO2 activation; DFT pore-size analysis)"}`

## Positive design features

- Measured pore volume: 0.36 cm3 g−1 (P/P0 = 0.9)
- BET area: 710 m2 g−1
- Two main pore sizes at ~1.06 nm and ~1.26 nm (DFT)

## Negative design features

- Interpenetration (twofold) reduces accessible pore space relative to non-interpenetrated analogs

## Agent design implication

Twofold interpenetrated pcu frameworks like NU-650 yield sub-2 nm pores (∼1.1–1.3 nm) and moderate surface area/porosity; expect lower accessible pore volume than corresponding non-interpenetrated analogs.

## Evidence

> N2 adsorption isotherm at 77 K after supercritical CO2 activation suggests NU-650 has the experimental total pore volume of 0.36 cm3 g−1 at P/P0 = 0.9. The apparent Brunauer−Emmett−Teller (BET) area of NU-650 is estimated to be 710 m2 g−1. Pore-size distribution based on DFT models reveals it has two main pores centered at 1.06 and 1.26 nm, respectively.

Evidence location: page 3 (Results: NU-650 adsorption and pore analysis)

## Links

- Source: [[sources/src_3b254ae858]]