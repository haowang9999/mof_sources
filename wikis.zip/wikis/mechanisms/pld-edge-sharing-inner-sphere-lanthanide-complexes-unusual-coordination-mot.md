---
title: "Edge-sharing inner-sphere lanthanide complexes (unusual coordination motifs) were observed in MOFs d ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_c88d608b3b]
confidence: low
---


# Edge-sharing inner-sphere lanthanide complexes (unusual coordination motifs) were observed in MOFs d ...[TRUNCATED]... 

## Mechanism claim

Edge-sharing inner-sphere lanthanide complexes (unusual coordination motifs) were observed in MOFs despite theoretical expectations that nanoconfinement-driven decreased dielectric screening would amplify electrostatic repulsion and disfavor such motifs; the origins of these driving forces are not fully resolved.

## Applicability

- Task: `pld`
- Mechanism type: `confinement-modified electrostatics enabling unexpected coordination motifs`
- Condition scope: `{"gas": "aqueous (experimental observations in MOFs)", "temperature_K": null, "pressure_bar": null, "material_family": "MOFs (general nanoconfinement context)", "method": "experiment (XAFS) plus theoretical discussion"}`

## Positive design features

- experimental identification of edge-sharing surface species at metal-oxo clusters
- highlights that confinement can produce coordination motifs not predicted by simple bulk electrostatics

## Negative design features

- mechanistic origins remain under investigation and are not yet established

## Agent design implication

When predicting or designing coordination environments under confinement, include modeling/experiments that account for altered dielectric screening and local chemical environment, and be open to observing coordination motifs that differ from bulk expectations.

## Evidence

> "Such edge-sharing complexes are not expected due to electrostatic repulsion, which in theory should be amplified under nanoconfinement due to decreased dielectric screening. We are currently investigating the origins of the driving forces behind the formation of these unusual surface species."; "we conclude... Ln can potentially form not only the typical mono- and bidentate binuclear surface complexes but also unusual edge-sharing complexes in MOFs."

Evidence location: pages 8-9 Conclusions

## Links

- Source: [[sources/src_c88d608b3b]]