---
title: "The added alkali-metal cations are likely inaccessible to H2 (not acting as exposed strong binding s ...[TRUNCATED]... "
type: mechanism
tags: [mixed, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_b0ea8c70ab]
confidence: medium
---


# The added alkali-metal cations are likely inaccessible to H2 (not acting as exposed strong binding s ...[TRUNCATED]... 

## Mechanism claim

The added alkali-metal cations are likely inaccessible to H2 (not acting as exposed strong binding sites); 1H NMR solvent quantification rules out extensive cation solvation, so cations are inferred to be localized near carboxylates and shielded by framework interpenetration or otherwise inaccessible.

## Applicability

- Task: `mixed`
- Mechanism type: `cation accessibility inference; exclusion of solvation (experimental)`
- Condition scope: `{"gas": "H2 (implication pertains to adsorbates generally)", "temperature_K": null, "pressure_bar": null, "material_family": "1·M (M = Li, Na, K) reduced MOFs (triply interwoven)", "method": "experiment (1H NMR solvent quantification, adsorption, PXRD, EPR)"}`

## Positive design features

- 1H NMR shows low residual solvent inconsistent with widespread solvation of dopant ions
- PXRD indicates retained crystallinity

## Negative design features

- dopant cations likely localized near carboxylates and shielded by interpenetration
- lack of direct cation–H2 coordination

## Agent design implication

When doping interpenetrated MOFs, check cation accessibility—if cations are localized/shielded, do not expect direct cation–H2 coordination; instead, focus on structural effects (e.g., displacement/interpenetration changes) to improve uptake.

## Evidence

> we infer that the added metal ions are simply inaccessible to hydrogen. Two scenarios can be envisioned: (1) dopant cations localized near negatively charged carboxylates which effectively shielded them from gas exposure on account of framework interpenetration or (2) dopant cations strongly solvated (by DMF or THF molecules). To test the second idea, we determined the post evacuation solvent content of the 1·M materials via 1H NMR... the residual solvent content is independent of lithium cation loading, indicating that not-quite-complete framework evacuation rather than the solvation of dopant ions accounts for the small amount of solvent found. We can therefore rule out cation solvation as a factor in the adsorption performance ...

Evidence location: Results and Discussion (section 3.3), Table 3

## Links

- Source: [[sources/src_b0ea8c70ab]]