---
title: "Precise tuning of pore size/dimensions is required to separate similarly sized molecules by molecula ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_a034d4944a]
confidence: high
---


# Precise tuning of pore size/dimensions is required to separate similarly sized molecules by molecula ...[TRUNCATED]... 

## Mechanism claim

Precise tuning of pore size/dimensions is required to separate similarly sized molecules by molecular sieving, but this tuning is difficult in most solid-state materials and requires careful synthetic or post-synthetic approaches.

## Applicability

- Task: `pld`
- Mechanism type: `fabrication limitation for molecular sieving`
- Condition scope: `{"gas": "mixtures with similarly sized molecules (e.g., CO2 vs CH4/N2)", "temperature_K": null, "pressure_bar": null, "material_family": "porous solids / MOFs", "method": "review"}`

## Positive design features

- uniform pore topologies enable sieving if achievable

## Negative design features

- practical difficulty in precise pore-dimension control

## Agent design implication

Expect engineering challenges when targeting molecular-sieving separations; allocate effort to synthetic strategies that allow sub-angstrom control of pore apertures or use post-synthetic modification.

## Evidence

> In order to separate molecules of similar size or shape in a mixture, one must build a medium with a specified size and tune the pore size, which can be a very precise operation due to the difficulty of precisely adjusting the dimension and functioning in the majority of solid-state materials. (page 6)

Evidence location: page 6

## Links

- Source: [[sources/src_a034d4944a]]