---
title: "Monolayer hydrogen adsorption assumes all adsorbed H2 molecules are in contact with the sorbent surf ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_ff1b0c9d63]
confidence: high
---


# Monolayer hydrogen adsorption assumes all adsorbed H2 molecules are in contact with the sorbent surf ...[TRUNCATED]... 

## Mechanism claim

Monolayer hydrogen adsorption assumes all adsorbed H2 molecules are in contact with the sorbent surface; monolayer capacity relates to surface area via As = na,m L σm and specific surface area as = As / m.

## Applicability

- Task: `h2`
- Mechanism type: `adsorption mode (monolayer) and quantitative relation`
- Condition scope: `{"gas": "H2", "temperature_K": null, "pressure_bar": null, "material_family": "general sorbents / MOFs", "method": "conceptual / analytical"}`

## Positive design features

- provides route to compute surface area from H2 monolayer capacity

## Negative design features

- Not specified

## Agent design implication

Maximizing specific surface area increases the monolayer hydrogen capacity; monolayer capacity estimates can be used to infer accessible surface area for H2.

## Evidence

> In monolayer adsorption, all adsorbed H2 molecules are in contact with the sorbent surface... The monolayer hydrogen capacity (na,m) is determined ... The surface area (As) of the sorbent is usually calculated from the monolayer hydrogen capacity when the area effectively occupied by the H2 molecules in the complete monolayer (σm) is known: As = na,m L σm ... as = As / m.

Evidence location: Section 2.2 Surface Area (page 3–4)

## Links

- Source: [[sources/src_ff1b0c9d63]]