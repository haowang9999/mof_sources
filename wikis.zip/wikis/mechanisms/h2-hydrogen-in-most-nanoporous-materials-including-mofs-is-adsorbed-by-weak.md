---
title: "Hydrogen in most nanoporous materials (including MOFs) is adsorbed by weak physisorption with low is ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_b1552d4a9d]
confidence: high
---


# Hydrogen in most nanoporous materials (including MOFs) is adsorbed by weak physisorption with low is ...[TRUNCATED]... 

## Mechanism claim

Hydrogen in most nanoporous materials (including MOFs) is adsorbed by weak physisorption with low isosteric heats; reported typical ranges are on the order of a few to ~10 kJ·mol−1.

## Applicability

- Task: `h2`
- Mechanism type: `energetics / physisorption`
- Condition scope: `{"gas": "H2", "temperature_K": null, "pressure_bar": null, "material_family": "general nanoporous materials including MOFs, crosslinked polymers, porous carbons", "method": "review"}`

## Positive design features

- reversible, high-rate adsorption at cryogenic temperatures
- clear opportunities to increase interaction via targeted chemical modifications

## Negative design features

- low adsorption enthalpy (reported ranges ~4–10 kJ·mol−1 across sources) limits uptake at ambient temperature

## Agent design implication

Expect MOFs to require low temperatures (e.g., 77 K) or introduction of higher-affinity sites / operational strategies to achieve useful H2 loadings at or near ambient conditions.

## Evidence

> Heat values of hydrogen adsorption for most nanoporous materials, including MOFs, crosslinked polymers, or porous carbons, are within the range of 4–7 kJ·mol−1.  ...  the Qst values in most porous MOFs is within the range of 5–10 kJ·mol−1.

Evidence location: pages 2, 8

## Links

- Source: [[sources/src_b1552d4a9d]]