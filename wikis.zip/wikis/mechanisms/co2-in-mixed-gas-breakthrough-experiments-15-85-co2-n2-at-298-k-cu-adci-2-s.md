---
title: "In mixed-gas breakthrough experiments (15/85 CO2/N2) at 298 K, Cu(adci)-2 shows competitive CO2 capt ...[TRUNCATED]... "
type: mechanism
tags: [co2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_83cde498f9]
confidence: high
---


# In mixed-gas breakthrough experiments (15/85 CO2/N2) at 298 K, Cu(adci)-2 shows competitive CO2 capt ...[TRUNCATED]... 

## Mechanism claim

In mixed-gas breakthrough experiments (15/85 CO2/N2) at 298 K, Cu(adci)-2 shows competitive CO2 capture performance relative to benchmark CALF-20: its dry breakthrough time is 29.7 min g−1 (≈87% of CALF-20's 34.2 min g−1) and it retains breakthrough time better than CALF-20 upon prehumidification to 60% RH.

## Applicability

- Task: `co2`
- Mechanism type: `performance_under_mixed_gas_and_humidity`
- Condition scope: `{"gas": "CO2/N2 (v:v = 15:85)", "temperature_K": 298, "pressure_bar": null, "material_family": "Cu(adci)-2 vs CALF-20", "method": "breakthrough experiments"}`

## Positive design features

- Cu(adci)-2 breakthrough time in dry: 29.7 min g−1
- Cu(adci)-2 breakthrough time relatively unchanged from dry to 30% and 60% RH
- superior performance in highly humid conditions compared to CALF-20

## Negative design features

- absolute breakthrough time of Cu(adci)-2 is lower than CALF-20 in dry condition (≈87%)
- prehumidification and high RH (60%) reduce capacities for both materials

## Agent design implication

Amine-functionalized ultramicropores that combine Lewis basic sites with confined aromatic surfaces can improve resilience of CO2 capture performance under humid flue-gas-like conditions; benchmark comparisons should include prehumidification protocols and humidity cycling.

## Evidence

> Page 6: "In a dry condition, CO2 breakthrough time of Cu(adci)-2 was 87% compared to CALF-20 (29.7 vs 34.2 min g−1). ... the time of CALF-20 in a 60% RH experiment reduced to 74% of that in the dry experiment (25.4 min g−1), whereas the time of Cu(adci)-2 in a 60% RH experiment was still not significantly changed, showing the superior performance of Cu(adci)-2 in a highly humid condition."

Evidence location: page 6 (breakthrough experiments)

## Links

- Source: [[sources/src_83cde498f9]]