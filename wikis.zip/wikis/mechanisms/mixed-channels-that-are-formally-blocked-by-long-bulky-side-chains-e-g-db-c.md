---
title: "Channels that are formally blocked by long/bulky side chains (e.g., DB) can still become permeable f ...[TRUNCATED]... "
type: mechanism
tags: [mixed, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_a318a71841]
confidence: medium
---


# Channels that are formally blocked by long/bulky side chains (e.g., DB) can still become permeable f ...[TRUNCATED]... 

## Mechanism claim

Channels that are formally blocked by long/bulky side chains (e.g., DB) can still become permeable for specific adsorbates if host–guest interactions are sufficiently strong, i.e., adsorptive-enabled gating where chemical affinity overcomes steric blockage.

## Applicability

- Task: `mixed`
- Mechanism type: `adsorptive-enabled gating (host–guest interactions overcoming blocked apertures)`
- Condition scope: `{"gas": "general adsorptives (CO2, C2H2 among tested gases)", "temperature_K": 298, "pressure_bar": null, "material_family": "Zn2(fu-bdc)2bipy series (DB exception highlighted)", "method": "simulation (dynamic PSD from MD snapshots) and experiment (breakthrough/isotherm comparisons)"}`

## Positive design features

- strong/suitable host–guest interactions (enable diffusion where apertures are formally blocked)

## Negative design features

- materials with long/bulky side chains (DB) that formally block channels

## Agent design implication

If side-chain functionalization formally blocks channels (as in DB), either select adsorbates with stronger host–guest interactions to enable diffusion or modify linker chemistry to reduce blockage; conversely, design side chains that require specific host–guest interactions to implement adsorptive-selective gating.

## Evidence

> "PSDs of the limited (smallest diameter along a free path) and largest (largest diameter along a free path) pore sizes show that all materials except for DB are guest-accessible; see Figure 3. Experimental results show that DB only is porous toward adsorptives with suitable host−guest interactions, enabling diffusion through formally blocked channels."

Evidence location: PAGE 3 (Results and Discussion)

## Links

- Source: [[sources/src_a318a71841]]