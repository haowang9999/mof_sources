---
title: "Geometric screening and Henry-regime simplifications are appropriate for dilute (Henry's-law) condit ...[TRUNCATED]... "
type: mechanism
tags: [pld|mixed, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_97052fb350]
confidence: high
---


# Geometric screening and Henry-regime simplifications are appropriate for dilute (Henry's-law) condit ...[TRUNCATED]... 

## Mechanism claim

Geometric screening and Henry-regime simplifications are appropriate for dilute (Henry's-law) conditions; at higher pressures or non-dilute loadings one must use GCMC for adsorption and MD/TST for diffusion because mixture effects and collective diffusion become important.

## Applicability

- Task: `pld|mixed`
- Mechanism type: `method applicability / thermodynamic regime specification`
- Condition scope: `{"gas": "general adsorbates at higher pressures or non-dilute loadings", "temperature_K": null, "pressure_bar": "higher / non-dilute", "material_family": "MOFs", "method": "GCMC/MD/TST (as required for non-dilute conditions)"}`

## Positive design features

- GCMC/MD/TST capture mixture effects, collective diffusion, and adsorption at realistic loadings

## Negative design features

- these methods require significantly larger computational resources

## Agent design implication

For realistic operating conditions (higher pressures or non-dilute loadings), plan to apply GCMC for adsorption equilibria and MD or TST for diffusion to obtain accurate predictions of separation performance.

## Evidence

> Our calculations for adsorption and membrane selectivity for spherical adsorbates are based on a simplified description that is relevant in the Henry’s law regime. ... To describe practical situations where higher pressures are important, well developed molecular simulation methods based on Grand Canonical Monte Carlo (for adsorption), and molecular dynamics and/or transition-state theory (for diffusion, including self-diffusion or collective diffusion leading to net mass transfer) are available.

Evidence location: page 7539 (concluding remarks) and page 11 (discussion)

## Links

- Source: [[sources/src_97052fb350]]