---
title: "Comparing predictions for defect-free MOF crystals with experimental membranes can be nontrivial: di ...[TRUNCATED]... "
type: mechanism
tags: [pld|mixed, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_97052fb350]
confidence: medium
---


# Comparing predictions for defect-free MOF crystals with experimental membranes can be nontrivial: di ...[TRUNCATED]... 

## Mechanism claim

Comparing predictions for defect-free MOF crystals with experimental membranes can be nontrivial: discrepancies (e.g., predicted vs observed selectivities for ZIF-8, ZIF-7, CuBTC) are often attributable to microstructural defects, grain boundaries, orientation issues in films, or other processing-related effects that allow bypass flux.

## Applicability

- Task: `pld|mixed`
- Mechanism type: `experimental artifact / microstructure effect`
- Condition scope: `{"gas": "H2, CH4 and other gases in membrane experiments", "temperature_K": 298, "pressure_bar": null, "material_family": "thin-film MOF membranes, mixed-matrix membranes", "method": "comparison of simulation predictions with experiments"}`

## Positive design features

- Not specified

## Negative design features

- microstructural defects (grain boundaries) that permit bypass flux
- orientation issues for 1D pore MOFs in films

## Agent design implication

When experimental thin-film membranes show lower selectivity than predicted, investigate microstructural defects and control crystal orientation (especially for 1D pore MOFs); consider mixed-matrix membranes to separate intrinsic pore-permeation from film defects.

## Evidence

> These predicted selectivities are orders of magnitude larger than the modest selectivities that have been seen experimentally. We believe, although we cannot unambiguously demonstrate, that this discrepancy is mostly associated with defects in the microstructure of the intergrown thin films, where defects associated with grain boundaries can allow significant fluxes of CH4 (and H2) through the membranes. ... The fact that this MOF has one-dimensional pores provides a hint that controlling the orientation of MOF crystals within an intergrown film may be critical to the success of such a film as a membrane.

Evidence location: page 9-11

## Links

- Source: [[sources/src_97052fb350]]