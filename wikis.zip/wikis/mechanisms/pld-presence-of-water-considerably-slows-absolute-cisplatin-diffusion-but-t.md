---
title: "Presence of water considerably slows absolute cisplatin diffusion, but the relative ranking of diffu ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_8ce39338bc]
confidence: high
---


# Presence of water considerably slows absolute cisplatin diffusion, but the relative ranking of diffu ...[TRUNCATED]... 

## Mechanism claim

Presence of water considerably slows absolute cisplatin diffusion, but the relative ranking of diffusivities across frameworks is preserved; moreover, non-solvated non-bonded (SMD) diffusion energy barriers correlate strongly with solvated diffusivities, so non-solvated SMD barriers can serve as semi-quantitative proxies for screening relative release rates.

## Applicability

- Task: `pld`
- Mechanism type: `kinetic hindrance by solvent; correlative proxy for screening`
- Condition scope: `{"gas": "cisplatin in solvated vs non-solvated simulation", "temperature_K": null, "pressure_bar": null, "material_family": "UiO-66 family and related frameworks tested", "method": "equilibrium MD with and without water; SMD (non-solvated)"}`

## Positive design features

- relative diffusivity ranking preserved when solvent is included
- strong correlation between ΔUMOF-CPT (SMD non-solvated) and solvated diffusivities

## Negative design features

- absolute diffusivities lower when solvent is present (water slows diffusion)

## Agent design implication

For high-throughput comparative screening, compute non-solvated SMD (or PMF) diffusion energy barriers to rank candidates; reserve solvent-explicit MD for top candidates when absolute rate estimates are needed.

## Evidence

> While the presence of water considerably slows down diffusion, the ranking of the diffusivities remains the same regardless of the presence of water. The non-bonded MOF–CPT diffusion energy barriers of cisplatin movement through each non-solvated UiO framework using SMD simulations is strongly correlated with the cisplatin diffusivities calculated in solvated frameworks.

Evidence location: page 6-7 (Fig. 4 discussion); page 12

## Links

- Source: [[sources/src_8ce39338bc]]