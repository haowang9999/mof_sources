---
title: "Open (coordinatively unsaturated) metal sites increase isosteric enthalpy (Qst) and tend to raise 29 ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_b1552d4a9d]
confidence: high
---


# Open (coordinatively unsaturated) metal sites increase isosteric enthalpy (Qst) and tend to raise 29 ...[TRUNCATED]... 

## Mechanism claim

Open (coordinatively unsaturated) metal sites increase isosteric enthalpy (Qst) and tend to raise 298 K uptake, particularly in high-surface-area MOFs; creating such sites (e.g., removal of coordinated solvent) is an effective strategy (SNU-15 Co example yields Qst ~15 kJ·mol−1).

## Applicability

- Task: `h2`
- Mechanism type: `open metal sites / chemisorption-enhanced physisorption`
- Condition scope: `{"gas": "H2", "temperature_K": null, "pressure_bar": null, "material_family": "MOFs with open metal sites (e.g., SNU-15)", "method": "experiment / review"}`

## Positive design features

- measured 298 K uptakes are higher for MOFs with open metal sites
- explicit example: SNU-15 Co removal of coordinated H2O yields vacant Co sites and Qst = 15 kJ·mol−1

## Negative design features

- effect is most pronounced in MOFs with very high surface area (>3000 m2·g−1)
- creating open sites may require thermal activation and can affect stability

## Agent design implication

Design SBUs and linkers that yield stable open metal sites (e.g., removable axial solvent on paddle-wheel units or metal centers in porphyrin linkers) to increase Qst and ambient-temperature uptake; targeted activation protocols can create coordination vacancies (SNU-15 example).

## Evidence

> Open metal sites may increase the Qst value. H2 adsorption values at 298 K for MOFs with open metal sites are higher than those without; tendency pronounced for A > 3000 m2·g−1. In SNU-15, removal of coordinated H2O created vacant Co(II) sites allowing side-on H2 bonding with Qst = 15 kJ·mol−1 at zero coverage.

Evidence location: pages 8-9

## Links

- Source: [[sources/src_b1552d4a9d]]