---
title: "GCMC simulations treated MOF structures as rigid frameworks (periodic); supercells were applied when ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_fc58db74fa]
confidence: high
---


# GCMC simulations treated MOF structures as rigid frameworks (periodic); supercells were applied when ...[TRUNCATED]... 

## Mechanism claim

GCMC simulations treated MOF structures as rigid frameworks (periodic); supercells were applied when necessary to ensure system dimensions at least twice the nonbonded cutoff (12 Å), which neglects dynamic framework flexibility except via choosing representative phases.

## Applicability

- Task: `pld`
- Mechanism type: `simulation assumption impacting predicted adsorption (neglects framework flexibility)`
- Condition scope: `{"gas": "general (GCMC adsorbates)", "temperature_K": null, "pressure_bar": null, "material_family": "MOFs", "method": "GCMC simulation (rigid-framework)"}`

## Positive design features

- periodic, rigid-framework assumption simplifies and standardizes simulations

## Negative design features

- neglects framework flexibility (breathing) except where a representative phase was selected

## Agent design implication

When using rigid-framework GCMC, explicitly select the MOF structural phase representative of operating conditions (temperature/pressure) for flexible/breathing MOFs, or consider flexible-framework methods if breathing is expected to affect adsorption.

## Evidence

> “All the MOFs structures were treated as rigid frameworks with periodic boundaries; when necessary, supercells were applied to ensure the system size to be twice longer than the cutoff distance (12 Å ).”

Evidence location: STAR+METHODS, Grand canonical Monte Carlo simulations (page ~12)

## Links

- Source: [[sources/src_fc58db74fa]]