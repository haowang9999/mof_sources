---
title: "Empirical extreme performances: reported excess H2 capacities at −196 °C vary widely (several wt% to ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_fa8cccd644]
confidence: high
---


# Empirical extreme performances: reported excess H2 capacities at −196 °C vary widely (several wt% to ...[TRUNCATED]... 

## Mechanism claim

Empirical extreme performances: reported excess H2 capacities at −196 °C vary widely (several wt% to >9 wt%); NU-100 (NU100) reported 9.05 wt% at −196 °C and 7 MPa (7 MPa = 70 bar).

## Applicability

- Task: `h2`
- Mechanism type: `empirical performance data`
- Condition scope: `{"gas": "H2", "temperature_K": 77, "pressure_bar": 70, "material_family": "MOFs (example: NU-100 / NU100)", "method": "review / literature report"}`

## Positive design features

- very high ABET correlated with higher gravimetric excess capacities in some MOFs

## Negative design features

- highest reported values are under cryogenic and elevated pressure conditions

## Agent design implication

When pursuing high gravimetric cryogenic capacity, target ultrahigh-surface-area MOFs (NU100-class) and validate performance at intended cryogenic pressures; also evaluate volumetric metrics and practical operating conditions.

## Evidence

> Excess H2 storage capacities in the range of 2.4 to 9.1 wt% have been obtained in MOFs with Brunauer–Emmett–Teller (BET) areas (ABET) of up to 6000 m2 g−1. The highest H2 storage capacity reported to date is 9.05 wt% at −196 °C and 7 MPa for NU100. || "NU100, which reaches 9.05 wt% at 7 MPa and −196 °C."

Evidence location: page 1 (Introduction) || page 15

## Links

- Source: [[sources/src_fa8cccd644]]