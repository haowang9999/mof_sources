---
title: "Under experimental conditions (78 K, ~1 atm) in soc-MOF the density of H2 in the pores reaches appro ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_532b708453]
confidence: high
---


# Under experimental conditions (78 K, ~1 atm) in soc-MOF the density of H2 in the pores reaches appro ...[TRUNCATED]... 

## Mechanism claim

Under experimental conditions (78 K, ~1 atm) in soc-MOF the density of H2 in the pores reaches approximately 0.05 g cm^-3 (approaching liquid hydrogen density of 0.07 g cm^-3) and pores fill at relatively low pressure approaching saturation near 1 atm.

## Applicability

- Task: `h2`
- Mechanism type: `adsorption_behavior / uptake`
- Condition scope: `{"gas": "H2", "temperature_K": 78, "pressure_bar": 1.0, "material_family": "soc-MOF", "method": "experiment (reported uptake) and simulation (performed at experimentally observed loading)"}`

## Positive design features

- high pore H2 density (~0.05 g cm^-3)
- reversible sorption and pores filled at relatively low pressure

## Negative design features

- Not specified

## Agent design implication

Ionic MOFs with narrow channels can achieve near-liquid hydrogen densities in their pores at cryogenic temperatures; aim to maximize accessible pore volume while maintaining narrow channels to promote early pore filling and high volumetric uptake.

## Evidence

> At 78 K and 1.0 atm, the density of H2 in the pores is approximately 0.05 g cm-3, while liquid hydrogen at its boiling point of 20 K has a density of 0.07 g cm-3. ... Hydrogen sorption isotherms were measured at 78 K on soc-MOF and showed that the pores were filled at relatively lower pressure. The MOF approached saturation at 1.0 atm, indicative of the near liquid density of the sorbed hydrogen.

Evidence location: PAGE 2

## Links

- Source: [[sources/src_532b708453]]