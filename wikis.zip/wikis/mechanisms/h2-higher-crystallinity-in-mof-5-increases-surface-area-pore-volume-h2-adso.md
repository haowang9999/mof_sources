---
title: "Higher crystallinity in MOF-5 increases surface area, pore volume, H2 adsorption capacity and therma ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_ff1b0c9d63]
confidence: high
---


# Higher crystallinity in MOF-5 increases surface area, pore volume, H2 adsorption capacity and therma ...[TRUNCATED]... 

## Mechanism claim

Higher crystallinity in MOF-5 increases surface area, pore volume, H2 adsorption capacity and thermal stability (examples: higher As and Va and increased Tdec in interwoven/high-crystallinity samples).

## Applicability

- Task: `h2`
- Mechanism type: `structure-property correlation`
- Condition scope: `{"gas": "H2", "temperature_K": null, "pressure_bar": null, "material_family": "MOF-5 (structurally modified MOF-5 samples)", "method": "experiment"}`

## Positive design features

- high crystallinity
- interwoven structure (ultramicroporous) in some samples

## Negative design features

- Not specified

## Agent design implication

Aim for higher crystallinity during synthesis of MOF-5 derivatives to increase BET surface area, pore volume, H2 uptake and thermal stability.

## Evidence

> The obtained results confirmed that higher crystallinity in MOF-5 leads to higher As and Va values, in addition to higher H2 adsorption capacity and thermal stability ... The interwoven MOF-5 samples showed an ultramicroporous structure and reached 1.7 and 2.0 H2 wt%, and an increase in the decomposition temperature, Tdec, to 773 and 783 K, respectively.

Evidence location: Table 1 and preceding text (page 11-12)

## Links

- Source: [[sources/src_ff1b0c9d63]]