---
title: "Diamine functionalization of expanded M2(dobpdc) materials leads to cooperative chemisorption via fo ...[TRUNCATED]... "
type: mechanism
tags: [co2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_20dae1036b]
confidence: high
---


# Diamine functionalization of expanded M2(dobpdc) materials leads to cooperative chemisorption via fo ...[TRUNCATED]... 

## Mechanism claim

Diamine functionalization of expanded M2(dobpdc) materials leads to cooperative chemisorption via formation of ammonium carbamate chains, producing step-like (sigmoidal) CO2 adsorption isotherms whose step pressure can be tuned by amine identity and substitution.

## Applicability

- Task: `co2`
- Mechanism type: `cooperative chemisorption (ammonium carbamate chain formation / cooperative insertion into metal–amine bonds)`
- Condition scope: `{"gas": "CO2 (pure and low-concentration mixtures)", "temperature_K": null, "pressure_bar": null, "material_family": "M2(dobpdc) (expanded MOF-74 / DOBPDC) functionalized with diamines or alkylamines", "method": "simulation (explicit chemisorption modeling) and experimental literature"}`

## Positive design features

- step-like isotherm yields strong uptake at low partial pressures
- cooperativity can be tuned (step position/steepness) via choice of diamine, alkyl substitution, and metal identity

## Negative design features

- requires pore geometry and spacing that permit chain formation and can be sensitive to steric substitution
- too-strong chain-stabilizing interactions can increase regeneration energy

## Agent design implication

To achieve sharp low-pressure CO2 uptake suitable for TSA-style operation, functionalize DOBPDC-type frameworks with appropriate diamines to promote ammonium-carbamate chain formation and tune step pressure by amine selection and substitution.

## Evidence

> “Formation of ammonium carbamate chains takes place for different diamine molecules on the adsorbent, leading to isotherms exhibiting step-like shapes at given temperatures.” | “The simulations show that this step originates from a mechanism wherein the CO2 gas molecule is cooperatively and reversibly inserted into metal–amine bond followed by formation of ammonium carbamate chain structure.”

Evidence location: page 2 (Introduction); pages 3-5 (Results)

## Links

- Source: [[sources/src_20dae1036b]]