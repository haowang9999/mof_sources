---
title: "Cu(adci)-2 exhibits substantial low-pressure CO2 uptake (2.01 mmol g−1 at 298 K and 15 kPa) with a l ...[TRUNCATED]... "
type: mechanism
tags: [co2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_83cde498f9]
confidence: high
---


# Cu(adci)-2 exhibits substantial low-pressure CO2 uptake (2.01 mmol g−1 at 298 K and 15 kPa) with a l ...[TRUNCATED]... 

## Mechanism claim

Cu(adci)-2 exhibits substantial low-pressure CO2 uptake (2.01 mmol g−1 at 298 K and 15 kPa) with a low experimental zero-coverage isosteric heat of adsorption (Qst ≈ 27.5–27.6 kJ mol−1), indicating physisorptive binding favorable for lower regeneration energy.

## Applicability

- Task: `co2`
- Mechanism type: `adsorption_energetics`
- Condition scope: `{"gas": "CO2", "temperature_K": 298, "pressure_bar": 0.15, "material_family": "Cu(adci)-2", "method": "experiment (gas adsorption; virial / LF analysis)"}`

## Positive design features

- CO2 uptake 2.01 mmol g−1 at 298 K, 15 kPa
- Qst ≈ 27.5–27.6 kJ mol−1 (zero-loading, experimental)

## Negative design features

- Not specified

## Agent design implication

Use aromatic amine functionalization (rather than alkylamine chemisorbers) to keep Qst in a moderate physisorption range (≈25–50 kJ mol−1) to balance uptake and lower regeneration energy.

## Evidence

> Page 2: "The CO2 uptake levels at 15 kPa were ... 2.01 mmol g−1 at 298 K... The Qst values for CO2 and N2 were calculated to be 27.5 and 24.2 kJ mol−1, respectively, at zero loading according to a virial analysis."; page 1 intro: "aromatic amines... physisorb CO2 with Qst values generally in the range of 25 to 50 kJ mol−1."

Evidence location: page 2 (gas sorption results); page 1 (intro)

## Links

- Source: [[sources/src_83cde498f9]]