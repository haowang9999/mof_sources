---
title: "Electrostatic interactions were explicitly treated by computing MOF atomic charges using the DDEC me ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_fc58db74fa]
confidence: high
---


# Electrostatic interactions were explicitly treated by computing MOF atomic charges using the DDEC me ...[TRUNCATED]... 

## Mechanism claim

Electrostatic interactions were explicitly treated by computing MOF atomic charges using the DDEC method to better capture host–guest Coulombic contributions, important for polar or polarizable guests.

## Applicability

- Task: `pld`
- Mechanism type: `electrostatic interactions (host-guest Coulombic effects)`
- Condition scope: `{"gas": "polar or partially charged adsorbates (e.g., H2O, CH3I partial charges considered)", "temperature_K": null, "pressure_bar": null, "material_family": "MOFs", "method": "GCMC simulation with assigned partial charges (DDEC)"}`

## Positive design features

- use of DDEC for atomic charges to capture electrostatics

## Negative design features

- Not specified

## Agent design implication

Include chemically meaningful atomic charges (e.g., DDEC) when modelling adsorption of polar or polarizable guests so electrostatic host–guest contributions to binding are captured.

## Evidence

> “to accurately address the electrostatic interaction, atomic charges of MOFs were computed using the high-quality density-derived electrostatic charges (DDECs) method.”

Evidence location: STAR+METHODS, METHOD DETAILS (page ~11)

## Links

- Source: [[sources/src_fc58db74fa]]