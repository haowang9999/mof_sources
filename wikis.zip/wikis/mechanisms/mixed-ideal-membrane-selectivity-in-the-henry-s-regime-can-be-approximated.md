---
title: "Ideal membrane selectivity in the Henry’s regime can be approximated as (Kha/Khb) * exp(-(ΔEdiff_a - ...[TRUNCATED]... "
type: mechanism
tags: [mixed, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_97052fb350]
confidence: high
---


# Ideal membrane selectivity in the Henry’s regime can be approximated as (Kha/Khb) * exp(-(ΔEdiff_a - ...[TRUNCATED]... 

## Mechanism claim

Ideal membrane selectivity in the Henry’s regime can be approximated as (Kha/Khb) * exp(-(ΔEdiff_a - ΔEdiff_b)/RT) * sqrt(Mrb/Mra), assuming transition-state expressions for diffusivities and similar pre-exponential factors; if diffusion energy barriers are negligible, diffusivity ratios reduce to Knudsen diffusion.

## Applicability

- Task: `mixed`
- Mechanism type: `membrane selectivity model (Henry's regime)`
- Condition scope: `{"gas": "any pair of adsorbates where KH and ΔEdiff can be defined", "temperature_K": null, "pressure_bar": "low (Henry's regime)", "material_family": "MOFs", "method": "analytic approximation / simulation"}`

## Positive design features

- connects adsorption affinity and diffusion barriers to predict selectivity
- provides a simple form usable for screening

## Negative design features

- relies on transition-state theory and assumption of similar pre-exponential factors
- accuracy reduced if pre-exponentials differ or if multiple transport mechanisms dominate

## Agent design implication

To improve membrane selectivity in the Henry regime, target materials that both (a) increase KH for the preferred species and (b) produce a relatively larger ΔEdiff for the unwanted species; if ΔEdiff differences are negligible, expect selectivity governed by Knudsen diffusion instead.

## Evidence

> The ideal selectivity of a material in the Henry’s regime for a pair of adsorbates can be estimated using... Sa/b = (Kha/Khb) * exp(-(∆Ediff_a)/(RT)) / exp(-(∆Ediff_b)/(RT)) * sqrt(Mrb/Mra). ... If the energy barriers for diffusion are negligible, the ratio of diffusivities used in this expression becomes that of Knudsen diffusion.

Evidence location: page 4, equations (2) and surrounding text, section 2.2

## Links

- Source: [[sources/src_97052fb350]]