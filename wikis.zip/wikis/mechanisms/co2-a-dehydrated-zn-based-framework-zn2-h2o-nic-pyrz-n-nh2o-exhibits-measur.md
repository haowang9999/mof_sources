---
title: "A dehydrated Zn-based framework [Zn2(H2O)(nic)(pyrz)]n·nH2O exhibits measurable CO2 uptake (reported ...[TRUNCATED]... "
type: mechanism
tags: [co2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_a034d4944a]
confidence: medium
---


# A dehydrated Zn-based framework [Zn2(H2O)(nic)(pyrz)]n·nH2O exhibits measurable CO2 uptake (reported ...[TRUNCATED]... 

## Mechanism claim

A dehydrated Zn-based framework [Zn2(H2O)(nic)(pyrz)]n·nH2O exhibits measurable CO2 uptake (reported: 2.2 and 5.7 wt% at 0.15 bar, and 12.2 wt% at 298 K) and shows CO2/CH4 selectivity of ~22.4 when cooled to 273 K; at low partial pressures its CO2 uptake was reported comparable to H2, N2, and CH4.

## Applicability

- Task: `co2`
- Mechanism type: `physisorption / experimental uptake and thermodynamic selectivity`
- Condition scope: `{"gas": "CO2 (and comparisons to H2, N2, CH4)", "temperature_K": 298, "pressure_bar": 0.15, "material_family": "Zn-based porous framework [Zn2(H2O)(nic)(pyrz)]n·nH2O (dehydrated)", "method": "experiment (reported in review)"}`

## Positive design features

- demonstrates nonzero CO2 uptake at low pressure and higher uptake at ambient temperature
- high CO2/CH4 selectivity at reduced temperature (273 K)

## Negative design features

- some comparisons (to H2, N2, CH4) are qualitative; selectivity/uptake may change with pressure, humidity, or gas mixtures

## Agent design implication

Zn-based mixed-ligand frameworks can achieve appreciable CO2 uptake; cooling such materials can increase CO2/CH4 selectivity, but practical process constraints and humidity effects should be considered.

## Evidence

> The dehydrated framework revealed a carbon-dioxide absorption of 2.2 and 5.7 wt% at 0.15 bar and 12.2 wt% at 298 K. (page 14) || The selectivity of CO2 with regard to CH4 was determined to be 22.4 when cooled to 273 K. (page 14) || At low partial pressures, this is comparable to H2, N2, and CH4. (page 14)

Evidence location: page 14

## Links

- Source: [[sources/src_a034d4944a]]