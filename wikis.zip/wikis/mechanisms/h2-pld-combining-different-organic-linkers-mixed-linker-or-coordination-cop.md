---
title: "Combining different organic linkers (mixed-linker or coordination copolymerization) can create novel ...[TRUNCATED]... "
type: mechanism
tags: [h2|pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_ff1b0c9d63]
confidence: high
---


# Combining different organic linkers (mixed-linker or coordination copolymerization) can create novel ...[TRUNCATED]... 

## Mechanism claim

Combining different organic linkers (mixed-linker or coordination copolymerization) can create novel topologies with very high surface areas and substantially improved H2 uptake at elevated pressures (examples: UMCM-2, MOF-210).

## Applicability

- Task: `h2|pld`
- Mechanism type: `mixed-linker topology engineering → increased surface area and adsorption`
- Condition scope: `{"gas": "H2", "temperature_K": 77, "pressure_bar": [1, 46, 56, 70, 80], "material_family": "mixed-linker MOFs (UMCM-2, MOF-205, MOF-210)", "method": "experiment"}`

## Positive design features

- mixed linker frameworks with very high BET/Langmuir surface area
- high H2 uptake at high pressures

## Negative design features

- relatively low low-pressure uptake in some large-pore materials

## Agent design implication

Use mixed-linker synthesis to access frameworks with exceptional surface areas/topologies for high-pressure H2 storage applications; expect big gains at elevated pressure but verify low-pressure behavior.

## Evidence

> A combination of two types of organic linker within the same MOF structure could be another approach to increase the pore characteristics of MOFs... UMCM-2 ... MOF-210 ... For MOF-210, the hydrogen adsorption capacity at 77 K was 8.6 wt% at 56 bar of H2 and 17.6 wt% at 80 bar of H2.

Evidence location: section 4.1.3 (pages 14-15)

## Links

- Source: [[sources/src_ff1b0c9d63]]