---
title: "Platinum-group metal nanoparticles embedded in MOFs can form stable hydrides leading to high first-c ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_ff1b0c9d63]
confidence: high
---


# Platinum-group metal nanoparticles embedded in MOFs can form stable hydrides leading to high first-c ...[TRUNCATED]... 

## Mechanism claim

Platinum-group metal nanoparticles embedded in MOFs can form stable hydrides leading to high first-cycle H2 uptake but poor reversibility (example: Pt@MOF-177 showed large drop from first to second cycle), so caution is warranted for reversible storage applications.

## Applicability

- Task: `h2`
- Mechanism type: `irreversible chemisorption / metal hydride formation reducing reversibility`
- Condition scope: `{"gas": "H2", "temperature_K": 298, "pressure_bar": 144, "material_family": "Pt@MOF-177", "method": "experiment"}`

## Positive design features

- Not specified

## Negative design features

- high initial uptake but loss in subsequent cycles due to hydrogenation of metal NPs

## Agent design implication

Avoid platinum-group metals for NP incorporation when reversible H2 storage is required; prefer transition metals that do not form stable hydrides under operating conditions.

## Evidence

> The encapsulated Pt NPs in MOF-177 showed H2 adsorption of 2.5 wt% at 298 K and 144 bar of H2 in the first adsorption cycle, but only 0.5 wt% in the second cycle, which was similar to the value of pure MOF-177. Therefore, to avoid direct hydrogenation of the metal NPs incorporated in MOFs, the platinum group metals should be changed to transition metals to ensure they do not react readily with atomic hydrogen.

Evidence location: page 22, Section 4.3.1

## Links

- Source: [[sources/src_ff1b0c9d63]]