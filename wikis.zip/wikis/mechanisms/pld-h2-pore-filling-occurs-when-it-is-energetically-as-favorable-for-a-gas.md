---
title: "Pore filling occurs when it is energetically as favorable for a gas molecule to reside between monol ...[TRUNCATED]... "
type: mechanism
tags: [pld|h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_ff1b0c9d63]
confidence: high
---


# Pore filling occurs when it is energetically as favorable for a gas molecule to reside between monol ...[TRUNCATED]... 

## Mechanism claim

Pore filling occurs when it is energetically as favorable for a gas molecule to reside between monolayers in the pore center as it is to complete monolayer coverage; this underlies cooperative pore-filling in supermicropores.

## Applicability

- Task: `pld|h2`
- Mechanism type: `thermodynamic description of pore filling / cooperative adsorption`
- Condition scope: `{"gas": "general (applied to small molecules including H2)", "temperature_K": null, "pressure_bar": null, "material_family": "MOFs (supermicropores)", "method": "review / conceptual"}`

## Positive design features

- explains low-p/p0 pore filling events in supermicropores

## Negative design features

- Not specified

## Agent design implication

When designing pores in the 7–20 Å range, anticipate cooperative pore-filling behavior; pore geometry and chemical environment should be tuned to favor energetically comparable adsorption in pore center and surface monolayers.

## Evidence

> Pore filling occurs when it is energetically as favorable for a gas molecule to exist between the monolayers of the gas in the center of the pore as it is to complete the monolayer coverage.

Evidence location: Section 2.2 Surface Area (page 3)

## Links

- Source: [[sources/src_ff1b0c9d63]]