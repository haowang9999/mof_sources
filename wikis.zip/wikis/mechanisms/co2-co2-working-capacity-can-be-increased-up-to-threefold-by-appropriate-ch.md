---
title: "CO2 working capacity can be increased up to threefold by appropriate choice of side-chain functional ...[TRUNCATED]... "
type: mechanism
tags: [co2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_a318a71841]
confidence: high
---


# CO2 working capacity can be increased up to threefold by appropriate choice of side-chain functional ...[TRUNCATED]... 

## Mechanism claim

CO2 working capacity can be increased up to threefold by appropriate choice of side-chain functionalization while preserving gating behavior in this materials family.

## Applicability

- Task: `co2`
- Mechanism type: `capacity modulation via chemical functionalization`
- Condition scope: `{"gas": "CO2", "temperature_K": null, "pressure_bar": null, "material_family": "the studied rigid honeycomb-like MOF series", "method": "experimental (adsorption/breakthrough)"}`

## Positive design features

- functionalization choice -> up to ~3× CO2 working capacity increase

## Negative design features

- Not specified

## Agent design implication

Screen linker side-chain chemistries to boost CO2 working capacity (possible up to ~3×) and validate gating remains functional via breakthrough testing.

## Evidence

> it is notable that the CO2 working capacity can be tripled by means of functionalization choice without sacrificing the gating behavior

Evidence location: page 8 (end of paragraph before Conclusions)

## Links

- Source: [[sources/src_a318a71841]]