---
title: "Classical simulations used in this work omit nuclear quantum dispersion effects; prior path-integral ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_532b708453]
confidence: high
---


# Classical simulations used in this work omit nuclear quantum dispersion effects; prior path-integral ...[TRUNCATED]... 

## Mechanism claim

Classical simulations used in this work omit nuclear quantum dispersion effects; prior path-integral Monte Carlo (PIMC) work showed decreased sorption of ~10-15% relative to classical simulations, so classical estimates here may modestly overestimate absolute sorption.

## Applicability

- Task: `h2`
- Mechanism type: `modeling caveat (nuclear quantum effects)`
- Condition scope: `{"gas": "H2", "temperature_K": "low (relevant to studied 78 K)", "pressure_bar": 1.0, "material_family": "MOFs (general)", "method": "comparison between classical Monte Carlo and PIMC (literature)"}`

## Positive design features

- Not specified

## Negative design features

- classical model likely overestimates sorption by a modest amount (10-15%) compared to PIMC which includes nuclear quantum dispersion

## Agent design implication

When making quantitative predictions of absolute H2 uptake at low temperature, include nuclear quantum dispersion (e.g., PIMC) or apply a correction factor; but use the qualitative role of polarization identified here as robust.

## Evidence

> Note, a recent study modeling hydrogen sorption in MOF materials has shown that, under the relatively low-temperature conditions studied here, a quantum statistical mechanical description of the hydrogen structure is required to obtain quantitative accuracy. The earlier work included nuclear quantum dispersion effects via ... PIMC, but did not include electronic induction. The results showed a decreased sorption of 10-15% relative to the purely classical simulations... Given that it is computationally prohibitive to perform PIMC simulations including polarization, the present study will focus on the role of electronic polarization within a classical model. Given the prior work, our estimates of hydrogen sorption strength may be a slight overestimate...

Evidence location: page 3

## Links

- Source: [[sources/src_532b708453]]