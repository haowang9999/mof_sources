---
title: "NbOFFIVE-1-Ni is hydrolytically robust: Crystallinity retained between 25–400 °C (VT-PXRD), stable u ...[TRUNCATED]... "
type: mechanism
tags: [co2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_36df794947]
confidence: high
---


# NbOFFIVE-1-Ni is hydrolytically robust: Crystallinity retained between 25–400 °C (VT-PXRD), stable u ...[TRUNCATED]... 

## Mechanism claim

NbOFFIVE-1-Ni is hydrolytically robust: Crystallinity retained between 25–400 °C (VT-PXRD), stable under variable-humidity PXRD and water adsorption; CO2 isotherms unchanged after 6 months immersion in liquid water.

## Applicability

- Task: `co2`
- Mechanism type: `material stability enabling practical CO2 adsorption under humid/wet conditions`
- Condition scope: `{"gas": "water exposure; CO2 adsorption measured before/after", "temperature_K": null, "pressure_bar": null, "material_family": "NbOFFIVE-1-Ni", "method": "experiment (TGA, VT-PXRD, in situ humidity PXRD, water adsorption isotherms)"}`

## Positive design features

- retained crystallinity 25–400 °C
- CO2 isotherms unchanged after 6 months in liquid water
- good H2S tolerance (PXRD preserved after H2S exposure)

## Negative design features

- Not specified

## Agent design implication

Pillar choice and metal–ligand coordination (NbOF5 pillars and Ni nodes) can yield fluorinated MOFs that combine high trace-CO2 affinity with exceptional hydrolytic and some chemical (H2S) tolerance, enabling use in humid practical conditions.

## Evidence

> High thermal stability ... established that the material retained its crystallinity over the explored temperature range. Markedly, the hydrolytic stability of the material was confirmed by performing in situ variable-humidity PXRD and multiple water adsorption isotherms on NbOFFIVE-1-Ni. The exceptional water stability was further confirmed by the conformity of the resultant CO2 isotherms before and after immersion of material in liquid water for 6 months. Moreover, NbOFFIVE-1-Ni showed excellent tolerance to hydrogen sulfide ... as evidenced by the preservation of the material PXRD pattern after exposure to H2S and by performing H2S adsorption isotherms.

Evidence location: page 3

## Links

- Source: [[sources/src_36df794947]]