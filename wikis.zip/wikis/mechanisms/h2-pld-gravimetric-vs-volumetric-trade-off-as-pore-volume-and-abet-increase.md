---
title: "Gravimetric vs volumetric trade-off: as pore volume and ABET increase, particle/bulk density usually ...[TRUNCATED]... "
type: mechanism
tags: [h2|pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_fa8cccd644]
confidence: high
---


# Gravimetric vs volumetric trade-off: as pore volume and ABET increase, particle/bulk density usually ...[TRUNCATED]... 

## Mechanism claim

Gravimetric vs volumetric trade-off: as pore volume and ABET increase, particle/bulk density usually decreases; highest gravimetric uptakes (reported up to ~12 wt%) do not necessarily give highest volumetric uptakes (volumetric capacities reported to peak around ~40 kg H2 m−3).

## Applicability

- Task: `h2|pld`
- Mechanism type: `tradeoff / volumetric vs gravimetric`
- Condition scope: `{"gas": "H2", "temperature_K": 77, "pressure_bar": null, "material_family": "MOFs", "method": "review / comparative data"}`

## Positive design features

- high gravimetric (absolute) H2 capacity

## Negative design features

- reduced bulk density
- lower volumetric H2 capacity despite high gravimetric uptake

## Agent design implication

Balance pore volume and framework/bulk density for target application: to maximize volumetric H2 storage, avoid sacrificing packing density for extreme surface area; consider densification, interpenetration, or hybridization strategies.

## Evidence

> The increase in pore volume also results in a reduction of particle density. Indeed, while absolute gravimetric H2 capacities reach values as high as 120 mg H2 per g (12 wt%), volumetric H2 capacities peak at values of around 40 kg H2 per m3. Thus, MOFs with high ABET and high absolute H2 uptake on a gravimetric basis are not necessarily those with the highest H2 uptake on a volumetric basis.

Evidence location: page 2 (BET, pore volume and volumetric discussion) || page 6, section 3.1 (Fig. 3d referenced)

## Links

- Source: [[sources/src_fa8cccd644]]