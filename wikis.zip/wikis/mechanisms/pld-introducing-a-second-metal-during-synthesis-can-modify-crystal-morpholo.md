---
title: "Introducing a second metal during synthesis can modify crystal morphology (more small-particle cryst ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_340141308b]
confidence: medium
---


# Introducing a second metal during synthesis can modify crystal morphology (more small-particle cryst ...[TRUNCATED]... 

## Mechanism claim

Introducing a second metal during synthesis can modify crystal morphology (more small-particle crystals), reduce particle size, broaden XRD diffraction peaks (indicative of smaller crystal size and subtle lattice changes), and EDS shows even elemental distribution — changes associated with a more developed/altered pore structure.

## Applicability

- Task: `pld`
- Mechanism type: `morphology / crystallography influence on pore structure`
- Condition scope: `{"gas": "not gas-specific", "temperature_K": null, "pressure_bar": null, "material_family": "MxM1−x(BDC)TED0.5 (M = Zn, Cu, Co, Ni)", "method": "experiment (SEM, XRD, EDS)"}`

## Positive design features

- competitive coordination between two metals leading to smaller-particle crystals
- EDS mapping shows even distribution of both metals across crystals

## Negative design features

- morphology can become less regular / more disordered

## Agent design implication

Co-incorporation of a second metal is a practical route to alter pore structure in M(BDC)TED0.5; expect smaller particle sizes, altered exposed planes (XRD broadening/shifts), and changes in porosity that should be correlated with adsorption measurements.

## Evidence

> In terms of the Cu-based bimetal MOFs, we can find that more small-particle crystals appear in bimetallic MOFs due to the competitive coordination of the two metals... according to the analysis results of energy-dispersive spectroscopy (EDS) mapping ... both metals in all bimetal MOFs are evenly distributed in the entire MOF structure... XRD analysis results show that the crystal structures of M(BDC)TED0.5 synthesized with different metal ions are similar... the diffraction peak appears to be broadened, which may be attributed to the reduction of the crystal size.

Evidence location: pages 2-4 (SEM, EDS, XRD discussion)

## Links

- Source: [[sources/src_340141308b]]