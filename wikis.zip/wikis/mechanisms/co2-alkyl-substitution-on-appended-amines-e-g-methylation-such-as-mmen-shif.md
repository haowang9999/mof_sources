---
title: "Alkyl substitution on appended amines (e.g., methylation such as mmen) shifts the cooperative adsorp ...[TRUNCATED]... "
type: mechanism
tags: [co2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_20dae1036b]
confidence: medium
---


# Alkyl substitution on appended amines (e.g., methylation such as mmen) shifts the cooperative adsorp ...[TRUNCATED]... 

## Mechanism claim

Alkyl substitution on appended amines (e.g., methylation such as mmen) shifts the cooperative adsorption step pressure and can weaken metal–carbamate interactions, thereby tuning both the step position and regenerability (easier desorption).

## Applicability

- Task: `co2`
- Mechanism type: `chemical substitution altering cooperativity and binding strength (steric/electronic effects)`
- Condition scope: `{"gas": "CO2", "temperature_K": null, "pressure_bar": null, "material_family": "larger-pore M/DOBPDC and MOF-74 materials functionalized with alkyl-substituted amines (e.g., mmen)", "method": "simulation and literature-cited experimental observations"}`

## Positive design features

- alkyl substitution provides a knob to tune the pressure at which cooperative uptake occurs and to moderate binding strength for better desorption
- methyl groups in mmen were specifically noted to help facile desorption by weakening Mg–carbamate interactions

## Negative design features

- over-substitution may inhibit chain formation or reduce working capacity due to steric effects; may also affect hydrophobicity/humidity response

## Agent design implication

Use alkyl substitution (including small substituents like methyl) to shift the cooperative adsorption step and/or reduce regeneration energy, but simulate or test the exact substitution to ensure cooperative chain formation and acceptable capacity remain.

## Evidence

> “In addition, multiple alkyl groups bonded to the amino group yield a shift in the step-like adsorption isotherms in the larger pore structures, at a given temperature.” | “mmen-Mg/DOBPDC, in which the methyl groups help in the facile desorption by weakening the Mg–carbamate interaction.”

Evidence location: page 1 (Abstract); page 7 (Figure 6 discussion)

## Links

- Source: [[sources/src_20dae1036b]]