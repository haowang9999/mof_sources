---
title: "NbOFFIVE-1-Ni (a fluorinated pcu-MOF) exhibits superior physisorptive uptake at 400 ppm CO2 and 298  ...[TRUNCATED]... "
type: mechanism
tags: [co2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_36df794947]
confidence: high
---


# NbOFFIVE-1-Ni (a fluorinated pcu-MOF) exhibits superior physisorptive uptake at 400 ppm CO2 and 298  ...[TRUNCATED]... 

## Mechanism claim

NbOFFIVE-1-Ni (a fluorinated pcu-MOF) exhibits superior physisorptive uptake at 400 ppm CO2 and 298 K (1.3 mmol/g; 51.4 cm3 (STP) cm−3) compared to previously reported physical adsorbents (e.g., SIFSIX-3-Cu: 44.6 cm3 cm−3), while retaining a moderate regeneration energy (~54 kJ/mol).

## Applicability

- Task: `co2`
- Mechanism type: `physisorption driven by optimized pore size and fluorine-based adsorption sites`
- Condition scope: `{"gas": "CO2", "temperature_K": 298, "pressure_bar": null, "material_family": "NbOFFIVE-1-Ni (fluorinated MOF)", "method": "experiment"}`

## Positive design features

- high volumetric and gravimetric uptake at 400 ppm CO2
- moderate desorption/regeneration energy (54 kJ/mol)
- physisorption-based (reversible) adsorption behavior

## Negative design features

- Not specified

## Agent design implication

Using fluorinated, contracted channels (as in NbOFFIVE-1-Ni) can achieve the highest reported physisorptive uptake at ambient temperature for trace CO2, with regeneration energies substantially below those of typical chemical sorbents.

## Evidence

> NbOFFIVE-1-Ni exhibits the highest CO2 gravimetric and volumetric uptake (ca. 1.3 mmol/g and 51.4 cm3 (STP) cm−3) for a physical adsorbent at 400 ppm of CO2 and 298 K. ... NbOFFIVE-1-Ni adsorbs a 51.4 cm3/cm3 (1.3 mmol/g) of CO2 at 400 ppm and 298 K as compared to 44.6 cm3/cm3 for the SIFSIX-3-Cu ... NbOFFIVE-1-Ni offers the complete CO2 desorption at 328 K under vacuum with an associated moderate energy input of 54 kJ/mol.

Evidence location: page 1 (abstract) and page 4

## Links

- Source: [[sources/src_36df794947]]