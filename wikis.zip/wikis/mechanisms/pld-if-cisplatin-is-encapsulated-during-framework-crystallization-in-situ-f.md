---
title: "If cisplatin is encapsulated during framework crystallization (in situ), frameworks with pore window ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_8ce39338bc]
confidence: medium
---


# If cisplatin is encapsulated during framework crystallization (in situ), frameworks with pore window ...[TRUNCATED]... 

## Mechanism claim

If cisplatin is encapsulated during framework crystallization (in situ), frameworks with pore windows smaller than the drug (example: ZIF-11) can trap the drug such that release is governed by pH-triggered framework degradation rather than diffusion.

## Applicability

- Task: `pld`
- Mechanism type: `pore-window blocking leading to degradation-driven release`
- Condition scope: `{"gas": "", "temperature_K": null, "pressure_bar": null, "material_family": "ZIFs (example: ZIF-11)", "method": "simulation-based screening context; contextual reference to pH-sensitive degradation"}`

## Positive design features

- very small pore windows prevent diffusive escape after in situ encapsulation
- pH-sensitive degradation can trigger release in acidic environments

## Negative design features

- such trapping requires loading during crystallization and cannot be achieved by post-synthesis soaking

## Agent design implication

When in situ encapsulation is feasible, selecting frameworks with pore windows smaller than the guest can enable depot-style retention until triggered (e.g., pH) release.

## Evidence

> If it is possible to load cisplatin during crystallization, ZIF-11 would outcompete other MOFs screened as cisplatin cannot pass through its pore windows; therefore, release rates would be purely driven by the pH triggered framework degradation.

Evidence location: abstract / page 2; pages 12-13

## Links

- Source: [[sources/src_8ce39338bc]]