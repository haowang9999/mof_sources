---
title: "Adsorption site preference differs by species: I2 and CH3I preferentially occupy the center of the p ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_fc58db74fa]
confidence: medium
---


# Adsorption site preference differs by species: I2 and CH3I preferentially occupy the center of the p ...[TRUNCATED]... 

## Mechanism claim

Adsorption site preference differs by species: I2 and CH3I preferentially occupy the center of the pore channel (or slightly off-center), while H2O preferentially binds near Al clusters and framework backbones via hydrogen bonding; this spatial partitioning affects competitive uptake under humid conditions.

## Applicability

- Task: `pld`
- Mechanism type: `spatial adsorption site preference / binding-site chemistry`
- Condition scope: `{"gas": "I2, CH3I, H2O, N2, O2 (competitive adsorption)", "temperature_K": 423, "pressure_bar": 1, "material_family": "MIL-53-Al-CH3 (representative functionalized MIL-53-Al)", "method": "GCMC simulations for density plots and DFT binding-energy calculations"}`

## Positive design features

- center of pore channels provides larger space to accommodate larger molecules (I2, CH3I)
- methyl functionalization enhances adsorption of I2 and CH3I (DFT supports higher binding energies)

## Negative design features

- H2O binds strongly to Al clusters (DFT binding energy 40.52 kJ/mol) and to hydroxyl groups via hydrogen bonding, potentially competing with framework sites
- smaller gases (N2, O2) can occupy sites near Al clusters, benzene rings, and methyl groups

## Agent design implication

Design pore channels with central cavities favorable to large iodine species while controlling hydrophilic sites (e.g., Al-coordinated hydroxyls) to limit water binding at critical adsorption positions; consider functional groups that steer large adsorbates to channel center while keeping water at less competitive locations.

## Evidence

> “It could be observed that the I2 and CH3I molecules were primarily concentrated near the center of pore channels, whereas the H2O molecules were mainly located near the backbones of the framework. ... DFT calculations ... The optimal adsorption positions for I2 (65.90 kJ/mol) and CH3I (47.86 kJ/mol) were slightly off-center from the channel; ... the adsorption situations for H2O were complex: Al clusters were the optimal adsorption sites with the highest binding energy of 40.52 kJ/mol, followed by the methyl (34.16 kJ/mol), the benzene ring (23.25 kJ/mol), and the center of the pore channel (12.45 kJ/mol). Importantly, the hydroxyl functional groups connected to Al clusters played a significant role in hydrogen bonding interactions to achieve a high binding energy.”

Evidence location: pages 6-8

## Links

- Source: [[sources/src_fc58db74fa]]