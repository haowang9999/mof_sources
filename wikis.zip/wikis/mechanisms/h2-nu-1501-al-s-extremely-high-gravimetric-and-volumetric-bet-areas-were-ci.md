---
title: "NU-1501-Al's extremely high gravimetric and volumetric BET areas were cited as main reasons for its  ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_b1552d4a9d]
confidence: high
---


# NU-1501-Al's extremely high gravimetric and volumetric BET areas were cited as main reasons for its  ...[TRUNCATED]... 

## Mechanism claim

NU-1501-Al's extremely high gravimetric and volumetric BET areas were cited as main reasons for its reported high hydrogen deliverable capacity when using a combined temperature/pressure swing (77 K & 100 bar -> 160 K & 5 bar).

## Applicability

- Task: `h2`
- Mechanism type: `combined structural and operational strategy (T/P swing)`
- Condition scope: `{"gas": "H2", "temperature_K": "77 -> 160 (combined change)", "pressure_bar": "100 -> 5 (combined change)", "material_family": "NU-1501-Al (ultramicroporous MOF)", "method": "experiment (reported performance)"}`

## Positive design features

- extremely high gravimetric and volumetric surface areas correlate with high delivered capacity under T/P swing

## Negative design features

- requires non-ambient (cryogenic + pressure) operation and T/P cycling to realize reported deliverable capacities

## Agent design implication

To reach very high deliverable H2 capacities, pursue ultrahigh surface area and volumetric metrics and consider temperature/pressure-swing operation rather than relying on single-condition ambient storage.

## Evidence

> The ultramicroporous MOF, NU-1501-Al, exhibits high values for both gravimetric and volumetric BET areas (7310 m2·g−1 and 2060 m2·cm−3, respectively). These were considered the main reasons for the high value of hydrogen storage capacity (14.0 wt% and 46.2 g·dm−3) under a combined T and P(H2) change from 77 K and 100 bar to 160 K and 5 bar.

Evidence location: page 4

## Links

- Source: [[sources/src_b1552d4a9d]]