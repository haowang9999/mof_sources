---
title: "Pore-size dependence: nanopores <1.5 nm are most efficient for H2 storage across pressures, while po ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_fa8cccd644]
confidence: medium
---


# Pore-size dependence: nanopores <1.5 nm are most efficient for H2 storage across pressures, while po ...[TRUNCATED]... 

## Mechanism claim

Pore-size dependence: nanopores <1.5 nm are most efficient for H2 storage across pressures, while pores of 1.5–2.5 nm substantially enhance high-pressure capacity.

## Applicability

- Task: `pld`
- Mechanism type: `pore-size dependent uptake`
- Condition scope: `{"gas": "H2", "temperature_K": null, "pressure_bar": "general (nanopores <1.5 nm); high pressures (1.5–2.5 nm beneficial)", "material_family": "MOFs (general)", "method": "review"}`

## Positive design features

- pore sizes <1.5 nm efficient across pressures
- 1.5–2.5 nm pores aid high-pressure storage

## Negative design features

- Not specified

## Agent design implication

When tailoring PSD for H2, prioritize nanopores <1.5 nm for broad efficiency and incorporate controlled fractions of 1.5–2.5 nm pores if targeting high-pressure charging.

## Evidence

> The presence of 1.5 to 2.5 nm pores has been shown to significantly enhance H2 storage capacity at high pressures. However, nanopores smaller than 1.5 nm are found to be the most efficient for H2 storage at all pressure levels.

Evidence location: page 6, section 3.1

## Links

- Source: [[sources/src_fa8cccd644]]