---
title: "Calculated integral enthalpies of adsorption for H2 in soc-MOF (polarizable simulations) are -10.645 ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_532b708453]
confidence: medium
---


# Calculated integral enthalpies of adsorption for H2 in soc-MOF (polarizable simulations) are -10.645 ...[TRUNCATED]... 

## Mechanism claim

Calculated integral enthalpies of adsorption for H2 in soc-MOF (polarizable simulations) are -10.645 ± 0.188 kJ/mol at saturation (113 H2 per unit cell) and -14.354 ± 1.685 kJ/mol at the zero-loading limit; polarization accounts for ~23% of total potential energy at saturation and ~27% when unsaturated. These computed enthalpies appear larger than some experimental isosteric heat measurements (~6.5 kJ/mol), a discrepancy noted and discussed by the authors.

## Applicability

- Task: `h2`
- Mechanism type: `thermodynamics (enthalpy contributions)`
- Condition scope: `{"gas": "H2", "temperature_K": 78, "pressure_bar": null, "material_family": "soc-MOF", "method": "simulation (polarizable potential)"}`

## Positive design features

- substantial polarization energy fraction (~23–27%)
- strong attractive interactions retained at higher loadings

## Negative design features

- computed enthalpies appear larger than some experimental isosteric heat measurements (~6.5 kJ/mol)

## Agent design implication

Expect polarization to contribute a non-negligible fraction (roughly a quarter) of adsorption potential energy; optimizing polarization sources (open metal sites, charged linkers) can increase adsorption enthalpy, but validate computed absolute values against experiment.

## Evidence

> ∆Hsat_a was found to be -10.645 ( 0.188 kJ mol-1, while the unsaturated state yielded ∆Hunsat_a of -14.354 ( 1.685 kJ mol-1; ... Polarization contributed 23% of the total potential energy at saturation and 27% when unsaturated. These enthalpies appear large compared to the experimental measurements that give a relatively constant isosteric heat of sorption of about 6.5 kJ mol-1.

Evidence location: page 9 (enthalpy results paragraph and IV. Conclusions)

## Links

- Source: [[sources/src_532b708453]]