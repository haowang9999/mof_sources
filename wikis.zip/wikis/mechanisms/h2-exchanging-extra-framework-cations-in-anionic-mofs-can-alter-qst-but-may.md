---
title: "Exchanging extra-framework cations in anionic MOFs can alter Qst but may not substantially change H2 ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_ff1b0c9d63]
confidence: medium
---


# Exchanging extra-framework cations in anionic MOFs can alter Qst but may not substantially change H2 ...[TRUNCATED]... 

## Mechanism claim

Exchanging extra-framework cations in anionic MOFs can alter Qst but may not substantially change H2 uptake under some conditions (example Mn3[(Mn4Cl)3(BTT)8]2 retained ~2.00–2.29 wt% at 77 K, 1.2 bar across cation variants).

## Applicability

- Task: `h2`
- Mechanism type: `electrostatic field from cations affecting adsorption energetics but not necessarily capacity`
- Condition scope: `{"gas": "H2", "temperature_K": 77, "pressure_bar": 1.2, "material_family": "anionic MOFs capable of cation exchange", "method": "experiment (ion exchange, adsorption isotherms)"}`

## Positive design features

- Qst variation observed after cation exchange

## Negative design features

- measured H2 capacity not substantially improved in the example

## Agent design implication

Cation exchange in anionic frameworks can tune Qst and electrostatic environment; however, do not assume capacity will increase—validate uptake experimentally under target conditions.

## Evidence

> In the Mn3[(Mn4Cl)3(BTT)8]2 ... framework, Mn2+ ions can be exchanged with Li+, Cu+, Fe2+, Co2+, Ni2+, Cu2+, or Zn2+ ions. The Qst values ... demonstrate a relatively large variation, but ... The values of hydrogen adsorption capacity measured at 77 K and 1.2 bar of H2 for the ion-exchange frameworks and the original Mn3[(Mn4Cl)3(BTT)8]2 were within 2.00–2.29 wt%.

Evidence location: page 19

## Links

- Source: [[sources/src_ff1b0c9d63]]