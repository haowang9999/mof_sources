---
title: "Metal nanoparticle size influences H2 uptake behavior: smaller Pt NPs in IRMOF-8 increased H2 adsorp ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_ff1b0c9d63]
confidence: medium
---


# Metal nanoparticle size influences H2 uptake behavior: smaller Pt NPs in IRMOF-8 increased H2 adsorp ...[TRUNCATED]... 

## Mechanism claim

Metal nanoparticle size influences H2 uptake behavior: smaller Pt NPs in IRMOF-8 increased H2 adsorption (sizes 2.2 nm > 3.9 nm > 9.1 nm); Pd NP size determines hydride vs solid-solution formation with size-dependent desorption energetics.

## Applicability

- Task: `h2`
- Mechanism type: `size-dependent adsorption/absorption and hydride formation`
- Condition scope: `{"gas": "H2", "temperature_K": null, "pressure_bar": null, "material_family": "Pt in IRMOF-8; Pd in MIL-101/MIL-100 examples", "method": "experiment"}`

## Positive design features

- smaller NPs (e.g., 2.2 nm Pt) gave higher adsorption in IRMOF-8
- Pd NPs 2–3 nm formed hydride phases whereas 1 nm formed solid solutions

## Negative design features

- Not specified

## Agent design implication

Control NP size relative to MOF pore geometry: smaller NPs may enhance uptake in some MOF hosts; very small Pd NPs may avoid bulk-like hydride formation, altering reversibility and desorption energetics.

## Evidence

> For Pt-modified IRMOF-8 prepared by CVD, the dependence of hydrogen adsorption capacity on the size of Pt NPs was indicated as Pt/IRMOF-8-1 > Pt/IRMOF-8-2 > Pt/IRMOF-8-3, where the incorporated Pt NPs had sizes of 2.2, 3.9, and 9.1 nm, respectively. ... It was experimentally confirmed that during H2 absorption Pd NPs with a size of 2–3 nm formed a hydride phase (as in the case of bulk Pd), whereas Pd NPs with a size of 1 nm created solid solutions under ambient conditions.

Evidence location: pages 22-23, Section 4.3.1

## Links

- Source: [[sources/src_ff1b0c9d63]]