---
title: "Encapsulation of guests with sizes matched to host pores can improve stability of guest species and  ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_fa8cccd644]
confidence: high
---


# Encapsulation of guests with sizes matched to host pores can improve stability of guest species and  ...[TRUNCATED]... 

## Mechanism claim

Encapsulation of guests with sizes matched to host pores can improve stability of guest species and the composite (example: perovskite QDs 1.5–2 nm in HKUST-1 improved stability at 70% RH).

## Applicability

- Task: `pld`
- Mechanism type: `pore-guest size matching for stability and protection`
- Condition scope: `{"gas": null, "temperature_K": null, "pressure_bar": null, "material_family": "HKUST-1 with encapsulated guests; general MOF hosts", "method": "post-synthetic encapsulation experiments"}`

## Positive design features

- pore-size matched encapsulation enhances guest stability under humidity

## Negative design features

- Not specified

## Agent design implication

Select guest sizes comparable to host pore dimensions to stabilize labile guests; verify encapsulation and environmental stability experimentally.

## Evidence

> Perovskite QDs of 1.5–2 nm matched the pore size of HKUST-1 and the resulting material improved its stability under 70% RH, whereas QDs alone decomposed.

Evidence location: Section 4.2 / page ~12

## Links

- Source: [[sources/src_fa8cccd644]]