---
title: "Analytic bounds based on simple circular pore-bottleneck models capture trends in calculated diffusi ...[TRUNCATED]... "
type: mechanism
tags: [pld|ch4|mixed, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_97052fb350]
confidence: medium
---


# Analytic bounds based on simple circular pore-bottleneck models capture trends in calculated diffusi ...[TRUNCATED]... 

## Mechanism claim

Analytic bounds based on simple circular pore-bottleneck models capture trends in calculated diffusion activation energies and predict that MOFs with PLD between ~2.2 and ~3.6 Å will produce significant diffusion activation energies for CH4 (useful for kinetic hindrance without complete impermeability).

## Applicability

- Task: `pld|ch4|mixed`
- Mechanism type: `approximate theoretical bounds linking PLD to activation energy`
- Condition scope: `{"gas": "CH4 (modeled as spherical Lennard-Jones particle)", "temperature_K": null, "pressure_bar": null, "material_family": "MOFs", "method": "analytical bounds calibrated to simulations"}`

## Positive design features

- simple geometric/energetic bounds reproduce observed trends

## Negative design features

- bounds are approximate and based on specific atom-count assumptions

## Agent design implication

Use the provided PLD-to-activation-energy bounds to pre-screen MOFs for desired ranges of diffusion barriers (for CH4, target PLD 2.2–3.6 Å for significant but potentially surmountable barriers).

## Evidence

> To define these bounds... For the lower (upper) bound it is assumed that the hypothetical bottleneck is defined by two C (four H) atoms... The lower value for this range was chosen to be the value where the lower bound for the diffusion activation energy was 100 kJ/mol... Applying this analysis for CH4 predicts that MOFs with pore-limiting diameters between 2.2 and 3.6 Å will define significant diffusion activation energies.

Evidence location: page 8-9

## Links

- Source: [[sources/src_97052fb350]]