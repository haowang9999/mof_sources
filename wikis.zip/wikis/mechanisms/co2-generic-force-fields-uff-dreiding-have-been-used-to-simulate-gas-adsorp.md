---
title: "Generic force fields (UFF, Dreiding) have been used to simulate gas adsorption in MOFs and generally ...[TRUNCATED]... "
type: mechanism
tags: [co2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_1fa85425f9]
confidence: medium
---


# Generic force fields (UFF, Dreiding) have been used to simulate gas adsorption in MOFs and generally ...[TRUNCATED]... 

## Mechanism claim

Generic force fields (UFF, Dreiding) have been used to simulate gas adsorption in MOFs and generally showed good agreement with experimentally measured gas uptake data, validating their use for MOF simulations; however, significant quantitative differences in CO2 uptake can occur between generic FFs and ab initio force fields for hMOFs.

## Applicability

- Task: `co2`
- Mechanism type: `simulation accuracy / model sensitivity`
- Condition scope: `{"gas": "CO2 (and other gases considered in uptake comparisons)", "temperature_K": null, "pressure_bar": null, "material_family": "MOFs and hMOFs", "method": "simulation (GCMC)"}`

## Positive design features

- generic FFs (UFF, Dreiding) enable large-scale screening and can reproduce experimental uptake trends

## Negative design features

- quantitative discrepancies between generic and ab initio force fields for CO2 uptake

## Agent design implication

Use generic FFs for initial high‑throughput screening to capture trends, but validate top candidates with higher‑accuracy (ab initio derived) force fields or experiment before final selection.

## Evidence

> "Generic FFs, Universal Force Field (Rappe et al., 1992), and Dreiding (Mayo et al., 1990) have been used for simulation of gas adsorption and diffusion in MOFs ... Molecular simulations employing either UFF or Dreiding showed good agreement with the experimentally measured gas uptake data of MOFs, validating the usage of generic FFs for MOFs (Colon and Snurr, 2014)." and "Significant quantitative differences between the CO2 uptakes predicted by the generic FF and the ab initio FF were reported." (page 4).

Evidence location: page 4 (Force Fields)

## Links

- Source: [[sources/src_1fa85425f9]]