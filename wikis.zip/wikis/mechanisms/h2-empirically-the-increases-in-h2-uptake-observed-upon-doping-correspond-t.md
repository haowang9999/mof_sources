---
title: "Empirically, the increases in H2 uptake observed upon doping correspond to as many as ~13 hydrogen m ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_b0ea8c70ab]
confidence: high
---


# Empirically, the increases in H2 uptake observed upon doping correspond to as many as ~13 hydrogen m ...[TRUNCATED]... 

## Mechanism claim

Empirically, the increases in H2 uptake observed upon doping correspond to as many as ~13 hydrogen molecules per added alkali cation under the cryogenic, 1 atm conditions studied.

## Applicability

- Task: `h2`
- Mechanism type: `stoichiometric uptake per dopant ion (empirical observation/calculation)`
- Condition scope: `{"gas": "H2", "temperature_K": "cryogenic (examples reported at 77 and 87 K)", "pressure_bar": 1.0, "material_family": "triply interwoven MOF doped with alkali metals", "method": "experiment (H2 isotherms and dopant quantification)"}`

## Positive design features

- high apparent number of H2 molecules associated per added cation (up to ~13) under these cryogenic conditions

## Negative design features

- Not specified

## Agent design implication

When quantifying the effect of alkali-metal doping, report uptake both per unit mass and per dopant ion; expect up to ~13 H2 molecules associated (empirically) with each added cation in these materials under cryogenic, 1 atm conditions, but interpret cautiously given cation inaccessibility inference.

## Evidence

> The increases correspond to the uptake of as many as 13 hydrogen molecules per added cation.

Evidence location: Conclusions

## Links

- Source: [[sources/src_b0ea8c70ab]]