---
title: "At 77 K adsorption falls into distinct pressure regimes: at low pressure (~1 bar) uptake scales with ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_b1552d4a9d]
confidence: high
---


# At 77 K adsorption falls into distinct pressure regimes: at low pressure (~1 bar) uptake scales with ...[TRUNCATED]... 

## Mechanism claim

At 77 K adsorption falls into distinct pressure regimes: at low pressure (~1 bar) uptake scales with isosteric heat (Qst); at intermediate pressure (~30 bar) uptake correlates with surface area (As); at very high pressure (~120 bar) uptake correlates with pore volume (V).

## Applicability

- Task: `h2`
- Mechanism type: `pressure-dependent adsorption regime / scaling laws`
- Condition scope: `{"gas": "H2", "temperature_K": 77, "pressure_bar": null, "material_family": "general MOFs (theoretical results cited)", "method": "review (theoretical results)"}`

## Positive design features

- provides targetable metrics (Qst, As, V) depending on intended charging pressure

## Negative design features

- different regimes imply a single material optimization may not serve all pressure ranges

## Agent design implication

When designing MOFs for H2 storage at 77 K, choose the optimization target based on operating pressure: enhance Qst for low-pressure targets, maximize As for intermediate pressures, and maximize V for very high pressures.

## Evidence

> The obtained theoretical results suggest the existence of three adsorption modes at 77 K: (1) at low pressure (~1 bar of H2), the n_excess value is proportional to the value of Qst; (2) at ~30 bar of H2, the n_excess value is proportional to As; and (3) at ~120 bar of H2, the n_excess value is proportional to V.

Evidence location: page 4

## Links

- Source: [[sources/src_b1552d4a9d]]