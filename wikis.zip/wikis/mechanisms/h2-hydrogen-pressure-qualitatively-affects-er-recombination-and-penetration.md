---
title: "Hydrogen pressure qualitatively affects ER recombination and penetration depth: at low H2 pressure E ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_0abff73929]
confidence: medium
---


# Hydrogen pressure qualitatively affects ER recombination and penetration depth: at low H2 pressure E ...[TRUNCATED]... 

## Mechanism claim

Hydrogen pressure qualitatively affects ER recombination and penetration depth: at low H2 pressure ER recombination dominates and limits hydrogenation depth, while at higher H2 pressure ER recombination is suppressed (and packing H2 in cavities becomes unfavorable), increasing hydrogenation degree and penetration depth.

## Applicability

- Task: `h2`
- Mechanism type: `pressure-dependent_thermodynamics_and_kinetics`
- Condition scope: `{"gas": "H2 / atomic H", "temperature_K": null, "pressure_bar": "qualitative: low vs high H2 pressure regimes discussed", "material_family": "IRMOF-1 (linker BDC)", "method": "thermodynamic/kinetic argument based on DFT-calculated barriers and equilibria"}`

## Positive design features

- Higher H2 pressure can shift equilibria to favor fuller hydrogenation and greater penetration
- Trapped H2 in cavities can raise internal pressure and promote hydrogenation locally

## Negative design features

- At low pressure, ER recombination prevents deep hydrogenation and limits utilization

## Agent design implication

Operating at elevated H2 pressure (or engineering trapped high-pressure cavities) can reduce ER recombination near pore entrances and increase the fraction of the MOF that becomes hydrogenated during spillover.

## Evidence

> "The effect of the hydrogen pressure on the thermodynamics of spillover can be explained by the H2 pressure dependence of the Eley-Rideal recombination reactions (Hgas + Hads → H2,gas). At low H2 pressures, ER recombination reactions would dominate ... However, as the H2 pressure is increased, the equilibrium of the ER recombination reaction is shifted because it becomes energetically unfavorable to squeeze more hydrogen molecules in the MOF cavities. As a result, at higher pressures, a larger fraction of the pores will follow the route to complete hydrogenation.... the penetration depth of atomic H into the crystal lattice will also increase because the higher pressure diminishes the ER recombination reactions that are responsible for underutilization of the MOF as explained above."

Evidence location: page 6-7

## Links

- Source: [[sources/src_0abff73929]]