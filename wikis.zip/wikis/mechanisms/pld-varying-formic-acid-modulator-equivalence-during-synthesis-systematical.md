---
title: "Varying formic-acid modulator equivalence during synthesis systematically tunes porosity, specific s ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_20cacd73e1]
confidence: high
---


# Varying formic-acid modulator equivalence during synthesis systematically tunes porosity, specific s ...[TRUNCATED]... 

## Mechanism claim

Varying formic-acid modulator equivalence during synthesis systematically tunes porosity, specific surface area, pore-size distribution and defect character in Ce-MOF-801: moderate formic acid (empirically ~50 equiv) produces a bimodal pore distribution including micropores (~0.5–0.7 nm) and maximizes SSA, whereas absence of modulator yields large mesopores and missing-cluster features and excessive modulator (>50 equiv) shifts pores >0.7 nm and reduces SSA.

## Applicability

- Task: `pld`
- Mechanism type: `synthesis → structure relation (modulator-controlled defect engineering alters porosity/textural properties)`
- Condition scope: `{"gas": "N2 for physisorption characterization (77 K)", "temperature_K": 77, "pressure_bar": null, "material_family": "Ce-MOF-801 series (Ce-MOF-801-neq; n = 0, 50, 100, 150, 200)", "method": "experiment (BET/NLDFT, SEM, TG)"}`

## Positive design features

- Type IV N2 isotherms with H3 hysteresis indicating mesoporous character across samples
- Ce-MOF-801-50eq exhibits highest reported SSA in series (598.84 m2/g) and bimodal pores including 0.5–0.7 nm micropores
- 0eq sample shows increased pore volume and large mesopores consistent with missing-cluster defects

## Negative design features

- Higher formic acid loadings (>50 equiv) produce pores mainly >0.7 nm and declining SSA
- 0eq yields irregular particle-size distribution and larger interparticle voids (missing-cluster defects)

## Agent design implication

Adjust formic-acid modulator equivalence to tune pore populations: use moderate (~50 eq) formic acid to create microporosity and maximize SSA for Ce-MOF-801 under the reported synthesis; avoid zero modulation if large mesopores/interparticle voids are undesirable and avoid excessive modulation if target is high SSA and microporosity.

## Evidence

> A series of Ce-based MOFs with different defect contents were synthesized via a modulator-induced defect engineering strategy with the aid of the cell pulverization technique. The N2 adsorption–desorption isotherms exhibited by all samples at 77 K are typical type IV with H3 hysteresis loops, indicating the presence of mesoporous structures. As the amount of the formic acid modulator was increased, the SSA of the Ce-MOF-801-neq samples first increased, reaching a maximum value of 598.84 m2/g for the Ce-MOF-801-50eq sample, before subsequently declining at higher formic acid concentrations. When the formic acid loading exceeded 50 equiv, the pore sizes of the MOFs were primarily above 0.7 nm. In contrast, the MOFs synthesized using 50 equiv of formic acid exhibited a bimodal pore size distribution, with pores not only in the 0.7 nm range but also in the 0.5−0.7 nm micropore region. The BET curve of Ce-MOF-801-0eq shows significant hysteresis loops, suggesting irregularities in particle size distribution and larger interparticle voids consistent with missing cluster defects.

Evidence location: Pages 1–6 (Abstract; Materials and Methods; Results: N2 adsorption discussion, Figure 2c–d, Figure 2e; pages labeled 5–6 in excerpts)

## Links

- Source: [[sources/src_20cacd73e1]]