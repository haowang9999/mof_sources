---
title: "Largest cavity diameter (LCD) exerts a stronger influence than other single geometric factors on iod ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_fc58db74fa]
confidence: medium
---


# Largest cavity diameter (LCD) exerts a stronger influence than other single geometric factors on iod ...[TRUNCATED]... 

## Mechanism claim

Largest cavity diameter (LCD) exerts a stronger influence than other single geometric factors on iodine adsorption by controlling constricted porosity and the compactness of MOF–iodine interactions.

## Applicability

- Task: `pld`
- Mechanism type: `pore-topology modulation of host–guest interaction`
- Condition scope: `{"gas": "I2 and CH3I (mixed humid stream)", "temperature_K": 423, "pressure_bar": 1, "material_family": "MOFs (screened set)", "method": "GCMC simulation and pore-metric correlation analysis"}`

## Positive design features

- Appropriate LCD creates 'constricted porosity' enhancing host–iodine interaction

## Negative design features

- Not specified

## Agent design implication

Prioritize tuning LCD (pore cavity size) when engineering MOFs for iodine capture, as LCD more directly alters interaction strength and effective porosity than some other single metrics.

## Evidence

> “...LCD exhibited more obvious and greater impact on adsorption performance, by causing the constricted porosity and compact interaction between the MOFs and iodine molecules.”

Evidence location: page 4

## Links

- Source: [[sources/src_fc58db74fa]]