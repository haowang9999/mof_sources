---
title: "Iodine selectivity (I2 or CH3I) in mixed-gas adsorption was computed using a ratio-based metric: (X_ ...[TRUNCATED]... "
type: mechanism
tags: [mixed, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_fc58db74fa]
confidence: high
---


# Iodine selectivity (I2 or CH3I) in mixed-gas adsorption was computed using a ratio-based metric: (X_ ...[TRUNCATED]... 

## Mechanism claim

Iodine selectivity (I2 or CH3I) in mixed-gas adsorption was computed using a ratio-based metric: (X_iodine/Y_iodine) / (X_others/Y_others), where X denotes uptake and Y denotes gas-phase concentration; competing components included N2, O2 and H2O.

## Applicability

- Task: `mixed`
- Mechanism type: `selectivity metric (thermodynamic/computational definition)`
- Condition scope: `{"gas": "I2 or CH3I (target) vs N2, O2, H2O (other components)", "temperature_K": null, "pressure_bar": null, "material_family": "MOFs", "method": "GCMC simulation"}`

## Positive design features

- increased uptake of iodine relative to others increases selectivity

## Negative design features

- Not specified

## Agent design implication

To increase iodine selectivity in a MOF under mixed-gas conditions, design or choose materials that maximize iodine uptake while minimizing uptake of competing components at relevant gas-phase concentrations.

## Evidence

> “In addition, the selectivity of I2 and CH3I during adsorption was calculated as the following equation: selectivity_iodine = (X_iodine/Y_iodine) / (X_others/Y_others) ... where X_iodine and Y_iodine denoted the uptake amounts and gas phase concentration of targeted gas iodine (I2 or CH3I)... X_others and Y_others were the uptake amounts and gas phase concentration of other gas components (N2, O2 and H2O).”

Evidence location: STAR+METHODS, Grand canonical Monte Carlo simulations (page ~12)

## Links

- Source: [[sources/src_fc58db74fa]]