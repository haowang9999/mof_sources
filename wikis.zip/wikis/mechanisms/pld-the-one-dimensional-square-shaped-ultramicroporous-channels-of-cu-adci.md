---
title: "The one-dimensional square-shaped ultramicroporous channels of Cu(adci)-2 have all NH2 groups orient ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_83cde498f9]
confidence: high
---


# The one-dimensional square-shaped ultramicroporous channels of Cu(adci)-2 have all NH2 groups orient ...[TRUNCATED]... 

## Mechanism claim

The one-dimensional square-shaped ultramicroporous channels of Cu(adci)-2 have all NH2 groups oriented the same way so that pairs of NH2 groups face each other across channel walls; this geometry enables the sandwich-like CO2 binding site and allows activation by vacuum at 373 K without solvent exchange.

## Applicability

- Task: `pld`
- Mechanism type: `pore_geometry / pore_function_relation`
- Condition scope: `{"gas": "CO2 (relevant)", "temperature_K": 373, "pressure_bar": null, "material_family": "Cu(adci)-2 (pts topology, one-dimensional square channels)", "method": "synchrotron PXRD / Rietveld analysis and activation experiments"}`

## Positive design features

- uniform orientation of NH2 groups in channel
- pairs of NH2 facing each other across channel walls
- activation at 373 K under vacuum possible without solvent exchange

## Negative design features

- Not specified

## Agent design implication

Design ultramicroporous channels with uniformly oriented polar functional groups (e.g., NH2) arranged to face each other across small channel diameters to create cooperative binding pockets and allow straightforward thermal vacuum activation.

## Evidence

> Synchrotron powder X-ray diffraction and a Rietveld analysis reveal that the Cu(adci)-2 structure has one-dimensional square-shaped channels, in each of which all affiliated ligands, specifically NH2 groups at the 2-position of the imidazolate ring, have the same orientation, with a pair of NH2 groups therefore facing each other on opposite sides of the channel walls. Cu(adci)-2 could be activated by heating at 373 K under a vacuum without a solvent exchange treatment.

Evidence location: page 6 (conclusions and structural analysis)

## Links

- Source: [[sources/src_83cde498f9]]