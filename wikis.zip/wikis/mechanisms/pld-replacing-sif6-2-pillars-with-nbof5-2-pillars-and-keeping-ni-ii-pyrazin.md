---
title: "Replacing (SiF6)2− pillars with (NbOF5)2− pillars and keeping Ni(II)-pyrazine layers produced contra ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_36df794947]
confidence: high
---


# Replacing (SiF6)2− pillars with (NbOF5)2− pillars and keeping Ni(II)-pyrazine layers produced contra ...[TRUNCATED]... 

## Mechanism claim

Replacing (SiF6)2− pillars with (NbOF5)2− pillars and keeping Ni(II)-pyrazine layers produced contracted square channels in NbOFFIVE-1-Ni (F···F-derived diameter 3.210(8) Å), smaller than SIFSIX-3-Ni (3.694(1) Å) and SIFSIX-3-Cu (3.483(1) Å); this contraction correlates with enhanced CO2 uptake at low pressures.

## Applicability

- Task: `pld`
- Mechanism type: `pore_size (PLD) tuning via pillar chemistry`
- Condition scope: `{"gas": "CO2 (implication for adsorption)", "temperature_K": 298, "pressure_bar": null, "material_family": "NbOFFIVE-1-Ni vs SIFSIX-3-M", "method": "experiment (SCXRD, adsorption isotherms)"}`

## Positive design features

- use of (NbOF5)2− pillar yields shorter F···F spacing in channel
- smaller channel diameter correlates to larger low-pressure uptake

## Negative design features

- structural rationale for how a longer Nb−F bond leads to reduced pendant-F separation is material-architecture specific (authors present as design rationale)

## Agent design implication

Tune pillar identity to adjust the F···F distance (pore-limiting diameter); substituting SiF6 by NbOF5 was used to produce a smaller effective channel in this family and thereby boost trace-CO2 performance.

## Evidence

> NbOFFIVE-1-Ni encloses a relatively contracted square-shaped channels with a slightly smaller diameter of 3.210(8) Å (derived from the distance between the pendant fluorine centers, F···F ...) than those of the SIFSIX-3-Ni and SIFSIX-3-Cu ... This remarkable CO2 uptake improvement ... is directly correlated to the closer proximity of the pendant fluorine centers decorating the square-shaped channels, as in the case of NbOFFIVE-1-Ni with an F···F distance of 3.210(8) Å as compared to the 3.694(1) Å distance in the case of the SIFSIX-3-Ni.

Evidence location: page 3-4

## Links

- Source: [[sources/src_36df794947]]