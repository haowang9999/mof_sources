---
title: "Functionalization enables quantitative tuning across a practical range: sorption strength difference ...[TRUNCATED]... "
type: mechanism
tags: [co2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_a318a71841]
confidence: high
---


# Functionalization enables quantitative tuning across a practical range: sorption strength difference ...[TRUNCATED]... 

## Mechanism claim

Functionalization enables quantitative tuning across a practical range: sorption strength differences observed of ~1.5–15.5 kJ/mol and experimentally observed C2H2/CO2 selectivities in dynamic experiments of ~4.1–10.9 across the series.

## Applicability

- Task: `co2`
- Mechanism type: `quantitative tuning of adsorption energetics and selectivity via functionalization`
- Condition scope: `{"gas": "C2H2 and CO2", "temperature_K": null, "pressure_bar": null, "material_family": "functionalized rigid honeycomb-like MOF series", "method": "isosteric enthalpy derivation and breakthrough/selectivity experiments"}`

## Positive design features

- wide tunability of sorption energetics and selectivity

## Negative design features

- Not specified

## Agent design implication

Expect broad modulation of adsorption enthalpies and selectivities by choosing different side-chain functional groups; use thermodynamic metrics and dynamic tests to map performance.

## Evidence

> Both directing factors in tandem can be utilized to tune the gating behavior across a wide range of sorption strength differences (1.5−15.5 kJ/mol) and practically observed selectivities (4.1−10.9) for C2H2/CO2 separation.

Evidence location: page 8 (Conclusions)

## Links

- Source: [[sources/src_a318a71841]]