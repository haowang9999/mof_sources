---
title: "MOF atomic partial charges were derived from ab initio fragment calculations that implicitly include ...[TRUNCATED]... "
type: mechanism
tags: [h2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_532b708453]
confidence: high
---


# MOF atomic partial charges were derived from ab initio fragment calculations that implicitly include ...[TRUNCATED]... 

## Mechanism claim

MOF atomic partial charges were derived from ab initio fragment calculations that implicitly include condensed-phase polarization; accordingly, MOF–MOF self-polarization was excluded in explicit polarization calculations and only induced-field interactions between H2 and MOF atoms were computed to avoid double-counting.

## Applicability

- Task: `h2`
- Mechanism type: `electrostatics / polarization bookkeeping`
- Condition scope: `{"gas": "H2", "temperature_K": 78, "pressure_bar": null, "material_family": "soc-MOF", "method": "simulation / ab initio charge derivation"}`

## Positive design features

- ab initio-derived partial charges
- avoids double-counting of MOF self-polarization

## Negative design features

- MOF–MOF induced polarization excluded (assumed implicit in charges)

## Agent design implication

When partial charges are fit from ab initio fragments that account for condensed-phase polarization, exclude MOF–MOF self-polarization in explicit polarization models to avoid double-counting; include only guest-induced MOF polarization.

## Evidence

> Since the atomic point charges of the MOF were calculated by ab initio to implicitly include polarization, MOF-MOF self-polarization was disallowed by excluding MOF-MOF electric field interactions, and only the induced field interactions between the H2 and MOF atoms were calculated.

Evidence location: page 6 (polarization calculation details)

## Links

- Source: [[sources/src_532b708453]]