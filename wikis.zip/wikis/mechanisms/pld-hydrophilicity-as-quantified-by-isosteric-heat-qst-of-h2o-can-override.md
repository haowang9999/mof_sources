---
title: "Hydrophilicity (as quantified by isosteric heat Qst of H2O) can override pore-metric benefits: high  ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_fc58db74fa]
confidence: medium
---


# Hydrophilicity (as quantified by isosteric heat Qst of H2O) can override pore-metric benefits: high  ...[TRUNCATED]... 

## Mechanism claim

Hydrophilicity (as quantified by isosteric heat Qst of H2O) can override pore-metric benefits: high Qst(H2O) leads to competitive adsorption with I2 and reduces I2 uptake/selectivity even when other pore metrics are favorable.

## Applicability

- Task: `pld`
- Mechanism type: `competitive adsorption (water vs iodine) driven by hydrophilicity`
- Condition scope: `{"gas": "I2 in humid environment (mixed with H2O vapor, N2, O2)", "temperature_K": 423, "pressure_bar": 1, "material_family": "MOFs (screened set)", "method": "GCMC simulation with calculated Qst"}`

## Positive design features

- Low Qst(H2O) correlates with higher I2 uptake/selectivity (hydrophobic frameworks retain iodine in presence of water)

## Negative design features

- High Qst(H2O) causes water to competitively occupy adsorption sites and lower I2 uptake/selectivity

## Agent design implication

Even if pore metrics (LCD, PLD, surface area) are within optimal ranges, ensure low affinity for water (low Qst(H2O)) for I2 capture in humid conditions; otherwise hydrophilicity can negate structural advantages.

## Evidence

> “The reason might lie in its high Qst of H2O (34.8 kJ/mol), which led to the more drastic competitive adsorption between the H2O and I2 and therefore reduced I2 selectivity... Conversely, Zn(1,3-BDP) and MIL-53-Al with the lowest Qst of H2O of 16.5 kJ/mol and 13.6 kJ/mol, exhibited the top-two I2 uptake amounts and selectivity. Consequently, it could be concluded that the Qst of H2O had a significant impact on I2 adsorption due to competitive adsorption in MOFs.”

Evidence location: page 4

## Links

- Source: [[sources/src_fc58db74fa]]