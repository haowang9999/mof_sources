---
title: "Permselectivity of H2/CH4 shows a local maximum when PLD is between 2.5–3.5 Å but also displays mini ...[TRUNCATED]... "
type: mechanism
tags: [h2|pld|mixed, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_90953381a0]
confidence: high
---


# Permselectivity of H2/CH4 shows a local maximum when PLD is between 2.5–3.5 Å but also displays mini ...[TRUNCATED]... 

## Mechanism claim

Permselectivity of H2/CH4 shows a local maximum when PLD is between 2.5–3.5 Å but also displays minima within the same PLD window; PLD is a key but not sole predictor for H2/CH4 separation.

## Applicability

- Task: `h2|pld|mixed`
- Mechanism type: `size-based sieving combined with material-specific adsorption/diffusion effects`
- Condition scope: `{"gas": "H2/CH4", "temperature_K": null, "pressure_bar": null, "material_family": "CoRE-MOFMs / CoRE‑MOF membranes", "method": "simulation / dataset analysis"}`

## Positive design features

- PLD 2.5–3.5 Å can maximize H2/CH4 permselectivity in many cases

## Negative design features

- Within same PLD range minima in permselectivity also observed; PLD alone insufficient

## Agent design implication

Prioritize PLD tuning to ~2.5–3.5 Å when targeting H2/CH4 separation, but also consider other descriptors (adsorption affinity, diffusion selectivity, pore geometry beyond PLD) because PLD alone does not guarantee optimal permselectivity.

## Evidence

> "We found that the permselectivity of H2/CH4 had a maximum when PLD was between 2.5–3.5 Å, but a minimum value also existed within the same range... The results indicated that PLD was a key, but not perfect, separation performance index for H2/CH4."

Evidence location: page 6

## Links

- Source: [[sources/src_90953381a0]]