---
title: "Hydrogen adsorption measurements were done as physisorption at 77 K over 0–1 bar, with samples activ ...[TRUNCATED]... "
type: mechanism
tags: [h2|pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_340141308b]
confidence: high
---


# Hydrogen adsorption measurements were done as physisorption at 77 K over 0–1 bar, with samples activ ...[TRUNCATED]... 

## Mechanism claim

Hydrogen adsorption measurements were done as physisorption at 77 K over 0–1 bar, with samples activated by vacuum outgassing up to 170 °C (sufficient to remove solvent without decomposition) and tested through adsorption–desorption cycling (20 cycles) with uptake recorded at 1 bar.

## Applicability

- Task: `h2|pld`
- Mechanism type: `experimental protocol (measurement conditions relevant to observed adsorption behavior)`
- Condition scope: `{"gas": "H2", "temperature_K": 77, "pressure_bar": "0-1 (uptake recorded at 1 bar during cycling)", "material_family": "M(BDC)TED0.5 samples", "method": "experiment (activation and adsorption cycling)"}`

## Positive design features

- activation: outgassing at 170 °C under vacuum to remove solvent without framework decomposition
- use of ultrahigh-purity gases
- stability testing via 20 adsorption−desorption cycles

## Negative design features

- Not specified

## Agent design implication

To reproduce reported H2 physisorption results on M(BDC)TED0.5, activate samples by vacuum outgassing to ~170 °C, measure at 77 K up to 1 bar, and consider cycling to test stability.

## Evidence

> The physical adsorption experiment was carried out at 77 K and 0−1 bar. Before analysis, the MOF samples (100 mg) were outgassed in the analysis tube under vacuum with heating up to 170 °C, which is sufficient to remove solvent molecules without thermal decomposition or loss of framework crystallinity. During the hydrogen cycle adsorption test, the samples were continuously subjected to adsorption−desorption operations for 20 cycles, and the hydrogen adsorption capacity of the samples was recorded when the pressure was 1 bar each time.

Evidence location: page 10 (Experimental section 4.5 Hydrogen Adsorption Measurements)

## Links

- Source: [[sources/src_340141308b]]