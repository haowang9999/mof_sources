---
title: "Kinetic diameters and PLD comparisons are useful heuristics: PLDs considerably larger than CH4's kin ...[TRUNCATED]... "
type: mechanism
tags: [pld|co2|ch4|mixed, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_97052fb350]
confidence: medium
---


# Kinetic diameters and PLD comparisons are useful heuristics: PLDs considerably larger than CH4's kin ...[TRUNCATED]... 

## Mechanism claim

Kinetic diameters and PLD comparisons are useful heuristics: PLDs considerably larger than CH4's kinetic diameter will likely permit rapid diffusion of both CO2 and CH4 (low diffusion-based selectivity), and PLDs substantially smaller than CO2's kinetic diameter will block permeation of both species; however, kinetic diameters are simplistic and electrostatic interactions (important for CO2) are not captured by LJ-only models.

## Applicability

- Task: `pld|co2|ch4|mixed`
- Mechanism type: `heuristic PLD-based sieving guidance with caveats`
- Condition scope: `{"gas": "CO2 and CH4 (heuristic comparison using reported kinetic diameters)", "temperature_K": null, "pressure_bar": null, "material_family": "MOFs", "method": "heuristic / geometric"}`

## Positive design features

- gives quick coarse-grained guidance for kinetic-sieving candidates

## Negative design features

- kinetic diameters are empirical and less meaningful for non-spherical molecules
- does not account for adsorbate-framework electrostatic interactions (important for CO2)

## Agent design implication

Use PLD vs. kinetic-diameter comparisons as an initial filter: avoid MOFs with PLD much larger than CH4 if diffusion-based discrimination is desired; seek materials with PLD between the kinetic diameters when aiming to allow one molecule but hinder the other — but treat CO2 cases cautiously and follow up with electrostatic-inclusive modeling.

## Evidence

> A useful, albeit simplistic, way to use the data in Figure 4 to select materials that may have value for kinetic separations is to compare the calculated pore-limiting diameters with the kinetic diameters of diffusing molecules... Materials that have pore-limiting diameters considerably larger than the kinetic diameter of CH4 are likely to allow both species to diffuse rapidly through their pores... On the other hand, materials with pore-limiting diameters substantially smaller than the kinetic diameter of CO2 will not allow either molecule to permeate through a MOF crystal.

Evidence location: page 6, section 3.2

## Links

- Source: [[sources/src_97052fb350]]