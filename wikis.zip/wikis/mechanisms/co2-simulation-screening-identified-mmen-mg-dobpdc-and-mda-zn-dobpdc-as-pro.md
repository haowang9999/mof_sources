---
title: "Simulation screening identified mmen-Mg/DOBPDC and mda-Zn/DOBPDC as promising candidates with high c ...[TRUNCATED]... "
type: mechanism
tags: [co2, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_20dae1036b]
confidence: medium
---


# Simulation screening identified mmen-Mg/DOBPDC and mda-Zn/DOBPDC as promising candidates with high c ...[TRUNCATED]... 

## Mechanism claim

Simulation screening identified mmen-Mg/DOBPDC and mda-Zn/DOBPDC as promising candidates with high cyclic working capacities for TSA-like cycles; mmen-Mg/DOBPDC was predicted to have higher uptake and better regenerability among the evaluated candidates, and mda-Zn/DOBPDC was estimated to deliver ~2.9 mmol·g−1 working capacity with a ~60°C regeneration swing in the simulations.

## Applicability

- Task: `co2`
- Mechanism type: `material-specific simulated performance (chemi-/physisorption balance and regenerability)`
- Condition scope: `{"gas": "pure CO2 and binary mixture 15% CO2 / 85% N2 (typical flue gas modeled)", "temperature_K": {"adsorption": null, "regeneration": 333}, "pressure_bar": "simulations performed for pressures 1 to 140 kPa; flue gas considered at near-atmospheric", "material_family": "amine-functionalized DOBPDC (mmen/Mg/DOBPDC and mda-Zn/DOBPDC)", "method": "simulation (GCMC + process-level TSA assessment)"}`

## Positive design features

- high cyclic working capacity predicted for listed candidates
- mmen functionalization predicted better uptake and cyclability among evaluated candidates in the study

## Negative design features

- results are simulation-based and depend on modeling assumptions (force fields, frozen frameworks, omission or simplified treatment of water/humidity and oxidative effects)

## Agent design implication

Prioritize mmen-Mg/DOBPDC and mda-Zn/DOBPDC for follow-up process-level simulation and experimental validation for TSA-based post-combustion CO2 capture, including tests under humid and realistic flue conditions.

## Evidence

> “Results show two potential structures with high cyclic working capacities if used for Temperature Swing Adsorption processes: mmen/Mg/DOBPDC and mda-Zn/DOBPDC. Among them, the -mmen functionalized structure has higher CO2 uptake and better cyclability (regenerability) for the flue gas mixtures and conditions studied.” | “mda-Zn/DOBPDC shows performance in the optimum range for post-combustion CO2 capture from ﬂue gas, enabling a working capacity of 2.9 mmol·g−1 with a 1T = 60◦C for regeneration.”

Evidence location: page 1 (Abstract); page 8 (Results/Conclusions)

## Links

- Source: [[sources/src_20dae1036b]]