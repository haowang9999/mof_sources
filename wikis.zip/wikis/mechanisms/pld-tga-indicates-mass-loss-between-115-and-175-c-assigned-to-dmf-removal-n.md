---
title: "TGA indicates mass loss between ~115 and 175 °C assigned to DMF removal; noncatenated materials (2,4 ...[TRUNCATED]... "
type: mechanism
tags: [pld, mechanism]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_90ad344e79]
confidence: medium
---


# TGA indicates mass loss between ~115 and 175 °C assigned to DMF removal; noncatenated materials (2,4 ...[TRUNCATED]... 

## Mechanism claim

TGA indicates mass loss between ~115 and 175 °C assigned to DMF removal; noncatenated materials (2,4,6,8) show greater solvent loss than 1,3,5,7 (catenated), consistent with larger pore volume in noncatenated frameworks.

## Applicability

- Task: `pld`
- Mechanism type: `porosity_vs_solvent_loss_correlation`
- Condition scope: `{"gas": "", "temperature_K": null, "pressure_bar": null, "material_family": "compounds 1-8 (Zn paddlewheel MOFs)", "method": "experiment (TGA)"}`

## Positive design features

- noncatenated materials — greater solvent (DMF) loss between 115–175 °C

## Negative design features

- catenated materials — lower solvent loss in that temperature range

## Agent design implication

Expect larger pore-volume (noncatenated) MOFs to release more solvent upon thermal activation; design activation procedures accordingly.

## Evidence

> “TGA ... revealed significant mass loss between 115 and 175 °C depending on the material. This is assigned to DMF molecules... Materials 2, 4, 6, and 8 show greater solvent loss than 1, 3, 5, and 7, which is expected going from a 2-fold catenated material to noncatenated material (see Figure 3a...).”

Evidence location: page 2-3

## Links

- Source: [[sources/src_90ad344e79]]