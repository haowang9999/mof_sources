---
title: "Catenation impact and controllability"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_b1552d4a9d]
confidence: high
---


# Catenation impact and controllability

## Claim A

Catenation can reduce H2 adsorption by blocking open metal sites and reducing accessible porosity.

## Claim B

Catenation is influenced by synthesis conditions and linker design (templates, bromination), implying it can be mitigated.

## Condition-based resolution

Catenation is detrimental to uptake when it blocks adsorption sites, but it can be mitigated through targeted synthesis strategies (template addition, linker substitution, reaction parameter control); nevertheless, synthesis control must be validated experimentally for each system.

## Agent warning

If using long linkers to increase As/V, include design and synthesis controls to prevent unwanted catenation; test activation procedures to evaluate accessibility of open sites.

## Evidence

> Catenation may be controlled by adding a template during solvothermal synthesis or by linker substitution (bromination). Example: non-catenated PCN-60 showed larger improvement in H2 adsorption than catenated PCN-6 because open metal sites were blocked in PCN-6.

## Links

- Source: [[sources/src_b1552d4a9d]]