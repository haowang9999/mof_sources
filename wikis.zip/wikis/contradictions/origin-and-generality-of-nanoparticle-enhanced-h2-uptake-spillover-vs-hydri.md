---
title: "origin and generality of nanoparticle-enhanced H2 uptake (spillover vs hydride formation)"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_ff1b0c9d63]
confidence: medium
---


# origin and generality of nanoparticle-enhanced H2 uptake (spillover vs hydride formation)

## Claim A

Some studies report increased H2 uptake or improved kinetics in MOF-NP composites attributed to spillover (NPs enabling dissociation and migration) or hydride formation (e.g., PdH formation).

## Claim B

Other studies report no spillover effects or contradictory outcomes; at least one paper revisited spillover measurements, implying reassessment or dispute of prior claims.

## Condition-based resolution

The origin of enhanced uptake in NP@MOF systems is system-dependent; both hydride formation and spillover have been proposed and observed in different systems. Differences depend on NP size, location (surface vs internal), incorporation method, host pore geometry, and potential framework degradation.

## Agent warning

Treat 'spillover' as a hypothesis that requires system-specific verification; when using metal-assisted strategies, verify mechanism with appropriate in situ characterization and cycling tests and monitor As/Va after incorporation.

## Evidence

> Formation of PdH0.6 was experimentally confirmed for the Pd NPs incorporated in MIL-100(Al), although the spill-over effect was also considered. As a result of the spill-over effect, faster kinetics was experimentally observed for Pd NPs encapsulated in HKUST-1. Conversely, some reports found no spillover in other MOF systems and re-evaluations of spillover measurements exist in the literature.

## Links

- Source: [[sources/src_ff1b0c9d63]]