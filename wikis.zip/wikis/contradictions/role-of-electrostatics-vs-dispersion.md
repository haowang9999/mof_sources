---
title: "role of electrostatics vs dispersion"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_c42cf01235]
confidence: high
---


# role of electrostatics vs dispersion

## Claim A

Electrostatic interactions are the differentiating factor across functionalizations and critical to boost CO2 sorption and selectivity.

## Claim B

Dispersion interactions can be larger in absolute magnitude than electrostatic interactions in many cases and remain an important baseline attractive contribution.

## Condition-based resolution

Dispersion provides baseline attractive interactions, but electrostatics control relative differences between functionalizations and thus are key for differentiation and targeted improvement strategies; both should be accounted for in design and simulation.

## Agent warning

Design and simulation workflows should account for both dispersion and electrostatics; improving electrostatic complementarity can yield larger relative gains even if dispersion remains a major energetic term.

## Evidence

> “we found a stronger correlation of DFT-calculated CO2 binding energies with the electrostatic interaction energies than with the dispersion interaction energies ... This is not to say that dispersion interactions are not important ... but to say that electrostatic interactions seem to be the differentiating factor across structures and critical to boost CO2 sorption."

## Links

- Source: [[sources/src_c42cf01235]]