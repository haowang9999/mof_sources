---
title: "Surface area (As) correlation with 77 K uptake"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_b1552d4a9d]
confidence: high
---


# Surface area (As) correlation with 77 K uptake

## Claim A

A linear relationship between H2 adsorption capacity at 77 K and As has been confirmed in numerous publications.

## Claim B

At 77 K and 1 bar, adsorption correlates with As only within 100–2000 m2·g−1 and does not correlate for higher As values.

## Condition-based resolution

Both are consistent: As is a useful predictor across a broad As range, but at low pressure and very high As the simple linear correlation breaks down because surface coverage is incomplete and adsorption is controlled by highest-affinity sites (Qst) and accessibility.

## Agent warning

Do not assume monotonic gains in low-pressure uptake by increasing As beyond ~2000 m2·g−1; consider affinity (Qst) and site accessibility instead.

## Evidence

> A linear relationship between the H2 adsorption capacity at 77 K and the As value has been confirmed in numerous publications. The adsorption capacity at 77 K and 1 bar of H2 is related to As within 100–2000 m2·g−1 and does not correlate for higher As values. This may be because the sorbent surface cannot be fully covered and H2 prefers highest-affinity sites.

## Links

- Source: [[sources/src_b1552d4a9d]]