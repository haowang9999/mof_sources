---
title: "Gating via pseudo-gating (noncovalent motifs) vs breathing (large volume change)"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_a318a71841]
confidence: medium
---


# Gating via pseudo-gating (noncovalent motifs) vs breathing (large volume change)

## Claim A

Halogen-bond interactions can evoke pseudo-gated adsorption with negligible volume change (no large-scale breathing).

## Claim B

Flexible substituents on linkers can direct breathing behavior involving larger-scale framework deformation.

## Condition-based resolution

These are distinct mechanisms: 'pseudo-gating' refers to gate-like adsorption responses with little net framework volume change, while 'breathing' involves larger-scale framework deformation. Both can yield selective adsorption but differ in kinetics, cycling stability, and design trade-offs.

## Agent warning

Do not assume all gate-like selectivity implies large-volume breathing; choose design motifs appropriate to whether minimal volume change or large-amplitude breathing is acceptable.

## Evidence

> Pseudo-Gated Adsorption with Negligible Volume Change Evoked by Halogen-Bond Interaction in the Nanospace of MOFs. (Ref. 48); Directing the breathing behavior of pillared-layered metal-organic frameworks via a systematic library of functionalized linkers bearing flexible substituents. (Ref. 57) (both cited in the paper)

## Links

- Source: [[sources/src_a318a71841]]