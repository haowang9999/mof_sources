---
title: "Affinity vs water sensitivity for amine-functionalized MOFs"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_20dae1036b]
confidence: high
---


# Affinity vs water sensitivity for amine-functionalized MOFs

## Claim A

Amine functionalization increases CO2 adsorption capacity, selectivity, and can improve kinetics and regenerability in dry conditions.

## Claim B

High CO2 affinity from amine functionalization entails hydrophilicity such that water can competitively adsorb with CO2; many promising MOFs require partial or complete drying of the gas stream unless oxidation-resistant chemistries are used.

## Condition-based resolution

Designs using amine functionalization must explicitly address water/oxidative conditions (drying, pre-treatment, or selection of oxidation-resistant/humidity-tolerant amines) because dry-lab/simulation performance may not transfer to humid feeds.

## Agent warning

Include humidity and oxidative stability in screening and validation for amine-functionalized MOFs; do not assume dry performance is representative of real flue/natural-gas streams.

## Evidence

> “Studies have shown that amine-functionalized MOFs have potential for greater adsorption capacity... However, ... the use of the most promising MOFs require partial or complete drying of the gas stream because high affinity for CO2 entails hydrophilicity, and thus water can competitively adsorb with CO2.” | “Water enables efficient CO2 capture from natural gas flue emissions in an oxidation-resistant diamine-appended metal–organic framework.”

## Links

- Source: [[sources/src_20dae1036b]]