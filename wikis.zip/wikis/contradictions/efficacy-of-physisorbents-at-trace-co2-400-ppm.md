---
title: "efficacy of physisorbents at trace CO2 (400 ppm)"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_36df794947]
confidence: high
---


# efficacy of physisorbents at trace CO2 (400 ppm)

## Claim A

Prevailing assumption: physisorption-based adsorbents are unlikely to be effective for CO2 capture at very low concentrations (400 ppm) due to weak interactions.

## Claim B

Experimental data: SIFSIX-3 family and NbOFFIVE-1-Ni (physisorption-based MOFs) show excellent CO2 selectivity and high uptake at low concentrations, with NbOFFIVE-1-Ni being the top physical adsorbent at 400 ppm.

## Condition-based resolution

For designed fluorinated MOFs with contracted channels and aligned pendant fluorine centers, physisorption can provide sufficiently strong interactions to enable effective trace-CO2 capture; therefore the general assumption does not hold for these tailored materials.

## Agent warning

Do not generalize that physisorption is ineffective at trace CO2; pore chemistry and geometry (e.g., aligned fluorine centers, optimal PLD) can invert that expectation. However, water sensitivity must be considered and mitigated by design.

## Evidence

> It was intuited that chemisorption-based sorbents are the foremost option for traces CO2 capture ... Contradictorily to this uncorroborated assumption, we recently published a series of CO2-selective MOF adsorbents ... showing excellent CO2 selectivity and uptake at relatively low CO2 concentrations using solely the physisorption mechanism ... NbOFFIVE-1-Ni exhibits the highest CO2 gravimetric and volumetric uptake ... at 400 ppm of CO2 and 298 K.

## Links

- Source: [[sources/src_36df794947]]