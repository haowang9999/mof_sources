---
title: "role_of_catenation_in_MOF_performance"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_90ad344e79]
confidence: high
---


# role_of_catenation_in_MOF_performance

## Claim A

Noncatenated MOFs have larger channels and pores and therefore higher porosity (beneficial for maximizing void volume and some catalysis applications).

## Claim B

Catenation can be useful for precise pore sizes, essential for separations.

## Condition-based resolution

Choice between promoting or suppressing catenation should be guided by application: maximize porosity (suppress catenation) for storage/catalysis where large voids are desired; retain or induce catenation when precise, smaller pore sizes are required for molecular sieving/separations.

## Agent warning

Do not treat catenation as universally negative; design objective must define whether to suppress or permit interpenetration.

## Evidence

> “Noncatenated systems should have larger channels and pores than their catenated counterparts, a feature of value in certain catalysis applications. (On the other hand, catenation can be useful for precise pore sizes, essential for separations.)”

## Links

- Source: [[sources/src_90ad344e79]]