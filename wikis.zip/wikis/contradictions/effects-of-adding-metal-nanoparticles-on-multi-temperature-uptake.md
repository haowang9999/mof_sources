---
title: "Effects of adding metal nanoparticles on multi-temperature uptake"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_b1552d4a9d]
confidence: medium
---


# Effects of adding metal nanoparticles on multi-temperature uptake

## Claim A

Incorporating Pd nanoparticles into MIL-100(Al) increased H2 uptake at 298 K (likely due to Pd hydride formation / spillover).

## Claim B

The same Pd incorporation reduced H2 uptake at 77 K and 40 bar because BET area and pore volume decreased after impregnation.

## Condition-based resolution

Nanoparticle addition can produce opposite effects at cryogenic vs ambient temperatures because morphological loss of accessible porosity can reduce cryogenic uptake while hydride formation or spillover can increase RT uptake; net effect depends on NP loading, dispersion, and whether enhanced binding offsets lost pore volume and added mass.

## Agent warning

Expect tradeoffs when adding NPs: improvements at RT may come at the cost of cryogenic uptake and gravimetric capacity; validate across relevant temperature/pressure regimes.

## Evidence

> Pd impregnation in MIL-100(Al) reduced A and V and decreased 77 K uptake, whereas 298 K uptake increased (likely Pd hydride formation); formation of PdHx was experimentally confirmed and spillover was considered.

## Links

- Source: [[sources/src_b1552d4a9d]]