---
title: "NU-651 porosity: simulated vs experimentally measured"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_3b254ae858]
confidence: high
---


# NU-651 porosity: simulated vs experimentally measured

## Claim A

Simulated pore size distribution (Zeo++) indicates NU-651 has a uniform pore size of 1.9 nm and calculated porosity of 76.7%.

## Claim B

Experimental porosity/accessibility of NU-651 could not be measured after supercritical CO2 activation or perfluoropentane exchange (no N2 sorption data available).

## Condition-based resolution

Treat Zeo++-derived pore size and porosity for NU-651 as predictive/crystallographic metrics only; experimental validation via activation and gas sorption is required to confirm accessible porosity. The paper reports inability to access experimental porosity for NU-651, so simulated values should not be assumed equal to accessible porosity.

## Agent warning

Do not assume simulated porosity equals experimentally accessible porosity—prioritize experimental activation and N2 (or target gas) sorption to confirm performance before application-level decisions.

## Evidence

> The simulated pore size distribution from Zeo++ calculation revealed NU-651 has uniform pore size of 1.9 nm. The calculated porosity of NU-651 based on crystal structure is 76.7%... Unfortunately, we were not able to access the porosity of NU-651 after either supercritical CO2 activation or perfluoropentane exchange.

## Links

- Source: [[sources/src_3b254ae858]]