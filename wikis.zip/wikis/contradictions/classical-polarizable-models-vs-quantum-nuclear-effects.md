---
title: "classical polarizable models vs quantum nuclear effects"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_532b708453]
confidence: medium
---


# classical polarizable models vs quantum nuclear effects

## Claim A

Many-body electronic polarization is the dominant contribution to H2 physisorption in soc-MOF and dramatically affects adsorption predictions.

## Claim B

Classical simulations (even with polarization) may overestimate sorption by ~10–15% because they neglect hydrogen nuclear quantum effects as shown by prior PIMC studies.

## Condition-based resolution

Polarization remains a dominant and necessary component to include in modeling ionic/narrow-pore MOFs to capture qualitative behavior and induced-dipole driven structure; however, absolute adsorption amounts predicted by classical polarizable simulations should be treated as possibly modest overestimates at cryogenic temperatures. Combining polarization with nuclear quantum treatments is ideal for quantitative accuracy but is often computationally prohibitive.

## Agent warning

Do not interpret strong binding or absolute uptake from classical polarizable simulations as exact experimental values at cryogenic temperatures; incorporate an uncertainty margin or seek quantum nuclear corrections for quantitative claims.

## Evidence

> Previous simulations ... are demonstrated here to be the dominant contribution to hydrogen physisorption. ... The results showed a decreased sorption of 10-15% relative to the purely classical simulations. ... it is computationally prohibitive to perform PIMC simulations including polarization, the present study will focus on the role of electronic polarization within a classical model.

## Links

- Source: [[sources/src_532b708453]]