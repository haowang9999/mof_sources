---
title: "IAST predictions vs experimental breakthrough for BA"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_a318a71841]
confidence: high
---


# IAST predictions vs experimental breakthrough for BA

## Claim A

IAST predicted a certain performance for BA (implied different behavior in IAST ranking).

## Claim B

Experimentally, BA shows sorption strengths for CO2 and C2H2 and available pore volume comparable to DP and performs similarly—contrary to the initial prediction by IAST values.

## Condition-based resolution

This contradiction occurs for heavily functionalized MOFs in competitive sorption; experimental breakthrough data should be used to resolve performance expectations and capture kinetic/nonideal effects.

## Agent warning

Do not trust IAST alone for heavily functionalized frameworks; always validate with breakthrough experiments to capture nonideal energetic and kinetic effects.

## Evidence

> BA shows sorption strengths for CO2 and C2H2 as well as available pore volume comparable to that of DP and performs similarly—contrary to the initial prediction by IAST values.

## Links

- Source: [[sources/src_a318a71841]]