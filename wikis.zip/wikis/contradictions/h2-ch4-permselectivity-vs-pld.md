---
title: "H2/CH4 permselectivity vs PLD"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_90953381a0]
confidence: high
---


# H2/CH4 permselectivity vs PLD

## Claim A

Permselectivity of H2/CH4 had a maximum when PLD was between 2.5–3.5 Å.

## Claim B

A minimum value of permselectivity for H2/CH4 also existed within the same PLD range (2.5–3.5 Å).

## Condition-based resolution

The dataset shows heterogeneous behavior within the PLD window: PLD is a dominant factor but not a sole determinant of permselectivity; other factors (adsorption selectivity, diffusion selectivity, pore geometry beyond PLD) produce variability.

## Agent warning

When filtering candidates by PLD alone within 2.5–3.5 Å, expect variability; further screening by adsorption/diffusion metrics or secondary descriptors is required to avoid false positives/negatives.

## Evidence

> "We found that the permselectivity of H2/CH4 had a maximum when PLD was between 2.5–3.5 Å, but a minimum value also existed within the same range... The results indicated that PLD was a key, but not perfect, separation performance index for H2/CH4."

## Links

- Source: [[sources/src_90953381a0]]