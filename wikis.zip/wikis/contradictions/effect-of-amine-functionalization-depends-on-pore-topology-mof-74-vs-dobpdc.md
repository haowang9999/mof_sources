---
title: "Effect of amine functionalization depends on pore topology (MOF-74 vs DOBPDC)"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_20dae1036b]
confidence: high
---


# Effect of amine functionalization depends on pore topology (MOF-74 vs DOBPDC)

## Claim A

In narrow-pore Mg-MOF-74, amine functionalization can reduce CO2 uptake significantly (reported ~50–60% lower at 15 kPa) due to occupation of metal sites and steric blocking.

## Claim B

In expanded DOBPDC frameworks, amine functionalization (e.g., en- and mmen-Mg/DOBPDC) can increase low-pressure uptake relative to the bare expanded framework (e.g., ∼3.6 mmol·g−1 at 15 kPa, ~15% higher than bare).

## Condition-based resolution

Net effect of amine functionalization depends on pore size/architecture and resulting available void fraction after grafting: narrow pores lose physisorptive capacity when occupied/blocked by amines, while expanded pores can accommodate amines and enable cooperative chemisorption without as large a loss of accessible volume.

## Agent warning

Do not generalize functionalization effects across MOF families—simulate or experimentally verify for each framework topology, amine identity, and functionalization degree before down-selection.

## Evidence

> “The adsorption uptake for the functionalized Mg-MOF-74 structures decreases about 50–60%... As shown... the capacities of the bare materials at typical flue gas conditions are reduced by using the expanded hexagonal version (M/DOBPDC), however... -en and -mmen versions of Mg/DOBPDC present a capacity of ∼3.6 mmol·g−1 at 15 kPa, 15% higher than the one achieved with the bare material.”

## Links

- Source: [[sources/src_20dae1036b]]