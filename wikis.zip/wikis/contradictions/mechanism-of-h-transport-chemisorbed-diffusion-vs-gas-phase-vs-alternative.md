---
title: "mechanism of H transport (chemisorbed diffusion vs gas-phase vs alternative hole-mediated proposals)"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_0abff73929]
confidence: medium
---


# mechanism of H transport (chemisorbed diffusion vs gas-phase vs alternative hole-mediated proposals)

## Claim A

High chemisorbed diffusion barriers support gas-phase or weakly physisorbed atomic H diffusion as the plausible transport route for spillover in MOFs.

## Claim B

Alternative mechanisms such as hole-mediated transport have been proposed elsewhere in the literature (ref. 21) but are not demonstrated here.

## Condition-based resolution

The paper's DFT barrier calculations argue against long-range chemisorbed diffusion in ideal MOFs and present gas-phase/physisorbed H transport as plausible. Alternative hole-mediated or other defect-mediated mechanisms are noted in the literature but not substantiated by the presented calculations; they would require independent validation.

## Agent warning

Avoid assuming a single universal transport mechanism; consider testing for hole-mediated or other defect-specific transport processes experimentally or computationally if relevant to your materials.

## Evidence

> "A radically different possibility has also been recently suggested: The authors of ref 21 have proposed a hole-mediated mechanism... However, we will show in the following that diffusion of H in the gas phase is plausible and can explain qualitatively many observations associated with spillover, including the necessity of pore defects."

## Links

- Source: [[sources/src_0abff73929]]