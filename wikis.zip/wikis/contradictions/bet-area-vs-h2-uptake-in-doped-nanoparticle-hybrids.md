---
title: "BET area vs H2 uptake in doped/nanoparticle hybrids"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_fa8cccd644]
confidence: high
---


# BET area vs H2 uptake in doped/nanoparticle hybrids

## Claim A

Higher ABET often correlates with increased H2 uptake in carbon-containing hybrids.

## Claim B

Addition of metal ions or nanoparticles often reduces SSA but can increase H2 uptake; thus BET alone may mispredict performance for doped hybrids.

## Condition-based resolution

Predictive power of BET depends on whether uptake is dominated by accessible surface area or by newly introduced/stronger adsorption sites; combine SSA with PSD, Qst and direct isotherms when evaluating hybrids.

## Agent warning

Do not use BET alone to accept/reject candidates, especially for doped or nanoparticle-containing hybrids.

## Evidence

> Some carbon-containing hybrids increase ABET and uptake (MOF-5@MWCNTs), whereas Pd-loaded SNU-3 increased uptake despite a 43% SSA decrease, indicating SSA is not universally predictive.

## Links

- Source: [[sources/src_fa8cccd644]]