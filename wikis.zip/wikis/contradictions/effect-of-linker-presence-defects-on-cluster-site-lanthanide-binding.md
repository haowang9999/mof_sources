---
title: "Effect of linker presence / defects on cluster-site lanthanide binding"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_c88d608b3b]
confidence: medium
---


# Effect of linker presence / defects on cluster-site lanthanide binding

## Claim A

Missing linkers result in favorable lanthanide binding sites at oxo clusters (defects increase cluster binding and available coordination sites).

## Claim B

Lanthanides can coordinate to metal-oxo cluster sites (bridging oxygens) even when linkers are present and defect signatures are similar; defects are beneficial but not strictly necessary.

## Condition-based resolution

Both statements are presented and supported: defect creation increases the number of accessible cluster oxygens and can enhance uptake, but intrinsic bridging oxygens on intact clusters can also support inner-sphere chemisorption if accessible. The net effect on uptake/selectivity depends on the MOF chemistry, site accessibility, and experimental conditions.

## Agent warning

Do not assume that introducing intact linkers will fully prevent metal-oxo cluster coordination of lanthanides; conversely, creating defects increases cluster-site availability but may not be the only controlling factor. Experimentally quantify the net effect of linker density vs defect density on uptake/selectivity for your MOF and target Ln (use XAFS, TGA, porosimetry).

## Evidence

> "Missing linkers result in favorable Ln binding sites at oxo clusters; however, Ln can coordinate to metal sites even with linkers in place."; "thermogravimetric characterization indicates that the defect characteristics of Cr-MIL-101 and Cr-MIL-101-NH2 is similar. This indicates that Lu3+ adsorption does not require a defect site (missing linker), and Lu3+ can bind at the bridging oxygen sites, as well as defect sites."

## Links

- Source: [[sources/src_c88d608b3b]]