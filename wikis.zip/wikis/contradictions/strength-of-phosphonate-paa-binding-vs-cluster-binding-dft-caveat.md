---
title: "Strength of phosphonate (PAA) binding vs cluster binding (DFT caveat)"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_c88d608b3b]
confidence: medium
---


# Strength of phosphonate (PAA) binding vs cluster binding (DFT caveat)

## Claim A

DFT indicates PAA (multidentate) binding is significantly more favorable than monodentate Zr-oxo binding; reprotonation variations (~0.14 eV) are small relative to this difference.

## Claim B

DFT calculations were performed under 'dry' conditions with only a few water molecules and without an explicit bulk aqueous reservoir, which limits quantitative accuracy for fully aqueous energetics.

## Condition-based resolution

The qualitative ordering (multidentate phosphonate stronger than monodentate oxo in the model) is supported by DFT and is robust to small protonation changes shown, but absolute energy differences and aqueous free energies may differ in bulk solution. Treat the DFT result as qualitative guidance to be validated experimentally.

## Agent warning

Use DFT results to prioritize multidentate chelating linkers as promising strategies, but validate binding strengths and selectivity experimentally under realistic aqueous conditions (e.g., calorimetry, batch adsorption).

## Evidence

> "This variation is noted as an error bar in Section 3.5; it is far less than the energy difference between cases (a) and (b)." ... "The current approach instead aims to conduct relatively computationally inexpensive DFT calculations under 'dry' conditions, with a few water molecules added..."

## Links

- Source: [[sources/src_c88d608b3b]]