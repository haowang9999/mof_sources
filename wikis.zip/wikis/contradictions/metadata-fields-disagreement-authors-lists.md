---
title: "Metadata fields disagreement (authors lists)"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_c88d608b3b]
confidence: medium
---


# Metadata fields disagreement (authors lists)

## Claim A

Some chunk-level records omitted or abbreviated the author list.

## Claim B

Other chunk-level records provided full author names (Anastasia G. Ilgen; R. Eric Sikma; Dorina F. Sava Gallis; Kevin Leung; Chengjun Sun; Boyoung Song; Kadie M. M. Sanchez; Jacob G. Smith).

## Condition-based resolution

The merged metadata retains the most specific non-empty author list available from the chunks. Users should be aware that some chunk extracts omitted authors; the chosen list reflects the more complete entries.

## Agent warning

If precise author ordering or completeness is mission-critical, verify against the original paper/DOI (10.1021/acsami.4c09445) because some chunk extracts had incomplete metadata.

## Evidence

> Chunk-level metadata variations: some entries contained the full author list while one entry had an empty authors array.

## Links

- Source: [[sources/src_c88d608b3b]]