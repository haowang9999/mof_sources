---
title: "optimal Qst value (thermodynamic estimate vs. GCMC simulation)"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_8d4a290e19]
confidence: high
---


# optimal Qst value (thermodynamic estimate vs. GCMC simulation)

## Claim A

Thermodynamic analysis (Bhatia & Myers method with DSo ≈ -8R) predicts an optimal Qst ≈ 13.4 kJ/mol for delivery between 120 and 1.5 bar at ambient temperature.

## Claim B

GCMC simulations across eight MOFs predict optimal average Qst values around 18.5–22 kJ/mol for the same delivery pressures and temperature.

## Condition-based resolution

The discrepancy is attributed to the thermodynamic assumption DSo ≈ -8R being invalid for materials with strong adsorption sites; when a larger magnitude of entropy change (e.g., DSo ≈ -10.1R) is used, the thermodynamic relation yields an optimal Qst (~18.5 kJ/mol) consistent with simulations.

## Agent warning

Do not rely solely on simple thermodynamic estimates that assume a fixed entropy change (DSo ≈ -8R) when strong adsorption sites are expected; verify with detailed simulation or experiment.

## Evidence

> "we calculated that the optimal Qst... is 13.4 kJ/mol... These values are considerably larger than the value from the thermodynamic calculation (13.4 kJ/mol). We attribute this difference to the inability of DSo ≈ -8R to describe materials with strong adsorption sites... the ΔSo/R values increase as Qst increases... If ΔSo ≈ -10.1R is applied... the calculated optimal Qst is around 18.5 kJ/mol, which agrees well with our GCMC results."

## Links

- Source: [[sources/src_8d4a290e19]]