---
title: "CO2 and H2 adsorption data absence"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_fc58db74fa]
confidence: high
---


# CO2 and H2 adsorption data absence

## Claim A

Design implications and rules provided for pore metrics (PLD, LCD) in MOFs are supported for I2 and CH3I capture under humid conditions.

## Claim B

No claims regarding CO2 or H2 adsorption mechanisms are present in the source text.

## Condition-based resolution

The provided study and evidence focus exclusively on I2, CH3I and competition with H2O/N2/O2 under the screening conditions; it does not provide data or mechanism statements for CO2 or H2.

## Agent warning

Do not transfer these PLD/LCD rules or confidence levels to CO2 or H2 adsorption without additional evidence specific to those gases; screening/selection criteria may differ for different gas sizes, polarities and chemistries.

## Evidence

> The paper consistently discusses I2, CH3I, H2O, N2 and O2 in the simulations and explicitly notes conditions and molecule sizes (e.g., CH3I kinetic diameter = 4.23 Å). No CO2 or H2 adsorption results or discussion are reported in the provided text.

## Links

- Source: [[sources/src_fc58db74fa]]