---
title: "Carbon hybridization effect on SSA"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_fa8cccd644]
confidence: medium
---


# Carbon hybridization effect on SSA

## Claim A

Some carbon-based treatments (e.g., amorphous carbon coatings via pyrolysis) reduce measured BET area (MOF-5 example).

## Claim B

Other carbon incorporations (e.g., templated porous carbon like ZTC or well-dispersed CNTs/MWCNTs) can increase overall SSA and H2 uptake.

## Condition-based resolution

Outcome depends on carbon integration method: coatings/overlayers may block pores and reduce SSA, while incorporation of porous/tailored carbon components can increase accessible porosity and SSA.

## Agent warning

Assess the specific carbon integration method (coating vs templated porous additive) and measure SSA and PSD experimentally.

## Evidence

> Amorphous carbon-coated MOF-5 had reduced BET (1740 vs 3450 m2 g−1), while MIL-101(Cr)@ZTC hybrid showed increased surface area (2957 m2 g−1) and higher H2 uptake.

## Links

- Source: [[sources/src_fa8cccd644]]