---
title: "Pore-window size numeric comparisons and flexibility (ZIF-8 vs ZIF-11)"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_8ce39338bc]
confidence: low
---


# Pore-window size numeric comparisons and flexibility (ZIF-8 vs ZIF-11)

## Claim A

ZIF-8 pore window diameter is reported as ~3.4 Å (comparable to cisplatin ~5 Å) leading to gate-opening barriers.

## Claim B

ZIF-11's largest pore-window size is reported as ~3 Å in screening context and ligand rotation contributes to diffusion hindrance.

## Condition-based resolution

Both statements emphasize that these ZIFs have nominally small windows relative to the quoted cisplatin size and that framework flexibility (ligand rotation/gate opening) affects diffusion. Numeric values reported in different parts of the manuscript are close but may stem from differing definitions or contexts; users should verify experimental or high-resolution computational pore-window measurements for candidates.

## Agent warning

Do not rely solely on single quoted numeric window diameters; consider framework flexibility, solvation, host–guest energetics, and measurement/definition differences. Verify pore-window values and dynamic behavior for candidate frameworks before design decisions.

## Evidence

> The pore window diameter of ZIF-8 (∼3.4 Å) is stated and ZIF-11 is discussed with a largest pore-window size of ∼3 Å; both are noted as smaller than the cited cisplatin size (~5 Å) and ligand rotation/gate-opening plays a role in diffusion limitation.

## Links

- Source: [[sources/src_8ce39338bc]]