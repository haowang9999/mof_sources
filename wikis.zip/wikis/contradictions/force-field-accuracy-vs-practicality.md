---
title: "force field accuracy vs practicality"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_1fa85425f9]
confidence: medium
---


# force field accuracy vs practicality

## Claim A

Generic force fields (UFF, Dreiding) show good agreement with experimentally measured gas uptake data and are validated for MOF simulations (supports using generic FFs for screening).

## Claim B

Significant quantitative differences have been reported between CO2 uptakes predicted by generic force fields and ab initio force fields (cautions against sole reliance on generic FFs).

## Condition-based resolution

Generic FFs are suitable for large-scale trend‑finding and initial screening, but top candidates should be re-evaluated with higher-fidelity (ab initio) FFs or experiment because numerical uptake predictions can differ.

## Agent warning

Use generic FFs for triage, but validate final selections; do not assume quantitative accuracy from generic FFs alone.

## Evidence

> "Molecular simulations employing either UFF or Dreiding showed good agreement with the experimentally measured gas uptake data of MOFs ..." and "Significant quantitative differences between the CO2 uptakes predicted by the generic FF and the ab initio FF were reported." (page 4).

## Links

- Source: [[sources/src_1fa85425f9]]