---
title: "Amine loading versus performance (quantity vs identity/void space)"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_20dae1036b]
confidence: medium
---


# Amine loading versus performance (quantity vs identity/void space)

## Claim A

Increasing amine content (more grafting) could be expected to increase CO2 capture performance.

## Claim B

More amine is not inherently better: amine identity, steric footprint, and the void space remaining after grafting determine whether increasing amine density helps or harms working capacity and selectivity.

## Condition-based resolution

Performance is a function of both amine quantity and amine type/sterics—optimal loading must be identified per material and application rather than assumed maximal.

## Agent warning

When prioritizing candidates, evaluate amine identity, steric effects, and resulting pore accessibility under intended cycles; screening should include varied loading levels.

## Evidence

> “Design of amine-functionalized metal–organic frameworks for CO2 separation: the more amine, the better?” (cited literature) | “Simulations have shown that the available void space left by the amine and the type of amine functional group plays a crucial role... the left bottom section is mostly composed of the amine-functionalized M-MOF-74 structures, with a low cyclic working capacity due to reduced interactions between the heterodiamine and CO2.”

## Links

- Source: [[sources/src_20dae1036b]]