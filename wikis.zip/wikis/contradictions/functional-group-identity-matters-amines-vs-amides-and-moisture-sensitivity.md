---
title: "functional group identity matters (amines vs amides) and moisture sensitivity"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_c42cf01235]
confidence: medium
---


# functional group identity matters (amines vs amides) and moisture sensitivity

## Claim A

Amine functionalization has demonstrated CO2-capture benefits and has been studied under dry and humid conditions.

## Claim B

Amide functionalization does not always produce the expected guest binding behavior in MOFs.

## Condition-based resolution

Functional group identity and local environment matter: amines have demonstrated benefits (including humid-condition studies) while amides have shown failures in some cases; performance must be validated per functional group and under the intended humidity conditions.

## Agent warning

Do not generalize across all N-containing groups; validate specific functional groups in context (pore environment, moisture, topology) and include humid testing where relevant.

## Evidence

> References: "Amine Functionalised Metal Organic Frameworks (MOFs) as Adsorbents for Carbon Dioxide."; "The Chemistry of CO2 Capture in an Amine-Functionalized Metal−Organic Framework under Dry and Humid Conditions."; "Amides Do Not Always Work: Observation of Guest Binding in an Amide-Functionalized Porous Metal−Organic Framework."

## Links

- Source: [[sources/src_c42cf01235]]