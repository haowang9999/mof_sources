---
title: "charge assignment impact on selectivity rankings"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_1fa85425f9]
confidence: medium
---


# charge assignment impact on selectivity rankings

## Claim A

PQeq charges can give a quick estimate of material potential but can considerably disagree with high‑quality quantum-derived charges in calculated CO2/N2 selectivities.

## Claim B

For CO2/H2O separations, a study found that the majority of top MOFs ranked by CO2 selectivity are identical regardless of the charge assignment method.

## Condition-based resolution

Charge assignment method may critically affect selectivity predictions for some separations (e.g., CO2/N2) but may be less impactful for others (e.g., CO2/H2O); impact depends on the gas pair and specific framework electronic environment.

## Agent warning

Do not generalize charge-assignment robustness across all gas mixtures and separations. Use fast charge methods for coarse screening but verify top candidates with higher-accuracy charges, especially for CO2/N2 separations or when electrostatics are critical.

## Evidence

> "Comparison between PQeq and high quality point charges derived from quantum chemistry for the top performing materials showed a considerable disagreement in the calculated CO2/N2 selectivities ..." (Haldoupis et al., 2012a,b) and "A recent study ... found that majority of the top MOFs ranked based on CO2 selectivities are identical regardless of the charge assignment method (Wei et al., 2017)." (pages 4-5).

## Links

- Source: [[sources/src_1fa85425f9]]