---
title: "Surface area vs pore size importance for RT H2 uptake"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_b1552d4a9d]
confidence: high
---


# Surface area vs pore size importance for RT H2 uptake

## Claim A

High surface area correlates with higher H2 uptake (general expectation).

## Claim B

Frameworks with modest BET surface area can show significant H2 adsorption if pore sizes are optimal (~5–7 Å) due to potential overlap.

## Condition-based resolution

At 298 K the dominant descriptor depends on pressure: pore volume matters more at low pressure and surface area at high pressure; additionally, pore diameter (5–7 Å) can compensate for lower BET area by increasing local interaction energy.

## Agent warning

Do not use BET surface area alone to rank candidates for RT H2 uptake; include pore size and pore volume in the evaluation and consider operating pressure.

## Evidence

> Examples indicate that, even with small A, hydrogen adsorption can be significant if pore size is ~5–7 Å. Also, at 298 K n correlates with V at low P and with A at high P.

## Links

- Source: [[sources/src_b1552d4a9d]]