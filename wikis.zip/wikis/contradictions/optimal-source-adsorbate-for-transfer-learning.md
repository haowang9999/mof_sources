---
title: "optimal source adsorbate for transfer learning"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_71bcf59437]
confidence: medium
---


# optimal source adsorbate for transfer learning

## Claim A

Methane is a better source task than hydrogen for transfer learning (generic/textural clusters): methane→hydrogen yielded high R2, hydrogen→methane performed poorly in at least one cluster.

## Claim B

When using topology-based clusters, there is no preferential source adsorption task (topology clusters did not show methane advantage).

## Condition-based resolution

The apparent contradiction is resolved by the clustering method: generic/textural clusters show asymmetry in task transferability (favoring methane as source), whereas topology-based clusters span more of the feature space and remove the preferential source-task effect.

## Agent warning

Do not assume a single adsorbate will always be the best source for transfer learning; performance depends on how the MOF dataset is partitioned (generic textural clusters vs topology clusters), PCA distances, and the specific cluster compositions.

## Evidence

> We find that hydrogen was a less effective source task ... Methane though, performed well as the source task ... When looking at the same exercise, but instead using the topology clusters, the general trends with distance in the PC space remain. However, we no longer see a preferential source adsorption task.

## Links

- Source: [[sources/src_71bcf59437]]