---
title: "humidity tolerance vs long-term hydrolytic stability"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_83cde498f9]
confidence: high
---


# humidity tolerance vs long-term hydrolytic stability

## Claim A

Cu(adci)-2's CO2 capture ability is retained under 60% RH in breakthrough experiments.

## Claim B

Cu(adci)-2 loses surface area and CO2 capacity after exposure to 80% RH for 1 week or to liquid water for 1 day.

## Condition-based resolution

Short-term or moderate humidity (e.g., 60% RH breakthrough) does not guarantee long-term stability; prolonged exposure at higher RH or immersion in liquid water causes degradation.

## Agent warning

Do not assume moisture tolerance from a single moderate-RH breakthrough test; include longer-term/high-RH exposures and humidity cycling in evaluation and avoid design choices that expose metal atoms to water if long-term wet stability is required.

## Evidence

> Page 1 (abstract): "breakthrough experiments under dry and 60% relative humidity conditions show that its CO2 capture ability is retained even in the presence of high amounts of moisture." vs Page 3 / Page 5: "BET surface areas were measured and found to be ... after exposure to 80% relative humidity for 1 week, to liquid water for 1 day... exposure to 80% RH for 1 week or to liquid water for 1 day reduced the CO2 capacity fairly well."

## Links

- Source: [[sources/src_83cde498f9]]