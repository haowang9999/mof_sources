---
title: "Classical simulation uptake vs quantum-inclusive results"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_532b708453]
confidence: high
---


# Classical simulation uptake vs quantum-inclusive results

## Claim A

Classical Monte Carlo simulations (used in this work) report high H2 uptake and demonstrate polarization-dominated binding.

## Claim B

Prior PIMC simulations that included nuclear quantum dispersion (but not electronic induction) found 10-15% lower sorption than classical simulations.

## Condition-based resolution

Qualitative mechanism (polarization dominance) remains important; absolute uptake values from classical simulations should be treated as slight overestimates until quantum nuclear effects are included together with many-body polarization.

## Agent warning

When using classical-simulation-derived uptake numbers for design decisions, apply corrections or validate with quantum-inclusive methods where possible.

## Evidence

> The earlier work ... included nuclear quantum dispersion effects via the computationally intensive path integral Monte Carlo simulations (PIMC)... The results showed a decreased sorption of 10-15% relative to the purely classical simulations. ... Given the prior work, our estimates of hydrogen sorption strength may be a slight overestimate...

## Links

- Source: [[sources/src_532b708453]]