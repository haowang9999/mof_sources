---
title: "ABET/Chahine heuristic vs pore-volume and PSD effects"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_fa8cccd644]
confidence: high
---


# ABET/Chahine heuristic vs pore-volume and PSD effects

## Claim A

Chahine's heuristic (≈1 wt% H2 per 500 m2 g−1 ABET) suggests a simple linear scaling of gravimetric H2 uptake with BET area.

## Claim B

For many MOFs, especially at very high ABET, Chahine's rule does not hold because BET measurements can reflect pore volume more than true accessible surface area; PSD and Qst strongly affect uptake.

## Condition-based resolution

Use BET area as a first-order predictor across typical ABET ranges, but for ultra-high ABET MOFs explicitly consider pore volume, PSD and isosteric enthalpy and measure H2 isotherms at target T/P. Compute volumetric uptake using framework or packing density when volumetric metrics matter.

## Agent warning

Do not filter candidates solely by ABET or Chahine's rule — combine BET with PSD, micropore volume and Qst measurements.

## Evidence

> When excess H2 storage capacities at −196 °C are plotted as a function of ABET for many MOFs, the observed trend does not follow Chahine’s heuristic rule. BET can be more indicative of pore volume at very high values.

## Links

- Source: [[sources/src_fa8cccd644]]