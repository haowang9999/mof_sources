---
title: "Effect of bimetal introduction on thermal stability"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_340141308b]
confidence: medium
---


# Effect of bimetal introduction on thermal stability

## Claim A

The introduction of bimetals may lead to a decrease in the thermal stability of MOFs (general caution stated by authors).

## Claim B

Introduction of Ni into Cu(BDC)TED0.5 (forming Cu0.5Ni0.5) improved thermal stability relative to Cu alone (reported stable to ~350 °C vs Cu decomposition at ~300 °C).

## Condition-based resolution

Thermal stability changes upon bimetal introduction are metal- and composition-dependent. Inclusion of a more thermally robust metal (e.g., Ni) can raise decomposition temperature, whereas other combinations may lower stability.

## Agent warning

Do not assume bimetal substitution will uniformly increase or decrease thermal stability; always perform TGA for each composition and consider both uptake and thermal stability in screening.

## Evidence

> All in all, although the introduction of bimetals may lead to a decrease in the thermal stability of MOFs, the MOFs still maintain a high stability ... Cu(BDC)TED0.5 has the worst thermal stability and begins to decompose at 300 °C while Ni(BDC)TED0.5 ... can reach up 400 °C. ... the thermal stability of Cu0.5Ni0.5(BDC)TED0.5 has improved compared to that of Cu(BDC)TED0.5.

## Links

- Source: [[sources/src_340141308b]]