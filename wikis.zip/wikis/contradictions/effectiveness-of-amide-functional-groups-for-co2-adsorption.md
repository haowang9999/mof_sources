---
title: "effectiveness of amide functional groups for CO2 adsorption"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_a034d4944a]
confidence: medium
---


# effectiveness of amide functional groups for CO2 adsorption

## Claim A

The review reports that amide functional groups (and amine/hydroxyl) show high performance in CO2 separation in MOFs with CO2 vacancies via Lewis basicity/polarity/H-bonding.

## Claim B

A cited reference indicates 'Amides Do Not Always Work: Observation of Guest Binding in an Amide-Functionalized Porous Metal-Organic Framework', showing amide functionalization can fail in some specific frameworks.

## Condition-based resolution

Amide (and other) functionalization can improve CO2 interactions in many MOFs with accessible sites, but in some frameworks amide-functionalization does not produce the expected guest binding — effectiveness is framework- and site-accessibility-dependent.

## Agent warning

Do not assume amide functionalization will always improve CO2 capture; validate on the specific framework and consider steric accessibility, pore environment, and competing guest interactions.

## Evidence

> The high performance of the amine, amide and hydroxyl functions in CO2 separation was observed in MOFs with CO2 vacancies. (page 14) || Cited reference title: 'Amides Do Not Always Work: Observation of Guest Binding in an Amide-Functionalized Porous Metal-Organic Framework.'

## Links

- Source: [[sources/src_a034d4944a]]