---
title: "Detecting pore-size effects: spectroscopy vs energetics"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_c88d608b3b]
confidence: medium
---


# Detecting pore-size effects: spectroscopy vs energetics

## Claim A

XAFS spectroscopy did not detect changes to the first coordination shell of Lu3+ when comparing UiO-66 and UiO-68 (modest pore/window differences).

## Claim B

Prior calorimetry studies on porous materials detected pore-size impacts on adsorption energetics that were not evident from spectroscopic speciation alone.

## Condition-based resolution

XAFS-first-shell invariance does not preclude pore-size effects on adsorption thermodynamics or kinetics; calorimetry or other energetic probes can reveal differences even when first-shell geometry is unchanged.

## Agent warning

Complement spectroscopic speciation with energetic measurements (calorimetry) and adsorption capacity/kinetics studies to fully assess pore-size impacts.

## Evidence

> "The first Lu−O shell is identical for the four MOFs... This indicates that the decrease in the window apertures and pore diameters in UiO-66 vs UiO-68 has no impact on the first coordination shell of Lu3+, at least at a level that could be detected spectroscopically."; "no pore-size dependency on surface speciation could be detected spectroscopically when pore diameters decreased from 7 to 4 nm; however, pore-size impact on adsorption was detected and quantified with calorimetric measurements..."

## Links

- Source: [[sources/src_c88d608b3b]]