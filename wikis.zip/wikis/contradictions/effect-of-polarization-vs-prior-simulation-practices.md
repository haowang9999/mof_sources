---
title: "Effect of polarization vs prior simulation practices"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_532b708453]
confidence: high
---


# Effect of polarization vs prior simulation practices

## Claim A

Previous simulations of hydrogen sorption often neglected many-body polarization and focused on quadrupole interactions.

## Claim B

This work shows many-body polarization is the dominant contribution to H2 physisorption in soc-MOF and can be ~4x larger than quadrupolar interactions in representative geometries.

## Condition-based resolution

For charged frameworks and narrow pores (as in soc-MOF), include many-body polarization; older approaches that omit it will miss the dominant binding term.

## Agent warning

Do not assume quadrupole and van der Waals terms alone capture binding in charged, narrow-pore MOFs; update modeling protocols to include many-body polarization for such systems.

## Evidence

> Previous simulations of hydrogen storage in MOFs and other materials have not focused on the role of polarization effects, but they are demonstrated here to be the dominant contribution to hydrogen physisorption. ... As an estimate ... the polarization energy is a factor of 4 larger and is always attractive.

## Links

- Source: [[sources/src_532b708453]]