---
title: "Effect of interpenetration on surface area (framework-dependence)"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_fa8cccd644]
confidence: high
---


# Effect of interpenetration on surface area (framework-dependence)

## Claim A

Interpenetration can decrease surface area (Table 2 notes).

## Claim B

In PCN-6 and some other systems, interpenetration increased measured Langmuir/BET surface area and improved H2 uptake.

## Condition-based resolution

The effect of interpenetration on measured surface area is framework- and topology-dependent; interpenetration can either increase or decrease SSA depending on how it affects pore connectivity and measurement methodology.

## Agent warning

Do not assume interpenetration will always reduce or always increase SSA — evaluate experimentally or via simulation for each framework.

## Evidence

> Table 2 mentions potential decrease in surface area with interpenetration, whereas PCN-6 interpenetration increased Langmuir SA from 2700 to 3800 m2 g−1 (41% increase) and raised volumetric and gravimetric H2 uptake.

## Links

- Source: [[sources/src_fa8cccd644]]