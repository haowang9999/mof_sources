---
title: "halogenated MOFs as top CO2 performers (prior HTCS vs DFT-corrected results)"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_c42cf01235]
confidence: high
---


# halogenated MOFs as top CO2 performers (prior HTCS vs DFT-corrected results)

## Claim A

Previous HTCS studies reported halogenated MOFs among top performers for CO2 capture.

## Claim B

Those prior results are likely artefacts because electronegativity-equalization charge methods overestimate halogen charges; DFT-fitted MBBB/REPEAT charges yield different (more reliable) adsorption predictions.

## Condition-based resolution

Re-evaluate halogenated MOFs using DFT-fitted charge schemes (MBBB or REPEAT) or validated equilibration parameterizations rather than electronegativity-equalization to determine true performance.

## Agent warning

Do not trust HTCS rankings that used electronegativity-equalization charge assignment for systems where electrostatics matter (e.g., halogenated linkers); re-run with DFT-derived or validated charges before prioritizing halogenated candidates.

## Evidence

> “issues with computational cost have motivated the use of inexpensive 'electronegativity equalization' methods to assign Coulomb charges...Such processes overestimate charges of, for instance, halogens...Thus, in previous HTCS studies, halogenated MOFs were consistently found as top performers for CO2 capture...we have demonstrated that the use of molecular building block-based (MBBB) charges...result in sorption loadings and mechanisms consistent with those obtained with charges that fit the DFT-calculated ESP in the MOF unit cell (e.g., REPEAT charges)."

## Links

- Source: [[sources/src_c42cf01235]]