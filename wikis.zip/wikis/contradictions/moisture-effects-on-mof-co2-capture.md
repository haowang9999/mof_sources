---
title: "moisture effects on MOF CO2 capture"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_c42cf01235]
confidence: medium
---


# moisture effects on MOF CO2 capture

## Claim A

Some MOFs (e.g., a nickel isonicotinate MOF cited) achieve excellent moisture stability for postcombustion CO2 capture.

## Claim B

Humidity affects CO2 capture chemistry in amine-functionalized MOFs and can change capture energetics/behavior.

## Condition-based resolution

Material-specific: some MOFs are moisture-stable while others show humidity-dependent behavior; performance must be verified for the target material and conditions.

## Agent warning

Do not generalize moisture stability across MOFs; include humidity testing early when designing capture materials.

## Evidence

> References: "Ultralow Parasitic Energy for Postcombustion CO2 Capture Realized in a Nickel Isonicotinate Metal−Organic Framework with Excellent Moisture Stability."; "The Chemistry of CO2 Capture in an Amine-Functionalized Metal−Organic Framework under Dry and Humid Conditions."

## Links

- Source: [[sources/src_c42cf01235]]