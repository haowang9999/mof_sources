---
title: "Defect count vs SSA / final porosity (nonlinear dependence)"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_20cacd73e1]
confidence: high
---


# Defect count vs SSA / final porosity (nonlinear dependence)

## Claim A

Higher number of missing ligands correlates with larger SSA (positive correlation observed across some samples).

## Claim B

Samples with comparable missing-ligand counts (e.g., 150eq vs 200eq) show substantially different SSA, indicating defect count alone does not fully determine SSA.

## Condition-based resolution

Defect type, spatial distribution (missing-linker vs missing-cluster), particle size, pore connectivity and metal identity also affect final porosity and SSA; thus the number of missing ligands is a contributing but not exclusive determinant of SSA and accessible porosity.

## Agent warning

Do not assume a linear mapping from 'number of missing ligands' to SSA; validate with pore-size distribution, particle-size and surface-area measurements and consider metal identity and defect type.

## Evidence

> Figure 2e shows a trend where samples with higher numbers of missing ligands tended to exhibit larger SSA; however, despite comparable missing-ligand counts between Ce-MOF-801-150eq and Ce-MOF-801-200eq, the latter displayed substantially lower SSA (404.10 m2/g), suggesting other structural factors modulate final textural properties.

## Links

- Source: [[sources/src_20cacd73e1]]