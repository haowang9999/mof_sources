---
title: "maximum achievable spillover capacity on IRMOF-1"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_0abff73929]
confidence: high
---


# maximum achievable spillover capacity on IRMOF-1

## Claim A

Simple site-counting (12 H sites per BDC linker) suggests a theoretical maximum of ∼4.5 wt% H2 excess.

## Claim B

DFT calculations find structures with more than six added H atoms are unstable with respect to forming H2; the thermodynamic sink is the six-H state (∼2.3 wt% excess), so ∼4.5 wt% is not supported thermodynamically.

## Condition-based resolution

Site counting neglects reaction energetics. Thermodynamic (DFT) analysis indicates only the six-H hydrogenation state is a stable sink under modeled conditions; therefore estimates based purely on nominal site counts overpredict achievable chemisorbed-H capacity for IRMOF-1.

## Agent warning

Do not rely on nominal binding-site counts to predict achievable spillover capacity; validate with thermodynamic and kinetic modeling or experiments before using site-count-based targets.

## Evidence

> "Suri et al.15 obtained similar binding energies for H on the linker sites but suggested, by counting 12 possible H binding sites on the BDC linker, that ∼4.5 wt % H2 could potentially be stored in IRMOF-1 by spillover. However, it was clearly shown in the calculations that structures with more than six added H atoms are unstable with respect to forming H2, so that such high capacities cannot be expected by IRMOF-1."

## Links

- Source: [[sources/src_0abff73929]]