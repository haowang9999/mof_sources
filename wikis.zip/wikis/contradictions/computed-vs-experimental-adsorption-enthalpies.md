---
title: "Computed vs experimental adsorption enthalpies"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_532b708453]
confidence: medium
---


# Computed vs experimental adsorption enthalpies

## Claim A

Computed integral adsorption enthalpies for H2 in soc-MOF are -10.6 to -14.4 kJ/mol (polarizable simulations).

## Claim B

Experimental isosteric heat measurements for soc-MOF give a relatively constant qst of about 6.5 kJ/mol.

## Condition-based resolution

Authors note the discrepancy, validate computational approach by reproducing IRMOF-1 values that agree with experiment, and emphasize that polarization is critical in soc-MOF despite quantitative differences.

## Agent warning

Do not assume computed adsorption enthalpies will exactly match experiment for soc-MOF; validate with experiments or alternative simulation checks. Use computed polarization trends qualitatively rather than relying on absolute enthalpy magnitudes without calibration.

## Evidence

> These enthalpies appear large compared to the experimental measurements that give a relatively constant isosteric heat of sorption of about 6.5 kJ mol-1. ... all of the evidence does clearly support that polarization is a critical factor influencing sorption in soc-MOF. ... As a control, the integral heats of sorption in IRMOF-1 at the low-density limit were calculated ... The result was ∆Hunsat_a = -5.998 ( 0.298 kJ mol-1, in good agreement with extant values.

## Links

- Source: [[sources/src_532b708453]]