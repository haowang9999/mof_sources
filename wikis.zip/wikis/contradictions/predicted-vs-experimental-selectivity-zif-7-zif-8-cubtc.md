---
title: "predicted vs experimental selectivity (ZIF-7, ZIF-8, CuBTC)"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_97052fb350]
confidence: medium
---


# predicted vs experimental selectivity (ZIF-7, ZIF-8, CuBTC)

## Claim A

Simulations predict extremely high H2/CH4 selectivities for some MOFs (orders of magnitude) and specific ideal selectivities (e.g., CuBTC favors CH4 in Henry regime).

## Claim B

Thin-film experimental measurements report only modest H2/CH4 selectivities for ZIF-7/ZIF-8 and differing selectivities for CuBTC; discrepancies exist between predicted intrinsic and measured apparent selectivities.

## Condition-based resolution

Authors attribute the discrepancies largely to microstructural defects in intergrown thin films (grain boundaries), orientation issues, or film processing, and note that more experimental and microstructural characterization is needed to resolve specific cases.

## Agent warning

Treat high intrinsic selectivity predictions with caution; prioritize experimental assessment of film quality, defect density, crystal orientation, and consider mixed-matrix membranes to probe intrinsic behavior.

## Evidence

> Our calculations predict extremely high H2/CH4 selectivities for these two materials ... These predicted selectivities are orders of magnitude larger than the modest selectivities that have been seen experimentally. ... For CuBTC, our calculations predict an ideal selectivity that favors CH4 by a factor of ∼3. ... Experimentally, however, low selectivities favoring H2 are observed.

## Links

- Source: [[sources/src_97052fb350]]