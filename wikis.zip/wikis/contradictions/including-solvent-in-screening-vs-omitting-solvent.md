---
title: "Including solvent in screening vs. omitting solvent"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_8ce39338bc]
confidence: high
---


# Including solvent in screening vs. omitting solvent

## Claim A

Pure-component (dry) GCMC simulations adequately capture theoretical maximum loading and are suitable for initial high-throughput screening.

## Claim B

MD and free-energy calculations with explicit water reveal favorable cisplatin–solvation interactions which can prevent achieving theoretical dry-GCMC loading unless pores accommodate the solvation shell or MOF–cisplatin interactions outcompete solvation.

## Condition-based resolution

Use dry GCMC for rapid initial screening (upper-bound capacity). Follow up promising candidates with solvent-explicit MD/BAR to confirm that solvation does not prevent practical loading; treat dry-GCMC numbers as upper bounds, not guaranteed realized loadings.

## Agent warning

Do not assume nGCMC maxima will be achieved experimentally; validate top candidates with explicit-solvent simulations or experiments.

## Evidence

> Pure-component GCMC simulations adequately capture maximum reported experimental loading as an upper bound. However, MD simulations in the presence of water reveal favorable interaction energies between cisplatin and its solvation shell, which might result in theoretical loading not being achieved experimentally unless pore size or MOF–drug energetics compensate.

## Links

- Source: [[sources/src_8ce39338bc]]