---
title: "BET applicability for MOFs"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_ff1b0c9d63]
confidence: high
---


# BET applicability for MOFs

## Claim A

BET theory and the common p/p0 range (0.05–0.3) are commonly used to calculate surface areas and can give reasonable values in many cases.

## Claim B

For supermicroporous and ultramicroporous MOFs the BET calculation can be inaccurate; BET must be adapted and limited to appropriate ranges with specific criteria (Llewellyn et al.).

## Condition-based resolution

Apply the Llewellyn et al. criteria (linearity of n(1−p/p0), positive C≥10, nm within linear region), be aware of probe-molecule dependence and framework deformation; use alternative probes or methods where appropriate.

## Agent warning

Do not blindly apply the standard BET 0.05–0.3 p/p0 range for microporous MOFs; validate the BET fit and consider complementary measurements.

## Evidence

> It has been shown that the BET surface area calculated from the N2 adsorption isotherm obtained by the GCMC simulation is very similar to the experimental BET surface area... In the case of supermicroporous MOFs and ultramicroporous materials with pores that vary in terms of size, form, and chemical surroundings, the BET calculation on the surface area is inaccurate. In 2007, Llewellyn et al. recommended consistent criteria ... I. Senkovska and S. Kaskel concluded that strong surface tension effects during subcritical adsorption can cause deformation of adsorbent structure ... the BET equation to determine the surface area of MOFs should be adapted to a specific situation.

## Links

- Source: [[sources/src_ff1b0c9d63]]