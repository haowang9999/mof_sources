---
title: "applicability of LJ, nonpolar adsorbate models to CO2"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_97052fb350]
confidence: medium
---


# applicability of LJ, nonpolar adsorbate models to CO2

## Claim A

The authors intentionally limit their calculations to nonpolar adsorbates and avoid assigning framework charges; the LJ-based calculations therefore exclude electrostatic interactions.

## Claim B

The authors nevertheless use kinetic diameters of CO2 (and CH4) in PLD-based heuristics to suggest MOFs for CO2/CH4 separation.

## Condition-based resolution

The use of CO2 kinetic diameter is presented only as a simplistic heuristic for initial filtering; the LJ-based adsorption and diffusion calculations in the paper were not applied to CO2 because electrostatic interactions were intentionally omitted. Follow-up modeling including framework partial charges and explicit CO2 models is recommended for CO2-related decisions.

## Agent warning

Treat any conclusions about CO2 from LJ/nonpolar screening as provisional heuristics only; perform follow-up modeling including framework partial charges and explicit CO2 models before decision-making.

## Evidence

> We further limit our attention to nonpolar adsorbates, since this removes the necessity of assigning charges to each MOF framework atom... A useful, albeit simplistic, way to use the data in Figure 4 to select materials that may have value for kinetic separations is to compare the calculated pore-limiting diameters with the kinetic diameters of diffusing molecules.

## Links

- Source: [[sources/src_97052fb350]]