---
title: "Affinity (Qst) vs pore-volume effects on iodine uptake/selectivity"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_fc58db74fa]
confidence: high
---


# Affinity (Qst) vs pore-volume effects on iodine uptake/selectivity

## Claim A

Increasing affinity (Qst) via polar functionalization enhances iodine selectivity.

## Claim B

Functionalization-induced pore-volume reduction can lower I2 uptake despite increased selectivity.

## Condition-based resolution

Affinity improvements (higher Qst) increase selectivity, but for large species like I2 the absolute uptake is strongly limited by available pore volume/steric space; for CH3I uptake within the MIL-53-Al-X series is more affinity-driven and less sensitive to modest pore-volume loss.

## Agent warning

Do not assume that raising binding energy via heavy functionalization will increase capacity for large adsorbates; always evaluate pore-volume changes and competitive adsorption with water. Trade-offs differ between I2 and CH3I and depend on the specific MOF geometry and degree of pore blocking.

## Evidence

> “the functionalization of the polarized functional groups did enhance the I2 selectivity ... but the I2 adsorption amounts did not have the obvious enhancement. ... it was attributed to the smaller pore volume and bigger steric hindrance that limited the I2 uptake ... The CH3I uptake amounts and selectivity were positively correlated with the Qst of CH3I ... The impact of the functionalization-induced reduction in pore volume was nearly negligible (Figure S5).”

## Links

- Source: [[sources/src_fc58db74fa]]