---
title: "direct dopant–H2 binding predicted computationally vs. experimental observation of unchanged Qst and cation shielding in catenated MOFs"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_b0ea8c70ab]
confidence: medium
---


# direct dopant–H2 binding predicted computationally vs. experimental observation of unchanged Qst and cation shielding in catenated MOFs

## Claim A

Computational studies predict that direct interaction of dopant ions with H2 (in accessible environments) can dramatically increase H2 uptake (up to ~500% under some conditions) and increase heats of adsorption by several kJ/mol.

## Claim B

Experimental observations for the triply-catenated MOF show little or no change in isosteric heats of adsorption after alkali-metal doping and indicate dopant cations are structurally shielded (or otherwise inaccessible), so direct dopant–H2 interactions are not responsible for the observed uptake enhancements.

## Condition-based resolution

The computational potential applies when dopant ions are exposed and can directly interact with H2; in the studied triply catenated frameworks the dopants are embedded/shielded (1H NMR rules out solvation as the reason) and the observed uptake enhancements correlate with increased BET/micropore area rather than increased Qst. Thus the computational predictions are not contradicted per se, but their applicability is limited by dopant accessibility in catenated systems.

## Agent warning

Do not assume computationally predicted large increases in ambient-temperature/high-pressure H2 binding will be realized in catenated MOFs with embedded/shielded dopants. Verify cation accessibility, Qst, and pore metrics experimentally; if direct ion–H2 binding is desired, redesign toward single, non-catenated networks that expose dopant sites.

## Evidence

> Recent computational studies suggest ... provided that direct interaction of dopant ions with hydrogen can be achieved. Remarkably, the enhancements are obtained without significant changes in heats of adsorption, implying that H2 molecules do not interact directly with dopant metal ions. To test the second idea, we determined the post evacuation solvent content... We can therefore rule out cation solvation as a factor... We conclude instead that the added cations are shielded by the catenated frameworks themselves from direct interaction with adsorbents.

## Links

- Source: [[sources/src_b0ea8c70ab]]