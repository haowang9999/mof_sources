---
title: "Use of kinetic diameter vs actual diffusion behavior"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_97052fb350]
confidence: high
---


# Use of kinetic diameter vs actual diffusion behavior

## Claim A

If PLD is smaller than the kinetic diameter of a gas, that gas cannot permeate the MOF (strict size exclusion).

## Claim B

Even when PLD is smaller than the nominal kinetic diameter, finite energy barriers (and framework flexibility) can permit diffusion — e.g., CO2 diffuses with ~10 kJ/mol barrier while CH4 faces ~70 kJ/mol in a reported MOF example.

## Condition-based resolution

Kinetic diameters are heuristics; when PLD is near or slightly below kinetic diameters, compute energetic diffusion barriers (including framework flexibility) because adsorption/interatomic interactions set finite activation energies that determine permeation rates.

## Agent warning

Do not use a strict PLD < kinetic diameter cutoff to exclude materials; perform energy-barrier calculations for borderline PLD values to avoid discarding promising kinetic-separation materials.

## Evidence

> It is important to note that the use of kinetic diameters outlined above cannot be taken literally... CH4 could diffuse in this material by overcoming an energy barrier of ∼70 kJ/mol... CO2 experiences an energy barrier to diffusion in the same material of ∼10 kJ/mol

## Links

- Source: [[sources/src_97052fb350]]