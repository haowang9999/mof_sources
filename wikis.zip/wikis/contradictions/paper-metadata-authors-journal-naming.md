---
title: "paper metadata (authors / journal naming)"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_0abff73929]
confidence: medium
---


# paper metadata (authors / journal naming)

## Claim A

Some chunk-level records list authors as George M. Psofogiannakis and George E. Froudakis; others list only G. E. Froudakis or no authors.

## Claim B

Journal name is variably given as 'J. Phys. Chem. C' and 'Journal of Physical Chemistry C'.

## Condition-based resolution

The merged metadata uses the most specific non-empty author list available (George M. Psofogiannakis; George E. Froudakis) and provides the full journal name with abbreviation. Users should note alternate attributions in some source records.

## Agent warning

If exact bibliographic attribution is critical (e.g., citation indexing), verify author lists and journal naming against the publisher/DOI record.

## Evidence

> Chunk records include varying author lists and journal name forms; DOI 10.1021/jp109541n is consistent across records.

## Links

- Source: [[sources/src_0abff73929]]