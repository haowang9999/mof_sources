---
title: "adsorption energetics: simulation vs experiment"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_83cde498f9]
confidence: high
---


# adsorption energetics: simulation vs experiment

## Claim A

GCMC/DFT simulations predict binding energies/zero-coverage enthalpies around −39 to −43 kJ mol−1 (simulated ~39.5 kJ mol−1 zero-coverage Qst).

## Claim B

Experimental zero-coverage Qst determined from isotherm fitting is ~27.5–27.6 kJ mol−1.

## Condition-based resolution

The authors note that simulated zero-coverage Qst values are higher than experimental outcomes and that this overestimation may explain overprediction of low-pressure uptake in simulations.

## Agent warning

Do not rely solely on simulation-derived enthalpies to predict regeneration energy or low-pressure uptake; use experimental Qst for process design and treat simulated binding energies as likely upper-bound estimates.

## Evidence

> Pages 5-6: "The binding energy for the MC-minimized site was estimated to be −39.4 kJ mol−1 ... binding energy: −42.7 kJ mol−1. ... one explanation being that the simulated zero-coverage Qst values are higher than the experimental outcomes (∼39.5 vs 27.6 kJ mol−1)."; LF model ΔU (CO2) = −27.6015 kJ mol−1 from experimental fitting.

## Links

- Source: [[sources/src_83cde498f9]]