---
title: "effect of catenation/interpenetration on H2 adsorption"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_ff1b0c9d63]
confidence: medium
---


# effect of catenation/interpenetration on H2 adsorption

## Claim A

Catenation (e.g., PCN-6) increased H2 uptake at higher pressures compared to non-catenated analogue (PCN-60): at 77 K and 50 bar na = 8.7 wt% (PCN-6) vs 5.5 wt% (PCN-60).

## Claim B

Catenation can reduce low-pressure H2 uptake by blocking open metal sites and excessive interpenetration can reduce BET area and uptake.

## Condition-based resolution

Catenation's impact is condition- and degree-dependent: moderate catenation can reduce pore size and improve high-pressure uptake via stronger host–guest interactions, while it can simultaneously block open metal sites or reduce accessible surface area important for low-pressure adsorption.

## Agent warning

Do not assume catenation universally improves H2 uptake; evaluate target pressure/temperature range and check OMS accessibility and BET area when considering catenation strategies.

## Evidence

> INS experiments suggested that in these MOFs, the open metal sites are most favorable for the H2 molecules, and at higher P values, the interaction between the H2 molecules and the organic linkers becomes stronger in the catenated PCN-6. Table 3: at 77 K and 50 bar, na = 8.7 wt% (PCN-6) vs 5.5 wt% (PCN-60). ... after activation at 323 K, H2 adsorption at 77 K and 1 bar was 1.74 and 1.35 wt% for PCN-6 and PCN-60, whereas after activation at 423 K these values increased to 1.9 and 1.62 wt%, respectively. The larger improvement in H2 adsorption for the non-catenated PCN-60 was explained by the open metal sites, which were blocked in the catenated PCN-6. When MOFs are catenated too much, they show very low H2 adsorption.

## Links

- Source: [[sources/src_ff1b0c9d63]]