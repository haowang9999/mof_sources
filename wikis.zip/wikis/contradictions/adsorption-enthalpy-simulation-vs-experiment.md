---
title: "adsorption_enthalpy_simulation_vs_experiment"
type: contradiction
tags: [contradiction, caveat]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_532b708453]
confidence: medium
---


# adsorption_enthalpy_simulation_vs_experiment

## Claim A

Simulated integral enthalpies for H2 adsorption in soc-MOF are −14.35 kJ/mol (unsaturated) and −10.65 kJ/mol (saturated), with polarization contributing ~23–27%.

## Claim B

Experimentally measured isosteric heat of sorption for soc-MOF is about 6.5 kJ/mol (relatively constant).

## Condition-based resolution

Authors note conceptual and practical reasons these quantities can be compared under certain assumptions, but nevertheless the simulated values exceed the reported experimental isosteric heat. Use polarization-inclusive models for mechanistic insight, but validate simulated energetics against isotherm-derived heats where possible and consider model/parameter uncertainties (e.g., estimated polarizabilities, classical treatment of nuclear motion).

## Agent warning

Treat simulated adsorption enthalpies for soc-MOF with caution; discrepancies with experiment exist and are acknowledged.

## Evidence

> ΔHsat_a was found to be -10.645 ( 0.188 kJ mol-1, while the unsaturated state yielded ΔHunsat_a of -14.354 ( 1.685 kJ mol-1; ... Polarization contributed 23% ... These enthalpies appear large compared to the experimental measurements that give a relatively constant isosteric heat of sorption of about 6.5 kJ mol-1.

## Links

- Source: [[sources/src_532b708453]]