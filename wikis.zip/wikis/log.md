# Wiki Log

## [2026-05-01 23:15:08] init | Created empty MOF Mechanism LLM Wiki

## [2026-05-01 23:15:08] init | Initialized wiki directories and index

## [2026-05-01 23:30:45] init | Initialized wiki directories and index

## [2026-05-02 00:22:52] ingest | 1-s2.0-S1387181110000673-main.pdf

- source_id=src_8d4a290e19
- primary_task=h2
- task_tags=h2
- mechanisms=6
- design_rules=3
- contradictions=1
- updated_topics=wiki/topics/h2_adsorption.md, wiki/topics/cross_task_tradeoffs.md

## [2026-05-02 01:45:11] ingest | 244703_1_online.pdf

- source_id=src_8ce39338bc
- primary_task=pld
- task_tags=pld
- mechanisms=12
- design_rules=6
- contradictions=2
- updated_topics=wiki/topics/pld_design.md, wiki/topics/cross_task_tradeoffs.md

## [2026-05-02 02:09:24] ingest | 291.pdf

- source_id=src_90ad344e79
- primary_task=pld
- task_tags=pld, co2, mixed
- mechanisms=6
- design_rules=3
- contradictions=1
- updated_topics=wiki/topics/pld_design.md, wiki/topics/co2_adsorption.md, wiki/topics/cross_task_tradeoffs.md

## [2026-05-02 05:14:23] ingest | A_review_on_modified_MOFs_as_CO2_adsorbents_using_.pdf

- source_id=src_a034d4944a
- primary_task=co2
- task_tags=co2, pld, mixed
- mechanisms=11
- design_rules=7
- contradictions=2
- updated_topics=wiki/topics/co2_adsorption.md, wiki/topics/pld_design.md, wiki/topics/cross_task_tradeoffs.md

## [2026-05-02 06:07:08] ingest | Computational_Screening_of_Metal-Organic_Framework.pdf

- source_id=src_90953381a0
- primary_task=mixed
- task_tags=co2, h2, pld, mixed
- mechanisms=13
- design_rules=6
- contradictions=2
- updated_topics=wiki/topics/co2_adsorption.md, wiki/topics/h2_adsorption.md, wiki/topics/pld_design.md, wiki/topics/cross_task_tradeoffs.md

## [2026-05-02 07:32:27] ingest | a-fine-tuned-fluorinated-mof-addresses-the-needs-for-trace-co2-removal-and-air-capture-using-physisorption.pdf

- source_id=src_36df794947
- primary_task=co2
- task_tags=co2, pld, mixed
- mechanisms=7
- design_rules=3
- contradictions=1
- updated_topics=wiki/topics/co2_adsorption.md, wiki/topics/pld_design.md, wiki/topics/cross_task_tradeoffs.md

## [2026-05-02 10:03:28] ingest | an-amine-functionalized-ultramicroporous-metal-organic-framework-for-postcombustion-co2-capture.pdf

- source_id=src_83cde498f9
- primary_task=co2
- task_tags=co2, pld, mixed
- mechanisms=10
- design_rules=2
- contradictions=2
- updated_topics=wiki/topics/co2_adsorption.md, wiki/topics/pld_design.md, wiki/topics/cross_task_tradeoffs.md

## [2026-05-02 12:42:57] ingest | d3me00016h.pdf

- source_id=src_71bcf59437
- primary_task=h2
- task_tags=h2, pld, mixed
- mechanisms=14
- design_rules=10
- contradictions=1
- updated_topics=wiki/topics/h2_adsorption.md, wiki/topics/pld_design.md, wiki/topics/cross_task_tradeoffs.md

## [2026-05-02 13:49:24] ingest | d4nr03969f.pdf

- source_id=src_fa8cccd644
- primary_task=h2
- task_tags=h2, pld, mixed
- mechanisms=22
- design_rules=10
- contradictions=4
- updated_topics=wiki/topics/h2_adsorption.md, wiki/topics/pld_design.md, wiki/topics/cross_task_tradeoffs.md

## [2026-05-02 15:47:42] ingest | defect-engineering-in-ce-based-metal-organic-frameworks-toward-enhanced-catalytic-performance-for-hydrogenation-of.pdf

- source_id=src_20cacd73e1
- primary_task=pld
- task_tags=pld
- mechanisms=9
- design_rules=5
- contradictions=3
- updated_topics=wiki/topics/pld_design.md, wiki/topics/cross_task_tradeoffs.md

## [2026-05-02 16:00:28] ingest | designing-adsorptive-gating-via-linker-side-chain-functionalization-in-a-honeycomb-mof.pdf

- source_id=src_a318a71841
- primary_task=pld
- task_tags=co2, pld, mixed
- mechanisms=11
- design_rules=8
- contradictions=3
- updated_topics=wiki/topics/co2_adsorption.md, wiki/topics/pld_design.md, wiki/topics/cross_task_tradeoffs.md

## [2026-05-02 16:16:22] ingest | efficient-calculation-of-diffusion-limitations-in-metal-organic-framework-materials-a-tool-for-identifying-materials.pdf

- source_id=src_97052fb350
- primary_task=pld
- task_tags=pld, h2, co2, mixed
- mechanisms=19
- design_rules=11
- contradictions=3
- updated_topics=wiki/topics/pld_design.md, wiki/topics/h2_adsorption.md, wiki/topics/co2_adsorption.md, wiki/topics/cross_task_tradeoffs.md

## [2026-05-02 16:27:22] ingest | enhancing-hydrogen-adsorption-capacity-of-metal-organic-frameworks-m(bdc)ted0-5-through-constructing-a-bimetallic.pdf

- source_id=src_340141308b
- primary_task=h2
- task_tags=h2, pld, mixed
- mechanisms=9
- design_rules=6
- contradictions=1
- updated_topics=wiki/topics/h2_adsorption.md, wiki/topics/pld_design.md, wiki/topics/cross_task_tradeoffs.md

## [2026-05-02 16:40:34] ingest | fchem-08-574622.pdf

- source_id=src_20dae1036b
- primary_task=co2
- task_tags=co2, pld, mixed
- mechanisms=13
- design_rules=8
- contradictions=3
- updated_topics=wiki/topics/co2_adsorption.md, wiki/topics/pld_design.md, wiki/topics/cross_task_tradeoffs.md

## [2026-05-02 16:51:05] ingest | fmats-05-00004.pdf

- source_id=src_1fa85425f9
- primary_task=co2
- task_tags=co2, pld, mixed
- mechanisms=13
- design_rules=10
- contradictions=2
- updated_topics=wiki/topics/co2_adsorption.md, wiki/topics/pld_design.md, wiki/topics/cross_task_tradeoffs.md

## [2026-05-02 17:01:24] ingest | framework-reduction-and-alkali-metal-doping-of-a-triply-catenating-metal-organic-framework-enhances-and-then-diminishes.pdf

- source_id=src_b0ea8c70ab
- primary_task=h2
- task_tags=h2, pld, mixed
- mechanisms=7
- design_rules=4
- contradictions=1
- updated_topics=wiki/topics/h2_adsorption.md, wiki/topics/pld_design.md, wiki/topics/cross_task_tradeoffs.md

## [2026-05-02 17:20:31] ingest | hydrogen-adsorption-in-metalorganic-frameworks-4.pdf

- source_id=src_b1552d4a9d
- primary_task=h2
- task_tags=h2, pld, mixed
- mechanisms=20
- design_rules=12
- contradictions=4
- updated_topics=wiki/topics/h2_adsorption.md, wiki/topics/pld_design.md, wiki/topics/cross_task_tradeoffs.md

## [2026-05-02 17:29:06] ingest | local-coordination-environment-of-lanthanides-adsorbed-onto-cr-and-zr-based-metal-organic-frameworks.pdf

- source_id=src_c88d608b3b
- primary_task=pld
- task_tags=pld
- mechanisms=8
- design_rules=7
- contradictions=5
- updated_topics=wiki/topics/pld_design.md, wiki/topics/cross_task_tradeoffs.md

## [2026-05-02 17:39:16] ingest | main.pdf

- source_id=src_fc58db74fa
- primary_task=pld
- task_tags=pld
- mechanisms=17
- design_rules=11
- contradictions=2
- updated_topics=wiki/topics/pld_design.md, wiki/topics/cross_task_tradeoffs.md

## [2026-05-02 18:07:09] ingest | nanomaterials-11-01638.pdf

- source_id=src_ff1b0c9d63
- primary_task=h2
- task_tags=h2, pld, mixed
- mechanisms=40
- design_rules=15
- contradictions=4
- updated_topics=wiki/topics/h2_adsorption.md, wiki/topics/pld_design.md, wiki/topics/cross_task_tradeoffs.md

## [2026-05-02 18:14:51] ingest | on-the-mechanism-of-hydrogen-storage-in-a-metal-organic-framework-material (1).pdf

- source_id=src_532b708453
- primary_task=h2
- task_tags=h2
- mechanisms=17
- design_rules=6
- contradictions=3
- updated_topics=wiki/topics/h2_adsorption.md, wiki/topics/cross_task_tradeoffs.md

## [2026-05-02 18:24:20] ingest | on-the-mechanism-of-hydrogen-storage-in-a-metal-organic-framework-material.pdf

- source_id=src_532b708453
- primary_task=h2
- task_tags=h2, pld, mixed
- mechanisms=12
- design_rules=7
- contradictions=3
- updated_topics=wiki/topics/h2_adsorption.md, wiki/topics/pld_design.md, wiki/topics/cross_task_tradeoffs.md

## [2026-05-02 18:31:36] ingest | regulation-of-catenation-in-metal-organic-frameworks-with-tunable-clathrochelate-based-building-blocks.pdf

- source_id=src_3b254ae858
- primary_task=pld
- task_tags=pld
- mechanisms=13
- design_rules=5
- contradictions=2
- updated_topics=wiki/topics/pld_design.md, wiki/topics/cross_task_tradeoffs.md

## [2026-05-02 18:45:33] ingest | role-of-pore-chemistry-and-topology-in-the-co2-capture-capabilities-of-mofs-from-molecular-simulation-to-machine.pdf

- source_id=src_c42cf01235
- primary_task=co2
- task_tags=co2, pld, h2, mixed
- mechanisms=15
- design_rules=7
- contradictions=5
- updated_topics=wiki/topics/co2_adsorption.md, wiki/topics/pld_design.md, wiki/topics/h2_adsorption.md, wiki/topics/cross_task_tradeoffs.md

## [2026-05-02 18:50:53] ingest | significantly-enhanced-hydrogen-storage-in-metal-organic-frameworks-via-spillover.pdf

- source_id=src_572b475183
- primary_task=h2
- task_tags=h2
- mechanisms=0
- design_rules=0
- contradictions=0
- updated_topics=wiki/topics/h2_adsorption.md, wiki/topics/cross_task_tradeoffs.md

## [2026-05-02 19:02:37] ingest | theoretical-explanation-of-hydrogen-spillover-in-metal-organic-frameworks.pdf

- source_id=src_0abff73929
- primary_task=h2
- task_tags=h2, pld, mixed
- mechanisms=11
- design_rules=5
- contradictions=5
- updated_topics=wiki/topics/h2_adsorption.md, wiki/topics/pld_design.md, wiki/topics/cross_task_tradeoffs.md
