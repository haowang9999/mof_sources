---
title: "Cross-task Tradeoffs: CO2, H2, and PLD"
type: topic
tags: [co2, h2, pld, tradeoff, design_rule, membranes, fluorinated]
created: "2026-05-01"
updated: "2026-05-02"
sources: [[sources/src_8d4a290e19]] [[sources/src_8ce39338bc]] [[sources/src_90ad344e79]] [[sources/src_a034d4944a]] [[sources/src_90953381a0]] [[sources/src_36df794947]] [[sources/src_83cde498f9]] [[sources/src_71bcf59437]] [[sources/src_fa8cccd644]] [[sources/src_20cacd73e1]] [[sources/src_a318a71841]] [[sources/src_97052fb350]] [[sources/src_340141308b]] [[sources/src_20dae1036b]] [[sources/src_1fa85425f9]] [[sources/src_b0ea8c70ab]] [[sources/src_b1552d4a9d]] [[sources/src_c88d608b3b]] [[sources/src_fc58db74fa]] [[sources/src_ff1b0c9d63]] [[sources/src_532b708453]] [[sources/src_3b254ae858]] [[sources/src_c42cf01235]] [[sources/src_572b475183]] [[sources/src_0abff73929]]
confidence: medium
---

# Cross-task Tradeoffs: CO2, H2, and PLD

This topic aggregates experimentally validated and simulation‑backed tradeoffs tying pore‑ and surface‑related descriptors (PLD / LCD / PSD / surface area / void fraction / catenation / defects / side‑chain flexibility) to adsorption energetics (Qst, Henry's constant) and transport/kinetics (diffusion barriers, permeability, gating, activation). The page is cumulative: earlier observations are preserved and augmented with mechanistic and modeling‑hygiene lessons from Belof et al., Tan & Shan, Chen et al., Anderson et al., and theoretical work on hydrogen spillover (Psofogiannakis & Froudakis) plus a recent experimental catalyst‑assisted spillover study. Key unifying theme: the same knobs — PLD/LCD/PSD, functionalization, node composition, defects, hydrophilicity, and catenation/interpenetration — control gas‑phase physisorption (H2/CO2/I2/CH3I) and solution/chemisorption (Ln uptake); quantitative impacts depend strongly on guest polarizability/quadrupole, temperature, pressure, and medium. Numeric cutoffs are condition‑specific and must be confirmed by simulation/experiment.

---

## Stable synthesis (robust observations, preserved + newly integrated)

Preserved earlier observations and added robust, transferable statements from Anderson et al., Belof et al., Tan & Shan, Chen et al., the new experimental spillover study, and the theoretical spillover study (Psofogiannakis & Froudakis). Emphasize practical numeric heuristics and modeling/synthesis hygiene Agents must apply.

- PLD as an early accessibility filter
  - Screening evidence: CH3I (kinetic diameter ≈ 4.23 Å) cannot enter MOFs with PLD < 4.23 Å under Tan & Shan simulated conditions (423 K, 1 bar). Use PLD as an early exclusion filter. ([[sources/src_fc58db74fa]])

- LCD and pore geometry modulate host–guest compactness
  - Tan & Shan: LCD ≈ 7.1 Å produced constricted porosity enhancing I2 adsorption; LCD often exerted a stronger influence on I2 uptake than surface area. ([[sources/src_fc58db74fa]])

- Interpenetration / catenation strongly changes PLD/LCD and crystallographic porosity
  - Chen et al. (NU‑650 / NU‑651) — experimental SCXRD and adsorption (see mechanisms & design rules). ([[sources/src_3b254ae858]])

- Hydrophilicity (Qst(H2O)) can override favorable pore metrics under humid conditions
  - High Qst(H2O) frameworks competitively adsorb water and reduce I2 uptake/selectivity even when PLD/LCD and surface area are favorable; low Qst(H2O) correlated with top-performing I2 uptakes in Tan & Shan's humid screening (423 K). ([[sources/src_fc58db74fa]])

- Pore volume vs affinity: size‑dependent control over large vs mid‑sized guests
  - In MIL‑53‑Al functional series, pore volume (Vp ≈ 0.37–0.62 cm3·g−1) largely controlled I2 uptake; CH3I uptake was more affinity (Qst) driven. Functionalization often increases Qst(CH3I) and CH3I uptake even with modest Vp losses. ([[sources/src_fc58db74fa]])

- CO2: electrostatics dominate site specificity; functional‑group chemistry ranks
  - Anderson et al. (2018) DFT + GCMC set of functional groups shows CO2 binding to functionalized building blocks is primarily electrostatic: CO2 aligns its central C toward the most negative atom on the functionality and O atoms toward positive atoms. Polar/polarizable groups (OH, SH, CN, NH2, NO2) typically improve CO2 affinity. DFT ranking (representative ordering) shows -(NH2)2 and -(CN)4 near the top; -(CH3), -(CF3), and some fully halogenated cases toward the weak end. ([[sources/src_c42cf01235]])

- HTCS artifact risk: charge assignment matters
  - Anderson et al. demonstrate inexpensive electronegativity‑equalization methods can overestimate halogen charges and spuriously promote halogenated MOFs in HTCS. DFT‑fitted MBBB or unit‑cell REPEAT charges produce more reliable adsorption predictions and recover correlations between DFT binding energies and GCMC loadings (Spearman SRCC ≈ 0.61 at 1 bar when accurate charges used; SRCC ≈ 0.022 when charges are set to zero). Use DFT‑based or validated charge schemes for electrostatics‑sensitive tasks (CO2, polar guests). ([[sources/src_c42cf01235]])

- Functionalization changes pore geometry — always recompute PLD/LPD
  - Linker chemistry can alter PLD/LPD, void fraction and topology; therefore recompute geometric descriptors (Zeo++) and rerun adsorption simulations after any functionalization. Anderson et al. quantify cases where functionalization improved intrinsic binding but reduced accessible porosity, negating gains. ([[sources/src_c42cf01235]])

- Machine learning enables interpretable first‑pass descriptors
  - Decision tree analysis identified Highest Bond Dipole Moment (HBDM) of the functional group as a top predictor: HBDM > 0.319 e·Å predicts improved CO2/N2 selectivity in >90% of studied cases (dataset/context: 31 parent MOFs functionalized in the Anderson study). Use HBDM as a cheap first‑pass screening descriptor, but verify with full simulation. ([[sources/src_c42cf01235]])

- H2 polarization, quantum corrections and pore regimes
  - Belof et al. and Zeleňák findings preserved: many‑body polarization is critical for charged/ionic narrow‑pore MOFs at cryogenic temperatures (78 K) and nuclear quantum effects and explicit polarization models must be considered for reliable H2 predictions. Typical Qst(H2) ≈ 4–7 kJ·mol−1 in many MOFs; classical simulations may overestimate low‑T uptake by ≈10–15%. ([[sources/src_532b708453]], [[sources/src_ff1b0c9d63]])

- Node geometry and π pockets
  - When functional groups are intrinsically weak binders (e.g., -(H)4, -(CH3)2), CO2 can instead bind strongly at node regions where overlapping potentials create 'π pockets' — topology and linker convergence can override local functional‑group effects. ([[sources/src_c42cf01235]])

- Hydrogen spillover as an augmentation strategy (experimental + theoretical synthesis)
  - Experimental: physical mixing of MOFs (examples: MOF‑5, IRMOF‑8) with a supported metal catalyst (Pt on activated carbon, Pt/AC) at small catalyst:MOF mass fraction (~1:9 wt catalyst:MOF reported) can produce measurable increases in H2 gravimetric uptake and faster uptake kinetics under cryogenic and high‑pressure conditions (isotherms at 77 K and up to ≈10 MPa). Such augmentation is mechanistically distinct from pure physisorption and cannot be modeled by standard GCMC alone. ([[sources/src_572b475183]], [[sources/src_532b708453]])
  - Theoretical: DFT cluster and reaction‑path analyses (Psofogiannakis & Froudakis) formalize the spillover sequence and set realistic thermodynamic/kinetic limits for IRMOF‑1 (MOF‑5) and similar BDC‑linker frameworks: (i) H2 dissociates on metal, (ii) atomic H is emitted into the gas phase or as weakly physisorbed species, (iii) atomic H sticks rapidly to linker sites (first‑addition barrier ≈ 0.08 eV; subsequent additions often barrierless), (iv) Eley–Rideal (ER) recombination with gas‑phase H can have near‑zero barriers (0–0.11 eV) and undo chemisorption near entrances, and (v) chemisorbed‑H long‑range migration in the chemisorbed state is kinetically prohibitive (barriers ≈ 1.3–1.6 eV). ([[sources/src_0abff73929]])

- Thermodynamic ceiling for IRMOF‑1 chemisorption
  - DFT thermodynamics on BDC-linker cluster models indicate that although 12 nominal H sites exist per linker, structures with >6 added H atoms are unstable with respect to H2 formation; the six‑H hydrogenated linker is the thermodynamic sink corresponding to ≈2.3 wt% excess uptake. Site‑counting (12 sites → ≈4.5 wt%) therefore overpredicts achievable chemisorbed H capacity for IRMOF‑1. ([[sources/src_0abff73929]])

- Per‑atom chemisorption energetics (IRMOF‑1 BDC linker, DFT clusters)
  - Representative per‑atom binding energies (eV, negative = bound): Ha ≈ −2.0 eV; Hb ≈ −4.0 to −4.4 eV (strongest, carbocycle); Hc ≈ −2.6 to −2.7 eV; Hd ≈ −0.9 to −1.0 eV (weak, O‑bound). Avoid designs that create excessive weak O–H (Hd‑like) populations if chemisorption retention is the goal. ([[sources/src_0abff73929]])

- Measurement and analysis hygiene
  - BET: apply micropore‑appropriate analyses (Llewellyn criteria, etc.). When structure vs adsorption disagree, check for interpenetration, occluded solvent, framework collapse, and charge/forcefield choices. Recompute PLD/LCD after any chemical alteration. For spillover studies include catalyst controls, loading and mixing protocol details, activation conditions, and reproducibility statistics. For spillover interpret DFT limits (thermodynamic sink) alongside experimental observations (defect/collapse dependence). ([[sources/src_ff1b0c9d63]], [[sources/src_3b254ae858]], [[sources/src_c42cf01235]], [[sources/src_572b475183]], [[sources/src_0abff73929]])

---

## Condition‑specific mechanisms (concise mechanistic cards with conditions)

Each card specifies conditions so Agents pick correct modeling/experimental follow‑ups.

- Mechanism: CO2 binding to functional groups is primarily electrostatic and directional
  - Task: choose functional groups / site models for CO2 adsorption
  - Conditions: CO2, DFT/GCMC contexts (Anderson et al. dataset); room‑temperature 313 K simulations used in many ML/mixture protocols
  - Claim: CO2 aligns positively charged central C toward most negative atoms of functional groups while O atoms face positive atoms; electrostatics dominate site specificity.
  - Evidence: [[mechanisms/co2-co2-binding-to-functionalized-mof-building-blocks-is-dominated-by-elect]]; [[sources/src_c42cf01235]]
  - Confidence: high

- Mechanism: Polar/polarizable functional groups (OH, SH, CN, NH2, NO2) often improve CO2 capture but topology matters
  - Task: functionalization planning for CO2 capture
  - Conditions: CO2 pure and mixture contexts; 313 K simulations in Anderson et al.
  - Claim: These groups tend to increase CO2 binding/loadings if pore topology and aperture are not adversely changed by the substitution.
  - Evidence: [[mechanisms/co2-mixed-functionalization-with-polar-polarizable-groups-hydroxyl-thiol-cy]]; [[sources/src_c42cf01235]]
  - Confidence: medium

- Mechanism: Linker functionalization can change pore sizes and sometimes topology
  - Task: anticipate geometric side effects of chemistry edits
  - Conditions: linker modifications (steric/polar substitutions) in multiple topologies
  - Claim: Functionalization may reduce PLD/LPD or change topology; recompute geometry metrics after functionalization.
  - Evidence: [[mechanisms/pld-co2-linker-functionalization-can-change-pore-sizes-and-sometimes-topolo]]; [[sources/src_c42cf01235]]
  - Confidence: high

- Mechanism: Accurate electrostatics are critical in simulation; E‑equalization can misrank halogenated MOFs
  - Task: HTCS charge assignment policy
  - Conditions: CO2 and other polar gases; screening pipelines where electrostatics drive ranking
  - Claim: DFT‑derived MBBB or REPEAT charges are substantially more reliable than inexpensive E‑equalization methods which may produce halogenated false positives.
  - Evidence: [[mechanisms/mixed-accurate-representation-of-electrostatics-in-simulations-is-critical]]; [[sources/src_c42cf01235]]
  - Confidence: high

- Mechanism: Precombustion CO2 capture metric protocol (operational definitions)
  - Task: compute comparable precombustion metrics
  - Conditions: 20:80 CO2:H2 adsorption at 20 bar (adsorption) and pure CO2 at 1 bar (desorption); T = 313 K (Anderson protocol)
  - Claim: Working capacity = adsorption − desorption; desorption composition assumption can produce negative WC for low‑selectivity materials.
  - Evidence: [[mechanisms/h2-co2-mixed-precombustion-co2-capture-metrics-in-this-study-were-computed]]; [[sources/src_c42cf01235]]
  - Confidence: high

- Mechanism: ML‑derived HBDM threshold predicts likely beneficial functionalizations
  - Task: rapid prioritization of candidate functional groups
  - Conditions: CO2:N2 at 1 bar classification in Anderson dataset
  - Claim: HBDM > 0.319 e·Å predicts improved CO2/N2 selectivity in >90% of cases; use this as a first pass.
  - Evidence: [[mechanisms/co2-decision-tree-analysis-ml-identifies-the-highest-bond-dipole-moment-hbd]]; [[sources/src_c42cf01235]]
  - Confidence: medium

- Mechanism: H2 spillover sequence (theoretical synthesis)
  - Task: plan or interpret catalyst‑assisted H2 storage experiments or models
  - Conditions: room temperature (298 K) context considered in paper; IRMOF‑1 / BDC linker cluster models; DFT reaction‑path analysis
  - Claim: Spillover proceeds in discrete steps — (1) H2 dissociation on metal catalyst, (2) atomic H emission (gas phase or weakly physisorbed), (3) atomic H sticking (chemisorption) to linker sites (first addition barrier ≈ 0.08 eV; subsequent barrierless additions up to thermodynamic sink), (4) possible ER recombination (gas‑phase H + adsorbed H → H2) with very small barriers (0–0.11 eV) that limit penetration depth, and (5) chemisorbed‑H diffusion is kinetically slow (barriers ≈ 1.3–1.6 eV) so gas‑phase/physisorbed transport and defects/entrances are required for deep penetration.
  - Evidence: [[mechanisms/h2-mixed-general-spillover-sequence-h2-dissociates-on-metal-catalyst-partic]]; [[sources/src_0abff73929]]
  - Confidence: high (for IRMOF‑1 cluster models and mechanism logic)

- Mechanism: Gas‑phase/weakly physisorbed atomic H transport is plausible and often necessary
  - Task: design pore networks or defect densities to enable spillover penetration
  - Conditions: IRMOF‑1 and similar narrow‑pore MOFs; defective/mesoporous vs ideal crystal contrast
  - Claim: Because chemisorbed diffusion barriers are large, atomic H likely travels as airborne or weakly physisorbed H through pore entrances/mesopores; defects greatly assist penetration.
  - Evidence: [[mechanisms/h2-pld-gas-phase-or-weakly-physisorbed-atomic-h-diffusion-within-mof-pores]]; [[sources/src_0abff73929]]
  - Confidence: medium

- Mechanism: Thermodynamic ceiling for IRMOF‑1 chemisorption ≈ 2.3 wt% (DFT)
  - Task: set realistic capacity targets for chemisorption‑based spillover on BDC linkers
  - Conditions: IRMOF‑1 BDC linker cluster DFT thermodynamics; neutral framework model
  - Claim: Six‑H hydrogenated linker state is thermodynamic sink → ≈2.3 wt% excess; nominal 12‑site counting overpredicts capacity.
  - Evidence: [[mechanisms/h2-thermodynamic-capacity-limit-for-irmof-1-bdc-linker-although-12-nominal]]; [[sources/src_0abff73929]]
  - Confidence: high

(Previously listed H2 many‑body polarization and quantum‑correction mechanisms preserved — see earlier mechanism links.)

---

## Design implications for Agent (actionable rules, additive to existing PLD/membrane rules)

Operational rules Agents should apply in screening, modeling, synthesis planning. New Anderson‑driven CO2/HTCS/ML rules and spillover experimental/theoretical rules are added while preserving Belof, Tan and Chen rules.

- Rule: Use polar functional groups (OH, SH, CN, NH2, NO2) to improve CO2 affinity — but validate topology and pore metrics
  - When: objective = increase CO2 physisorption/selectivity
  - Action:
    - Prioritize pore‑facing installation of polar/polarizable groups.
    - After each proposed functionalization, recompute PLD/LPD, surface area and void fraction (e.g., Zeo++) and run DFT/GCMC or validated surrogate to confirm net benefit. ([[design_rules/co2-use-polar-functional-groups-e-g-oh-sh-cn-nh2-no2-to-increase-co2-affini]], [[sources/src_c42cf01235]])
  - Failure modes:
    - Functionalization reduces PLD or changes topology and negates gains.

- Rule: For HTCS of CO2 and other electrostatics‑sensitive targets, use DFT‑fitted or validated charge schemes
  - When: electrostatics may influence ranking (halogenated linkers, strong dipoles)
  - Action:
    - Use MBBB, REPEAT, or validated charge‑equilibration parameterizations; record charge provenance.
    - If computational cost prohibits full DFT charges, validate approximations on a representative subset before full screening. ([[design_rules/mixed-when-performing-high-throughput-computational-screening-for-co2-and-o]], [[sources/src_c42cf01235]])
  - Failure modes:
    - Electronegativity‑equalization methods may produce false positives (especially halogenated MOFs).

- Rule: Recompute pore metrics after functionalization (mandatory)
  - When: any linker substitution, pendant group or metal doping that changes sterics/geometry
  - Action:
    - Compute PLD/LPD, surface area, void fraction, and run adsorption simulation(s) for the targeted gas/mixture. ([[design_rules/pld-co2-after-functionalizing-linkers-always-recompute-pore-metrics-pld-lpd]], [[sources/src_c42cf01235]])
  - Metadata: label results as 'crystallographic' (Zeo++) vs 'measured' (BET/DFT validated).

- Rule: Use HBDM as a first‑pass filter for CO2/N2 selectivity improvement
  - When: selecting functional groups for experimental follow‑up
  - Action:
    - Compute HBDM for candidate functional groups; prioritize those with HBDM > 0.319 e·Å for CO2/N2 selectivity improvement probability (>90% in Anderson dataset).
    - For borderline HBDM values, consult topology descriptors (most‑negative‑charge in pore, void fraction) and run full simulation before synthesis. ([[design_rules/co2-use-hbdm-highest-bond-dipole-moment-of-the-functional-group-as-an-inexp]], [[sources/src_c42cf01235]])
  - Failure modes:
    - Parent topology may prevent functional group from contributing as intended.

- Rule: Follow Anderson precombustion protocol for comparable computational evaluation
  - When: evaluating precombustion CO2 capture (CO2/H2 separation)
  - Action:
    - Simulate adsorption for CO2:H2 = 20:80 at 20 bar and desorption as pure CO2 at 1 bar at 313 K to compute working capacity and selectivity; flag negative WC cases. ([[design_rules/h2-co2-use-the-study-s-mixture-pressure-protocol-for-computational-evaluati]], [[sources/src_c42cf01235]])
  - Failure modes:
    - Low selectivity makes desorption assumption invalid and WC misleading.

- Rule: If DFT binding to intended functional group is weak, evaluate node/linker geometry for π‑pockets
  - When: DFT binding energies for functional group are low but measured/simulated loading is unexpectedly high
  - Action:
    - Inspect GCMC density maps for node‑convergent adsorption sites; if present, consider topology changes that enhance node overlap or retain current node environment. ([[design_rules/co2-if-dft-binding-to-the-intended-functional-group-is-weak-evaluate-node-l]], [[sources/src_c42cf01235]])

- Rule: Treat spillover augmentation as mechanistically distinct from physisorption
  - When: interpreting enhanced H2 uptakes from catalyst‑containing samples
  - Action:
    - Do not rely on GCMC/physisorption simulations alone. Either (a) model the full spillover sequence (dissociative catalysis, atomic‑H emission, sticking energies, ER recombination kinetics) with appropriate quantum/kinetic methods, or (b) treat experimental spillover enhancement as an empirical augmentation but only after strict control experiments and thermodynamic checks (DFT stability of hydrogenated states). ([[sources/src_572b475183]], [[sources/src_0abff73929]])
  - Failure modes:
    - Overestimating intrinsic MOF performance from catalyst‑augmented uptakes.

- New Rule: Validate thermodynamic stability of proposed chemisorption sites before using site counts for capacity estimates
  - When: design aims to increase chemisorbed‑H capacity (spillover)
  - Action:
    - For candidate linkers, run DFT thermodynamics to verify hydrogenated states are minima vs H2 formation; do not use nominal site counts as capacity proxies (IRMOF‑1 example: DFT → ≈2.3 wt% realistic sink vs 4.5 wt% by site counting). ([[design_rules/h2-when-selecting-or-designing-linkers-to-increase-chemisorption-capacity-v]], [[sources/src_0abff73929]])
  - Failure modes:
    - Pursuing nominal‑site increases that are thermodynamically unstable.

- New Rule: Engineer pore entrances / mesopores / controlled defects to enable gas‑phase atomic‑H transport but monitor artifacts
  - When: goal is deep spillover penetration in narrow/ideal pore MOFs
  - Action:
    - Introduce controlled mesopores, entrance density, or templated defects to admit atomic H (DFT shows chemisorbed diffusion is unrealistic in ideal lattices).
    - Simultaneously monitor for inclusions, trapped solvent, oxide clusters or irreversible reaction products that can mimic increased uptake. Report PXRD, BET, TEM, and chemical analysis of inclusions. ([[design_rules/pld-h2-mixed-introduce-or-preserve-pore-defects-mesopore-channels-and-incre]], [[sources/src_0abff73929]])
  - Failure modes:
    - Excessive or uncontrolled defects reduce usable surface area or introduce spurious adsorption.

- New Rule: Ensure catalysts and nanoparticles do not block pore channels; favor emission without obstruction
  - When: adding supported catalysts (Pt/Pd) for spillover
  - Action:
    - Select nanoparticle sizes and loading protocols that avoid blocking pore mouths; consider locating catalysts on supports near pore entrances or in mesopores rather than inside narrow channels.
    - Quantify catalyst dispersion and presence via TEM and adsorption baseline tests. ([[design_rules/h2-ensure-catalyst-nanoparticles-do-not-block-pore-channels-and-where-benef]], [[sources/src_0abff73929]])
  - Failure modes:
    - Catalyst occlusion of channels eliminates possible gains.

- New Rule: Mitigate Eley–Rideal recombination losses when designing for spillover
  - When: linkers present labile O‑H adsorption sites or atomic‑H is abundant near entrances
  - Action:
    - Reduce labile O‑H populations (chemical modification), operate at higher H2 pressure to shift ER equilibrium, or modulate atomic‑H flux/distribution to decrease ER collisions. ([[design_rules/h2-mitigate-eley-rideal-recombination-losses-by-a-reducing-labile-o-h-adsor]], [[sources/src_0abff73929]])
  - Failure modes:
    - Fixes that reduce ER may also reduce net filling if they lower sticking to desired sites.

- Rule: When planning spillover augmentation experiments, document and control all catalyst/host contact parameters
  - When: objective = test catalyst‑assisted H2 uptake enhancement (spillover)
  - Action:
    - Record catalyst identity (e.g., Pt/AC), catalyst loading and mass ratio (experimental mixes near 1:9 wt reported), particle size and dispersion, mixing method (physical grinding, impregnation), activation/pretreatment conditions, and contact intimacy metrics.
    - Use control experiments (MOF alone, catalyst alone, physical separation) and report cycling, kinetics and desorption behavior. Measure isotherms at relevant T/P (e.g., 77 K and up to ≈10 MPa; room‑temperature spillover claims typically reported at 69–100 bar) using Sieverts or equivalent apparatus; report BET, pore volume, and any change in PXRD after mixing/activation. ([[sources/src_572b475183]], [[sources/src_0abff73929]])
  - Failure modes:
    - Apparent uptake increases may be due to catalyst or support adsorption artefacts, improper baselines, or irreversible chemisorption.

- Rule: Prioritize catalyst emission/supply improvements when supply is rate‑limiting
  - When: pore network appears open but hydrogenation remains low
  - Action:
    - Improve catalyst dissociation activity, increase catalyst proximity/distribution relative to MOF crystals, or redesign support/catalyst architecture to increase airborne atomic‑H emission. ([[design_rules/h2-prioritize-improving-generation-and-supply-of-atomic-h-from-catalysts-ac]], [[sources/src_0abff73929]])
  - Failure modes:
    - Increasing catalyst without ensuring non‑blocking placement can worsen accessibility.

- Preserve and apply prior rules
  - PLD exclusion thresholds (e.g., for CH3I and other size‑limited guests), H2 many‑body polarization inclusion for charged/narrow channels, NU‑650/NU‑651 steric control of interpenetration, Qst(H2O) humid‑stream screening, BET/micropore analysis hygiene, and recommendations around nanoparticles/spillover remain. Recompute geometric descriptors after any pore‑altering chemistry change. ([[sources/src_fc58db74fa]], [[sources/src_532b708453]], [[sources/src_3b254ae858]], [[sources/src_c42cf01235]], [[sources/src_0abff73929]]).

---

## Contradictions and caveats

Flag contradictions and methodological caveats so Agents do not overgeneralize.

- Contradiction: Simulated vs experimentally accessible porosity (NU‑651)
  - A: Zeo++ on NU‑651 predicts uniform pore ≈ 1.9 nm and crystallographic porosity ≈ 76.7%. ([[sources/src_3b254ae858]])
  - B: NU‑651 activation/experimental porosity was not obtained in that study; simulated porosity remains predictive until validated.
  - Resolution: Treat Zeo++ outputs as crystallographic predictions; require activation + sorption to claim accessible porosity. See [[contradictions/nu-651-porosity-simulated-vs-experimentally-measured]].

- Contradiction: Halogenated MOFs as top CO2 performers — artifact vs reality
  - A: Prior HTCS often listed halogenated MOFs as top performers.
  - B: Anderson et al. show electronegativity‑equalization charge methods overestimate halogen charges and produce artefactual rankings; DFT‑fitted charges change rankings. ([[sources/src_c42cf01235]])
  - Resolution: Reassess halogenated candidates with DFT‑derived charges (MBBB/REPEAT) before committing to synthesis. See [[contradictions/halogenated-mofs-as-top-co2-performers-prior-htcs-vs-dft-corrected-results]].

- Contradiction: Functionalization effect predicted by DFT vs actual loading mechanism
  - A: Functional groups with strong DFT binding energies usually increase loading.
  - B: Weak functional groups sometimes result in high loadings due to node π‑pockets; topology can override functional‑group expectations. ([[sources/src_c42cf01235]])
  - Resolution: Combine molecular binding estimates with full‑framework GCMC and density maps to determine where adsorption occurs. See [[contradictions/functionalization-effect-on-co2-loading-vs-adsorption-site-mechanism]].

- Contradiction: Role of electrostatics vs dispersion
  - A: Anderson et al. find electrostatics are the differentiating factor across functionalizations and correlate better with DFT binding.
  - B: Dispersion remains a significant baseline attractive term and cannot be neglected.
  - Resolution: Both terms must be included; electrostatics are essential to rank functionalizations and predict selectivity differences. See [[contradictions/role-of-electrostatics-vs-dispersion]].

- Contradiction / major caveat: Hydrogen spillover — signal vs mechanism vs reproducibility
  - A: Recent experimental study reports measurable H2 uptake enhancement and kinetic effects when MOFs (examples: MOF‑5, IRMOF‑8) are physically mixed with Pt/AC catalysts and characterized at 77 K and up to ≈10 MPa; uptake, kinetics and reversibility were reported. ([[sources/src_572b475183]])
  - B: Psofogiannakis & Froudakis provide a theoretical limit and mechanism showing (i) chemisorbed diffusion barriers are high, (ii) gas‑phase/physisorbed atomic‑H transport + defects are required for penetration, and (iii) ER recombination and thermodynamics set ceilings (e.g., ≈2.3 wt% for IRMOF‑1). Experimental claims showing >2.3 wt% at room temperature often involve defective/collapsed structures and require rigorous controls. ([[sources/src_0abff73929]])
  - Resolution: Require detailed controls (MOF alone, catalyst/support alone, physically separated vs intimate contact), repeated cycling, and complementary spectroscopic/chemical probes before accepting spillover as an intrinsic augmentation mechanism. Treat reported enhancements as contingent until independently reproduced. See [[contradictions/spillover-reproducibility-and-mechanistic-ambiguity]] and [[contradictions/maximum-achievable-spillover-capacity-on-irmof-1]].

- Contradiction: Mechanism of H transport
  - A: DFT barrier calculations argue against long‑range chemisorbed diffusion in ideal MOFs and support gas‑phase/physisorbed H transport assisted by defects/mesopores.
  - B: Alternative mechanisms (e.g., hole‑mediated transport) have been proposed elsewhere but are not demonstrated here.
  - Resolution: Do not assume a single universal transport mechanism; evaluate mechanism‑specific predictions experimentally (isotope tracing, spatially resolved spectroscopy) before generalizing. See [[contradictions/mechanism-of-h-transport-chemisorbed-diffusion-vs-gas-phase-vs-alternative]].

- Practical caveat: Charge model provenance and computational cost
  - Record charge methodology (MBBB/REPEAT), LJ parameters, any charge equilibration parameterization used, and benchmark subsets versus DFT. If DFT charges are infeasible for large HTCS, validate cheaper schemes on representative families. ([[sources/src_c42cf01235]])

- Methodological caveat: Transferability limits
  - Polarization‑driven H2 enhancements at 78 K do not automatically transfer to RT H2 uptake, CO2 adsorption or aqueous chemisorption; validate across T/P and medium. ([[sources/src_532b708453]], [[sources/src_c42cf01235]], [[sources/src_0abff73929]])

- Metadata / reproducibility warning
  - For polarization: record Thole parametrization, site polarizabilities and their provenance, dipole solver settings, cutoffs; for charge assignments: record MBBB/REPEAT details; for porosity reporting: explicitly tag Zeo++/crystallographic vs experimentally measured after activation. For spillover: record catalyst support identity, catalyst dispersion, catalyst:MOF mass ratio, mixing protocol (grinding, impregnation), activation/pretreatment, isotherm measurement method (Sieverts apparatus settings), cycling/reversibility data, and appropriate controls. ([[sources/src_532b708453]], [[sources/src_c42cf01235]], [[sources/src_3b254ae858]], [[sources/src_572b475183]], [[sources/src_0abff73929]])

---

## Linked pages

Mechanisms (existing + newly emphasized from the spillover source):
- [[mechanisms/h2-the-experimental-soc-mof-material-sorbs-hydrogen-in-its-pores-at-78-k-an]]
- [[mechanisms/h2-molecular-hydrogen-s-attractive-interactions-in-the-heterogeneous-conden]]
- [[mechanisms/h2-explicit-many-body-electronic-polarization-induction-is-the-dominant-con]]
- [[mechanisms/h2-quantitative-estimate-example-for-molecular-hydrogen-placed-0-30-nm-from]]
- [[mechanisms/h2-the-soc-mof-s-highly-ionic-charged-framework-open-indium-coordination-si]]
- [[mechanisms/h2-polarization-interactions-in-the-soc-mof-simulations-lead-to-two-distinc]]
- [[mechanisms/h2-the-total-interaction-potential-used-comprises-ewald-electr]]
- [[mechanisms/h2-mof-atomic-partial-charges-were-derived-from-ab-initio-fragment-calculat]]
- [[mechanisms/h2-site-polarizabilities-for-the-h2-thole-model-were-fit-to-reproduce-the-h]]
- [[mechanisms/h2-the-polarizability-of-indium-in-the-in2-state-present-in-the-soc-mof-sbu]]
- [[mechanisms/h2-polarization-dipoles-were-converged-using-an-iterative-gauss-seidel-smoo]]
- [[mechanisms/h2-simulations-were-performed-at-78-k-using-the-experimentally-determined-h]]
- [[mechanisms/h2-classical-simulations-that-neglect-nuclear-quantum-effects-may-modestly]]
- [[mechanisms/h2-calculated-adsorption-energetics-for-soc-mof-integral-adsorption-enthalp]]
- [[mechanisms/h2-in-less-polar-large-pore-frameworks-example-irmof-1-mof-5-including-many]]
- [[mechanisms/co2-the-authors-project-that-co2-sorption-in-soc-mof-would-likely-be-quite]]
- [[mechanisms/pld-nu-650-twofold-interpenetrated-pcu-zn-mof-has-an-experimental-total-por]]
- [[mechanisms/pld-simulations-zeo-based-on-crystal-structure-indicate-nu-651-non-interpen]]
- [[mechanisms/pld-mixed-introducing-bulky-n-butyl-groups-into-the-cores-of-clathrochelate]]
- [[mechanisms/co2-h2-mixed-regulation-of-interpenetration-catenation-in-mofs-is-an-effect]]
- [[mechanisms/h2-framework-catenation-isomerism-impacts-hydrogen-uptake-in-mofs-literatur]]
- [[mechanisms/mixed-interpenetration-and-porosity-influence-high-pressure-gas-adsorption]]
- [[mechanisms/mixed-inconsistencies-in-adsorption-properties-and-powder-xrd-data-of-mof-5]]
- [[mechanisms/pld-linker-conformation-during-modulated-synthesis-can-be-used-to-control-i]]
- [[mechanisms/pld-interpenetration-in-mofs-can-be-controlled-by-liquid-phase-epitaxy-lite]]
- [[mechanisms/co2-incorporation-of-lithium-cations-into-mofs-can-enhance-co2-ch4-selectiv]]
- [[mechanisms/pld-algorithms-and-tools-exist-for-high-throughput-geometry-based-analysis]]
- [[mechanisms/pld-interwoven-interpenetrated-mof-topologies-can-produce-extra-large-pores]]
- [[mechanisms/mixed-transient-catenation-in-a-zirconium-based-mof-affects-mechanical-stab]]
- [[mechanisms/co2-co2-binding-to-functionalized-mof-building-blocks-is-dominated-by-elect]]
- [[mechanisms/co2-mixed-functionalization-with-polar-polarizable-groups-hydroxyl-thiol-cy]]
- [[mechanisms/pld-co2-linker-functionalization-can-change-pore-sizes-and-sometimes-topolo]]
- [[mechanisms/mixed-accurate-representation-of-electrostatics-in-simulations-is-critical]]
- [[mechanisms/h2-co2-mixed-precombustion-co2-capture-metrics-in-this-study-were-computed]]
- [[mechanisms/mixed-machine-learning-models-decision-trees-and-ensemble-regression-method]]
- [[mechanisms/co2-dft-calculated-co2-binding-strengths-vary-substantially-across-function]]
- [[mechanisms/co2-h2-co2-generally-interacts-more-strongly-with-mof-functional-groups-tha]]
- [[mechanisms/co2-dft-binding-energies-correlate-with-gcmc-predicted-co2-loadings-across]]
- [[mechanisms/co2-when-functional-groups-provide-weak-co2-binding-e-g-h-4-and-ch3-2-co2-c]]
- [[mechanisms/co2-h2-mixed-magnitude-of-functionalization-effects-observed-good-functiona]]
- [[mechanisms/co2-h2-topology-encodes-pore-shape-and-polydispersity-certain-topologies-th]]
- [[mechanisms/co2-decision-tree-analysis-ml-identifies-the-highest-bond-dipole-moment-hbd]]
- [[mechanisms/co2-amine-functionalization-is-a-prominent-strategy-to-enhance-co2-binding]]
- [[mechanisms/co2-h2-mixed-ultra-microporous-single-ligand-mofs-and-pore-designs-that-cre]]
- [[mechanisms/h2-spillover-enhances-hydrogen-storage-in-mofs-when-mixed-with-supported-metals]] (experimental)
- [[mechanisms/h2-mixed-general-spillover-sequence-h2-dissociates-on-metal-catalyst-partic]] (new)
- [[mechanisms/h2-experimental-observations-some-studies-report-enhanced-room-temperature]] (new)
- [[mechanisms/h2-thermodynamic-capacity-limit-for-irmof-1-bdc-linker-although-12-nominal]] (new)
- [[mechanisms/h2-per-atom-binding-energies-dft-cluster-models-for-atomic-h-on-irmof-1-bdc]] (new)
- [[mechanisms/h2-chemisorbed-h-diffusion-is-kinetically-prohibitive-in-ideal-irmof-1-migr]] (new)
- [[mechanisms/h2-pld-gas-phase-or-weakly-physisorbed-atomic-h-diffusion-within-mof-pores]] (new)
- [[mechanisms/h2-sticking-adsorption-kinetics-on-the-bdc-linker-the-first-h-addition-has]] (new)
- [[mechanisms/h2-eley-rideal-abstraction-gas-phase-h-adsorbed-h-h2-has-very-small-or-zero]] (new)
- [[mechanisms/h2-site-selective-sequence-of-hydrogenation-on-the-bdc-linker-same-side-ca]] (new)
- [[mechanisms/h2-hydrogen-pressure-qualitatively-affects-er-recombination-and-penetration]] (new)
- [[mechanisms/h2-rate-limiting-considerations-gas-phase-or-physisorbed-atomic-h-diffusion]] (new)

Design rules (existing + newly added):
- [[design_rules/h2-incorporate-charged-ionic-framework-sites-exposed-metal-coordination-sit]]
- [[design_rules/h2-when-modeling-h2-sorption-in-mofs-include-explicit-many-body-polarizatio]]
- [[design_rules/h2-ensure-h2-models-reproduce-both-the-molecular-quadrupole-and-polarizabil]]
- [[design_rules/h2-treat-classical-model-derived-absolute-uptakes-at-low-temperature-with-c]]
- [[design_rules/h2-ensure-parameter-provenance-for-metal-polarizabilities-and-dipole-solver]]
- [[design_rules/h2-pld-mixed-use-ionic-cationic-frameworks-with-narrow-1-nm-channels-and-lo]]
- [[design_rules/h2-mixed-include-explicit-many-body-electronic-polarization-e-g-thole-apple]]
- [[design_rules/h2-avoid-double-counting-polarization-when-combining-ab-initio-derived-part]]
- [[design_rules/pld-use-sbu-fragment-level-ab-initio-calculations-including-relevant-ligand]]
- [[design_rules/h2-expect-multiple-distinct-adsorbate-populations-e-g-dipolar-h2-species-in]]
- [[design_rules/h2-mixed-when-relying-on-classical-simulation-results-for-cryogenic-h2-upta]]
- [[design_rules/h2-if-using-polarizable-thole-type-models-fit-atomic-site-polarizabilities]]
- [[design_rules/pld-increase-steric-bulk-at-the-ligand-core-to-avoid-framework-interpenetra]]
- [[design_rules/pld-mixed-use-structure-based-simulations-e-g-zeo-and-geometry-based-comput]]
- [[design_rules/pld-use-synthesis-condition-levers-modulated-synthesis-linker-conformation]]
- [[design_rules/mixed-if-adsorption-or-pxrd-data-appear-inconsistent-with-expected-porosity]]
- [[design_rules/co2-introduce-lewis-acidic-cations-e-g-li-to-increase-co2-ch4-selectiv]]
- [[design_rules/co2-use-polar-functional-groups-e-g-oh-sh-cn-nh2-no2-to-increase-co2-affini]]
- [[design_rules/mixed-when-performing-high-throughput-computational-screening-for-co2-and-o]]
- [[design_rules/pld-co2-after-functionalizing-linkers-always-recompute-pore-metrics-pld-lpd]]
- [[design_rules/h2-co2-use-the-study-s-mixture-pressure-protocol-for-computational-evaluati]]
- [[design_rules/co2-use-hbdm-highest-bond-dipole-moment-of-the-functional-group-as-an-inexp]]
- [[design_rules/co2-if-dft-binding-to-the-intended-functional-group-is-weak-evaluate-node-l]]
- [[design_rules/co2-when-targeting-humid-flue-gases-prioritize-moisture-stable-mofs-or-stra]]
- [[design_rules/h2-consider-spillover-catalyst-augmentation-for-enhanced-h2-capacity]] (experimental)
- [[design_rules/pld-h2-mixed-introduce-or-preserve-pore-defects-mesopore-channels-and-incre]] (new)
- [[design_rules/h2-ensure-catalyst-nanoparticles-do-not-block-pore-channels-and-where-benef]] (new)
- [[design_rules/h2-when-selecting-or-designing-linkers-to-increase-chemisorption-capacity-v]] (new)
- [[design_rules/h2-mitigate-eley-rideal-recombination-losses-by-a-reducing-labile-o-h-adsor]] (new)
- [[design_rules/h2-prioritize-improving-generation-and-supply-of-atomic-h-from-catalysts-ac]] (new)

Contradictions (existing + newly emphasized):
- [[contradictions/effect-of-polarization-vs-prior-simulation-practices]]
- [[contradictions/classical-polarizable-models-vs-quantum-nuclear-effects]]
- [[contradictions/adsorption-enthalpy-simulation-vs-experiment]]
- [[contradictions/paper-metadata-variants]]
- [[contradictions/nu-651-porosity-simulated-vs-experimentally-measured]]
- [[contradictions/tradeoff-between-catenation-interpenetration-porosity-adsorption-and-mechan]]
- [[contradictions/halogenated-mofs-as-top-co2-performers-prior-htcs-vs-dft-corrected-results]]
- [[contradictions/functionalization-effect-on-co2-loading-vs-adsorption-site-mechanism]]
- [[contradictions/role-of-electrostatics-vs-dispersion]]
- [[contradictions/functional-group-identity-matters-amines-vs-amides-and-moisture-sensitivity]]
- [[contradictions/moisture-effects-on-mof-co2-capture]]
- [[contradictions/spillover-reproducibility-and-mechanistic-ambiguity]] (emphasized)
- [[contradictions/maximum-achievable-spillover-capacity-on-irmof-1]] (new)
- [[contradictions/mechanism-of-h-transport-chemisorbed-diffusion-vs-gas-phase-vs-alternative]] (new)
- [[contradictions/role-of-defects-and-inclusions-in-observed-uptake]] (new)
- [[contradictions/importance-of-pore-network-access-vs-atomic-h-generation-as-rate-limiting-s]] (new)
- [[contradictions/paper-metadata-authors-journal-naming]] (new)

Sources (selected):
- Belof J. L., Stern A. C., Eddaoudi M., Space B., "On the Mechanism of Hydrogen Storage in a Metal‑Organic Framework Material", J. Am. Chem. Soc., 2007 — [[sources/src_532b708453]].
- Chen Z., Idrees K. B., Shetty S., Xie H., Wasson M. C., et al., "Regulation of Catenation in Metal−Organic Frameworks with Tunable Clathrochelate‑Based Building Blocks", Cryst. Growth Des. 2021 — [[sources/src_3b254ae858]].
- Anderson R., Rodgers J., Argueta E., Biong A., Gómez‑Gualdrón D. A., "Role of Pore Chemistry and Topology in the CO2 Capture Capabilities of MOFs: From Molecular Simulation to Machine Learning", Chemistry of Materials, 2018 — [[sources/src_c42cf01235]].
- Mulfort et al., Langmuir 2009: alkali‑doping / partial reduction experimental dataset — [[sources/src_b0ea8c70ab]].
- Zeleňák V., Saldan I., "Factors Affecting Hydrogen Adsorption in Metal–Organic Frameworks: A Short Review", Nanomaterials 2021 — [[sources/src_ff1b0c9d63]].
- Ilgen, Sikma, Sava Gallis, Leung, et al., ACS AMI 2024: lanthanide coordination in Cr/Zr MOFs — [[sources/src_c88d608b3b]].
- Tan H., Shan G., "Computational screening and functional tuning of chemically stable metal organic frameworks for I2/CH3I capture in humid environments", iScience 2024 — [[sources/src_fc58db74fa]].
- Psofogiannakis, G. M.; Froudakis, G. E., "Theoretical Explanation of Hydrogen Spillover in Metal‑Organic Frameworks", J. Phys. Chem. C, 2011 — [[sources/src_0abff73929]].
- New experimental study reporting catalyst‑assisted H2 spillover in MOFs (Pt/AC mixed with MOF‑5, IRMOF‑8): gravimetric H2 isotherms at 77 K and high pressure (up to ≈10 MPa), kinetics, reversibility, BET/pore metrics and mixing protocol details — [[sources/src_572b475183]].

---

Notes on provenance and recommended metadata (updated)
- For functionalization/catenation claims record: functional group identity and position, HBDM of the group, DFT binding energies (with method), SCXRD unit cell, topology, PLD/LPD and Zeo++ settings, whether porosity is measured or Zeo++ predicted, activation method, and any failed activation notes. (NU‑651 was not activated in Chen et al.; Anderson provides charge/DFT provenance). ([[sources/src_3b254ae858]], [[sources/src_c42cf01235]])
- For electrostatics: record charge assignment method (MBBB/REPEAT vs electronegativity equilibration), parameters and benchmarking sets used; for polarizable models record Thole parameters and site polarizabilities. ([[sources/src_c42cf01235]], [[sources/src_532b708453]])
- For CO2 workflows: record ML model descriptors used (HBDM thresholds), mixture/pressure protocols (e.g., precombustion: 20:80 CO2:H2 at 20 bar adsorption / pure CO2 at 1 bar desorption at 313 K), temperature and pressure, and whether mixture GCMC was used. ([[sources/src_c42cf01235]])
- For H2 workflows: explicitly record measurement/simulation temperatures (e.g., 77–78 K for cryogenic testing, 298 K for RT) and whether nuclear quantum effects or polarization were included.
- For humid/organohalide workflows record temperature and RH (e.g., 423 K in Tan & Shan when relevant), partial pressures, structural phase used for breathing MOFs, and Qst(H2O) estimates.
- For spillover experiments: record catalyst identity and support (e.g., Pt/AC), catalyst:MOF mass ratio, catalyst dispersion/particle size, mixing protocol (physical grinding vs impregnation), activation/pretreatment conditions, isotherm measurement method (Sieverts apparatus settings), cycling/reversibility data, and appropriate controls (MOF alone, catalyst/support alone). ([[sources/src_572b475183]], [[sources/src_0abff73929]])
- When planning synthesis/in silico optimization that changes pore chemistry (linker bulk, polar substituents, pillar length, node composition, dopants), annotate expected effects on catenation, PLD/LCD/PSD, adsorption energy/Qst, surface area, accessible pore volume and windows; compute PLD/LPD with Zeo++ and dynamic PSD from MD; then re‑evaluate deliverable capacity and kinetics with topology‑ and solvent‑aware methods before committing to synthesis.

---