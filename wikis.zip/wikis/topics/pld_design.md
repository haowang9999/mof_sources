---
title: "PLD and Pore-Aperture Design Synthesis"
type: topic
tags: [pld, pore, topology, mechanism, design_rule]
created: "2026-05-01"
updated: "2026-05-02"
sources: [[sources/src_8ce39338bc]], [[sources/src_90ad344e79]], [[sources/src_a034d4944a]], [[sources/src_90953381a0]], [[sources/src_36df794947]], [[sources/src_83cde498f9]], [[sources/src_71bcf59437]], [[sources/src_fa8cccd644]], [[sources/src_20cacd73e1]], [[sources/src_a318a71841]], [[sources/src_97052fb350]], [[sources/src_340141308b]], [[sources/src_20dae1036b]], [[sources/src_1fa85425f9]], [[sources/src_b0ea8c70ab]], [[sources/src_b1552d4a9d]], [[sources/src_c88d608b3b]], [[sources/src_fc58db74fa]], [[sources/src_ff1b0c9d63]], [[sources/src_532b708453]], [[sources/src_3b254ae858]], [[sources/src_c42cf01235]], [[sources/src_0abff73929]]
confidence: medium
---

# PLD and Pore-Aperture Design Synthesis

This living synthesis accumulates mechanisms and agent-actionable design implications for controlling pore-limiting diameter (PLD), window/aperture sizes, linker length/topology, node connectivity, interpenetration/catenation, and oversize/encapsulation risk in MOFs. It integrates synthesis levers (steric linker design, modulation, epitaxy), functionalization effects, electrostatics fidelity, and computational guardrails (Zeo++, GCMC, DFT, polarizable models, ML descriptors). Preserve family‑specific caveats — do not assume universal transferability.

Summary takeaway (short)
- PLD is the geometric gate for molecular access; use PLD/LCD prefilters and escalate to energetic/diffusion calculations when PLD is within ≈0.1–0.3 nm of the target kinetic diameter. Example: for CH3I in Tan & Shan screening a PLD < 4.23 Å excluded uptake. [[mechanisms/pld-pore-limiting-diameter-pld-smaller-than-the-kinetic-diameter-of-ch3i-4]], [[design_rules/pld-exclude-mof-candidates-whose-pld-is-smaller-than-the-kinetic-diameter-o]]
- Linker functionalization frequently changes pore metrics (PLD/LPD/void fraction) and can alter topology/interpenetration; always recompute pore metrics and rescreen interpenetration probability after functionalization. [[mechanisms/pld-co2-linker-functionalization-can-change-pore-sizes-and-sometimes-topolo]], [[design_rules/pld-co2-after-functionalizing-linkers-always-recompute-pore-metrics-pld-lpd]]
- Electrostatics drive CO2 binding to pore-facing functionalities (CO2 carbon aligns to most negative atom); accurate Coulomb charges (MBBB, REPEAT) are required in HTCS to avoid artefacts (notably halogenated linkers). Use DFT-derived charges or validated equilibration parameters when electrostatics matter. [[mechanisms/co2-co2-binding-to-functionalized-mof-building-blocks-is-dominated-by-elect]], [[mechanisms/mixed-accurate-representation-of-electrostatics-in-simulations-is-critical]], [[design_rules/mixed-when-performing-high-throughput-computational-screening-for-co2-and-o]]
- ML-derived simple descriptors (HBDM — highest bond dipole moment of the functional group) can be effective first-pass rules: HBDM > 0.319 e·Å predicted improvement in CO2/N2 selectivity in >90% of cases in the referenced dataset; use as a cheap filter but validate with full-framework simulation. [[mechanisms/co2-decision-tree-analysis-ml-identifies-the-highest-bond-dipole-moment-hbd]], [[design_rules/co2-use-hbdm-highest-bond-dipole-moment-of-the-functional-group-as-an-inexp]]
- Topology matters: large‑pore topologies (e.g., rht, stp, rhr, ssb) are less responsive to functionalization for CO2:H2 selectivity; confined topologies are more sensitive. Select topology appropriate to the intended functionalization strategy. [[mechanisms/co2-h2-topology-encodes-pore-shape-and-polydispersity-certain-topologies-th]]
- For H2 spillover: ideal, defect-free narrow‑pore MOFs (small PLD) will not support long-range chemisorbed‑H diffusion — gas‑phase or weakly physisorbed atomic‑H transport through entrance channels/mesopores is the plausible route that enables deep hydrogenation. Design of PLD and entrance topology must therefore consider mesopore/entrance density and catalyst placement. [[mechanisms/h2-mixed-general-spillover-sequence-h2-dissociates-on-metal-catalyst-partic]], [[design_rules/pld-h2-mixed-introduce-or-preserve-pore-defects-mesopore-channels-and-incre]]

## Stable synthesis (high-confidence consensus & dataset-supported findings)
- PLD as primary geometric filter (high confidence)
  - PLD/LCD computed with Zeo++ remain the first geometric filter for transport/sieving design. When PLD approaches the target species' effective diameter escalate to energetic/diffusion checks. [[design_rules/pld-use-computed-pld-lcd-zeo-as-primary-filters-for-molecular-accessibility]]
- Functionalization → geometric/topological coupling (high confidence)
  - Linker functionalization commonly changes PLD/LPD and void fraction and can induce topology changes (including altered interpenetration). Treat chemical modification as a coupled geometry/topology change — recompute PLD/LCD/PSD and run adsorption simulations after any functionalization. [[mechanisms/pld-co2-linker-functionalization-can-change-pore-sizes-and-sometimes-topolo]], [[design_rules/pld-co2-after-functionalizing-linkers-always-recompute-pore-metrics-pld-lpd]]
- Electrostatics fidelity for polar adsorbates (high confidence)
  - For CO2 and other polar species, accurate Coulomb charges (DFT-fitted MBBB or unit-cell fits such as REPEAT) materially alter predicted loadings and mechanisms. Inexpensive electronegativity‑equalization methods can spuriously promote halogenated MOFs. Use DFT-derived or validated charge schemes for HTCS and mechanistic interpretation. [[mechanisms/mixed-accurate-representation-of-electrostatics-in-simulations-is-critical]], [[design_rules/mixed-when-performing-high-throughput-computational-screening-for-co2-and-o]]
- Linker elongation / rigidity (high confidence; conditioned)
  - Elongating linkers increases internal surface area and pore volume but raises flexibility, collapse and interpenetration risk. Use rigid SBUs or isoreticular series to isolate pore-size effects; always recompute geometry descriptors after changes. [[mechanisms/h2-pld-longer-organic-linkers-elongation-increase-surface-area-and-pore-vol]], [[design_rules/h2-pld-increase-organic-linker-length-to-raise-surface-area-and-h2-uptake-b]]
- Interpenetration control by sterics and synthesis (medium–high confidence)
  - Bulky core substituents suppress catenation (NU‑650 → NU‑651 example), and modulation/epitaxy can bias linker conformation/topology. Validate simulated crystallographic porosity against experimental access after activation. [[mechanisms/pld-nu-650-twofold-interpenetrated-pcu-zn-mof-has-an-experimental-total-por]], [[mechanisms/pld-simulations-zeo-based-on-crystal-structure-indicate-nu-651-non-interpen]], [[design_rules/pld-increase-steric-bulk-at-the-ligand-core-to-avoid-framework-interpenetra]]
- Topology-specific sensitivity to functionalization (medium–high confidence)
  - Certain topologies with larger intrinsic pores (rht, stp, rhr, ssb) show little CO2:H2 selectivity gain upon functionalization; smaller/confined topologies show larger responses. Use topology choice to amplify or damp functionalization effects. [[mechanisms/co2-h2-topology-encodes-pore-shape-and-polydispersity-certain-topologies-th]]
- Node and π-pocket effects (medium confidence)
  - When functional group intrinsic binding is weak, nodes or convergent-linker regions (π pockets) can dominate adsorption; topology/linker arrangement may thus offset weak functional groups. Consider node geometry as a deliberate design variable. [[mechanisms/co2-when-functional-groups-provide-weak-co2-binding-e-g-h-4-and-ch3-2-co2-c]]
- Spillover-specific additions (IRMOF-family evidence; confidence graded)
  - Chemisorbed‑H diffusion within ideal narrow pores is kinetically prohibitive (DFT barriers ~1.3–1.6 eV), so chemisorbed‑H migration cannot be relied on to distribute H through an ideal crystal. Gas‑phase or weakly physisorbed atomic‑H transport through entrance channels/mesopores is the plausible mechanism enabling deep hydrogenation; it requires sufficient entrance density and catalyst‑emitted atomic H. [[mechanisms/h2-chemisorbed-h-diffusion-is-kinetically-prohibitive-in-ideal-irmof-1-migr]], [[mechanisms/h2-pld-gas-phase-or-weakly-physisorbed-atomic-h-diffusion-within-mof-pores]]

## Condition-specific mechanisms (actionable, conditions and confidence)
- Functional-group electrostatic alignment (high confidence)
  - Mechanism: CO2 aligns with its positive C toward the most negative pore-facing atom; electrostatics determine preferred binding orientation. Action: place negatively charged/polar atoms pore-facing to create electrostatic pockets for CO2. [[mechanisms/co2-co2-binding-to-functionalized-mof-building-blocks-is-dominated-by-elect]]
- Functionalization may cause PLD reduction / topology shift (high confidence)
  - Mechanism: added group steric volume reduces aperture or can force a different packing/topology, changing PLD and interpenetration likelihood. Action: after any functionalization recompute PLD/LPD/void fraction and evaluate interpenetration/packing simulations before synthesis. [[mechanisms/pld-co2-linker-functionalization-can-change-pore-sizes-and-sometimes-topolo]], [[design_rules/pld-co2-after-functionalizing-linkers-always-recompute-pore-metrics-pld-lpd]]
- Electrostatics vs dispersion (high confidence)
  - Mechanism: dispersion is baseline attraction but electrostatics differentiates functional groups; correct Coulomb description is required for linking DFT binding to macroscopic loading. Action: include both contributions in DFT/GCMC workflows; prefer MBBB/REPEAT charges for electrostatics. [[mechanisms/co2-dft-calculated-co2-binding-strengths-vary-substantially-across-function]], [[mechanisms/co2-dft-binding-energies-correlate-with-gcmc-predicted-co2-loadings-across]], [[design_rules/mixed-when-performing-high-throughput-computational-screening-for-co2-and-o]]
- HBDM as a cheap filter for CO2/N2 selectivity (medium confidence)
  - Mechanism: ML decision tree found HBDM of functional group > 0.319 e·Å predicts improved CO2:N2 selectivity in >90% cases (dataset conditions: 1 bar, 313 K). Action: calculate group HBDM; if >0.319 e·Å, prioritize functionalization candidate, otherwise consult topology and charge descriptors. [[mechanisms/co2-decision-tree-analysis-ml-identifies-the-highest-bond-dipole-moment-hbd]], [[design_rules/co2-use-hbdm-highest-bond-dipole-moment-of-the-functional-group-as-an-inexp]]
- Spillover thermodynamics and site limits (high confidence for IRMOF-1 cluster models)
  - Mechanism: nominal site counts overestimate achievable chemisorbed‑H capacity. DFT cluster modeling of IRMOF‑1 BDC linkers finds a thermodynamic sink at six H per linker (~2.3 wt% excess); adding more H is unstable w.r.t. H2 formation. Action: do not extrapolate capacity linearly from site counts—compute thermodynamic stability of hydrogenated states for proposed linkers/materials. [[mechanisms/h2-thermodynamic-capacity-limit-for-irmof-1-bdc-linker-although-12-nominal]]
- Sticking and ER recombination kinetics (high confidence; IRMOF-1)
  - Mechanism: first atomic‑H sticking to BDC has a small barrier (~0.08 eV); subsequent additions are barrierless, so hydrogenation proceeds quickly at contacted sites. However, Eley–Rideal (gas‑phase H + adsorbed H → H2) barriers are very small (0–0.11 eV), making recombination effectively instantaneous at room temperature near entrances and limiting penetration depth. Action: mitigate ER losses by linker design (fewer weak O–H sites), catalyst distribution control, or operating at higher H2 pressure. [[mechanisms/h2-sticking-adsorption-kinetics-on-the-bdc-linker-the-first-h-addition-has]], [[mechanisms/h2-eley-rideal-abstraction-gas-phase-h-adsorbed-h-h2-has-very-small-or-zero]]
- Gas-pressure dependence on penetration (medium confidence)
  - Mechanism: increasing H2 pressure suppresses ER recombination thermodynamically and can increase penetration depth and degree of hydrogenation; at low H2 pressure ER dominates and limits filling. Action: where possible, test elevated H2 pressure regimes to assess deeper hydrogenation and to de-risk ER losses. [[mechanisms/h2-hydrogen-pressure-qualitatively-affects-er-recombination-and-penetration]]
- Rate-limiting generation vs diffusion (medium confidence)
  - Mechanism: intracrystallite gas‑phase/physisorbed atomic‑H diffusion is fast; the bottleneck is often generation and emission of atomic H from catalysts and entrance/access. Action: prioritize catalyst activity/distribution and ensure catalysts do not block pore mouths; create entrance channels or mesopores if supply is limiting. [[mechanisms/h2-rate-limiting-considerations-gas-phase-or-physisorbed-atomic-h-diffusion]]

## Design implications for Agent (practical checklist / workflows)
- Baseline geometric + electrostatic prefilter (extended)
  1. Compute PLD and LCD (Zeo++) with grid spacing ≈0.1 Å and record probe radius; attach operating T/P tags (e.g., 313 K/1 bar for CO2 postcombustion, 313 K/20 bar for CO2:H2 precombustion, 423 K/1 bar humid for Tan & Shan I2/CH3I context). [[design_rules/pld-use-computed-pld-lcd-zeo-as-primary-filters-for-molecular-accessibility]]
  2. If planning linker functionalization:
     - Recompute PLD/LPD, void fraction and surface area (Zeo++) and compare against parent; flag any ΔPLD or Δvoid fraction > 10% as high‑risk for altered transport or confinement. [[design_rules/pld-co2-after-functionalizing-linkers-always-recompute-pore-metrics-pld-lpd]]
     - Compute HBDM for the functional group. If HBDM > 0.319 e·Å (decision-tree threshold from dataset at 1 bar, 313 K) prioritize the functionalization for improving CO2/N2 selectivity; if below threshold consult topology and most-negative-charge descriptors before synthesis. [[design_rules/co2-use-hbdm-highest-bond-dipole-moment-of-the-functional-group-as-an-inexp]]
     - Evaluate whether added functionality sterically narrows PLD or induces interpenetration — simulate packing or apply heuristics. [[mechanisms/pld-co2-linker-functionalization-can-change-pore-sizes-and-sometimes-topolo]]
  3. For polar gases (CO2, H2 in ionic narrow channels): assign Coulomb charges using DFT‑derived MBBB or REPEAT when possible; if HTCS-level approximations are required, benchmark the chosen equilibration parameterization against a subset of DFT charges. Avoid electronegativity‑equalization methods when evaluating halogenated or highly polar linkers. [[mechanisms/mixed-accurate-representation-of-electrostatics-in-simulations-is-critical]], [[design_rules/mixed-when-performing-high-throughput-computational-screening-for-co2-and-o]]
  4. If PLD approaches the kinetic diameter of the target (within ≈0.1–0.3 nm), run DFT binding calculations, GCMC with accurate charges, and explicit diffusion (MD) or NEB barriers for guest crossing windows. For ionic/narrow channels include polarizable models (Thole) and consider conservative corrections for quantum nuclear effects at cryogenic T. [[design_rules/pld-use-computed-pld-lcd-zeo-as-primary-filters-for-molecular-accessibility]], [[mechanisms/h2-explicit-many-body-electronic-polarization-induction-is-the-dominant-con]]
  5. Topology selection: for CO2:H2 precombustion select smaller/confined topologies to maximize responsiveness to functionalization; avoid large-pore topologies (rht, stp, rhr, ssb) if the goal is to boost selectivity by linker chemistry. [[mechanisms/co2-h2-topology-encodes-pore-shape-and-polydispersity-certain-topologies-th]]
  6. Interpenetration control: if increasing PLD is the target without changing SBU chemistry, introduce steric bulk at the linker core (n‑butyl, tert‑butyl etc.) and simulate both interpenetrated and non‑interpenetrated packings. Plan modulation or epitaxial growth trials if linker redesign is impractical. [[mechanisms/pld-mixed-introducing-bulky-n-butyl-groups-into-the-cores-of-clathrochelate]], [[mechanisms/pld-linker-conformation-during-modulated-synthesis-can-be-used-to-control-i]]
  7. Experimental validation gate: require N2 or target‑gas sorption after activation before promotion; if simulated crystallographic porosity is high but measured porosity is low, investigate occluded guests, incomplete activation, or topology change. [[design_rules/mixed-if-adsorption-or-pxrd-data-appear-inconsistent-with-expected-porosity]], [[contradictions/nu-651-porosity-simulated-vs-experimentally-measured]]
- Spillover‑specific checklist (when H2 spillover is a target)
  - Geometric and pore-network actions:
    1. If the goal is spillover-enabled chemisorption, intentionally create or preserve entrance channels / mesopores and increase entrance density (templating, controlled partial collapse, hierarchical porosity). Avoid relying on an ideal defect-free, narrow-PLD crystal to achieve deep hydrogenation. [[design_rules/pld-h2-mixed-introduce-or-preserve-pore-defects-mesopore-channels-and-incre]]
    2. Simulate both ideal and defective/mesoporous packings with Zeo++/pore-network analyses and estimate transport accessibility for gas-phase atomic H. Flag candidates whose ideal PLD suggests accessibility but whose activation/packing will likely block entrances. [[mechanisms/h2-pld-gas-phase-or-weakly-physisorbed-atomic-h-diffusion-within-mof-pores]]
  - Catalyst and placement:
    3. Ensure catalyst nanoparticles (Pt, Pd) are sized/placed so they do not block pore mouths; distribute catalysts near entrances or within large channels/mesopores if emission into pore volumes is desired. Validate by imaging (TEM, EDS) and sorption tests. [[design_rules/h2-ensure-catalyst-nanoparticles-do-not-block-pore-channels-and-where-benef]]
    4. If low uptake persists despite open pore paths, prioritize increasing catalyst H2‑dissociation activity or catalyst density/proximity rather than further opening the pore network. [[design_rules/h2-prioritize-improving-generation-and-supply-of-atomic-h-from-catalysts-ac]]
  - Linker chemistry and thermodynamics:
    5. Do not rely on nominal binding‑site counts to estimate capacity. For each candidate linker, compute DFT thermodynamics for hydrogenated states (identify thermodynamic sink). If proposed modifications increase nominal sites, verify added sites are stable vs H2 formation (IRMOF‑1 BDC example: thermodynamic sink at 6 H/linker → ~2.3 wt% excess). [[design_rules/h2-when-selecting-or-designing-linkers-to-increase-chemisorption-capacity-v]]
    6. Design linkers to favor strong C‑bound motifs (analogous to Hb/Hc) and avoid producing many weak O–H sites (Hd) that are readily abstracted by ER recombination. [[design_rules/h2-mitigate-eley-rideal-recombination-losses-by-a-reducing-labile-o-h-adsor]]
  - Kinetic controls:
    7. Mitigate Eley–Rideal recombination by reducing labile weak O–H sites, controlling atomic‑H flux near entrances (catalyst placement, spatial separation), or operating at higher H2 pressure to shift ER equilibria. Test pressure dependence experimentally (room temperature comparisons: low vs elevated H2). [[design_rules/h2-mitigate-eley-rideal-recombination-losses-by-a-reducing-labile-o-h-adsor]]
  - Simulation and validation:
    8. Use DFT to compute per-atom binding energies and diffusion barriers on representative cluster models before planning macroscale spillover experiments. If DFT barriers for chemisorbed diffusion are >1 eV, treat gas-phase transport plus entrance engineering as the likely design route. [[mechanisms/h2-per-atom-binding-energies-dft-cluster-models-for-atomic-h-on-irmof-1-bdc]]
    9. When reporting spillover predictions, include whether capacity estimate is site-count or thermodynamics derived, list catalyst size/location, and include pore-entrance density metric in candidate metadata.
- Simulation fidelity guardrails
  - Use DFT (with dispersion corrections) to screen functional-group binding energies; only translate DFT binding into macroscopic predictions when Coulomb charges consistent with DFT are used in GCMC. Document charge derivation method and whether charges include condensed‑phase polarization. [[mechanisms/co2-dft-binding-energies-correlate-with-gcmc-predicted-co2-loadings-across]], [[design_rules/pld-include-chemically-meaningful-atomic-charges-e-g-ddec-when-modelling-ad]]
  - For spillover planning, compute both thermodynamic sinks and kinetic barriers (adsorption, ER abstraction, chemisorbed diffusion). If chemisorbed diffusion barriers are large (> ~1 eV), prioritize entrance/mesopore engineering and catalyst emission modeling. [[mechanisms/h2-chemisorbed-h-diffusion-is-kinetically-prohibitive-in-ideal-irmof-1-migr]]
  - When using polarizable models, avoid double-counting if charges were derived from polarized environments; either rederive charges consistently or disable MOF–MOF self‑polarization. [[design_rules/h2-avoid-double-counting-polarization-when-combining-ab-initio-derived-part]]
- Synthesis & characterization actions
  - If functionalization or catalyst loading causes unexpected lower uptake: recompute pore metrics, perform packing/SCXRD analysis, check for occluded guests, perform solvent-exchange / scCO2 activation, and collect PXRD before/after activation. If catalysts were added, confirm they did not block entrances (SEM/TEM). [[design_rules/pld-use-synthesis-condition-levers-modulated-synthesis-linker-conformation]], [[design_rules/pld-increase-steric-bulk-at-the-ligand-core-to-avoid-framework-interpenetra]], [[design_rules/h2-ensure-catalyst-nanoparticles-do-not-block-pore-channels-and-where-benef]]
  - When reporting candidate performance, include explicit statements about whether reported H2 uptake includes spillover contributions, catalyst presence and location, pressure dependence tests, and whether thermodynamic stability of chemisorbed states was assessed. This metadata prevents misinterpretation of site-count projections. [[contradictions/maximum-achievable-spillover-capacity-on-irmof-1]]

## Contradictions and caveats (flagged for downstream decision logic)
- PLD necessary but not sufficient (high confidence)
  - PLD is a geometric prefilter; flexibility, electrostatics, solvent, node pockets and microstructure can change effective transport and adsorption. Borderline PLD results require ΔEdiff, explicit‑solvent MD or experimental validation. [[contradictions/use-of-kinetic-diameter-vs-actual-diffusion-behavior]]
- Functionalization ↔ topology coupling (high confidence)
  - Claim: functionalization improves CO2 affinity. Counterpoint: functionalization often changes PLD/LPD and topology which can negate or reverse expected gains. Resolution: recompute pore metrics and run full-framework adsorption simulations; assign experimental priority when geometric metrics change. [[contradictions/functionalization-effect-on-co2-loading-vs-adsorption-site-mechanism]], [[mechanisms/pld-co2-linker-functionalization-can-change-pore-sizes-and-sometimes-topolo]]
- Halogenated MOFs and charge-method artefacts (high confidence)
  - Prior HTCS that used electronegativity‑equalization charges frequently ranked halogenated MOFs as top CO2 performers; DFT-corrected charges (MBBB/REPEAT) show these rankings can be artefactual. Agent warning: re-evaluate halogenated candidates with DFT‑consistent charges. [[contradictions/halogenated-mofs-as-top-co2-performers-prior-htcs-vs-dft-corrected-results]]
- Role of electrostatics vs dispersion (high confidence)
  - Dispersion is often larger in absolute magnitude, but electrostatics differentiate functionalizations and drive correlations between DFT binding and macroscopic loading. Account for both consistently. [[contradictions/role-of-electrostatics-vs-dispersion]]
- Moisture sensitivity (medium confidence)
  - Amines are often beneficial but humidity can change chemistry; some frameworks are moisture-stable while others degrade — verify material-specific humidity response. [[contradictions/moisture-effects-on-mof-co2-capture]], [[design_rules/co2-when-targeting-humid-flue-gases-prioritize-moisture-stable-mofs-or-stra]]
- Simulated crystallographic porosity vs accessible porosity (high confidence)
  - Zeo++ metrics are crystallographic; activation/kinetic trapping or guest occlusion may make simulated porosity inaccessible (NU‑651 example). Treat Zeo++ outputs as prioritization guidance and require experimental porosity validation before deployment. [[contradictions/nu-651-porosity-simulated-vs-experimentally-measured]]
- Double-counting polarization risk (high confidence)
  - Using ab initio charges derived from polarized calculations together with explicit induced-dipole simulations can double-count polarization; rederive consistent parameters or disable MOF–MOF self‑polarization. [[contradictions/classical-polarizable-models-vs-quantum-nuclear-effects]], [[design_rules/h2-avoid-double-counting-polarization-when-combining-ab-initio-derived-part]]
- Interpenetration tradeoffs (medium confidence)
  - Catenation can increase mechanical robustness and volumetric performance in some regimes but usually reduces accessible pore volume and can block OMS. Evaluate case-by-case. [[contradictions/tradeoff-between-catenation-interpenetration-porosity-adsorption-and-mechan]]
- Spillover-specific contradictions (preserve and flag)
  - Maximum achievable spillover capacity on IRMOF‑1:
    - Claim A (site counting): 12 H sites per BDC → ~4.5 wt% excess.
    - Claim B (DFT thermodynamics): stable sink at 6 H per linker → ~2.3 wt% excess; >6 H unstable to H2 formation. Resolution: do not use site counts alone; compute thermodynamic stability. [[contradictions/maximum-achievable-spillover-capacity-on-irmof-1]]
  - Mechanism of H transport:
    - Claim A: chemisorbed diffusion could redistribute H.
    - Claim B (this source): chemisorbed diffusion barriers are high; gas‑phase/physisorbed atomic H through entrances/mesopores is plausible. Resolution: barrier computations favor gas‑phase transport in ideal crystals; alternative mechanisms (hole‑mediated, defect‑specific) exist in literature and require case-by-case validation. [[contradictions/mechanism-of-h-transport-chemisorbed-diffusion-vs-gas-phase-vs-alternative]]
  - Role of defects and inclusions:
    - Defect engineering/partial collapse can increase entrance density and measured uptake, but inclusions/leftover solvates or reaction products may confound observed enhancements. Experimental controls and characterization are required. [[contradictions/role-of-defects-and-inclusions-in-observed-uptake]]
  - Importance of pore-network access vs atomic‑H generation:
    - Both matter: poor entrance access prevents catalyst-generated atoms from penetrating; once entrances adequate, catalyst emission/supply may limit uptake. Diagnose rate-limiting step experimentally. [[contradictions/importance-of-pore-network-access-vs-atomic-h-generation-as-rate-limiting-s]]
- Metadata caution
  - When using older literature or third‑party datasets for spillover claims, check whether reported uptakes included catalysts or defective/collapsed structures; these conditions materially change design recommendations. [[contradictions/paper-metadata-authors-journal-naming]]

## Linked pages
- Sources (newly ingested / key)
  - [[sources/src_fc58db74fa]] (Haoyi Tan & Guangcun Shan, iScience 2024 — I2/CH3I humid screening; GCMC + DFT + Zeo++)
  - [[sources/src_3b254ae858]] (Zhijie Chen et al., Cryst. Growth Des. 2021 — NU‑650/NU‑651 catenation control by bulky n‑butyl core substituents; Zeo++/DFT + experimental N2 for NU‑650)
  - [[sources/src_532b708453]] (Jonathan L. Belof et al., JACS 2007 — polarizable MC study of H2 in narrow ionic soc‑MOF; Thole‑Applequist)
  - [[sources/src_c42cf01235]] (Ryther Anderson et al., Chem. Mater. 2018 — HTCS DFT+GCMC+ML on CO2 capture: functionalization, topology, MBBB charges, HBDM descriptor)
  - [[sources/src_0abff73929]] (G. M. Psofogiannakis & G. E. Froudakis, J. Phys. Chem. C 2011 — DFT cluster study of hydrogen spillover in IRMOF‑1: thermodynamics, kinetics, diffusion, ER recombination, and role of defects/mesopores)
  - (other previously listed sources preserved)...
- Mechanisms (key items; additions)
  - [[mechanisms/pld-the-pore-limiting-diameter-pld-of-a-porous-crystal-determines-whether-a]]
  - [[mechanisms/pld-pld-and-largest-cavity-diameter-lcd-can-be-computed-from-a-geometric-gr]]
  - [[mechanisms/pld-pore-limiting-diameter-pld-smaller-than-the-kinetic-diameter-of-ch3i-4]]
  - [[mechanisms/pld-geometric-pore-metrics-lcd-void-fraction-surface-area-pore-volume-corre]]
  - [[mechanisms/pld-largest-cavity-diameter-lcd-exerts-a-stronger-influence-than-other-sing]]
  - [[mechanisms/pld-mil-53-al-exhibits-breathing-flexible-pore-phases-the-high-temperature]]
  - [[mechanisms/pld-nu-650-twofold-interpenetrated-pcu-zn-mof-has-an-experimental-total-por]]
  - [[mechanisms/pld-simulations-zeo-based-on-crystal-structure-indicate-nu-651-non-interpen]]
  - [[mechanisms/pld-mixed-introducing-bulky-n-butyl-groups-into-the-cores-of-clathrochelate]]
  - [[mechanisms/pld-linker-conformation-during-modulated-synthesis-can-be-used-to-control-i]]
  - [[mechanisms/pld-interpenetration-in-mofs-can-be-controlled-by-liquid-phase-epitaxy-lite]]
  - [[mechanisms/pld-co2-linker-functionalization-can-change-pore-sizes-and-sometimes-topolo]]
  - [[mechanisms/co2-co2-binding-to-functionalized-mof-building-blocks-is-dominated-by-elect]]
  - [[mechanisms/mixed-accurate-representation-of-electrostatics-in-simulations-is-critical]]
  - [[mechanisms/co2-dft-calculated-co2-binding-strengths-vary-substantially-across-function]]
  - [[mechanisms/co2-dft-binding-energies-correlate-with-gcmc-predicted-co2-loadings-across]]
  - [[mechanisms/co2-when-functional-groups-provide-weak-co2-binding-e-g-h-4-and-ch3-2-co2-c]]
  - [[mechanisms/co2-h2-topology-encodes-pore-shape-and-polydispersity-certain-topologies-th]]
  - [[mechanisms/co2-decision-tree-analysis-ml-identifies-the-highest-bond-dipole-moment-hbd]]
  - [[mechanisms/h2-explicit-many-body-electronic-polarization-induction-is-the-dominant-con]]
  - Added H2 / spillover mechanisms from Psofogiannakis & Froudakis (2011):
    - [[mechanisms/h2-mixed-general-spillover-sequence-h2-dissociates-on-metal-catalyst-partic]]
    - [[mechanisms/h2-experimental-observations-some-studies-report-enhanced-room-temperature]]
    - [[mechanisms/h2-thermodynamic-capacity-limit-for-irmof-1-bdc-linker-although-12-nominal]]
    - [[mechanisms/h2-per-atom-binding-energies-dft-cluster-models-for-atomic-h-on-irmof-1-bdc]]
    - [[mechanisms/h2-chemisorbed-h-diffusion-is-kinetically-prohibitive-in-ideal-irmof-1-migr]]
    - [[mechanisms/h2-pld-gas-phase-or-weakly-physisorbed-atomic-h-diffusion-within-mof-pores]]
    - [[mechanisms/h2-sticking-adsorption-kinetics-on-the-bdc-linker-the-first-h-addition-has]]
    - [[mechanisms/h2-eley-rideal-abstraction-gas-phase-h-adsorbed-h-h2-has-very-small-or-zero]]
    - [[mechanisms/h2-site-selective-sequence-of-hydrogenation-on-the-bdc-linker-same-side-ca]]
    - [[mechanisms/h2-hydrogen-pressure-qualitatively-affects-er-recombination-and-penetration]]
    - [[mechanisms/h2-rate-limiting-considerations-gas-phase-or-physisorbed-atomic-h-diffusion]]
- Design rules (key items; additions)
  - [[design_rules/pld-use-grid-spacing-0-1-a-for-fast-pld-lcd-screening-expect-an-uncertainty]]
  - [[design_rules/pld-exclude-mof-candidates-whose-pld-is-smaller-than-the-kinetic-diameter-o]]
  - [[design_rules/pld-co2-after-functionalizing-linkers-always-recompute-pore-metrics-pld-lpd]]
  - [[design_rules/mixed-when-performing-high-throughput-computational-screening-for-co2-and-o]]
  - [[design_rules/co2-use-polar-functional-groups-e-g-oh-sh-cn-nh2-no2-to-increase-co2-affini]]
  - [[design_rules/co2-use-hbdm-highest-bond-dipole-moment-of-the-functional-group-as-an-inexp]]
  - [[design_rules/co2-if-dft-binding-to-the-intended-functional-group-is-weak-evaluate-node-l]]
  - [[design_rules/h2-co2-use-the-study-s-mixture-pressure-protocol-for-computational-evaluati]]
  - [[design_rules/pld-increase-steric-bulk-at-the-ligand-core-to-avoid-framework-interpenetra]]
  - [[design_rules/pld-use-synthesis-condition-levers-modulated-synthesis-linker-conformation]]
  - [[design_rules/pld-use-structure-based-simulations-e-g-zeo-and-geometry-based-comput]]
  - Added spillover / H2 design rules:
    - [[design_rules/pld-h2-mixed-introduce-or-preserve-pore-defects-mesopore-channels-and-incre]]
    - [[design_rules/h2-ensure-catalyst-nanoparticles-do-not-block-pore-channels-and-where-benef]]
    - [[design_rules/h2-when-selecting-or-designing-linkers-to-increase-chemisorption-capacity-v]]
    - [[design_rules/h2-mitigate-eley-rideal-recombination-losses-by-a-reducing-labile-o-h-adsor]]
    - [[design_rules/h2-prioritize-improving-generation-and-supply-of-atomic-h-from-catalysts-ac]]
  - (other design rules preserved)...
- Contradictions (preserved + new)
  - [[contradictions/use-of-kinetic-diameter-vs-actual-diffusion-behavior]]
  - [[contradictions/nu-651-porosity-simulated-vs-experimentally-measured]]
  - [[contradictions/tradeoff-between-catenation-interpenetration-porosity-adsorption-and-mechan]]
  - [[contradictions/classical-polarizable-models-vs-quantum-nuclear-effects]]
  - [[contradictions/halogenated-mofs-as-top-co2-performers-prior-htcs-vs-dft-corrected-results]]
  - [[contradictions/functionalization-effect-on-co2-loading-vs-adsorption-site-mechanism]]
  - [[contradictions/role-of-electrostatics-vs-dispersion]]
  - [[contradictions/moisture-effects-on-mof-co2-capture]]
  - Spillover contradictions added:
    - [[contradictions/maximum-achievable-spillover-capacity-on-irmof-1]]
    - [[contradictions/mechanism-of-h-transport-chemisorbed-diffusion-vs-gas-phase-vs-alternative]]
    - [[contradictions/role-of-defects-and-inclusions-in-observed-uptake]]
    - [[contradictions/importance-of-pore-network-access-vs-atomic-h-generation-as-rate-limiting-s]]
  - (other contradictions preserved)

Notes and limitations
- Context specificity: correlations from Anderson et al. (Chem. Mater. 2018) apply to their HTCS context (DFT + GCMC at 313 K, specific topologies and functionalizations). Tan & Shan I2/CH3I and Belof et al. H2 polarization results are context-specific; do not generalize numeric thresholds across different T/P or guest chemistry without re-evaluation. Psofogiannakis & Froudakis (2011) use DFT cluster models for IRMOF‑1/BDC and their thermodynamic/kinetic thresholds are specific to that chemistry — generalize cautiously to other linkers/topologies. [[mechanisms/co2-h2-topology-encodes-pore-shape-and-polydispersity-certain-topologies-th]], [[mechanisms/h2-explicit-many-body-electronic-polarization-induction-is-the-dominant-con]], [[mechanisms/h2-thermodynamic-capacity-limit-for-irmof-1-bdc-linker-although-12-nominal]]
- Modeling fidelity: DFT-derived charges (MBBB, REPEAT) are recommended for accurate electrostatics. HTCS using cheap charge schemes may produce false positives (halogenated linkers). Include charge-method provenance in candidate metadata. For spillover claims include catalyst details and thermodynamic/kinetic computations. [[mechanisms/mixed-accurate-representation-of-electrostatics-in-simulations-is-critical]]
- Preserve prior mechanistic conclusions (iodine/H2/linker/interpenetration rules). The CO2 functionalization/topology insights and H2 spillover implications supplement existing PLD/linker/interpenetration guidance — where rules conflict, branch by T/P, guest polarity, catalyst presence and flag contradictions for downstream decision logic.
- Agents must recompute PLD/LCD/PSD after any linker functionalization/topology change, attach operating‑condition tags to recommendations, and pair geometric descriptors with energetic/dynamic checks (Qst, DFT binding, explicit-solvent MD, adsorption calorimetry) before committing to synthesis. When considering spillover strategies, require DFT thermodynamics and barrier calculations plus explicit description of catalyst placement and pore‑entrance engineering before prioritization.