---
title: "CO2 Adsorption Mechanism Synthesis"
type: topic
tags: [co2, adsorption, mechanism, design_rule, pld]
created: "2026-05-01"
updated: "2026-05-02"
sources: [[sources/src_90ad344e79]], [[sources/src_a034d4944a]], [[sources/src_90953381a0]], [[sources/src_83cde498f9]], [[sources/src_a318a71841]], [[sources/src_97052fb350]], [[sources/src_20dae1036b]], [[sources/src_1fa85425f9]], [[sources/src_c42cf01235]]
confidence: medium
---

# CO2 Adsorption Mechanism Synthesis

Cumulative synthesis of mechanisms and agent-actionable design implications for low‑pressure CO2 capture in MOFs, emphasizing strong adsorption sites (open metal sites, polar/Lewis‑basic groups, amines), pore‑size matching (PLD/LCD/PSD), and best practices for computational triage. Incorporates recent DFT+GCMC+ML evidence (Anderson et al., 2018) on the dominant role of electrostatics, functional‑group rankings, topology coupling, and practical charge‑assignment prescriptions for HTCS.

## Stable synthesis (cumulative notes)

- Electrostatics dominate CO2 binding to pore-facing functional groups.
  - Mechanism: CO2 aligns with its positively charged C atom toward the most negatively charged atom of functional groups while CO2 oxygens orient to positive sites; electrostatic complementarity is the principal differentiator across functionalizations. (high confidence; DFT + GCMC) See: [[mechanisms/co2-co2-binding-to-functionalized-mof-building-blocks-is-dominated-by-elect]]
  - Practical implication: place negatively charged atoms (O, N, S, halogens where appropriate) in pore-facing positions and design electrostatic pockets to increase Qst and low‑p CO2 uptake.

- Polar / polarizable functional groups often improve CO2 capture—but topology matters.
  - Mechanism: hydroxyl, thiol, cyano, amino, nitro groups commonly increase affinity/selectivity, but improvements can be negated or reversed when functionalization changes PLD/LPD or pore topology. (medium–high confidence; DFT+GCMC+ML) See: [[mechanisms/co2-mixed-functionalization-with-polar-polarizable-groups-hydroxyl-thiol-cy]], [[mechanisms/pld-co2-linker-functionalization-can-change-pore-sizes-and-sometimes-topolo]]
  - Practical implication: always recompute pore metrics (PLD/LPD/void fraction) after functionalization and re-run adsorption simulations to confirm net benefit.

- Quantified DFT ranking of functional groups (for examined set)
  - Finding: relative binding strength order (strongest → weakest) reported: -(NH2)2 > -(CN)4 > -(SH)2 > -(NO)2 > -(OH)2 > -(CN)2 > -(F)4 > -(Br)2 > -(CF)3 > -(F)2 > -(CH)3 > -(H)4 > -(Br)4. (high confidence for that dataset) See: [[mechanisms/co2-dft-calculated-co2-binding-strengths-vary-substantially-across-function]]

- Open metal sites / metal cations strengthen CO2 binding.
  - Mechanism: electrostatic interaction to metal cations and OMS increases adsorption enthalpy and low‑p uptake; water competes for OMS. (high confidence) See: [[mechanisms/co2-co2-interacts-strongly-with-metal-cations-and-open-metal-sites-in-mofs]]

- Amine grafting / diamine functionalization (DOBPDC / MOF‑74 families)
  - Mechanism summary: appended primary/secondary amines introduce chemisorption (carbamate/ammonium‑carbamate); expanded DOBPDC enables cooperative chain formation and stepwise isotherms; topology and steric footprint determine whether grafting helps or blocks pores. (high confidence) See: [[mechanisms/co2-amine-functionalization-is-a-prominent-strategy-to-enhance-co2-binding]], [[mechanisms/co2-diamine-functionalization-of-expanded-m2-dobpdc-materials-leads-to-coop]], [[mechanisms/co2-alkyl-substitution-on-appended-amines-e-g-methylation-such-as-mmen-shif]]

- Confinement and ultramicroporosity amplify both physisorption and sieving.
  - Mechanism: ultramicropores and designed single‑molecule traps (PLD tuned to molecular size) produce high per‑site Qst and can enable CO2/H2 separation via sieving and strong confinement. (medium confidence) See: [[mechanisms/co2-h2-mixed-ultra-microporous-single-ligand-mofs-and-pore-designs-that-cre]]

- Dispersion is a substantial baseline attraction; electrostatics controls relative gains.
  - Mechanism: dispersion contributes large absolute energy, but differences between functional groups and resulting selectivity gains are driven principally by electrostatic interaction differences. (high confidence) See contradiction: [[contradictions/role-of-electrostatics-vs-dispersion]]

- Practical HTCS guidance: charge accuracy matters for CO2 (and halogenated candidates).
  - Mechanism: inexpensive electronegativity‑equalization methods can overestimate halogen charges and spuriously prioritize halogenated MOFs; molecular building block-based (MBBB) or unit‑cell‑fitted (REPEAT) DFT charges are more reliable for adsorption prediction. (high confidence) See: [[mechanisms/mixed-accurate-representation-of-electrostatics-in-simulations-is-critical]], [[contradictions/halogenated-mofs-as-top-co2-performers-prior-htcs-vs-dft-corrected-results]]

- ML‑derived descriptors and decision rules are predictive and actionable.
  - Mechanism: decision‑tree analysis identifies the highest bond dipole moment (HBDM) of a functional group as the top predictor for CO2/N2 selectivity improvement; HBDM > 0.319 e·Å improved selectivity in >90% of cases in the dataset. (medium confidence) See: [[mechanisms/co2-decision-tree-analysis-ml-identifies-the-highest-bond-dipole-moment-hbd]]

- Topology and node geometry can create unexpected adsorption sites (π pockets).
  - Mechanism: when functional groups are weak binders (e.g., -(H)4, -(CH3)2), CO2 can preferentially occupy node regions where overlapping linker/node potentials form strong adsorption "π pockets", producing higher-than-expected loadings. (medium confidence) See: [[mechanisms/co2-when-functional-groups-provide-weak-co2-binding-e-g-h-4-and-ch3-2-co2-c]]

- Magnitude of functionalization effects (typical ranges observed)
  - Finding: "Good" functionalization increased CO2 loading up to ~1 mol·kg−1 (CO2:N2 case at 1 bar) and up to ~4 mol·kg−1 (CO2:H2 at 20 bar); "bad" functionalization decreased loadings by similar magnitudes in worst cases. Selectivity improvements up to ~6 (CO2:N2) and ~200 (CO2:H2) units were observed in the studied set. Use these as realistic target ranges for prioritization. (high confidence for the reported dataset) See: [[mechanisms/co2-h2-mixed-magnitude-of-functionalization-effects-observed-good-functiona]]

## Condition-specific mechanisms

- Trace‑CO2 (~400 ppm) physisorption with fluorinated contracted channels
  - Conditions: 298 K; ppCO2 ≈ 400 ppm.
  - Mechanism: electrostatic confinement by aligned F centers and tight channel confinement (SIFSIX / NbOFFIVE) produces high Qst and detectable ppm uptake. (high confidence) See: [[mechanisms/co2-contracted-square-shaped-channels-with-periodically-aligned-proximal-fl]]

- Post‑combustion / low‑pressure CO2 (≈0.05–0.15 bar)
  - Conditions: flue‑gas model (≈5–15% CO2 in N2), typical experimental screens at 298–313 K; many computational benchmarks use 1 bar for per‑adsorbent comparisons — always match the intended process.
  - Mechanisms:
    - Amine‑functionalized DOBPDC (diamine‑appended): cooperative ammonium‑carbamate chain formation yields sigmoidal isotherms; metal identity and amine substitution tune the step pressure. (high confidence)
    - Polar functionalization in ultramicropores: electrostatic pockets (HBDM high) increase low‑p uptake if pore aperture and topology allow access. (medium–high confidence)
  - Design implication: design cooperative steps to lie between adsorption and regeneration pCO2 to maximize working capacity.

- Precombustion CO2 (CO2/H2) metrics (study protocol)
  - Conditions used in Anderson et al.: adsorption = 20:80 CO2:H2 at 20 bar; desorption = pure CO2 at 1 bar; T = 313 K for reported metrics.
  - Mechanism: strong CO2 electrostatic interactions versus weak H2 interactions make CO2/H2 selectivity highly responsive to polar functionalization and pore confinement. (high confidence) See: [[mechanisms/h2-co2-mixed-precombustion-co2-capture-metrics-in-this-study-were-computed]]

- Membrane CO2 permeation / selective transport
  - Conditions: membrane tests / MD at process pressures (variable).
  - Mechanism: PLD/PSD and pore shape/topology control sieving and transport; rigidity approximations can fail for gating or narrow‑aperture membranes. (high confidence) See: [[mechanisms/pld-co2-linker-functionalization-can-change-pore-sizes-and-sometimes-topolo]]

- Humid / oxidative feeds
  - Conditions: flue gas with H2O vapor.
  - Mechanism: water competes with polar/amine sites and can change sorption energetics or degrade amine chemistries; moisture‑stable frameworks or hydrophobic co‑functionalization/multivariate strategies mitigate loss. (high confidence) See: [[design_rules/co2-when-targeting-humid-flue-gases-prioritize-moisture-stable-mofs-or-stra]], [[contradictions/moisture-effects-on-mof-co2-capture]]

## Design implications for Agent

Actionable rules, decision points and failure modes for an automated MOF design agent targeting low‑pressure CO2 uptake, pore‑size matching, and amine grafting. These extend existing rules with DFT+GCMC+ML‑derived prescriptions.

- Use electrostatics-aware charge assignment for HTCS triage and re‑evaluation.
  - If: screening MOFs where electrostatics influence CO2 (most CO2 screens)
  - Then: assign Coulomb charges using DFT‑fitted MBBB or REPEAT charges, or use validated equilibration parameterizations calibrated against DFT; avoid naïve electronegativity‑equalization (EEM) methods for final ranking because they can spuriously promote halogenated MOFs. Flag any halogenated candidates identified by EEM for DFT re-evaluation. (high confidence) See: [[design_rules/mixed-when-performing-high-throughput-computational-screening-for-co2-and-o]], [[contradictions/halogenated-mofs-as-top-co2-performers-prior-htcs-vs-dft-corrected-results]]

- HBDM as a cheap first‑pass functionalization filter.
  - If: evaluating whether a given functional group will likely increase CO2/N2 selectivity
  - Then: compute the Highest Bond Dipole Moment (HBDM) of the functional group. If HBDM > 0.319 e·Å, prioritize the functionalized variant (improvement in >90% of cases in the study); if ≤ 0.319 e·Å, consult topology, most‑negative‑charge and void fraction before advancing. (medium confidence) See: [[design_rules/co2-use-hbdm-highest-bond-dipole-moment-of-the-functional-group-as-an-inexp]]

- Recompute geometric pore metrics after any linker functionalization.
  - If: you functionalize linkers (OH, NH2, CN, etc.)
  - Then: run Zeo++ (PLD, LPD, void fraction, surface area) and rerun GCMC to confirm net improvement; treat functionalization as simultaneous chemistry+geometry perturbation. (high confidence) See: [[design_rules/pld-co2-after-functionalizing-linkers-always-recompute-pore-metrics-pld-lpd]]

- Use HTE triage but validate top candidates with higher‑fidelity models.
  - If: screening thousands of MOFs
  - Then: use UFF/Dreiding + PQeq (or similar) + MBBB/REPEAT approximations sparingly; for top candidates re-evaluate with DFT‑derived charges and, where relevant, refined FF parameters (and include electrostatics properly). Record which candidates change rank on re-evaluation and prioritize those for experiment. (medium confidence) See: [[design_rules/co2-use-generic-force-fields-and-approximate-charge-schemes-for-rapid-large]], [[mechanisms/mixed-accurate-representation-of-electrostatics-in-simulations-is-critical]]

- Integrate ML for prioritizing topology × functionalization pairs.
  - If: large combinatorial space of topologies and functionalizations
  - Then: train decision trees/ensemble models on DFT+GCMC data (or reuse trained models) to prioritize combinations; use feature importances (e.g., HBDM, most‑negative‑charge, void fraction) to guide synthesis choices. (medium confidence) See: [[mechanisms/mixed-machine-learning-models-decision-trees-and-ensemble-regression-method]]

- Process‑aware mixture simulation protocols (use study protocols for comparability)
  - If: evaluating precombustion performance for comparability with Anderson et al.
  - Then: simulate adsorption at 20 bar with 20:80 CO2:H2 and desorption as pure CO2 at 1 bar at 313 K; inspect selectivity — negative working capacity can arise if desorption assumption invalid. (high confidence) See: [[design_rules/h2-co2-use-the-study-s-mixture-pressure-protocol-for-computational-evaluati]], [[mechanisms/h2-co2-mixed-precombustion-co2-capture-metrics-in-this-study-were-computed]]
  - If: evaluating postcombustion (flue) separations, simulate at representative flue pCO2 (e.g., 0.05–0.15 bar) and include humidity.

- Functionalization degree and topology as optimization variables.
  - If: planning amine grafting or other high‑density functionalization
  - Then: treat coverage (0–100%) as a tunable parameter; evaluate partial coverage scenarios to avoid pore blocking and preserve void fraction. Prefer expanded topologies (e.g., DOBPDC types) for cooperative diamine chemistry. (high confidence) See: [[design_rules/co2-do-not-assume-maximizing-amine-grafting-density-improves-co2-performanc]], [[design_rules/pld-prioritize-expanded-linker-dobpdc-m2-dobpdc-frameworks-when-planning-to]]

- Prioritize ultra‑micropore traps for CO2/H2 separations.
  - If: target is precombustion CO2/H2 separations
  - Then: design ultra‑microporous single‑ligand MOFs or single‑molecule trap motifs that precisely size the adsorption site to exploit strong confinement and sieving. (medium confidence) See: [[mechanisms/co2-h2-mixed-ultra-microporous-single-ligand-mofs-and-pore-designs-that-cre]]

- Humidity testing and moisture‑stability checks early.
  - If: feed contains H2O
  - Then: include H2O in mixture GCMC/MD or at minimum run competitive adsorption checks and stability/cycling tests; favor oxidation‑resistant amines or hydrophobic co‑functionalizations when necessary. (high confidence) See: [[design_rules/co2-when-targeting-humid-flue-gases-prioritize-moisture-stable-mofs-or-stra]]

- Candidate advancement thresholds (process‑aware)
  - If: simulated cyclic working capacity ≥ ~2.5–3.0 mmol·g−1 under process‑relevant mixture and reasonable regeneration swing (~60°C) with passing humidity tests
  - Then: advance to detailed PSA/TSA process simulation and experiment. (medium confidence) See: [[design_rules/co2-when-a-candidate-shows-simulated-working-capacity-2-5-3-mmol-g-1-with-a]]

- Metadata and reproducibility (required)
  - Record: force field, partial‑charge method (PQeq / MBBB / REPEAT / DFT), framework rigidity, PLD/LCD grid, functionalization identity & coverage, isotherm temperatures, humidity level, and chemisorption model details.

## Contradictions and caveats

- Halogenated MOFs as HTCS top performers — artefact vs reality
  - Claim A: Some prior HTCS reported halogenated MOFs among top CO2 performers.
  - Claim B: EEM charge methods can overestimate halogen partial charges; reassigning charges with DFT‑fitted MBBB or REPEAT changes rankings and often demotes halogenated candidates. Do not prioritize halogenated candidates identified only with inexpensive charge models without DFT re-evaluation. (high confidence) See: [[contradictions/halogenated-mofs-as-top-co2-performers-prior-htcs-vs-dft-corrected-results]]

- Functionalization effect vs adsorption‑site mechanism
  - Claim A: Polar functionalization typically enhances CO2 uptake.
  - Claim B: In some topologies with weak functional groups, CO2 binds at node π pockets, making functional‑group binding energy a poor sole predictor.
  - Resolution: combine functional‑group binding metrics with topology/node geometry analysis and full‑framework simulations (density maps) to predict outcome. (medium confidence) See: [[contradictions/functionalization-effect-on-co2-loading-vs-adsorption-site-mechanism]]

- Role of electrostatics vs dispersion
  - Claim A: Electrostatics control relative gains across functionalizations and are critical for selectivity.
  - Claim B: Dispersion provides a large baseline attraction and cannot be ignored.
  - Resolution: account for both terms; use electrostatics (accurate charges) to drive differentiation but ensure dispersion parameters are reasonable. (high confidence) See: [[contradictions/role-of-electrostatics-vs-dispersion]]

- Amine vs other N‑containing groups and moisture sensitivity
  - Claim A: Amines reliably enhance CO2 binding and can be engineered for humidity tolerance.
  - Claim B: Some N‑functional groups (e.g., amides) do not behave as expected in particular pore contexts.
  - Resolution: validate specific N‑group chemistries under intended humidity and topology; do not generalize across all N‑containing functionalities. (medium confidence) See: [[contradictions/functional-group-identity-matters-amines-vs-amides-and-moisture-sensitivity]]

- Applicability of coarse force fields and zero-charge approximations
  - Issue: LJ‑only or zero‑charge models can miss CO2 electrostatic effects and produce misleading loadings/selectivities.
  - Resolution: use LJ prefilters for geometry and dispersion baseline but include Coulombic interactions (accurate charges) before advancing candidates. (high confidence) See: [[contradictions/applicability-of-lj-nonpolar-adsorbate-models-to-co2]], [[mechanisms/co2-dft-binding-energies-correlate-with-gcmc-predicted-co2-loadings-across]]

## Linked pages

Sources:
- [[sources/src_90ad344e79]] (Farha et al., JACS 2010)
- [[sources/src_a034d4944a]] (Al‑Saedi 2023 review)
- [[sources/src_90953381a0]] (2019 Computational screening — CoRE‑MOFs)
- [[sources/src_83cde498f9]] (Jo et al., ACS AMI 2022 — Cu(adci)-2)
- [[sources/src_a318a71841]] (Berger et al., J. Phys. Chem. C 2022 — linker side‑chain gating)
- [[sources/src_97052fb350]] (Haldoupis, Nair, Sholl, JACS 2010 — PLD/LCD and energy-grid estimators)
- [[sources/src_20dae1036b]] (Bahamon et al., Front. Chem., 2021 — amine functionalization of MOF-74 / DOBPDC)
- [[sources/src_1fa85425f9]] (Erucar & Keskin, Front. Mater., 2018 — high‑throughput MOF simulations for CO2 separation)
- [[sources/src_c42cf01235]] (Anderson et al., Chem. Mater., 2018 — Role of pore chemistry and topology; DFT+GCMC+ML)

Mechanisms (ingested / generated):
- [[mechanisms/co2-co2-binding-to-functionalized-mof-building-blocks-is-dominated-by-elect]]
- [[mechanisms/co2-mixed-functionalization-with-polar-polarizable-groups-hydroxyl-thiol-cy]]
- [[mechanisms/pld-co2-linker-functionalization-can-change-pore-sizes-and-sometimes-topolo]]
- [[mechanisms/mixed-accurate-representation-of-electrostatics-in-simulations-is-critical]]
- [[mechanisms/h2-co2-mixed-precombustion-co2-capture-metrics-in-this-study-were-computed]]
- [[mechanisms/mixed-machine-learning-models-decision-trees-and-ensemble-regression-method]]
- [[mechanisms/co2-dft-calculated-co2-binding-strengths-vary-substantially-across-function]]
- [[mechanisms/co2-h2-co2-generally-interacts-more-strongly-with-mof-functional-groups-tha]]
- [[mechanisms/co2-dft-binding-energies-correlate-with-gcmc-predicted-co2-loadings-across]]
- [[mechanisms/co2-when-functional-groups-provide-weak-co2-binding-e-g-h-4-and-ch3-2-co2-c]]
- [[mechanisms/co2-h2-mixed-magnitude-of-functionalization-effects-observed-good-functiona]]
- [[mechanisms/co2-decision-tree-analysis-ml-identifies-the-highest-bond-dipole-moment-hbd]]
- [[mechanisms/co2-amine-functionalization-is-a-prominent-strategy-to-enhance-co2-binding]]
- [[mechanisms/co2-h2-mixed-ultra-microporous-single-ligand-mofs-and-pore-designs-that-cre]]
- (plus previously ingested mechanism pages listed at the top of this file)

Design rules:
- [[design_rules/co2-use-polar-functional-groups-e-g-oh-sh-cn-nh2-no2-to-increase-co2-affini]]
- [[design_rules/mixed-when-performing-high-throughput-computational-screening-for-co2-and-o]]
- [[design_rules/pld-co2-after-functionalizing-linkers-always-recompute-pore-metrics-pld-lpd]]
- [[design_rules/h2-co2-use-the-study-s-mixture-pressure-protocol-for-computational-evaluati]]
- [[design_rules/co2-use-hbdm-highest-bond-dipole-moment-of-the-functional-group-as-an-inexp]]
- [[design_rules/co2-if-dft-binding-to-the-intended-functional-group-is-weak-evaluate-node-l]]
- [[design_rules/co2-when-targeting-humid-flue-gases-prioritize-moisture-stable-mofs-or-stra]]
- (plus previously ingested design rules listed at the top of this file)

Contradictions:
- [[contradictions/halogenated-mofs-as-top-co2-performers-prior-htcs-vs-dft-corrected-results]]
- [[contradictions/functionalization-effect-on-co2-loading-vs-adsorption-site-mechanism]]
- [[contradictions/role-of-electrostatics-vs-dispersion]]
- [[contradictions/functional-group-identity-matters-amines-vs-amides-and-moisture-sensitivity]]
- [[contradictions/moisture-effects-on-mof-co2-capture]]
- (plus previously listed contradictions)

If you are an automated agent using this page
- Always include Coulombic interactions (accurate charges) and process‑relevant mixtures before advancing candidates for CO2 separations.
- Use HBDM as a cheap first pass: if HBDM > 0.319 e·Å, functionalization is likely to improve CO2/N2 selectivity in most topologies; otherwise consult topology and charge descriptors.
- For HTCS throughput: use generic FF + validated fast charge parameterizations for triage, but re-evaluate top candidates with MBBB/REPEAT or DFT‑fitted charges and higher‑fidelity FFs.
- After any linker functionalization, recompute PLD/LPD/void fraction (Zeo++) and rerun adsorption simulations; treat geometry changes as co‑drivers of performance.
- Prefer expanded DOBPDC‑type topologies for cooperative diamine chemistries; always test partial‑coverage scenarios and humid stability.
- Advance materials that meet process‑relevant simulated cyclic working capacity targets (≳2.5–3.0 mmol·g−1) under realistic mixtures and humidity, and that remain robust when re‑evaluated with DFT‑level charges.
- Log all metadata (force field, charge method, rigidity, PLD grid, functionalization degree) for reproducibility and to enable identification of candidates sensitive to modeling choices.