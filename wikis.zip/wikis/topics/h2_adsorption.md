---
title: "H2 Adsorption Mechanism Synthesis"
type: topic
tags: [h2, adsorption, mechanism, design_rule]
created: "2026-05-01"
updated: "2026-05-02"
sources: [[sources/src_8d4a290e19]], [[sources/src_90953381a0]], [[sources/src_71bcf59437]], [[sources/src_fa8cccd644]], [[sources/src_97052fb350]], [[sources/src_340141308b]], [[sources/src_b0ea8c70ab]], [[sources/src_b1552d4a9d]], [[sources/src_ff1b0c9d63]], [[sources/src_532b708453]], [[sources/src_c42cf01235]], [[sources/src_572b475183]], [[sources/src_0abff73929]]
confidence: medium
---

# H2 Adsorption Mechanism Synthesis

Cumulative synthesis of mechanisms and agent‑actionable rules for H2 uptake in porous frameworks, emphasizing gravimetric/volumetric uptake, pore volume, surface area, density, accessible pore volume (Va), binding energetics (Qst and integral enthalpies), and modeling/measurement best practices. This page preserves prior conclusions (including many‑body polarization results from Belof et al. [[sources/src_532b708453]]) and integrates pore‑chemistry/topology and electrostatics lessons from Anderson et al. [[sources/src_c42cf01235]], plus theoretical DFT analysis of hydrogen spillover and transport in IRMOF‑type materials by Psofogiannakis & Froudakis (2011) [[sources/src_0abff73929]] and experimental catalyst‑assisted observations [[sources/src_572b475183]].

Key takeaways from [[sources/src_0abff73929]]:
- Detailed DFT cluster modeling supports a canonical spillover sequence (H2 dissociation on metal → atomic H emission → gas‑phase/weakly physisorbed H transport into pores → chemisorption on linker sites) and quantifies thermodynamics and kinetics for IRMOF‑1 (BDC) linkers. The calculations show:
  - Thermodynamic sink: at most six H atoms per BDC linker are stable vs H2 formation → corresponding chemisorbed excess ≈ 2.3 wt% for ideal IRMOF‑1 linkers (contrasts with naive 12‑site counting → ≈4.5 wt%). [[sources/src_0abff73929]]
  - Per‑atom DFT 