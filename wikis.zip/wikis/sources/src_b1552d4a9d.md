---
title: "Hydrogen Adsorption in Metal–Organic Frameworks"
type: source
tags: [h2, source, paper]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_b1552d4a9d]
confidence: medium
---


# Hydrogen Adsorption in Metal–Organic Frameworks

## Metadata

- Source ID: `src_b1552d4a9d`
- Raw file: `raw_sources/inbox/hydrogen-adsorption-in-metalorganic-frameworks-4.pdf`
- Primary task: `h2`
- Task tags: h2, pld, mixed
- Auto-classification confidence: `high`
- Auto-classification reason: The source is a focused review on hydrogen adsorption in MOFs (mechanisms, capacities at 77 K and elevated pressures, isosteric heat/Qst, binding energetics, specific examples like MOF-5, IRMOFs, NU-1501, PCN-610/NU-100). It also discusses pore- and linker-related design variables (surface area, pore volume, linker length, catenation, pore sizes/channels) that directly impact H2 storage, so PLD/pore-design content is substantial. CO2 is only mentioned in a passing list of gases and is not a focus.
- Authors: Vladimír Zeleňák
- Year: None
- Journal: Encyclopedia.pub (entry)
- DOI: 
- Material families: MOF-5 / IRMOFs, IRMOFs / MOF-5 family, PCN-610 / NU-100, NU-1501 (NU-1501-M, NU-1501-Al), UiO family (UiO-66, UiO-67), HKUST-1, MIL family, MIL-100(Al), DUT family, MOF-200, MOF-177, PCN-6 / PCN-60, SNU-6, porphyrin-based MOFs, Mn[(MnCl)(BTT)] family, M-URJC-n (Co, Cu, Zn) flexible sulfur-containing MOFs, pillared-layer Zn(bpta)/bipyridine frameworks, general microporous MOFs, metal–organic frameworks (general), microporous MOFs
- Methods: review, experiment, grand canonical Monte Carlo (GCMC) simulation, literature review
- Gas targets: H2, CO2

## Extracted mechanism claims

- **Hydrogen in most nanoporous materials (including MOFs) is adsorbed by weak physisorption with low isosteric heats; reported typical ranges are on the order of a few to ~10 kJ·mol−1.**  
  - Task: `h2`; confidence: `high`
  - Implication: Expect MOFs to require low temperatures (e.g., 77 K) or introduction of higher-affinity sites / operational strategies to achieve useful H2 loadings at or near ambient conditions.
  - Evidence: Heat values of hydrogen adsorption for most nanoporous materials, including MOFs, crosslinked polymers, or porous carbons, are within the range of 4–7 kJ·mol−1.  ...  the Qst values in most porous MOFs is within the range of 5–10 kJ·mol−1.
- **MOF-5 exhibits type I isotherm behavior at 77 K with substantial cryogenic uptake (4.7 wt% at 50 bar) but shows weak, nearly linear adsorption at 298 K (under-saturated in the 5–20 bar range).**  
  - Task: `h2`; confidence: `high`
  - Implication: High-surface-area MOFs like MOF-5 can deliver substantial gravimetric capacity at cryogenic temperatures; for room-temperature applications, focus on increasing binding strength or using cryogenic/pressure-swing operation.
  - Evidence: For MOF-5, the measured adsorption isotherm at 77 K showed type I behavior with H2 adsorption capacity of 4.7 wt% of H2 at P(H2) = 50 bar. ... The hydrogen adsorption isotherm at 298 K was approximately linear because the MOF-5 framework was under-saturated with gas within the range of 5–20 bar of H2.
- **At 77 K adsorption falls into distinct pressure regimes: at low pressure (~1 bar) uptake scales with isosteric heat (Qst); at intermediate pressure (~30 bar) uptake correlates with surface area (As); at very high pressure (~120 bar) uptake correlates with pore volume (V).**  
  - Task: `h2`; confidence: `high`
  - Implication: When designing MOFs for H2 storage at 77 K, choose the optimization target based on operating pressure: enhance Qst for low-pressure targets, maximize As for intermediate pressures, and maximize V for very high pressures.
  - Evidence: The obtained theoretical results suggest the existence of three adsorption modes at 77 K: (1) at low pressure (~1 bar of H2), the n_excess value is proportional to the value of Qst; (2) at ~30 bar of H2, the n_excess value is proportional to As; and (3) at ~120 bar of H2, the n_excess value is proportional to V.
- **Surface area (As) often predicts 77 K uptake and a linear relationship between As and uptake is observed over a broad range, but at low pressure (~1 bar) and very high As (> ~2000 m2·g−1) the correlation breaks down because surface cannot be fully covered and adsorption is dominated by highest-affinity sites.**  
  - Task: `h2|pld`; confidence: `high`
  - Implication: For 77 K intermediate-pressure applications increasing As is beneficial; for low-pressure (~1 bar) targets, simply increasing As beyond ~2000 m2·g−1 may not increase uptake — prioritize creating high-affinity adsorption sites and ensuring site accessibility.
  - Evidence: A linear relationship between the H2 adsorption capacity at 77 K and the As value has been confirmed in numerous publications. The adsorption capacity at 77 K and 1 bar of H2 is related to the As values within the range of 100–2000 m2·g−1 and does not correlate in the case of higher As values. This may be because the sorbent surface cannot be fully covered by H2 molecules at these high As and low P(H2) values. In addition, it is most likely that the H2 molecules will preferentially bind on the most thermodynamically favorable sites...
- **Pore sizes in MOFs are highly tunable; examples include IRMOFs with pore sizes from 3.8 to 28.8 Å, MOF-5 with cavities 15.1 Å and 11.0 Å, PCN-610/NU-100 with voids of 26.0, 18.6, 12.0 Å, and NU-1501 with ~2.2 nm hexagonal channels.**  
  - Task: `pld`; confidence: `high`
  - Implication: Pore diameters in MOFs can be targeted via linker choice and topology to match desired storage regimes or to create hierarchical voids.
  - Evidence: Pore size in IRMOFs can be incrementally varied from 3.8 to 28.8 Å ... overall structure of MOF-5 is composed of larger cavities (15.1 Å) and smaller cavities (11.0 Å) ... PCN-610/NU-100 ... three types of voids ... sizes 26.0, 18.6, and 12.0 Å ... NU-1501 ... open hexagonal channel with a pore size of ~2.2 nm.
- **NU-1501-Al's extremely high gravimetric and volumetric BET areas were cited as main reasons for its reported high hydrogen deliverable capacity when using a combined temperature/pressure swing (77 K & 100 bar -> 160 K & 5 bar).**  
  - Task: `h2`; confidence: `high`
  - Implication: To reach very high deliverable H2 capacities, pursue ultrahigh surface area and volumetric metrics and consider temperature/pressure-swing operation rather than relying on single-condition ambient storage.
  - Evidence: The ultramicroporous MOF, NU-1501-Al, exhibits high values for both gravimetric and volumetric BET areas (7310 m2·g−1 and 2060 m2·cm−3, respectively). These were considered the main reasons for the high value of hydrogen storage capacity (14.0 wt% and 46.2 g·dm−3) under a combined T and P(H2) change from 77 K and 100 bar to 160 K and 5 bar.
- **Longer organic linkers increase MOF surface area and pore volume (example: UiO-67 vs UiO-66), leading to higher high-pressure H2 uptake, but longer linkers can increase risk of catenation/interpenetration which reduces accessible porosity.**  
  - Task: `h2|pld`; confidence: `high`
  - Implication: Use longer organic linkers to increase surface area and pore volume for higher-pressure H2 storage, but apply synthesis controls to avoid catenation that reduces accessible sites.
  - Evidence: The longer linker in UiO-67 produced As = 2483 m2·g−1 vs 1281 m2·g−1 for UiO-66, V = 0.85 vs 0.43 cm3·g−1, and H2 uptake at 77 K and 38 bar of 4.6 wt% vs 2.4 wt%, respectively.
- **Framework catenation/interpenetration reduces accessible open metal sites and accessible porosity, lowering H2 uptake; catenation can be influenced/mitigated by linker design and synthesis conditions (templates, precursor concentration, temperature, ligand substitution).**  
  - Task: `pld`; confidence: `high`
  - Implication: Control catenation during synthesis (use templates, tune linker substitution, and reaction parameters) to maintain open metal sites and accessible pore volume when targeting high low-pressure uptake.
  - Evidence: Interweaving and interpenetration ... catenation may be controlled by adding a template during the solvothermal MOF synthesis ... Using a brominated and non-brominated ligand ... concluded that catenation may be controlled by the organic linker design. ... after activation the hydrogen adsorption capacity at 77 K and 1 bar was higher for the non-catenated PCN-60, explained by exposed open metal sites that were blocked in the catenated PCN-6.
- **Mixed-linker frameworks can create large pores and tune pore entrances; large pores may yield low low-pressure uptake but high high-pressure capacity (example: SNU-6 shows low 1 bar uptake at 77 K but high capacity at 70 bar).**  
  - Task: `h2`; confidence: `high`
  - Implication: Use mixed-linker frameworks to precisely control pore entrances and internal pore architecture to favor intended pressure regimes; ensure presence of favorable binding sites for low-pressure targets.
  - Evidence: The SNU-6 framework ... pore diameter of 18.2 Å ... As (BET) = 2590 m2·g−1. The hydrogen adsorption capacity at 77 K and 1 bar was relatively low (1.68 wt%); however, at 77 K and 70 bar n_excess and n_total values were 10.0 and 4.87 wt%, respectively.
- **Dynamic/flexible MOFs can exhibit gate-opening or breathing behavior in response to stimuli (T, P, guest insertion) which alters channel sizes and adsorption behavior; such flexibility can enable selective adsorption but often shows low RT gravimetric capacity.**  
  - Task: `h2`; confidence: `medium`
  - Implication: Consider flexible-linker strategies if gate-opening/selective adsorption is desired (e.g., H2/CO2 separation), but characterize hysteresis and expect tradeoffs with ambient-temperature gravimetric capacity.
  - Evidence: Dynamic MOFs ... reversibly change their channels by a large magnitude ... The hydrogen adsorption analysis of flexible sulfur-containing MOFs M-URJC-n showed gate-opening at low pressures with capacities 2.81, 2.21, 1.99 wt% at 77 K up to 18 bar, but only ~0.12–0.14 wt% at 298 K and 170 bar due to flexible ligands.
- **MOFs with moderate-to-high Qst and appropriate free volume can reach appreciable gravimetric uptake; reported targets include Qst ≈ 10–15 kJ·mol−1 with free volume 1.6–2.4 cm3·g−1 or Qst >20 kJ·mol−1 with free volume <1.5 cm3·g−1 to approach ~6 wt% H2.**  
  - Task: `h2`; confidence: `medium`
  - Implication: As a design goal, tune porosity and binding strength toward either (Qst 10–15 kJ·mol−1 with free volume 1.6–2.4 cm3·g−1) or (Qst >20 kJ·mol−1 with smaller free volume) to approach ~6 wt% H2.
  - Evidence: It was concluded that MOFs can reach approximately 6 wt% H2 when they are characterized by a Qst value of 10–15 kJ·mol−1 and a free volume within the range of 1.6–2.4 cm3·g−1, or Qst > 20 kJ·mol−1 and a free volume smaller than 1.5 cm3·g−1.
- **GCMC simulations indicate an optimal average Qst around ~20 kJ·mol−1 to maximize deliverable H2 at 298 K between low and high pressure states (example study low = 1.5 bar, high = 120 bar).**  
  - Task: `h2`; confidence: `medium`
  - Implication: Aim for binding sites or framework modifications that give an average Qst near 20 kJ·mol−1 to maximize deliverable H2 at 298 K between practical charging/discharging pressures, while validating against porosity losses.
  - Evidence: GCMC calculations suggested that for the maximum H2 delivery at 298 K, the optimal Qst value must be around ~20 kJ·mol−1.
- **Open (coordinatively unsaturated) metal sites increase isosteric enthalpy (Qst) and tend to raise 298 K uptake, particularly in high-surface-area MOFs; creating such sites (e.g., removal of coordinated solvent) is an effective strategy (SNU-15 Co example yields Qst ~15 kJ·mol−1).**  
  - Task: `h2`; confidence: `high`
  - Implication: Design SBUs and linkers that yield stable open metal sites (e.g., removable axial solvent on paddle-wheel units or metal centers in porphyrin linkers) to increase Qst and ambient-temperature uptake; targeted activation protocols can create coordination vacancies (SNU-15 example).
  - Evidence: Open metal sites may increase the Qst value. H2 adsorption values at 298 K for MOFs with open metal sites are higher than those without; tendency pronounced for A > 3000 m2·g−1. In SNU-15, removal of coordinated H2O created vacant Co(II) sites allowing side-on H2 bonding with Qst = 15 kJ·mol−1 at zero coverage.
- **Introducing metal nanoparticles (e.g., Pd) into MOFs can increase 298 K uptake (due to hydride formation or spillover) but often reduces 77 K uptake because of decreases in BET surface area and pore volume and the added mass of metal.**  
  - Task: `h2`; confidence: `medium`
  - Implication: If adding metal NPs to leverage spillover or hydride formation, carefully balance NP loading and dispersion to avoid excessive loss of surface area/pore volume and weigh mass penalties.
  - Evidence: Pd NPs infused in MIL-100(Al) reduced n at 77 K and 40 bar related to decreases in A and V, whereas at 298 K, n increased likely due to Pd hydride formation; formation of PdHx was experimentally confirmed and spillover was considered.
- **Small micropore diameters (~5–7 Å) produce overlapping potential fields from opposing pore walls, increasing H2 interaction energy and enabling significant adsorption even when BET surface area is modest.**  
  - Task: `pld`; confidence: `high`
  - Implication: Design micropores with diameters in the ~5–7 Å range (control linker length, interpenetration and pillar selection) to exploit potential overlap and improve room-temperature uptake, while monitoring free volume.
  - Evidence: Small diameter pores enable energy potentials to overlap between opposing walls, resulting in higher interaction energy with H2. Examples: frameworks with ~7×6 Å channels and another with average pore diameter 4.5 Å showed notable uptake despite modest BET area.
- **At 298 K the observed amount adsorbed correlates mainly with pore volume at low H2 pressure and with surface area at high H2 pressure; thus the dominant textural target depends on the charging pressure.**  
  - Task: `pld`; confidence: `high`
  - Implication: For low-pressure/near-ambient charging prioritize maximizing pore volume; for high-pressure storage prioritize maximizing surface area.
  - Evidence: At 298 K, the n value correlates mainly with the V value at low P(H2) and the A value at high P(H2).
- **Cation exchange in certain microporous MOFs can produce higher-enthalpy hydrogen adsorption (raising Qst) and thus tune adsorption energetics.**  
  - Task: `h2`; confidence: `medium`
  - Implication: Use cation exchange in suitable MOFs to increase H2 binding enthalpy when stronger adsorption is desired, but verify effects on deliverable capacity and stability.
  - Evidence: "High-enthalpy hydrogen adsorption in cation-exchanged variants of the microporous metal-organic framework Mn3[(Mn4Cl)3(BTT)8(CH3OH)10]2." (reference cited in review).
- **Functionalization of organic linkers is a viable means to modify hydrogen sorption energetics and capacity, though specific outcomes depend on the functional group and framework context.**  
  - Task: `h2`; confidence: `medium`
  - Implication: Use linker functionalization to tune H2 adsorption energetics for target conditions and validate experimentally or computationally for the specific framework.
  - Evidence: "Hydrogen sorption in functionalized metal-organic frameworks." (reference cited in review).
- **Design must balance gravimetric and volumetric uptake: very high porosity benefits gravimetric capacity but can reduce volumetric density; practical hydrogen storage requires optimizing both.**  
  - Task: `mixed`; confidence: `medium`
  - Implication: When designing MOFs for hydrogen storage, evaluate and optimize both gravimetric and volumetric performance and consider framework density and packing rather than maximizing surface area alone.
  - Evidence: "Balancing volumetric and gravimetric uptake in highly porous materials for clean energy." (reference cited in review).
- **MOFs are listed as promising adsorbers for small gases including CO2, but this review provides no CO2-specific mechanistic or quantitative data.**  
  - Task: `co2`; confidence: `low`
  - Implication: Treat MOFs as candidates for CO2 screening but obtain CO2-specific isotherms and Qst/selectivity data from CO2-focused studies before committing to a design.
  - Evidence: As a result of their ultra-high surface area values ... they were found to be promising gas adsorbers for small gaseous molecules, including ... CO2 ... (listing only).

## Extracted design rules

- **At 77 K, match the optimization target to the intended pressure regime: low-pressure (~1 bar) -> increase Qst (binding strength, e.g., open metal sites or functional groups); intermediate (~30 bar) -> maximize surface area (As); very high (~120 bar) -> maximize pore volume (V).**
  - IF: Operating temperature ≈ 77 K, Target storage pressure regime is specified (≈1, ≈30, or ≈120 bar)
  - THEN: Design MOFs with stronger binding sites (open metal sites, polar functional groups) for ~1 bar targets to increase Qst, Prioritize high surface-area linkers/topologies for ~30 bar targets, Prioritize maximizing pore volume (e.g., long linkers, large cavities) for ~120 bar targets
  - Why: The review reports theoretical results that uptake at 77 K scales with Qst at low pressure, with As at intermediate pressure, and with V at very high pressure.
- **Design micropore diameters in the ~5–7 Å range to exploit opposing-wall potential overlap and increase H2 binding energy, especially for room-temperature uptake.**
  - IF: aim: increase H2 interaction energy without excessive loss of free volume
  - THEN: Use linker length, pillar selection, and control of interpenetration/catenation to target channel diameters ~5–7 Å, Prioritize pore-shape engineering over maximizing BET surface area alone for RT performance
  - Why: Small pore diameters enable energy potentials to overlap between opposing walls, increasing interaction energy with H2; examples with ~7×6 Å channels or ~4.5 Å average pores showed notable uptake.
- **To increase low-pressure H2 uptake (≈1 bar at 77 K), create or preserve high-affinity adsorption sites (open metal sites, functionalized ligands) and avoid features that block them (catenation).**
  - IF: Operating at low pressure and cryogenic temperature, Framework contains potential open metal sites or modifiable linkers
  - THEN: Design linkers and synthesis to expose open metal sites and add polar functional groups to increase Qst, Avoid catenation/interpenetration by using templates or linker design choices
  - Why: At low pressure adsorption is proportional to Qst and examples show catenation can block open metal sites and reduce uptake.
- **If the target application prioritizes deliverable H2 at ambient temperature (298 K), aim for an average Qst near ~20 kJ·mol−1 and validate with GCMC/delivery simulations, balancing Qst increases against porosity loss.**
  - IF: goal: maximize deliverable gravimetric H2 at 298 K between low and high pressures (e.g., 1.5–120 bar), willingness to trade porosity vs binding strength
  - THEN: Engineer binding sites (open metals, polar cations, functionalized linkers) to raise Qst toward ~20 kJ·mol−1, Use GCMC or equivalent to simulate deliverable capacity and validate tradeoffs between Qst and usable free volume
  - Why: Simulations indicate an optimal Qst around 20 kJ·mol−1 for maximizing delivery at 298 K; practical strategies to raise Qst include open sites, cation fields, metal doping or functionalization.
- **If increasing surface area/pore volume via longer linkers, then implement synthesis controls to prevent catenation and preserve accessible porosity.**
  - IF: Goal is to increase As and V for enhanced high-pressure H2 uptake, Linker extension is synthetically feasible
  - THEN: Select longer rigid linkers or add aromatic rings to increase As and V, Employ synthesis templates or linker substitutions (e.g., bromination) and tune reaction conditions to avoid framework interpenetration
  - Why: Longer linkers (UiO-67 vs UiO-66) showed higher As and V and higher H2 uptake, but catenation can occur and block adsorption sites unless controlled.
- **If ultrahigh deliverable capacity per mass and volume is desired and T/P swings are acceptable, prioritize ultrahigh gravimetric and volumetric BET areas plus an operational T/P swing protocol.**
  - IF: Deliverable capacity (usable H2 upon discharge) is primary metric, Cryogenic and pressure-swing operation acceptable
  - THEN: Prioritize materials with very high gravimetric and volumetric BET areas (e.g., NU-1501-Al), Design operational protocol using combined temperature and pressure changes to maximize delivered amount
  - Why: NU-1501-Al's very high gravimetric/volumetric BET areas were linked to high hydrogen storage when using a combined temperature/pressure swing.
- **If adding catalytic metal nanoparticles (Pd, Pt) to exploit spillover or hydride formation, then optimize loading and placement to minimize pore blocking and mass penalty and validate uptake at both cryogenic and ambient temperatures.**
  - IF: Strategy: incorporate catalytic metal NPs into MOF pores/surfaces to enhance H2 uptake
  - THEN: Limit NP loading and choose infiltration method to minimize pore-blocking, Characterize BET surface area and pore volume before/after NP addition and measure H2 uptake at both cryogenic and ambient temperatures
  - Why: Pd NP impregnation in MIL-100(Al) reduced BET area and pore volume and decreased 77 K uptake, but increased 298 K uptake (likely PdHx); spillover considered but morphological tradeoffs occurred.
- **If targeting low-pressure/near-ambient charging at 298 K, prioritize pore volume; if targeting high-pressure charging, prioritize surface area.**
  - IF: temperature: 298 K (ambient); pressure regime: low vs high charging pressure
  - THEN: Optimize synthesis for larger pore volume when application involves low-pressure adsorption, Focus on maximizing accessible surface area for high-pressure storage
  - Why: At 298 K the amount adsorbed correlates mainly with pore volume at low pressure and with surface area at high pressure.
- **If higher H2 binding enthalpy is required, consider cation exchange or linker functionalization as routes to raise Qst, but validate impacts on deliverable capacity and stability.**
  - IF: target application benefits from stronger H2 binding (e.g., uptake at higher temperature or lower pressure), MOF is amenable to cation exchange or linker modification
  - THEN: Perform cation-exchange experiments or model cation-substituted variants and measure Qst, Design and test linker functionalizations that can increase polarity or specific interactions with H2
  - Why: References report high-enthalpy hydrogen adsorption in cation-exchanged variants and cite linker functionalization as a lever to tune sorption.
- **If larger pore volume or tailored connectivity is required, then use mixed-ligand or pillared 3D architectures to create large pores, but balance pore volume against binding strength and volumetric density.**
  - IF: application prioritizes increased pore volume or specific channel architectures, framework chemistry is compatible with mixed-ligand synthesis or pillaring
  - THEN: Design mixed-ligand syntheses or pillared linkers to achieve target pore sizes and test gas sorption and guest-exchange behavior, Monitor for unwanted catenation and volumetric performance
  - Why: References describe mixed-ligand MOFs and 3D pillared MOFs linked to gas sorption properties and guest-exchange behavior.
- **If designing for practical hydrogen storage, balance gravimetric and volumetric uptake rather than maximizing one metric alone.**
  - IF: target application requires both high gravimetric and volumetric capacity (e.g., onboard storage)
  - THEN: Evaluate candidate MOFs for both gravimetric and volumetric uptakes and prioritize materials that balance both metrics, Consider deliverable capacity and operating conditions in material selection
  - Why: Balancing volumetric and gravimetric uptake is critical for practical clean-energy storage applications.
- **Treat MOFs as candidate adsorbents for CO2 screening but obtain CO2-specific binding data from CO2-focused studies before design decisions.**
  - IF: Considering MOFs for CO2 capture or storage, No CO2-specific thermodynamic/kinetic data available in current source
  - THEN: Include MOF families with high surface area and appropriate pore sizes in screening libraries, Acquire CO2 adsorption isotherms and Qst/selectivity data under relevant conditions from dedicated CO2 studies
  - Why: The review lists CO2 among gases adsorbed by MOFs but provides no CO2-specific mechanistic or quantitative data.

## Contradiction notes

- **Surface area (As) correlation with 77 K uptake**: Both are consistent: As is a useful predictor across a broad As range, but at low pressure and very high As the simple linear correlation breaks down because surface coverage is incomplete and adsorption is controlled by highest-affinity sites (Qst) and accessibility.
  - Warning: Do not assume monotonic gains in low-pressure uptake by increasing As beyond ~2000 m2·g−1; consider affinity (Qst) and site accessibility instead.
- **Surface area vs pore size importance for RT H2 uptake**: At 298 K the dominant descriptor depends on pressure: pore volume matters more at low pressure and surface area at high pressure; additionally, pore diameter (5–7 Å) can compensate for lower BET area by increasing local interaction energy.
  - Warning: Do not use BET surface area alone to rank candidates for RT H2 uptake; include pore size and pore volume in the evaluation and consider operating pressure.
- **Effects of adding metal nanoparticles on multi-temperature uptake**: Nanoparticle addition can produce opposite effects at cryogenic vs ambient temperatures because morphological loss of accessible porosity can reduce cryogenic uptake while hydride formation or spillover can increase RT uptake; net effect depends on NP loading, dispersion, and whether enhanced binding offsets lost pore volume and added mass.
  - Warning: Expect tradeoffs when adding NPs: improvements at RT may come at the cost of cryogenic uptake and gravimetric capacity; validate across relevant temperature/pressure regimes.
- **Catenation impact and controllability**: Catenation is detrimental to uptake when it blocks adsorption sites, but it can be mitigated through targeted synthesis strategies (template addition, linker substitution, reaction parameter control); nevertheless, synthesis control must be validated experimentally for each system.
  - Warning: If using long linkers to increase As/V, include design and synthesis controls to prevent unwanted catenation; test activation procedures to evaluate accessibility of open sites.