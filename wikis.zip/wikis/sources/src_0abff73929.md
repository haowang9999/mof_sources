---
title: "Theoretical Explanation of Hydrogen Spillover in Metal-Organic Frameworks"
type: source
tags: [h2, source, paper]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_0abff73929]
confidence: medium
---


# Theoretical Explanation of Hydrogen Spillover in Metal-Organic Frameworks

## Metadata

- Source ID: `src_0abff73929`
- Raw file: `raw_sources/inbox/theoretical-explanation-of-hydrogen-spillover-in-metal-organic-frameworks.pdf`
- Primary task: `h2`
- Task tags: h2, pld, mixed
- Auto-classification confidence: `high`
- Auto-classification reason: Paper is a theoretical (DFT/ab initio) study of hydrogen spillover in IRMOF-1, focusing on H adsorption thermodynamics and kinetics, H capacity and binding energies, diffusion/transport of atomic H and the role of pore defects. Because it also analyzes diffusion through the pore network and the effect of ideal vs defective pore structure on spillover, pore-structure (pld) considerations are relevant; thus the source spans H2 adsorption and pore/diffusion design issues.
- Authors: George M. Psofogiannakis, George E. Froudakis
- Year: 2011
- Journal: Journal of Physical Chemistry C (J. Phys. Chem. C)
- DOI: 10.1021/jp109541n
- Material families: IRMOF-1 (MOF-5), IRMOF family, metal-organic frameworks (MOFs)
- Methods: DFT / ab initio (DFT/B3LYP/6-31G**, RI-DFT/BP86/def2-TZVP), cluster models (large L and small S linker models), constrained optimizations / reaction coordinate calculations, molecular dynamics (cited), computational simulation
- Gas targets: H2 (molecular H2 and atomic H)

## Extracted mechanism claims

- **General spillover sequence: H2 dissociates on metal catalyst particles to produce atomic H; atomic H transfers to the MOF receptor either in the gas phase or as weakly physisorbed species; atomic H sticks to receptor binding sites (linkers) to form chemisorbed H; Eley–Rideal (ER) recombination between gas-phase H and adsorbed H can reform H2 and limit net storage.**  
  - Task: `h2|mixed`; confidence: `high`
  - Implication: Optimize (a) catalyst ability to dissociate H2 and emit atomic H, (b) pore connectivity/entrances or mesopores to allow gas-phase/physisorbed H access, and (c) binding-site chemistry to favor stable chemisorption while mitigating ER recombination.
  - Evidence: "Hydrogen storage on such materials has been described through H spillover, a mechanism that involves the dissociation of H2 on the metal particles, atomic H diffusion from the particles to the sorbent, and chemisorption of atomic hydrogen on the material’s binding sites." "the proposed mechanism of spillover, consisting of the generation of gas-phase atomic H on the metal catalyst, H transfer in gas phase or physisorbed form, sticking of H atoms on the binding sites of the receptor, and Eley-Rideal recombination reactions, might be general and applicable to various spillover materials"
- **Experimental observations: some studies report enhanced room-temperature H2 uptakes consistent with spillover when MOFs are defective or partially collapsed and contain supported metal catalysts (e.g., Li & Yang reported ∼4 wt% for IRMOF-8 and ∼3 wt% for IRMOF-1 at 100 bar and 298 K; Tsao et al. reported 4.7 wt% at 69 bar and 298 K for partially collapsed IRMOF-8).**  
  - Task: `h2`; confidence: `high`
  - Implication: To reproduce or enhance reported room-temperature spillover uptakes, consider introducing controlled defects/collapsed regions in IRMOF-type materials and include supported metal catalysts (Pt/Pd) while monitoring for other defect-related artifacts.
  - Evidence: "Li and Yang...measured hydrogen uptakes close to 4 wt % for IRMOF-8 and close to 3 wt % for IRMOF-1 at 100 bar and 298 K." "Tsao et al. measured 4.7 wt % at 69 bar and 298 K for IRMOF-8 in which they had created a partially collapsed MOF network." "Furthermore, the experimental data so far show that defective MOF structures are necessary for spillover enhancement."
- **Thermodynamic capacity limit for IRMOF-1 BDC linker: although 12 nominal H binding sites exist per linker (theoretical site-count → ∼4.5 wt% excess), DFT calculations show that structures with more than six added H atoms are unstable with respect to H2 formation; the six-H hydrogenated linker is the thermodynamic sink corresponding to ∼2.3 wt% excess uptake.**  
  - Task: `h2`; confidence: `high`
  - Implication: Do not rely on raw site counts to estimate achievable spillover capacity; evaluate thermodynamic stability of hydrogenated states (and modify linker chemistry or add stabilizing motifs if higher capacity is desired).
  - Evidence: "Addition of six H atoms is thermodynamically favored with respect to molecular H2...the structure that contains six additional H atoms (L3, S3) is the thermodynamic sink in the overall scheme. Adding six H atoms to the linker translates to an excess uptake of 2.3 wt %, very close to the maximum uptake that has been observed experimentally for IRMOF-1 (which is ∼2.6 wt % excess uptake because of spillover9)." "Figure 1 also shows ... The calculations show that 12 H atoms can be added to the linker... However, it was clearly shown in the calculations that structures with more than six added H atoms are unstable with respect to forming H2, so that such high capacities cannot be expected by IRMOF-1."
- **Per-atom binding energies (DFT cluster models) for atomic H on IRMOF-1 BDC linker sites: approximate values are Ha ≈ -2.0 eV, Hb ≈ -4.0 to -4.4 eV, Hc ≈ -2.6 to -2.7 eV, Hd ≈ -0.9 to -1.0 eV (negative = bound). O-bound (Hd) sites are the weakest and thus most prone to abstraction.**  
  - Task: `h2`; confidence: `high`
  - Implication: Target linkers or functionalizations that create more binding motifs analogous to Hb/Hc and avoid producing many weak O–H sites to improve thermodynamic retention of atomic H.
  - Evidence: Table 1 shows: Ha energy per H (small model) -2.0 eV; Hb -4.4 eV; Hd -1.0 eV; Hc -2.7 eV. (Table reported energies for large and small models with negative numbers representing binding.)
- **Chemisorbed-H diffusion is kinetically prohibitive in ideal IRMOF-1: migration barriers for many elementary chemisorbed diffusion steps are very high (most between ∼1.3 and 1.6 eV), and for some transitions the transition state requires unrealistic framework deformation; desorption is generally easier than chemisorbed diffusion.**  
  - Task: `h2`; confidence: `high`
  - Implication: Do not rely on long-range chemisorbed-H surface diffusion for spillover in ideal narrow-pore MOFs; enable alternative transport pathways (gas-phase/physisorbed H, defects, mesopores) or embed catalysts appropriately.
  - Evidence: "Diffusion in the chemisorbed state is very unlikely.... For the migration of chemisorbed H between two O atoms, the transition state required large deformation of the structure (unrealistic in the rigid MOF framework), and even then the energy barrier to diffusion was larger than the desorption energy.... The energy barriers for many of the elementary diffusion steps are very high (up to about 1.60 eV). (b) H atoms in all binding sites can desorb easier than diffuse in chemisorbed state. Most energy barriers are between 1.3 and 1.6 eV."
- **Gas-phase or weakly physisorbed atomic H diffusion within MOF pores is a plausible and likely transport route for spillover (especially in defective/mesoporous structures) and qualitatively explains the necessity of pore defects/entrances for deep penetration.**  
  - Task: `h2|pld`; confidence: `medium`
  - Implication: Enable gas-phase or weakly physisorbed H transport by creating entrance channels/mesopores and distributing catalysts to allow atomic H to be emitted into pore volumes; do not assume chemisorbed diffusion will achieve long-range transfer.
  - Evidence: "During hydrogen spillover, atomic hydrogen cannot migrate in the chemisorbed state in the pore network but rather diffuses in the gas phase." "Diﬀusion of atomic H in the MOF is greatly assisted by pore defects, and spillover would be plugged in ideal MOF structures." "The gas-phase H spillover can naturally explain the transfer of H atoms between dissimilar surfaces, which would require very high energy barriers if H diffuses between them in chemisorbed form."
- **Sticking (adsorption) kinetics on the BDC linker: the first H addition has a small barrier (~0.08 eV) while subsequent additions up to the six-H thermodynamic sink are barrierless; generally, atomic H sticking to linker sites is kinetically facile.**  
  - Task: `h2`; confidence: `high`
  - Implication: Prioritize enabling atomic-H access to linkers (catalyst proximity, pore entrances) rather than improving intrinsic sticking kinetics; account for competing ER recombination.
  - Evidence: "it was observed that only the first hydrogen addition, that has the smallest adsorption energy, has a small energy barrier (0.08 eV), which is easily overcome at very low temperatures. ... All other H additions were completely barrierless. Thus, the thermodynamic driving force for formation of the hydrogenated structure would be quickly realized if the linker is brought into contact with H atoms." "During diffusion, atomic hydrogen can stick on all available binding sites on the linkers with negligible energy barriers."
- **Eley–Rideal abstraction (gas-phase H + adsorbed H → H2) has very small or zero barriers (reported 0–0.11 eV depending on hydrogenation state), making recombination effectively instantaneous at room temperature for many configurations; this limits penetration depth and reverts overhydrogenated linkers toward the thermodynamic minimum.**  
  - Task: `h2`; confidence: `high`
  - Implication: Mitigate ER recombination (for example by reducing labile O–H site population, increasing H2 pressure, altering flux/distribution of atomic H, or creating alternate diffusion paths) to increase net spillover storage and penetration depth.
  - Evidence: "The abstraction reactions of the structures with one, three, and five H atoms were found to be completely barrierless, while the barriers of the structures with two, four, and six H atoms were 0.04, 0.11, and 0.06 eV, respectively. Such energy barriers are negligible at room temperature.... (a) This mechanism may be responsible for decreased penetration of atomic H into the MOF pores.... (b) The ER abstraction reactions would be responsible for quickly reverting overhydrogenated linkers (linkers with more that six adsorbed H atoms for IRMOF-1 linkers) back to the thermodynamic minimum with respect to H2."
- **Site-selective sequence of hydrogenation on the BDC linker: same-side Ca ring atoms are hydrogenated first; Cb atoms are hydrogenated third and sixth; one carboxylate Od atom is hydrogenated later (seventh), which enables hydrogenation of Cc (eighth) due to favorable tetrahedral geometry from O-H formation.**  
  - Task: `h2`; confidence: `high`
  - Implication: Design linkers or catalytic environments that stabilize early-occupied ring sites (Ca/Cb) and account for sequence-dependent geometric effects when aiming to increase hydrogen uptake.
  - Evidence: "The order of hydrogenation of the BDC linker, as predicted by DFT optimizations... Same-side Ca ring atoms are hydrogenated first. Cb atoms are hydrogenated third and sixth in sequence.... One carboxylate Od atom is hydrogenated and then the seventh, which is necessary for H sticking on the Cc atom (eighth). The existence of the O-H bond turns the Cc-H bond formation from endothermic to highly exothermic as the Cc atom adopts a geometry that is favorable for tetrahedral coordination."
- **Hydrogen pressure qualitatively affects ER recombination and penetration depth: at low H2 pressure ER recombination dominates and limits hydrogenation depth, while at higher H2 pressure ER recombination is suppressed (and packing H2 in cavities becomes unfavorable), increasing hydrogenation degree and penetration depth.**  
  - Task: `h2`; confidence: `medium`
  - Implication: Operating at elevated H2 pressure (or engineering trapped high-pressure cavities) can reduce ER recombination near pore entrances and increase the fraction of the MOF that becomes hydrogenated during spillover.
  - Evidence: "The effect of the hydrogen pressure on the thermodynamics of spillover can be explained by the H2 pressure dependence of the Eley-Rideal recombination reactions (Hgas + Hads → H2,gas). At low H2 pressures, ER recombination reactions would dominate ... However, as the H2 pressure is increased, the equilibrium of the ER recombination reaction is shifted because it becomes energetically unfavorable to squeeze more hydrogen molecules in the MOF cavities. As a result, at higher pressures, a larger fraction of the pores will follow the route to complete hydrogenation.... the penetration depth of atomic H into the crystal lattice will also increase because the higher pressure diminishes the ER recombination reactions that are responsible for underutilization of the MOF as explained above."
- **Rate-limiting considerations: gas-phase or physisorbed atomic H diffusion within pores is very fast, therefore the rate-limiting step for achieving internal MOF hydrogenation by spillover may be the generation and supply/emission of airborne atomic H from the catalyst (and/or access via entrance pores), not intracrystallite diffusion per se.**  
  - Task: `h2`; confidence: `medium`
  - Implication: Focus on improving catalyst H2-dissociation activity and proximity/distribution relative to MOF crystals (or embedding catalysts without blocking pores) to increase emission/supply of atomic H into pore volumes.
  - Evidence: "As gas-phase (or physisorbed) H atom diffusion is very fast, the rate-limiting step in the overall process would be the generation of airborne atomic H and its supply from the catalyst to the MOF crystal."

## Extracted design rules

- **Introduce or preserve pore defects / mesopore channels and increase entrance density when aiming to enable gas-phase atomic-H transport into MOF crystals; avoid ideal (defect-free) pore networks which plug spillover diffusion.**
  - IF: Material is IRMOF-1 or similar narrow-pore MOF with ideal/defect-free lattice, Goal is to enable H spillover-based storage and deep hydrogenation
  - THEN: Engineer controlled pore defects, partial network collapse, templated mesopores, or bridging structures to create pathways for gas-phase/weakly physisorbed atomic H diffusion, Design crystals with more entrance pores or increased pore connectivity to improve penetration depth
  - Why: DFT analysis indicates chemisorbed-H migration is not feasible in ideal pores and that gas-phase H diffusion is greatly assisted by pore defects; mesopores and increased entrances accommodate gas-phase atomic H and increase penetration depth.
- **Ensure catalyst nanoparticles do not block pore channels and, where beneficial, disperse nanoparticles within the porous network without impeding atomic-H diffusion.**
  - IF: Using supported metal catalysts (Pt, Pd or similar) to generate atomic H for spillover, MOF pore channels are narrow or easily blocked by nanoparticles
  - THEN: Select nanoparticle sizes, loadings, and placements that avoid obstructing pore entrances or internal channels, Consider distributing catalysts near pore mouths or inside larger channels/mesopores to maximize emitted atomic-H access
  - Why: Embedded nanoparticles that impede pore-channel access will prevent atomic H from entering pore volumes, negating spillover transport benefits.
- **When selecting or designing linkers to increase chemisorption capacity, verify that additional chemisorption sites are thermodynamically stable with respect to H2 formation; do not rely solely on increasing nominal site counts.**
  - IF: Proposed modification increases the number of potential H binding sites (e.g., multi-ring linkers), Goal is to raise chemisorption-derived storage capacity
  - THEN: Compute thermodynamic stability of proposed hydrogenated states (DFT or equivalent) to confirm they are minima versus H2 formation before committing to synthesis, Prioritize linker chemistries that provide stable binding motifs (e.g., strong C-bound centers analogous to Hb/Hc)
  - Why: The maximum chemisorbed-H capacity is set by thermodynamics (e.g., IRMOF-1 BDC linker shows a six-H thermodynamic sink); adding nominal sites that are not stabilized will not increase achievable capacity.
- **Mitigate Eley–Rideal recombination losses by (a) reducing labile O–H adsorption sites or stabilizing them, (b) controlling atomic-H flux near labile sites, and/or (c) operating at higher H2 pressure to shift equilibrium away from ER recombination.**
  - IF: Adsorbed H is present on weak O–H (carboxylate) sites, Gas-phase atomic H is mobile and colliding with these sites
  - THEN: Design linkers that avoid producing many weak O–H adsorption sites or chemically modify carboxylates to strengthen O–H binding, Control distribution/flux of atomic H (catalyst placement, spatial separation) to reduce collisions with labile adsorbed H, Consider operating at elevated H2 pressures where ER recombination is less thermodynamically favored
  - Why: DFT shows O–H (Hd) sites have much lower bond energies and are readily abstracted by gas-phase H (ER), favoring H2 reformation and limiting net storage.
- **Prioritize improving generation and supply of atomic H from catalysts (activity, proximity, or distribution) when overall hydrogenation is limited despite apparent open pore pathways, since intracrystallite gas-phase H diffusion is very fast.**
  - IF: Observed/predicted fast intracrystallite gas-phase/physisorbed H diffusion, Low overall hydrogenation rate in MOF despite pore-access features
  - THEN: Increase catalyst activity for H-atom production or better distribute catalysts near or within accessible pore volumes, Investigate mechanisms of airborne atomic H emission/transfer and tune catalyst–MOF spacing accordingly
  - Why: The work indicates that internal gas-phase H diffusion is rapid; thus the bottleneck is often the supply/emission of atomic H from catalyst sources.

## Contradiction notes

- **maximum achievable spillover capacity on IRMOF-1**: Site counting neglects reaction energetics. Thermodynamic (DFT) analysis indicates only the six-H hydrogenation state is a stable sink under modeled conditions; therefore estimates based purely on nominal site counts overpredict achievable chemisorbed-H capacity for IRMOF-1.
  - Warning: Do not rely on nominal binding-site counts to predict achievable spillover capacity; validate with thermodynamic and kinetic modeling or experiments before using site-count-based targets.
- **mechanism of H transport (chemisorbed diffusion vs gas-phase vs alternative hole-mediated proposals)**: The paper's DFT barrier calculations argue against long-range chemisorbed diffusion in ideal MOFs and present gas-phase/physisorbed H transport as plausible. Alternative hole-mediated or other defect-mediated mechanisms are noted in the literature but not substantiated by the presented calculations; they would require independent validation.
  - Warning: Avoid assuming a single universal transport mechanism; consider testing for hole-mediated or other defect-specific transport processes experimentally or computationally if relevant to your materials.
- **role of defects and inclusions in observed uptake**: Pore-structure modification is a plausible route to increase penetration and capacity, but experimental validation is required since other defect-induced effects may confound uptake measurements.
  - Warning: When engineering defects/mesopores to enhance spillover, monitor for inclusions, trapped species, or reaction byproducts that could alter uptake or mimic increased storage.
- **importance of pore-network access vs atomic-H generation as rate-limiting step**: Both can be true: poor entrance/access will limit how much catalyst-generated atomic H can reach internal binding sites; once entrance/access is adequate, further improvements require increasing atomic-H generation/supply. Pore-blocking by embedded nanoparticles would negate benefits of fast internal diffusion.
  - Warning: Diagnose whether low uptake arises from blocked/insufficient entrances or from insufficient atomic-H generation; prioritize fixes accordingly (improve entrances first, then catalyst emission/distribution).
- **paper metadata (authors / journal naming)**: The merged metadata uses the most specific non-empty author list available (George M. Psofogiannakis; George E. Froudakis) and provides the full journal name with abbreviation. Users should note alternate attributions in some source records.
  - Warning: If exact bibliographic attribution is critical (e.g., citation indexing), verify author lists and journal naming against the publisher/DOI record.