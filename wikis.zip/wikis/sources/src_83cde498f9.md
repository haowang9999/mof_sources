---
title: "An Amine-Functionalized Ultramicroporous Metal−Organic Framework for Postcombustion CO2 Capture"
type: source
tags: [co2, source, paper]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_83cde498f9]
confidence: medium
---


# An Amine-Functionalized Ultramicroporous Metal−Organic Framework for Postcombustion CO2 Capture

## Metadata

- Source ID: `src_83cde498f9`
- Raw file: `raw_sources/inbox/an-amine-functionalized-ultramicroporous-metal-organic-framework-for-postcombustion-co2-capture.pdf`
- Primary task: `co2`
- Task tags: co2, pld, mixed
- Auto-classification confidence: `high`
- Auto-classification reason: The paper is explicitly focused on postcombustion/low-pressure CO2 capture using an amine-functionalized ultramicroporous MOF, reporting CO2 uptakes, isosteric heat, and breakthrough tests (including humid conditions). It also reports pore metrics (PLD/LCD), pore topology and pore-design discussion and simulations, so pore design (pld) is relevant; because both CO2 and pore-design topics are substantively treated, 'mixed' is included per guidelines. No H2 work is present.
- Authors: Donghui Jo, Su-Kyung Lee, Kyung Ho Cho, Ji Woong Yoon, U-Hwang Lee
- Year: 2022
- Journal: ACS Applied Materials & Interfaces
- DOI: 10.1021/acsami.2c15476
- Material families: amine-functionalized ultramicroporous MOFs, Cu(adci)-2 (pts topology), Cu(I) dicyanoimidazolate MOFs, CALF-20 (benchmark MOF)
- Methods: synchrotron powder X-ray diffraction / Rietveld analysis, synchrotron X-ray diffraction, gas adsorption isotherms (CO2, N2, H2O), water vapor isotherms (IGA), breakthrough experiments (dry and humid), virial analysis (Qst), virial / isosteric heat calculation, grand canonical Monte Carlo (GCMC) simulation (RASPA), radial distribution function analysis, DFT with dispersion correction (DFT-D) single-point and optimization, Zeo++ / Willems et al. pore analysis, BET/N2 sorption at 77 K, density functional theory with dispersion correction
- Gas targets: CO2, N2, H2O

## Extracted mechanism claims

- **Combining aromatic amine functionalization with ultramicroporosity enhances low-pressure CO2 adsorption via increased Lewis base–acid interactions (amine–CO2) and intensified London dispersion from confinement.**  
  - Task: `co2`; confidence: `high`
  - Implication: Design MOFs that colocate aromatic amine groups inside ultramicropores (<~7 Å, here PLD ~3.3 Å) to combine Lewis base–acid interactions and enhanced London dispersion for improved low-pressure CO2 uptake while keeping adsorption physisorptive.
  - Evidence: Abstract: "combining two strategies to design MOF physisorbents for enhanced CO2 capturing, i.e., aromatic amine functionalization and the introduction of ultramicroporosity (pore size <7 Å)"; Abstract/discussion: "preferential CO2 binding site of Cu(adci)-2 was predicted to be between two ligands... implying that its CO2 adsorption properties originate from the enhancement of Lewis base-acid and London dispersion interactions due to the amino groups and ultramicroporosity, respectively."
- **CO2 preferentially binds in a 'sandwich-like' site between two facing NH2-bearing ligands in the one-dimensional channels of Cu(adci)-2, as predicted by Monte Carlo simulation and radial distribution analysis.**  
  - Task: `co2`; confidence: `high`
  - Implication: Place amine functional groups to face each other across a narrow channel so that CO2 can occupy a cooperative 'sandwich' site between two ligands, increasing binding without high chemisorption energy.
  - Evidence: Page 3 / pages 5-6: "the NH2 groups of the ligands face each other in the channel of Cu(adci)-2."; "In a Monte Carlo simulation and a radial distribution analysis, the preferential CO2 binding site of Cu(adci)-2 was predicted to be between two ligands, forming a sandwich-like structure..."; "Figure 3c shows a preferential CO2 binding site ... linear-shaped molecule lies in the middle of two ligands facing each other, with an orientation identical to that of the ligands. Consequently, the CO2 atoms are influenced by the two ligands almost equally, showing a sandwich-like configuration."
- **CO2–amine interactions in Cu(adci)-2 are dominated by Lewis base–acid contacts rather than directional hydrogen bonding, with characteristic CCO2–N and OCO2–H RDF peaks around ~3.4 Å; additionally, intense London dispersion interactions between CO2 and ligand C atoms (RDF peaks ~3.3–4.0 Å) contribute significantly to binding.**  
  - Task: `co2`; confidence: `high`
  - Implication: Incorporate Lewis-basic amine functionalities positioned to provide ~3.3–3.5 Å contact distances to CO2 and design ultramicropores with closely spaced aromatic ligand surfaces (≈3.3–4.0 Å from adsorbate) to exploit both acid–base physisorption and dispersion.
  - Evidence: Page 5 (RDF analysis): "Both CCO2-N3 and OCO2-H1 RDFs ... are characterized by each first peak being around 3.4 Å, implying the major contribution of Lewis base-acid interaction between the amine and CO2 as opposed to hydrogen bonding."; "the RDFs between CO2 and ... the other framework atoms mostly show first peaks at a distance of 4 Å, which suggests intense London dispersion interactions between CO2 and the ligands. Particularly, ... CCO2-C3 and OCO2-C3 RDFs ... are 3.3 and 3.4 Å, respectively."
- **The calculated pore-limiting diameter (PLD = 3.27 Å) and largest cavity diameter (LCD = 3.65 Å) of Cu(adci)-2 make it ultramicroporous and are appropriate for kinetic discrimination between CO2 (kinetic diameter ~3.3 Å) and N2 (~3.64 Å), favoring CO2 uptake in the 1D square channels.**  
  - Task: `pld`; confidence: `high`
  - Implication: Target PLD ~3.2–3.3 Å with small LCD (~3.6 Å) in 1D channels to kinetically favor CO2 over N2 at low pressure for postcombustion separations.
  - Evidence: Page 3: "the largest cavity diameter (LCD) and pore limiting diameter (PLD) of Cu(adci)-2 were calculated to be 3.65 and 3.27 Å, respectively, with the Zeo++ program... These values are suitable for selective CO2 adsorption given the kinetic diameters of CO2 and N2 (3.3 and 3.64 Å, respectively)."
- **Cu(adci)-2 exhibits substantial low-pressure CO2 uptake (2.01 mmol g−1 at 298 K and 15 kPa) with a low experimental zero-coverage isosteric heat of adsorption (Qst ≈ 27.5–27.6 kJ mol−1), indicating physisorptive binding favorable for lower regeneration energy.**  
  - Task: `co2`; confidence: `high`
  - Implication: Use aromatic amine functionalization (rather than alkylamine chemisorbers) to keep Qst in a moderate physisorption range (≈25–50 kJ mol−1) to balance uptake and lower regeneration energy.
  - Evidence: Page 2: "The CO2 uptake levels at 15 kPa were ... 2.01 mmol g−1 at 298 K... The Qst values for CO2 and N2 were calculated to be 27.5 and 24.2 kJ mol−1, respectively, at zero loading according to a virial analysis."; page 1 intro: "aromatic amines... physisorb CO2 with Qst values generally in the range of 25 to 50 kJ mol−1."
- **Simulated binding energies for the MC-minimized CO2 site (DFT-D single-point −39.4 kJ mol−1; optimization −42.7 kJ mol−1) are larger than the experimentally measured zero-coverage Qst (~27.6 kJ mol−1), indicating simulations may overestimate binding strength at low coverage.**  
  - Task: `co2`; confidence: `medium`
  - Implication: Treat simulation-derived binding energies as potentially overestimated upper bounds; validate binding energetics and low-pressure uptake with experimental Qst measurements when designing regeneration strategies.
  - Evidence: Pages 5-6: "The binding energy for the MC-minimized site was estimated to be −39.4 kJ mol−1 according to single-point density functional theory calculations with dispersion correction ... binding energy: −42.7 kJ mol−1. ... one explanation being that the simulated zero-coverage Qst values are higher than the experimental outcomes (∼39.5 vs 27.6 kJ mol−1)."
- **Cu(adci)-2 shows S-shaped water adsorption isotherms with steep uptake at P/P0 ≈ 0.35–0.40 (indicating relative hydrophobicity compared to some water adsorbents) and retains CO2 capture performance under moderate humidity (60% RH breakthrough), but prolonged or severe humidity (80% RH for 1 week) or liquid water exposure (1 day) degrade porosity and reduce CO2 capacity.**  
  - Task: `mixed`; confidence: `medium`
  - Implication: Aromatic amine ultramicroporous MOFs can tolerate moderate humidity for CO2 capture, but designs must guard against metal-site exposure or geometries that admit water; include long-term/high-RH exposure testing to define operational limits.
  - Evidence: Page 2: "The water adsorption of Cu(adci)-2 at 298 and 313 K is characterized by S-shaped isotherms with steep adsorption at P/P0 = 0.35−0.40..., implying that Cu(adci)-2 is hydrophobic compared to well-known water adsorbents..."; Page 1 (abstract): "breakthrough experiments under dry and 60% relative humidity conditions show that its CO2 capture ability is retained even in the presence of high amounts of moisture."; Page 3 / Page 5: "BET surface areas were ... 515, 300 ... after exposure to 80% relative humidity for 1 week, to liquid water for 1 day... Cu(adci)-2 exhibited good resistance to a moderate humidity condition... whereas it did not to a severe humidity condition and to liquid water..."; "The CO2 capacity at 298 K and 15 kPa was scarcely reduced after exposure to atmospheric conditions for one month or to liquid ethanol for 1 day..., although exposure to 80% RH for 1 week or to liquid water for 1 day reduced the CO2 capacity fairly well."
- **In mixed-gas breakthrough experiments (15/85 CO2/N2) at 298 K, Cu(adci)-2 shows competitive CO2 capture performance relative to benchmark CALF-20: its dry breakthrough time is 29.7 min g−1 (≈87% of CALF-20's 34.2 min g−1) and it retains breakthrough time better than CALF-20 upon prehumidification to 60% RH.**  
  - Task: `co2`; confidence: `high`
  - Implication: Amine-functionalized ultramicropores that combine Lewis basic sites with confined aromatic surfaces can improve resilience of CO2 capture performance under humid flue-gas-like conditions; benchmark comparisons should include prehumidification protocols and humidity cycling.
  - Evidence: Page 6: "In a dry condition, CO2 breakthrough time of Cu(adci)-2 was 87% compared to CALF-20 (29.7 vs 34.2 min g−1). ... the time of CALF-20 in a 60% RH experiment reduced to 74% of that in the dry experiment (25.4 min g−1), whereas the time of Cu(adci)-2 in a 60% RH experiment was still not significantly changed, showing the superior performance of Cu(adci)-2 in a highly humid condition."
- **The one-dimensional square-shaped ultramicroporous channels of Cu(adci)-2 have all NH2 groups oriented the same way so that pairs of NH2 groups face each other across channel walls; this geometry enables the sandwich-like CO2 binding site and allows activation by vacuum at 373 K without solvent exchange.**  
  - Task: `pld`; confidence: `high`
  - Implication: Design ultramicroporous channels with uniformly oriented polar functional groups (e.g., NH2) arranged to face each other across small channel diameters to create cooperative binding pockets and allow straightforward thermal vacuum activation.
  - Evidence: Synchrotron powder X-ray diffraction and a Rietveld analysis reveal that the Cu(adci)-2 structure has one-dimensional square-shaped channels, in each of which all affiliated ligands, specifically NH2 groups at the 2-position of the imidazolate ring, have the same orientation, with a pair of NH2 groups therefore facing each other on opposite sides of the channel walls. Cu(adci)-2 could be activated by heating at 373 K under a vacuum without a solvent exchange treatment.
- **Aromatic amine functionalization generally yields physisorptive CO2 binding (Qst ~25–50 kJ mol−1) while alkylamine appendage at open metal sites typically produces chemisorption with much higher Qst (e.g., ~71 kJ mol−1 for mmen-Mg2(dobpdc)); Cu(adci)-2 follows the aromatic-amine physisorption behavior.**  
  - Task: `co2`; confidence: `high`
  - Implication: Prefer aromatic amine ligand functionalization over alkylamine grafting to OMSs when aiming for lower regeneration energy and physisorptive CO2 capture at low pressures.
  - Evidence: Page 1: "Alkylamines appended to open metal sites (OMSs) are identified as able to chemisorb CO2... the isosteric heat of adsorption (Qst)... becomes quite high for the alkylamine-appended MOFs, e.g., 71 kJ mol−1 for mmen-Mg2(dobpdc)... Meanwhile, aromatic amines... physisorb CO2 with Qst values generally in the range of 25 to 50 kJ mol−1."; Page 2: Cu(adci)-2 Qst = 27.5 kJ mol−1.

## Extracted design rules

- **If you want selective, low-pressure CO2 capture with moderate regeneration energy, then incorporate aromatic amine groups into ultramicroporous (<~7 Å) channels, orient pairs of NH2 to face each other across the channel, and target pore dimensions (PLD ~3.2–3.3 Å, LCD ~3.6 Å) so CO2 can occupy sandwich-like sites and benefit from combined Lewis base–acid and dispersion interactions.**
  - IF: target gas mixture = low-pressure CO2/N2 (postcombustion ~15 kPa CO2), goal = balance high low-pressure uptake and low regeneration energy, channel geometry allows CO2 to be near two facing functional groups (distances ~3.3–3.5 Å)
  - THEN: design linkers bearing aromatic NH2 groups oriented to face channel interior and opposite NH2 across small channels, engineer 1D ultramicropores with PLD ≈ 3.2–3.3 Å and LCD ≈ 3.6 Å, avoid open-metal-site alkylamine chemisorbers if low Qst / easier regeneration is desired
  - Why: RDFs and structural analysis show CO2 localizes between facing NH2 groups and close aromatic surfaces (CCO2–N, OCO2–H ~3.4 Å; CCO2–C ~3.3–3.4 Å); PLD 3.27 Å matches CO2 kinetic diameter and can kinetically discriminate against N2 while aromatic amines give moderate Qst (~27 kJ mol−1) favorable for regeneration.
- **If ultramicroporous amine-functionalized MOFs are intended for flue-gas applications, then explicitly validate moisture resilience across relevant RH and durations and avoid structural motifs that allow water access to vulnerable metal sites; if experimental zero-coverage Qst is low (~25–30 kJ mol−1), consider vacuum swing adsorption (VSA) but confirm water limits first.**
  - IF: application involves humid flue gas (e.g., up to tens of %RH), material contains metal centers that could be hydrolyzed, experimental zero-coverage Qst ≲ ~30 kJ mol−1
  - THEN: perform breakthrough tests at relevant RH (e.g., 40–60% RH) and longer-term exposure (e.g., 80% RH for days) and humidity cycling, consider linker orientations and metal coordination geometry to block water access (avoid irregular geometries that admit H2O to metal sites), if Qst is low and material is stable to intended RH, consider VSA process designs and shaping with alcohol-based solvents/binders
  - Why: Cu(adci)-2 retained CO2 capture in 60% RH breakthrough tests but lost porosity and CO2 capacity after 80% RH for 1 week or liquid water exposure—irregular Cu(I) tetrahedra likely allowed water access to metal atoms. Authors note low Qst and chemical stability support feasibility for shaping and VSA but caution that high humidity or liquid water reduce capacity.

## Contradiction notes

- **humidity tolerance vs long-term hydrolytic stability**: Short-term or moderate humidity (e.g., 60% RH breakthrough) does not guarantee long-term stability; prolonged exposure at higher RH or immersion in liquid water causes degradation.
  - Warning: Do not assume moisture tolerance from a single moderate-RH breakthrough test; include longer-term/high-RH exposures and humidity cycling in evaluation and avoid design choices that expose metal atoms to water if long-term wet stability is required.
- **adsorption energetics: simulation vs experiment**: The authors note that simulated zero-coverage Qst values are higher than experimental outcomes and that this overestimation may explain overprediction of low-pressure uptake in simulations.
  - Warning: Do not rely solely on simulation-derived enthalpies to predict regeneration energy or low-pressure uptake; use experimental Qst for process design and treat simulated binding energies as likely upper-bound estimates.