---
title: "Latest developments in the synthesis of metal–organic frameworks and their hybrids for hydrogen storage"
type: source
tags: [h2, source, paper]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_fa8cccd644]
confidence: medium
---


# Latest developments in the synthesis of metal–organic frameworks and their hybrids for hydrogen storage

## Metadata

- Source ID: `src_fa8cccd644`
- Raw file: `raw_sources/inbox/d4nr03969f.pdf`
- Primary task: `h2`
- Task tags: h2, pld, mixed
- Auto-classification confidence: `high`
- Auto-classification reason: This is a focused 2025 review on MOF synthesis and hybrids specifically for hydrogen (H2) storage, discussing capacities, DOE targets, adsorption at 77 K/−196 °C, BET/ABET metrics, isosteric enthalpy, gravimetric and volumetric uptake. It also emphasizes pore size distribution, pore volume, linker functionalization and interpenetration/structure tuning and hybridization strategies, so pore/PLD design is directly relevant. Because the paper strongly covers both H2 storage and pore-design/synthesis tradeoffs, 'mixed' is included with other tags.
- Authors: Laura Jimenez-Lopez, Rafael Morales Ospino, Leandro Goulart de Araujo, Alain Celzard, Vanessa Fierro
- Year: 2025
- Journal: Nanoscale
- DOI: 10.1039/d4nr03969f
- Material families: MOFs, MOF hybrids, carbon-based materials, ZIF-L, ZIF-8, HKUST-1, MOF-5, MOF-808, UiO-66, IRMOF-3, UMCM-1, DMOF-1, NU-2100, tetrazolate-based MOFs, Interpenetrated MOFs (IMOFs), MOF-on-MOF (core–shell, ternary), MOF/carbon hybrids, MOF/metal hybrids, MIL-101 (Cr), MIL-100(Al), SNU-3, MOF@clay, MOF@zeolite, ZTC (zeolite-templated carbon), Co-bpdc, V(II)-containing MOFs, mesoporous MOFs
- Methods: solvothermal/hydrothermal, sonochemical, electrochemical, microwave-assisted, ionothermal, mechanochemical, Resonant Acoustic Mixing (RAM), gas sorption analysis (N2/H2 isotherms), BET/ABET surface area analysis, isosteric enthalpy calculation (from isotherms at two temperatures), Grand Canonical Monte Carlo (GCMC) simulations, linker functionalization / post-synthetic modification, activation methods to create open metal sites (heating, vacuum, supercritical drying), mechanochemical; RAM (resonant acoustic mixing), post-synthetic covalent modification, hydrophobic coating (solution-immersion), pelletization / extrusion / granulation, MOF-on-MOF growth (epitaxial, heteroepitaxial, surfactant-assisted, nucleation-kinetic-guided, ligand/metal ion-exchange), interpenetration (catenation), in situ growth, physical mixing, ion exchange, chemical reduction, nanoparticle encapsulation, doping (Li+, metal ions), template methods, thermal modification / carbon coating (pyrolysis under N2), SEM / TEM / N2 adsorption–desorption isotherms, IUPAC physisorption protocols and BET consistency criteria
- Gas targets: H2, CO2, CH4, D2, H2O (water vapor)

## Extracted mechanism claims

- **Cryogenic H2 adsorption (−196 °C, 77 K) at moderate pressures requires materials with very high accessible surface area, high micropore volume, a tuned pore size distribution, and sufficient bulk/particle density to be practically useful.**  
  - Task: `h2`; confidence: `high`
  - Implication: For cryo-adsorptive H2 storage design MOFs/MOF-hybrids to maximise accessible SSA and micropore volume while controlling PSD and preserving packing density; evaluate both gravimetric and volumetric uptake at target T/P.
  - Evidence: Adsorption of H2 at −196 °C ... enables H2 to be stored at moderate pressures, of the order of 5 MPa, but requires high-surface area materials with a suitable pore size distribution (PSD) and high bulk density. || "In general, micropore volume is directly related to the surface area of a material. Consequently, to enhance H2 adsorption capacity at −196 °C, it is necessary to increase both specific surface area (SSA) and micropore volume within the MOF."
- **Empirical extreme performances: reported excess H2 capacities at −196 °C vary widely (several wt% to >9 wt%); NU-100 (NU100) reported 9.05 wt% at −196 °C and 7 MPa (7 MPa = 70 bar).**  
  - Task: `h2`; confidence: `high`
  - Implication: When pursuing high gravimetric cryogenic capacity, target ultrahigh-surface-area MOFs (NU100-class) and validate performance at intended cryogenic pressures; also evaluate volumetric metrics and practical operating conditions.
  - Evidence: Excess H2 storage capacities in the range of 2.4 to 9.1 wt% have been obtained in MOFs with Brunauer–Emmett–Teller (BET) areas (ABET) of up to 6000 m2 g−1. The highest H2 storage capacity reported to date is 9.05 wt% at −196 °C and 7 MPa for NU100. || "NU100, which reaches 9.05 wt% at 7 MPa and −196 °C."
- **Increasing ABET often coincides with increased pore volume and larger average pore diameter, which tends to reduce adsorbent–sorbate interaction strength (lower isosteric enthalpy of adsorption).**  
  - Task: `pld`; confidence: `medium`
  - Implication: When increasing surface area/pore volume to raise gravimetric storage, expect reduced binding strength; compensate via linker functionalization or open metal sites if stronger adsorption is required for higher-temperature operation.
  - Evidence: Moreover, increasing ABET leads to an increase in average pore volume and thus to a decrease in adsorbent–sorbate interactions and isosteric enthalpy of adsorption. || "The ability of any adsorbent to store H2 (wt%) is closely linked to its SSA. ... for very high ABET, Chahine’s heuristic rule is not valid, as the BET method accounts for pore volume more than SSA."
- **Gravimetric vs volumetric trade-off: as pore volume and ABET increase, particle/bulk density usually decreases; highest gravimetric uptakes (reported up to ~12 wt%) do not necessarily give highest volumetric uptakes (volumetric capacities reported to peak around ~40 kg H2 m−3).**  
  - Task: `h2|pld`; confidence: `high`
  - Implication: Balance pore volume and framework/bulk density for target application: to maximize volumetric H2 storage, avoid sacrificing packing density for extreme surface area; consider densification, interpenetration, or hybridization strategies.
  - Evidence: The increase in pore volume also results in a reduction of particle density. Indeed, while absolute gravimetric H2 capacities reach values as high as 120 mg H2 per g (12 wt%), volumetric H2 capacities peak at values of around 40 kg H2 per m3. Thus, MOFs with high ABET and high absolute H2 uptake on a gravimetric basis are not necessarily those with the highest H2 uptake on a volumetric basis.
- **MOF hybrids incorporating carbonaceous phases can improve thermal conductivity, increase accessible surface area or micropore volume, and tune chemical composition to enhance selectivity or kinetics for H2 adsorption.**  
  - Task: `h2|mixed`; confidence: `medium`
  - Implication: Combine MOFs with carbonaceous materials to enhance heat transfer, kinetics and cryogenic uptake; optimize type and loading of carbon to increase micropore fraction without blocking access and check both gravimetric and volumetric metrics.
  - Evidence: The addition of carbon-based materials to produce MOF hybrids can improve thermal conductivity and allow tuning of the chemical composition to provide greater selectivity for H2 adsorption compared with other gases. || Examples: MIL-101(Cr)@ZTC increased BET and H2 uptake; MOF-5@MWCNT increased Langmuir area (2160 → 3550 m2 g−1) and H2 storage; HKUST-1@graphite flake hybrids increased thermal conductivity and H2 uptake.
- **Linker functionalization and the creation/exposure of coordinatively unsaturated (open) metal sites are effective strategies to raise adsorption enthalpy (Qst) and improve H2 uptake at higher temperatures, including near-ambient.**  
  - Task: `h2`; confidence: `high`
  - Implication: To improve room-temperature or moderate-temperature H2 uptake, incorporate/linker-functionalize to create polar adsorption environments and activate frameworks to expose metal sites; characterize Qst and uptake to ensure target enthalpy (~15–25 kJ mol−1, optimal ≈20 kJ mol−1) is approached without over-strengthening.
  - Evidence: Linker functionalization seems to be an effective approach for enhancing the H2 adsorption enthalpy of MOFs ... Han et al. enhanced UiO-66 by incorporating dihydroxy and dialkoxy groups ... UiO-66-(OCH2CH3)2 exhibited a 98.3% improvement. ... post-synthetic covalent modifications can greatly enhance sorption affinity. ... Introduction of unsaturated metal sites ... activated NU-2100 exhibited an enthalpy of adsorption of 30 kJ mol−1. Simulations indicate an optimum (−ΔH)ads ≈20 kJ mol−1 for room-temperature storage.
- **Most MOFs interact with H2 primarily by van der Waals physisorption; typical (−ΔH)ads values are 5–12 kJ mol−1, which are generally too low for practical ambient-temperature storage where ~15–25 kJ mol−1 is desirable.**  
  - Task: `h2`; confidence: `high`
  - Implication: For room-temperature H2 storage, increase binding enthalpy into ~15–25 kJ mol−1 via chemistry (linker functionalization, open metal sites, dopants) while monitoring reversibility.
  - Evidence: Van der Waals forces ... are the main gas–adsorbent interaction. For optimum hydrogen storage and release cycles at room temperature, an adsorbent should have a (–ΔH)ads between 15 and 25 kJ mol−1. Unfortunately, the majority of MOFs exhibit (–ΔH)ads values between 5 and 12 kJ mol−1. Simulations (Bae and Snurr) indicate an optimum near 20 kJ mol−1.
- **Isosteric enthalpy of adsorption decreases with increasing average pore diameter: narrower pores (overlapping van der Waals fields) increase (−ΔH)ads and strengthen H2 binding.**  
  - Task: `pld`; confidence: `high`
  - Implication: To enhance adsorption enthalpy and H2 binding, design MOFs with smaller average pore diameters (narrow micropores) to exploit overlapping van der Waals interactions.
  - Evidence: The isosteric enthalpy of adsorption ((–ΔH)ads) exhibits a linear decrease with increasing average pore diameter. This is attributed to stronger adsorption forces in narrow pores due to overlapping van der Waals forces.
- **Pore-size dependence: nanopores <1.5 nm are most efficient for H2 storage across pressures, while pores of 1.5–2.5 nm substantially enhance high-pressure capacity.**  
  - Task: `pld`; confidence: `medium`
  - Implication: When tailoring PSD for H2, prioritize nanopores <1.5 nm for broad efficiency and incorporate controlled fractions of 1.5–2.5 nm pores if targeting high-pressure charging.
  - Evidence: The presence of 1.5 to 2.5 nm pores has been shown to significantly enhance H2 storage capacity at high pressures. However, nanopores smaller than 1.5 nm are found to be the most efficient for H2 storage at all pressure levels.
- **There is an ideal size scale where H2–surface interactions are maximized (near the H2 kinetic diameter ≈0.289 nm), but synthesizing materials with a unimodal PSD around ~0.3 nm and high surface area is challenging.**  
  - Task: `pld`; confidence: `medium`
  - Implication: Aim for narrow pore apertures approaching the H2 kinetic diameter to maximize adsorbate–surface interaction, but recognize synthetic challenges and potential losses in accessible area.
  - Evidence: H2 interactions with MOFs can be enhanced by reducing pore size, with the optimum size corresponding to the kinetic diameter of the H2 molecule (0.289 nm), although porous materials with a unimodal PSD of around 0.3 nm and high surface areas are difficult to obtain.
- **Post-synthetic covalent modifications, activation (to create open metal sites), and ion/particle doping are effective at increasing adsorption enthalpy and/or introducing new adsorption sites that can improve H2 uptake, sometimes substantially.**  
  - Task: `h2|pld`; confidence: `high`
  - Implication: Use post-synthetic modification, activation and dopants/nanoparticles to raise Qst and introduce active adsorption sites, but measure actual H2 isotherms and Qst since BET may decrease and site stability can be an issue.
  - Evidence: Post-synthetic covalent modifications can greatly enhance the sorption affinity of MOFs for H2. || "Another way to strengthen the interaction ... is through the introduction of unsaturated metal sites ... the activated MOF exhibited a high enthalpy of adsorption of 30 kJ mol−1." || Examples: MOF-5@Ni/Co slightly higher uptake; MIL-101@AC-Li gave very high uptakes (14.4 wt% at −196 °C and 100 bar); Pd/Pt loading increased uptake even when BET decreased.
- **Interpenetration (catenation) can reduce effective pore size, minimize vacant zones, improve framework stability, increase overlap of attractive potential between opposing pore walls, and often increase adsorption enthalpy and volumetric H2 uptake (examples include PCN-6 showing increases in SA and volumetric uptake).**  
  - Task: `h2`; confidence: `high`
  - Implication: Use interpenetration/catenation to produce finer pore apertures and increase overlapping adsorption potential for stronger H2 interactions and higher volumetric uptake, but evaluate SSA trade-offs case-by-case.
  - Evidence: Interpenetration minimizes vacant zones and has the potential to significantly improve framework stability. Catenation can produce materials with fine pores and enhance adsorption heat by increasing overlap of attractive potential between opposing pore walls. || In PCN-6 interpenetration increased Langmuir SA from 2700 to 3800 m2 g−1 and increased volumetric H2 uptake from 3.94 to 9.19 kg m−3 (and gravimetric from 1.35 to 1.9 wt%).
- **Some interpenetrated hybrid architectures combining MOFs with carbon scaffolds and unsaturated metal sites can yield good cryogenic H2 uptake even with modest ABET (example: Int-MOFMC-meso stored 2.02 wt% at −196 °C, 1 bar with ABET ~805 m2 g−1).**  
  - Task: `h2`; confidence: `medium-high`
  - Implication: When ABET is limited, combine interpenetration, carbon scaffolds and expose unsaturated metal sites to improve cryogenic uptake; validate with H2 isotherms at intended conditions.
  - Evidence: Int-MOFMC-meso was able to store 2.02 wt% H2 at −196 °C under 1 bar. ... the presence of an interpenetrated structure and the unsaturated metal site present on the mesopore surface improved H2 storage performance, even with a lower ABET.
- **Hydrophobic surface functionalization or coatings and core–shell MOF-on-MOF architectures can protect water-sensitive MOF cores from degradation, preserving crystal structure, morphology, surface area and H2 uptake after aqueous exposure.**  
  - Task: `h2`; confidence: `high`
  - Implication: Apply hydrophobic coatings, non-polar linker functionalization, or design core–shell MOF-on-MOF hybrids with hydrophobic shells to shield water-sensitive cores while monitoring pore accessibility.
  - Evidence: Qian et al. synthesized a hydrophobic DUT-4 that preserved crystal structure, morphology, surface area and H2 uptake after aqueous exposure. || Li et al. developed a MOF-on-MOF where a hydrophobic bio-MOF-14 shell protected a water-sensitive core; resulting hybrids showed selective gas storage and improved water stability.
- **Packing efficiency (tap density, crystal morphology and particle size) is critical for volumetric H2 storage; shaping/pelletization can improve volumetric density but risks pore collapse, pore blocking or amorphization if not controlled.**  
  - Task: `h2|pld`; confidence: `high`
  - Implication: Control crystal morphology/size and use shaping/binder strategies that minimize pore collapse to maximize volumetric H2 storage; measure tap density and volumetric uptake for candidate shapes.
  - Evidence: Packing efficiency is a key factor in determining the H2 storage capacity of MOFs. Suresh et al. improved packing efficiency and increased volumetric storage density of MOF-5 by controlling crystal morphologies and size distributions. Factors such as pore collapse, pore blocking and amorphization can reduce storage capacity of compressed MOFs.
- **Thermal conductivity of MOFs is generally low (<2 W m−1 K−1) due to high porosity and low density; thermal conductivity increases with higher density (>1.0 g cm−3), smaller pores (<1 nm) and four-connected metal nodes, and poor heat dissipation can limit effective uptake during fast, exothermic filling.**  
  - Task: `h2`; confidence: `medium-high`
  - Implication: For fast filling or cyclic operation, prefer MOFs or hybrids with higher thermal conductivity (denser frameworks, small pores, structural motifs) or add conductive fillers (graphite flakes, carbon) while monitoring porosity trade-offs.
  - Evidence: Islamov et al. reported MOFs exhibit enhanced thermal conductivity when they have high densities (>1.0 g cm−3), small pores (<1 nm) and four-connected metal nodes. The highly porous nature and low density of MOFs prevent efficient phonon transport and result in low thermal conductivities (<2 W m−1 K−1). || Example: HKUST-1@graphite flake hybrid increased thermal conductivity (hybrid monolith 3.15 W m−1 K−1 vs pure 0.49 W m−1 K−1) and improved H2 uptake.
- **Carbon-coating (amorphous carbon via thermal pyrolysis) can substantially improve moisture stability/hydrophobicity but often reduces measured BET surface area (example: MOF-5 decreased from 3450 to 1740 m2 g−1).**  
  - Task: `h2`; confidence: `high`
  - Implication: Use carbon coatings when water stability is a priority, but expect and quantify loss in accessible surface area and potential impact on adsorption capacity.
  - Evidence: Amorphous carbon-coated MOF-5 prepared by thermal modification under N2 (480–530 °C) had reduced BET areas (1740 vs. 3450 m2 g−1) but displayed better water stability compared with pristine MOF-5.
- **Metal ion doping and incorporation of metal nanoparticles (Ni, Co, Li+, Pd, Pt, Mg nanocrystals, etc.) can increase H2 adsorption enthalpy and uptake (including ambient-temperature improvements) although these additions often reduce measured SSA; synergistic combinations (e.g., AC + Li in MIL-101) can yield exceptional high-pressure cryogenic uptakes.**  
  - Task: `h2`; confidence: `high`
  - Implication: To enhance ambient or high-pressure H2 uptake, consider metal ion doping or nanoparticle incorporation (Li, Pd, Pt, Ni, Co, Mg), optimize dispersion/loading to avoid pore blockage, and verify uptake/Qst and reversibility experimentally.
  - Evidence: Among these sites are exposed metal ions, whose binding enthalpy lies between −20 and −30 kJ mol−1. Peedikakkal et al. showed metal-exchanged MOF-5@Ni and MOF-5@Co exhibit slightly higher H2 uptake. Prabhakaran and Deschamps reported MIL-101-B@AC-Li with 14.4 wt% at −196 °C and 100 bar despite lower ABET. Cheon et al. reported Pd-loaded SNU-3 increased H2 uptake despite a 43% decrease in surface area. Magnesium nanocrystals embedded in MOFs demonstrate synergistic physi-/chemisorption.
- **Carbon additive loading often has non-monotonic effects: low/optimal carbon amounts can create new small pores and increase micropore volume and H2 uptake, whereas excessive carbon loading can reduce uptake by blocking pores or lowering accessible MOF porosity.**  
  - Task: `pld`; confidence: `high`
  - Implication: Optimize carbon additive type and loading to balance increased microporosity and avoid pore blockage; measure PSD and H2 isotherms to confirm benefit.
  - Evidence: Petit et al. showed HKUST-1@GO (5 wt%) H2 uptake slightly higher than pristine, while 18 wt% GO lowered uptake. Prasanth et al. incorporated 8 wt% SWCNTs into MIL-101 leading to increased H2 capacities attributed to reduced pore size and increased micropore volume despite slight SSA decrease.
- **Encapsulation of guests with sizes matched to host pores can improve stability of guest species and the composite (example: perovskite QDs 1.5–2 nm in HKUST-1 improved stability at 70% RH).**  
  - Task: `pld`; confidence: `high`
  - Implication: Select guest sizes comparable to host pore dimensions to stabilize labile guests; verify encapsulation and environmental stability experimentally.
  - Evidence: Perovskite QDs of 1.5–2 nm matched the pore size of HKUST-1 and the resulting material improved its stability under 70% RH, whereas QDs alone decomposed.
- **Some specialized mechanisms/approaches beyond physisorption have been reported: quantum kinetic molecular sieving enables H2/D2 separation in narrow pores, and low-valent transition-metal sites (e.g., V(II)) can bind H2 via dihydrogen complexation enabling ambient-temperature storage in select MOFs.**  
  - Task: `h2`; confidence: `medium`
  - Implication: For isotope separation or ambient storage via stronger chemisorption, explore narrow-pore MOFs for quantum sieving and stabilized low-valent metal sites (e.g., V(II)) for dihydrogen complexation, but evaluate stability and reversibility.
  - Evidence: "Surface Interactions and Quantum Kinetic Molecular Sieving for H2 and D2 Adsorption on a Mixed Metal–Organic Framework Material" (ref). || "Ambient-Temperature Hydrogen Storage via Vanadium(II)-Dihydrogen Complexation in a Metal–Organic Framework" (ref).
- **Characterization caveat: BET/ABET must be applied with consistency criteria and used alongside pore-size distribution and direct gas isotherms because BET can conflate SSA and pore volume (particularly at very high ABET) and mislead H2 uptake expectations (Chahine's rule not universally valid for MOFs).**  
  - Task: `pld`; confidence: `high`
  - Implication: Do not rely on ABET alone for screening; apply BET consistency criteria, compute PSD and micropore volume, measure H2 isotherms at target T/P and estimate Qst to select candidates robustly.
  - Evidence: Due to limitations of the BET method, very high ABET values are more indicative of pore volume than actual surface area. When excess H2 storage capacities at −196 °C are plotted vs ABET for many MOFs, the trend does not follow Chahine's 1 wt% per 500 m2 g−1 rule. Use BET with consistency criteria and IUPAC physisorption evaluation.

## Extracted design rules

- **Balance ABET/pore volume against bulk/particle density when optimizing for volumetric H2 capacity; do not optimize ABET alone.**
  - IF: Target: H2 storage at cryogenic conditions (≈77 K) or volumetric capacity is a priority, ABET or pore volume is being increased
  - THEN: Compute volumetric uptake using realistic packing or single-crystal density, not only gravimetric ABET, Prefer pore architectures and synthesis routes that provide high accessible area while preserving packing density (consider interpenetration or controlled densification), If densification is used, verify porosity retention after compaction
  - Why: Increasing ABET tends to increase pore volume but reduces particle density, which can lower volumetric H2 capacity despite higher gravimetric uptake; volumetric uptake can plateau for very high-BET MOFs.
- **Use MOF–carbon hybrids or conductive fillers to improve thermal management (and often microporosity) especially when fast filling or cycling is required, but optimize loading to avoid pore blocking and loss of SSA.**
  - IF: Adsorption/desorption cycles limited by heat dissipation or kinetics, MOF formed into pellets/monoliths where heat management is important
  - THEN: Incorporate conductive carbonaceous phases (graphite flakes, CNTs, MWCNTs, graphene derivatives) at loadings that improve thermal conductivity while monitoring porosity, Measure thermal conductivity and H2 uptake/cycling behaviour to find optimal filler loading (examples show beneficial effects at ~10 wt% for HKUST-1 monoliths), Ensure dispersion and avoid inhomogeneous regions
  - Why: Carbon additions can improve thermal conductivity and increase accessible microporosity, facilitating H2 release and improving recovery during cycles.
- **Do not use ABET alone as a screening metric for H2 uptake—include pore size distribution, micropore volume and isosteric enthalpy (Qst) and measure H2 isotherms at intended T/P.**
  - IF: Screening MOF candidates for H2 storage (77 K and/or ambient targets), Only BET/ABET data are initially available
  - THEN: Acquire H2 isotherms at target temperatures and pressures, Compute pore size distribution and accessible micropore volume (NLDFT or equivalent), Estimate Qst from isotherms or other probes to assess binding strength
  - Why: ABET can be dominated by pore volume at very high values and Chahine's rule is not universally valid for MOFs; PSD and Qst strongly influence usable uptake.
- **To raise adsorption enthalpy toward the window desirable for ambient-temperature H2 storage (~15–25 kJ mol−1, optimal ≈20 kJ mol−1), use linker functionalization (polar/electron-rich groups), post-synthetic covalent modification, and activation to create open metal sites; verify Qst and reversibility.**
  - IF: Target: H2 storage at or near ambient temperature, Material synthesis allows functionalization or metal-site exposure
  - THEN: Introduce polar/electron-donating functional groups (–OH, –NH2, alkoxy, etc.) on linkers pre- or post-synthetically, Activate frameworks (heat, vacuum, supercritical drying) to expose coordinatively unsaturated metal sites, Characterize Qst and measure uptake/release cycles to ensure reversibility
  - Why: Functionalization and unsaturated metal sites increase (–ΔH)ads; experimental examples show large improvements (UiO-66 dialkoxy derivative, NU-2100 activation Qst ~30 kJ mol−1).
- **Target nanopores <1.5 nm for broadly efficient H2 storage; include a controlled fraction of 1.5–2.5 nm pores when aiming to boost high-pressure uptake.**
  - IF: Goal: robust H2 storage across a pressure range or specifically high-pressure charging, Material platform allows PSD engineering
  - THEN: Engineer PSD to include dominant fraction of pores <1.5 nm, Add controlled population of 1.5–2.5 nm pores for high-pressure capacity if needed, Verify PSD and H2 isotherms experimentally
  - Why: Nanopores <1.5 nm are efficient across pressures; pores of 1.5–2.5 nm enhance high-pressure storage.
- **If volumetric H2 storage is an objective, then improve packing efficiency (control crystal morphology/size, pelletization strategies) and/or induce interpenetration to increase framework density while monitoring SSA trade-offs.**
  - IF: Priority: volumetric uptake (mass per unit volume), Using powder MOFs intended for compaction or tank storage
  - THEN: Control synthesis to tune crystal size/morphology for better packing (choose solvothermal, mechanochemical, etc.), Consider interpenetration/catenation to reduce effective pore size and increase volumetric density, Test tap density, compactability and porosity retention after shaping; use binders that minimize pore collapse
  - Why: Packing efficiency and interpenetration can increase volumetric H2 capacity (PCN-6 interpenetration increased volumetric uptake substantially; MOF-5 packing strategies improved volumetric density).
- **If operation in humid environments is expected, then apply hydrophobic linker functionalization, hydrophobic coatings or design core–shell MOF-on-MOF shells to protect sensitive cores and retain H2 uptake.**
  - IF: Operational environment includes moisture or aqueous exposure, Material: water-sensitive MOF cores
  - THEN: Functionalize linkers with non-polar groups or apply hydrophobic coatings (solution-immersion or carbon coatings), Encapsulate sensitive MOFs within hydrophobic MOF shells (MOF-on-MOF core–shell), Characterize post-treatment porosity and H2 uptake after humidity exposure
  - Why: Hydrophobic coatings preserved DUT-4 properties after aqueous exposure; MOF-on-MOF shell (bio-MOF-14) protected water-sensitive cores and improved stability.
- **When evaluating doped or nanoparticle-containing MOF hybrids, measure H2 isotherms and Qst directly rather than relying solely on BET area because uptake can increase despite SSA reductions.**
  - IF: MOF hybrid contains metal ions, metal nanoparticles, or other dopants, Observed SSA decreases after modification or composition changes
  - THEN: Measure H2 uptake isotherms at relevant T/P (e.g., −196 °C, 25 °C) and compute Qst, Characterize micropore volume, PSD, and exposed adsorption sites (XPS, chemisorption probes), Perform control experiments to test for mechanisms like spillover
  - Why: Examples show H2 uptake increases despite large reductions in BET area (e.g., Pd-loaded SNU-3 increased uptake while SSA decreased 43%), indicating new adsorption sites can dominate performance.
- **If the goal is to leverage metal nanoparticles, alkali-metal doping or noble metals for enhanced uptake (including potential spillover), then optimize loading/dispersion and rigorously test for reproducible spillover or cooperative effects while monitoring pore blockage risks.**
  - IF: Goal: increase H2 uptake beyond physisorption limits or enhance ambient uptake, Material platform can host nanoparticles/dopants (e.g., HKUST-1, MIL-101, MOF-5)
  - THEN: Develop embedding/surface-loading/doping protocols that maximize dispersion and minimize pore occlusion, Run controls without metal NPs/dopants and probe mechanisms (e.g., temperature-programmed desorption, isotopic labeling) to verify spillover, Assess long-term stability and reversibility
  - Why: Studies report enhanced uptake with Pd/Pt nanoparticles and Li-doping but also show decreased SSA and the need to validate spillover contributions.
- **When designing mesoporous MOFs or tailoring large-pore architectures, apply synthetic strategies and linker selection/functionalization to control pore size, shape and spatial distribution and evaluate meso-/micro- scale PSD against target gases.**
  - IF: Requirement: tailored mesoporosity or controlled pore architecture, Material platform: MOFs where linker and synthesis routes can be tuned
  - THEN: Use templating, choice of linker size/geometry, and synthesis conditions to control pore size/shape/distribution, Characterize resulting PSD (IUPAC/NLDFT) and correlate with gas uptake, Beware over-interpenetration and functional-group crowding that may reduce accessible pore volume
  - Why: Mesoporous MOFs with controlled pore architecture have been demonstrated; linker choice and functionalization influence interpenetration and adsorption behavior.

## Contradiction notes

- **ABET/Chahine heuristic vs pore-volume and PSD effects**: Use BET area as a first-order predictor across typical ABET ranges, but for ultra-high ABET MOFs explicitly consider pore volume, PSD and isosteric enthalpy and measure H2 isotherms at target T/P. Compute volumetric uptake using framework or packing density when volumetric metrics matter.
  - Warning: Do not filter candidates solely by ABET or Chahine's rule — combine BET with PSD, micropore volume and Qst measurements.
- **Effect of interpenetration on surface area (framework-dependence)**: The effect of interpenetration on measured surface area is framework- and topology-dependent; interpenetration can either increase or decrease SSA depending on how it affects pore connectivity and measurement methodology.
  - Warning: Do not assume interpenetration will always reduce or always increase SSA — evaluate experimentally or via simulation for each framework.
- **Carbon hybridization effect on SSA**: Outcome depends on carbon integration method: coatings/overlayers may block pores and reduce SSA, while incorporation of porous/tailored carbon components can increase accessible porosity and SSA.
  - Warning: Assess the specific carbon integration method (coating vs templated porous additive) and measure SSA and PSD experimentally.
- **BET area vs H2 uptake in doped/nanoparticle hybrids**: Predictive power of BET depends on whether uptake is dominated by accessible surface area or by newly introduced/stronger adsorption sites; combine SSA with PSD, Qst and direct isotherms when evaluating hybrids.
  - Warning: Do not use BET alone to accept/reject candidates, especially for doped or nanoparticle-containing hybrids.