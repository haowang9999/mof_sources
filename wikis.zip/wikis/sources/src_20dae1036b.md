---
title: "Effect of Amine Functionalization of MOF Adsorbents for Enhanced CO2 Capture and Separation: A Molecular Simulation Study"
type: source
tags: [co2, source, paper]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_20dae1036b]
confidence: medium
---


# Effect of Amine Functionalization of MOF Adsorbents for Enhanced CO2 Capture and Separation: A Molecular Simulation Study

## Metadata

- Source ID: `src_20dae1036b`
- Raw file: `raw_sources/inbox/fchem-08-574622.pdf`
- Primary task: `co2`
- Task tags: co2, pld, mixed
- Auto-classification confidence: `high`
- Auto-classification reason: The paper is a molecular simulation study specifically aimed at improving post-combustion CO2 capture and separation via amine functionalization of MOF-74/DOBPDC. It focuses on CO2 adsorption isotherms, CO2/N2 selectivity, cyclic working capacity and regenerability and the cooperative chemisorption mechanism. The work also discusses pore/structure aspects (expanded DOBPDC, pore size allowing longer amines, steric hindrance effects), so pore design is a relevant secondary theme — hence inclusion of pld and mixed in the tags while keeping co2 as the primary task.
- Authors: Daniel Bahamon, Wei Anlu, Santiago Builes, Maryam Khaleel, Lourdes F. Vega
- Year: 2021
- Journal: Frontiers in Chemistry
- DOI: 10.3389/fchem.2020.574622
- Material families: M-MOF-74 (M2(dobdc)), M2(dobpdc) (expanded MOF-74 / DOBPDC), amine-functionalized variants (en, mmen, mda, dmen, heterodiamines, etc.), diamine-appended Mg2(dobpdc) and related extended MOF-74 structures
- Methods: Grand Canonical Monte Carlo (GCMC) molecular simulation (LAMMPS and GCMC workflows), explicit chemisorption modeling (Builes & Vega approach), Lennard-Jones with Lorentz–Berthelot mixing rules; Ewald summation for electrostatics, comparison to / citation of experimental literature
- Gas targets: CO2, N2, H2

## Extracted mechanism claims

- **Amine grafting/functionalization of MOF frameworks increases CO2 affinity and selectivity (often improving low-pressure uptake, kinetics and enabling chemisorptive mechanisms) but also increases hydrophilicity such that water can compete with CO2 and impair performance unless addressed.**  
  - Task: `co2`; confidence: `high`
  - Implication: Use amine grafting to raise low-pressure CO2 capture and selectivity, but explicitly include humidity/oxidation considerations in screening or use oxidation-resistant chemistries; tune amine identity and loading to balance uptake and regenerability.
  - Evidence: “Therefore, amine-functionalized MOFs are attracting great attention, as they are more effective than the corresponding original solid adsorbents... Studies have shown that amine-functionalized MOFs have potential for greater adsorption capacity, higher selectivity, faster CO2 adsorption kinetics, and lower regeneration temperatures…” | “...the use of the most promising MOFs require partial or complete drying of the gas stream because high affinity for CO2 entails hydrophilicity, and thus water can competitively adsorb with CO2.” | “Since it is known that the amine groups chemically react with CO2 and enable adsorption enhancement at very low pressures, chemisorption was explicitly considered...”
- **Diamine functionalization of expanded M2(dobpdc) materials leads to cooperative chemisorption via formation of ammonium carbamate chains, producing step-like (sigmoidal) CO2 adsorption isotherms whose step pressure can be tuned by amine identity and substitution.**  
  - Task: `co2`; confidence: `high`
  - Implication: To achieve sharp low-pressure CO2 uptake suitable for TSA-style operation, functionalize DOBPDC-type frameworks with appropriate diamines to promote ammonium-carbamate chain formation and tune step pressure by amine selection and substitution.
  - Evidence: “Formation of ammonium carbamate chains takes place for different diamine molecules on the adsorbent, leading to isotherms exhibiting step-like shapes at given temperatures.” | “The simulations show that this step originates from a mechanism wherein the CO2 gas molecule is cooperatively and reversibly inserted into metal–amine bond followed by formation of ammonium carbamate chain structure.”
- **Expanded DOBPDC materials have substantially larger surface area and pore diameters than MOF-74 (example cited: Mg/DOBPDC SBET ≈ 2,451 m2·g−1 and average pore diameter ≈ 21 Å vs Mg-MOF-74 SBET ≈ 816 m2·g−1), enabling accommodation of longer/bulkier alkyl- or diamine functional groups and enabling cooperative adsorption with less steric loss of capacity than in narrow pores.**  
  - Task: `pld`; confidence: `high`
  - Implication: Select expanded-linker DOBPDC analogues when planning to attach longer alkyl- or diamine functional groups to exploit cooperative adsorption mechanisms; verify pore diameter and surface area metrics and model partial/full functionalization cases.
  - Evidence: “For instance, Mg/DOBPDC has a surface area (SBET) of 2,451 m2·g−1 greater than the 816 m2·g−1 for Mg-MOF-74... The enlarged pores provide enough space to accommodate longer alkylamines onto the open metal sites of the framework compared to M-MOF-74 materials.” | “As shown... the capacities of the bare materials at typical flue gas conditions are reduced by using the expanded hexagonal version (M/DOBPDC), however... -en and -mmen versions of Mg/DOBPDC present a capacity of ∼3.6 mmol·g−1 at 15 kPa, 15% higher than the one achieved with the bare material.”
- **Simulation screening identified mmen-Mg/DOBPDC and mda-Zn/DOBPDC as promising candidates with high cyclic working capacities for TSA-like cycles; mmen-Mg/DOBPDC was predicted to have higher uptake and better regenerability among the evaluated candidates, and mda-Zn/DOBPDC was estimated to deliver ~2.9 mmol·g−1 working capacity with a ~60°C regeneration swing in the simulations.**  
  - Task: `co2`; confidence: `medium`
  - Implication: Prioritize mmen-Mg/DOBPDC and mda-Zn/DOBPDC for follow-up process-level simulation and experimental validation for TSA-based post-combustion CO2 capture, including tests under humid and realistic flue conditions.
  - Evidence: “Results show two potential structures with high cyclic working capacities if used for Temperature Swing Adsorption processes: mmen/Mg/DOBPDC and mda-Zn/DOBPDC. Among them, the -mmen functionalized structure has higher CO2 uptake and better cyclability (regenerability) for the flue gas mixtures and conditions studied.” | “mda-Zn/DOBPDC shows performance in the optimum range for post-combustion CO2 capture from ﬂue gas, enabling a working capacity of 2.9 mmol·g−1 with a 1T = 60◦C for regeneration.”
- **Grafting bulky amines or increasing the degree of amine functionalization to full coverage can reduce CO2 uptake due to steric hindrance / site blocking; partial functionalization (sub-100%) often provides a better balance of chemisorptive sites and accessible void space.**  
  - Task: `co2`; confidence: `high`
  - Implication: Treat functionalization degree as an optimization variable; include partial-coverage cases (e.g., ~60–75%) in screening and avoid assuming 100% coverage is best—especially with bulky grafts.
  - Evidence: “Furthermore, it is shown that more amine functional groups grafted on the MOFs and/or full functionalization of the metal centers do not lead to better CO2 separation capabilities due to steric hindrances.” | “The degree of functionalization in MOF-74 structures show that amine substitution below 100% provide better performance than the fully substituted material... It was found that the functionalization degree for Mg/DOBPDC and Zn/DOBPDC with the studied diamine-appended molecules is typically 72 and 61%, respectively.”
- **Alkyl substitution on appended amines (e.g., methylation such as mmen) shifts the cooperative adsorption step pressure and can weaken metal–carbamate interactions, thereby tuning both the step position and regenerability (easier desorption).**  
  - Task: `co2`; confidence: `medium`
  - Implication: Use alkyl substitution (including small substituents like methyl) to shift the cooperative adsorption step and/or reduce regeneration energy, but simulate or test the exact substitution to ensure cooperative chain formation and acceptable capacity remain.
  - Evidence: “In addition, multiple alkyl groups bonded to the amino group yield a shift in the step-like adsorption isotherms in the larger pore structures, at a given temperature.” | “mmen-Mg/DOBPDC, in which the methyl groups help in the facile desorption by weakening the Mg–carbamate interaction.”
- **Open metal (coordinatively unsaturated) M2+ sites in MOF-74 family are prime adsorption locations for CO2 at low pressures and can be used as anchoring points for amine grafting, converting physisorption into chemisorption.**  
  - Task: `co2`; confidence: `high`
  - Implication: Target open metal sites for amine grafting when seeking chemisorption-based low-pressure CO2 capture; account for the resulting change in mechanism and water sensitivity.
  - Evidence: “M-MOF-74 possess a high density of exposed M2+... Such bare metal sites are the preferred location for adsorption of CO2 molecules at lower pressures. ... Moreover, such unsaturated sites can be occupied by amines via coordination for improving the adsorption capabilities.”
- **Functionalization of narrow-pore Mg-MOF-74 with bulky amines reduces physisorptive CO2 uptake substantially (reported ~50–60% lower uptake at 15 kPa) relative to the bare material because chemisorption occupies metal sites and bulky grafts reduce available void fraction.**  
  - Task: `co2`; confidence: `high`
  - Implication: When functionalizing narrow-pore MOF-74 expect diminished physisorptive capacity from site occupation and steric blocking—consider expanded frameworks or partial functionalization to retain capacity.
  - Evidence: “At 15 kPa, the adsorption capacity of Mg-MOF-74 is 5.7 mmol·g−1... The adsorption uptake for the functionalized Mg-MOF-74 structures decreases about 50–60% at this condition, mostly due to lower interactions between CO2 molecules and the highly attractive metallic centers... saturation is reached at lower pressure due to the reduction of the available void fraction in the amine-containing frameworks.”
- **Open-metal identity (Mg vs Zn) strongly influences CO2 binding strength and regenerability: Mg provides stronger adsorption and higher selectivity but increases regeneration difficulty; Zn weakens binding (reducing isotherm steepness) and can improve regenerability at expense of some affinity.**  
  - Task: `co2`; confidence: `high`
  - Implication: Select Zn (weaker-binding) when regenerability and low desorption energy are priorities; select Mg when maximizing affinity/selectivity is required and higher regeneration energy is acceptable—model the trade-off for the intended process.
  - Evidence: “most of the structures that have been experimentally explored use Magnesium as the open metal site... Therefore, stronger interactions are achieved but the regeneration will be more difficult... simulated structures using a less attractive metal, such as Zinc, were also performed... as it is expected that the steepness of the isotherms gradually diminish as the temperature increases in these materials.”
- **Amine identity and substitution pattern affect uptake order and accessibility: diamines with two active amine groups (e.g., en, mda) produced higher uptake than mmen, which in turn outperformed dmen in the simulations; larger/bulkier substituents reduce CO2 accessibility via steric hindrance.**  
  - Task: `co2`; confidence: `high`
  - Implication: Prefer diamines with two reactive amine groups for stronger interactions when capacity is primary objective, but consider methylated or less bulky amines (e.g., mmen) when easier desorption/regenerability is prioritized.
  - Evidence: “According to the results... the performance order for the adsorption uptake of the different studied amine functional groups was found to be –en, –mda > -mmen > -dmen. Two main reasons for this behavior are: -mda and –en have two active amine functional groups... The other reason is due to steric hindrance... since bigger and bulkier molecules reduce the CO2 accessibility.”
- **Temperature shifts the chemisorption isotherm step in amine-functionalized materials to higher pressures as temperature increases; this temperature dependence can be exploited to obtain large working capacities and high regenerability for TSA processes provided the binding strength is correctly tuned.**  
  - Task: `co2`; confidence: `high`
  - Implication: Choose amine/metal combinations such that the chemisorption isotherm step shifts into the desired pressure range at the intended adsorption and regeneration temperatures (e.g., regeneration around 373 K) to maximize working capacity while limiting regeneration energy.
  - Evidence: “In the functionalized ones, with the explicit chemisorption analyzed in this study, it is observed that as the temperature increases the position of the isotherm step shifts to higher pressures... allowing large working capacities and almost complete regenerability under specific conditions. However, using an adsorbent that binds CO2 too strongly would increase the temperature (energy) required to break the framework–CO2 interactions...”
- **Some heterodiamine-functionalized M-MOF-74 variants exhibit low cyclic working capacity because the heterodiamine reduces interaction strength with CO2; available void space left by appended amines and the specific amine chemistry are critical determinants of capture performance.**  
  - Task: `co2`; confidence: `medium`
  - Implication: Avoid heterodiamine grafts that are predicted or shown to reduce CO2–amine interaction strength when high cyclic working capacity is a requirement; always consider the void space remaining after grafting and test candidate amines experimentally or in simulation.
  - Evidence: “the left bottom section is mostly composed of the amine-functionalized M-MOF-74 structures, with a low cyclic working capacity due to reduced interactions between the heterodiamine and CO2.” | “Simulations have shown that the available void space left by the amine and the type of amine functional group plays a crucial role in achieving optimal CO2 capture properties...”
- **Literature-cited experimental studies demonstrate (a) water-enabled efficient CO2 capture in oxidation-resistant diamine-appended MOFs and (b) direct observation/quantification of CO2 binding modes in amine-functionalized nanoporous solids, indicating that water compatibility and site-specific characterization are material-dependent and experimentally resolvable.**  
  - Task: `co2`; confidence: `medium`
  - Implication: For wet/oxidative streams, prefer or screen oxidation-resistant diamine chemistries and perform spectroscopic/site-resolved characterization to confirm binding modes and stability under humid/oxidative conditions.
  - Evidence: “Water enables efficient CO2 capture from natural gas flue emissions in an oxidation-resistant diamine-appended metal–organic framework.” | “Direct observation and quantification of CO2 binding within an amine-functionalized nanoporous solid.”

## Extracted design rules

- **Prioritize expanded-linker DOBPDC (M2(dobpdc)) frameworks when planning to graft longer alkyl- or diamine functional groups to enable cooperative ammonium-carbamate chain formation and step-like CO2 uptake.**
  - IF: target application: post-combustion CO2 capture (low CO2 partial pressure, e.g., 5–15%), need cooperative/step-like uptake or to host longer/bulkier amines
  - THEN: prioritize M2(dobpdc) candidates with documented large pore diameters (~21 Å) and high surface area in screening, simulate or experimentally verify that the chosen diamine fits sterically and can form carbamate/ammonium chains, evaluate partial vs full functionalization cases to find practical achievable loading
  - Why: Expanded pores physically accommodate longer alkyl/diamine groups enabling cooperative chemisorption mechanisms producing step-like isotherms beneficial for low partial-pressure capture.
- **Do not assume maximizing amine grafting density improves CO2 performance—treat functionalization degree as an optimization variable and include partial-coverage cases in screening.**
  - IF: functionalization approach: grafting amines onto open metal sites of MOF-74 or DOBPDC, aim: improved CO2 capacity/selectivity and usable working capacity
  - THEN: simulate and/or test multiple functionalization degrees (partial to full) and select the degree that maximizes working capacity and selectivity, evaluate steric packing and accessible free volume after grafting (especially for bulky amines)
  - Why: Simulations show that more amine functional groups and/or full functionalization do not necessarily lead to better separation due to steric hindrances; partial functionalization often yields better performance.
- **Use alkyl substitution on appended amines (including small substituents like methyl) to tune cooperative adsorption step pressure and to moderate binding strength for improved regenerability, but validate steric and humidity effects.**
  - IF: material: DOBPDC or MOF-74 functionalized with substituted amines, goal: tune the pressure/temperature at which cooperative uptake occurs and/or reduce regeneration energy
  - THEN: simulate or experimentally measure isotherm shape and binding strength with candidate alkyl-substituted amines, select substitutions that shift the step pressure as desired while retaining chain formation and acceptable regenerability
  - Why: The paper reports that alkyl substitution shifts step-like adsorption isotherms and methylation (mmen) weakens Mg–carbamate interaction aiding desorption.
- **Tune metal identity (e.g., Mg vs Zn) according to the trade-off between affinity/selectivity and regenerability.**
  - IF: process requires low regeneration energy / facile TSA, high selectivity is needed but not at the expense of impractical regeneration energy
  - THEN: consider Zn (weaker-binding) when regenerability and lower desorption temperature are priority, consider Mg when maximal affinity/selectivity is required and higher regeneration energy is acceptable
  - Why: Mg open sites produce stronger CO2 interactions and higher selectivity but require higher desorption temperatures; Zn provides weaker binding and easier regeneration.
- **Preserve accessible void space after amine grafting: design pore size, linker placement, and amine chemistry so appended amines leave sufficient free volume for CO2 access and cooperative binding.**
  - IF: material has open metal sites and will be functionalized with appended amines, goal is high working capacity, selectivity, and regenerability in cyclic operation
  - THEN: model the post-grafting accessible void fraction and steric packing before synthesis, prefer expanded pores for bulky grafts, or adopt partial functionalization to retain pore volume, screen amine chemistries for balance of binding strength and steric footprint
  - Why: Simulations show that the available void space left by the amine and the amine type critically determine capture properties; excessive loading or bulky amines can block pores and reduce working capacity.
- **For wet/oxidative feed streams, prefer oxidation-resistant diamine chemistries and test CO2 uptake/stability under humid and oxidative conditions rather than relying on dry-lab performance.**
  - IF: feed gas contains significant water or oxidative species (e.g., natural-gas flue emissions), using diamine-appended MOFs for CO2 capture
  - THEN: select oxidation-resistant diamine chemistries and experimentally verify performance under humid/oxidative conditions, do not assume dry simulation/lab performance transfers to humid feeds without mitigation
  - Why: Referenced experiments show water can enable efficient CO2 capture in oxidation-resistant diamine-appended MOFs, but only if the chemistry tolerates oxidation/humidity.
- **When a candidate shows simulated working capacity ≳2.5–3 mmol·g−1 with a realistic regeneration swing (~60°C), advance it to process-level simulation and experimental validation, but explicitly include humidity and impurities in follow-up evaluations.**
  - IF: simulated working capacity ≥ ~2.5–3 mmol·g−1 with realistic regeneration swing (~60°C), initial evaluation based on GCMC/process-level simulation
  - THEN: advance material to detailed PSA/TSA process simulation, experimental isotherms under humid conditions, and cycling stability tests, validate assumptions used in screening (force fields, framework flexibility, presence of water/impurities)
  - Why: mda-Zn/DOBPDC was identified in simulations as being in the optimum range with ~2.9 mmol·g−1 and 60°C regeneration, indicating promising process-level performance but requiring validation.
- **Avoid heterodiamine grafts that simulation indicates reduce CO2–amine interaction strength when high cyclic working capacity is required; however, consider other benefits (e.g., moisture stability) before discarding candidates.**
  - IF: targeting high cyclic working capacity for CO2 in M-MOF-74 type materials, heterodiamine variants are under consideration
  - THEN: screen heterodiamine-functionalized variants for reduced interaction strength and low cyclic capacity; deprioritize for working-capacity-focused applications, if heterodiamines have other desirable properties (e.g., moisture tolerance), include further tests before exclusion
  - Why: Some heterodiamine-functionalized M-MOF-74 structures showed low cyclic working capacity due to reduced interactions with CO2 in the simulations.

## Contradiction notes

- **Affinity vs water sensitivity for amine-functionalized MOFs**: Designs using amine functionalization must explicitly address water/oxidative conditions (drying, pre-treatment, or selection of oxidation-resistant/humidity-tolerant amines) because dry-lab/simulation performance may not transfer to humid feeds.
  - Warning: Include humidity and oxidative stability in screening and validation for amine-functionalized MOFs; do not assume dry performance is representative of real flue/natural-gas streams.
- **Effect of amine functionalization depends on pore topology (MOF-74 vs DOBPDC)**: Net effect of amine functionalization depends on pore size/architecture and resulting available void fraction after grafting: narrow pores lose physisorptive capacity when occupied/blocked by amines, while expanded pores can accommodate amines and enable cooperative chemisorption without as large a loss of accessible volume.
  - Warning: Do not generalize functionalization effects across MOF families—simulate or experimentally verify for each framework topology, amine identity, and functionalization degree before down-selection.
- **Amine loading versus performance (quantity vs identity/void space)**: Performance is a function of both amine quantity and amine type/sterics—optimal loading must be identified per material and application rather than assumed maximal.
  - Warning: When prioritizing candidates, evaluate amine identity, steric effects, and resulting pore accessibility under intended cycles; screening should include varied loading levels.