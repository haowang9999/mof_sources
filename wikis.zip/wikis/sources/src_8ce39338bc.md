---
title: "Cisplatin uptake and release in pH sensitive zeolitic imidazole frameworks"
type: source
tags: [pld, source, paper]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_8ce39338bc]
confidence: medium
---


# Cisplatin uptake and release in pH sensitive zeolitic imidazole frameworks

## Metadata

- Source ID: `src_8ce39338bc`
- Raw file: `raw_sources/inbox/244703_1_online.pdf`
- Primary task: `pld`
- Task tags: pld
- Auto-classification confidence: `high`
- Auto-classification reason: The paper focuses on cisplatin uptake/release in ZIFs and emphasizes pore-related design factors: pore volume, pore limiting diameters/window sizes, gate-opening/diffusion hindrance, and topology/functionalization effects on loading and release. It uses these pore properties to explain and control drug diffusion and release (including pH-triggered degradation), so the paper is primarily relevant to PLD/pore-structure design for MOF performance. There is no substantive discussion of CO2 or H2 adsorption.
- Authors: Megan J. Thompson, Stephen A. Wells, Tina Düren
- Year: 2021
- Journal: J. Chem. Phys.
- DOI: 10.1063/5.0046054
- Material families: ZIFs (zeolitic imidazolate frameworks), UiO-66 family (UiO-66, UiO-66(NH2), UiO-67, UiO-68), MOFs (general)
- Methods: GCMC (grand-canonical Monte Carlo), MD (molecular dynamics, equilibrium and non-equilibrium / SMD), umbrella sampling (PMF), Bennett Acceptance Ratio (BAR) alchemical free energy, GASP (flexibility window analysis), ab initio static energy calculations, PoreBlazer pore analysis
- Gas targets: 

## Extracted mechanism claims

- **Maximum cisplatin uptake is predominantly governed by the framework's accessible pore volume (geometric capacity).**  
  - Task: `pld`; confidence: `high`
  - Implication: To maximize theoretical loading capacity for cisplatin, prioritize frameworks with large accessible pore volumes (but verify host–guest chemistry and solvent effects as they can reduce realized uptake).
  - Evidence: Pure-component GCMC simulations show that the maximum cisplatin loading depends on the pore volume. (Pages/abstract: multiple references across the manuscript: nGCMC predicts large loadings for frameworks with large pore volumes.)
- **In the presence of water, achieving the theoretical maximum loading requires either pores large enough to accommodate cisplatin plus its solvation shell (wider cavities, cited as >~8 Å for octahedral cavities) or MOF–cisplatin interactions that are more favorable than cisplatin–solvation interactions.**  
  - Task: `pld`; confidence: `high`
  - Implication: When loading from aqueous solution, ensure pore cavities/windows accommodate the drug+solvation shell (prefer wider cavities) or engineer stronger adsorption sites to outcompete solvation.
  - Evidence: To achieve this maximum loading in the presence of water, either the pore size needs to be large enough to occupy both cisplatin and its solvation shell or the MOF–cisplatin interaction must be more favorable than the cisplatin–shell interaction. The authors also note wider cavities (>8 Å) are beneficial because tetrahedral pores (~8 Å) are too small to accommodate cisplatin plus its solvation shell.
- **Pure-component (dry) GCMC predicts a theoretical maximum loading (nGCMC) but experimental encapsulation from solution can be much lower (examples: ~10× lower for UiO-66/UiO-66(NH2)) because cisplatin thermodynamically favors its solvation shell over occupying an empty framework.**  
  - Task: `pld`; confidence: `high`
  - Implication: Use dry GCMC as a computationally efficient upper-bound screening metric but follow up with solvent-explicit free-energy methods (e.g., BAR) or experiments because solvent competition can drastically reduce realized uptake.
  - Evidence: The maximum uptake of cisplatin in UiO-66 and UiO-66(NH2) using pure-component GCMC simulations is 0.67:1 and 0.50:1 CPT:Zr, respectively... experimental loading via encapsulation yields uptakes of 0.06:1 CPT:Zr in both UiO-66 and UiO-66(NH2) (which is tenfold lower than nGCMC). Bennett’s acceptance ratio simulations show cisplatin favors its solvation shell to an empty framework.
- **Presence of water considerably slows absolute cisplatin diffusion, but the relative ranking of diffusivities across frameworks is preserved; moreover, non-solvated non-bonded (SMD) diffusion energy barriers correlate strongly with solvated diffusivities, so non-solvated SMD barriers can serve as semi-quantitative proxies for screening relative release rates.**  
  - Task: `pld`; confidence: `high`
  - Implication: For high-throughput comparative screening, compute non-solvated SMD (or PMF) diffusion energy barriers to rank candidates; reserve solvent-explicit MD for top candidates when absolute rate estimates are needed.
  - Evidence: While the presence of water considerably slows down diffusion, the ranking of the diffusivities remains the same regardless of the presence of water. The non-bonded MOF–CPT diffusion energy barriers of cisplatin movement through each non-solvated UiO framework using SMD simulations is strongly correlated with the cisplatin diffusivities calculated in solvated frameworks.
- **Cisplatin release (inter-pore diffusion) can be slowed either by decreasing pore-limiting diameters (increasing the pore-hop / gate-opening energy barrier) or by creating strong, spatially distributed adsorption sites (increasing non-bonded interaction energy barriers); however, narrowing windows hinders uptake from solution, so when post-synthesis encapsulation is required, enhancing MOF–drug adsorption is preferable.**  
  - Task: `pld`; confidence: `high`
  - Implication: If loading is performed from solution into a pre-synthesized framework, favor engineering strong adsorption sites (functionalization) rather than simply narrowing windows. If in-situ encapsulation is feasible, narrow windows can be used to trap drug until a triggered degradation event releases it.
  - Evidence: Both solvated and non-solvated simulations show that cisplatin release rates can be controlled by either decreasing the pore limiting diameters or by manipulating framework–cisplatin interaction energies to create strong, dispersed adsorption sites. The latter method is preferable if cisplatin loading is performed from solution into a pre-synthesized framework as weak interaction energies and small pore window diameters will hinder cisplatin uptake.
- **If cisplatin is encapsulated during framework crystallization (in situ), frameworks with pore windows smaller than the drug (example: ZIF-11) can trap the drug such that release is governed by pH-triggered framework degradation rather than diffusion.**  
  - Task: `pld`; confidence: `medium`
  - Implication: When in situ encapsulation is feasible, selecting frameworks with pore windows smaller than the guest can enable depot-style retention until triggered (e.g., pH) release.
  - Evidence: If it is possible to load cisplatin during crystallization, ZIF-11 would outcompete other MOFs screened as cisplatin cannot pass through its pore windows; therefore, release rates would be purely driven by the pH triggered framework degradation.
- **Gate-opening/flexible-window behavior (e.g., ZIF-8) can present energetic barriers to cisplatin diffusion because nominal pore-window diameters (reported ~3.4 Å for ZIF-8; ZIF-11 reported ~3 Å in parts of the text) are small compared to the quoted cisplatin size (~5 Å), so diffusion requires ligand rotation / gate opening and incurs an energetic cost.**  
  - Task: `pld`; confidence: `medium`
  - Implication: For flexible-window ZIFs anticipate gate-opening barriers for large drug molecules; consider larger-window frameworks, functionalization to create adsorption hotspots, or in situ encapsulation strategies.
  - Evidence: The pore window diameter of ZIF-8 (∼3.4 Å) is comparable to the size of cisplatin (∼5 Å); thus, CPT diffusion will be substantially hindered by gate-opening energetic barriers. The largest pore-window size in ZIF-11 is reported as ∼3 Å and ligand rotation can provide an example of diffusion hindrance due to framework displacement.
- **Helmholtz total free-energy barriers for cisplatin pore-to-pore diffusion in UiO-66 and UiO-66(NH2) (umbrella sampling) are modest (~22 kJ/mol) and are dominated by bonded (framework deformation) energy contributions; nevertheless, bonded potential-energy contributions evaluated via SMD show large numerical differences influenced by functionalization (SMD bonded barriers reported as ~406 kJ/mol for UiO-66 vs ~184 kJ/mol for UiO-66(NH2)).**  
  - Task: `pld`; confidence: `medium`
  - Implication: Evaluate bonded deformation contributions and how functionalization alters them when engineering frameworks for controlled diffusion; polar/flexible linkers can lower bonded barriers but may also affect host–guest interactions.
  - Evidence: The calculated Helmholtz total free energy barriers are ΔAumbrella = 22 kJ/mol for UiO-66 and UiO-66(NH2), dominated by bonded energies. The SMD bonded potential energy barrier was higher in UiO-66 (ΔUbonded,SMD = 406 kJ/mol) compared to UiO-66(NH2) (ΔUbonded,SMD = 184 kJ/mol), consistent with polar functionalization lowering ligand-rotation barriers.
- **Framework flexibility analysis (GASP) indicates the deformations required for cisplatin passage lie within the flexibility window for UiO-66 variants, so guest passage does not require covalent bond breaking (though it may incur energetic cost).**  
  - Task: `pld`; confidence: `high`
  - Implication: Use flexibility-window analysis (GASP) to ensure the required pore-window deformations for guest passage are feasible without bond rupture; if deformations exceed the window, passage may be impossible without chemical change.
  - Evidence: The extent of deformation from SMD simulations was found to be within the flexibility window of both UiO-66 and UiO-66(NH2), meaning cisplatin can move through the pore windows without breaking framework bonds.
- **Pore-access chemistry (hydrophobic vs polar) modulates uptake: hydrophobic frameworks like ZIF-8 can have large pore volumes but weak MOF–cisplatin interactions that favor cisplatin remaining in bulk water, and small pore windows that impose high bonded diffusion barriers hindering encapsulation from solution.**  
  - Task: `pld`; confidence: `high`
  - Implication: Do not rely solely on pore volume; ensure pore surface chemistry affords favorable interactions for uptake from solution and that windows are accessible for the intended encapsulation route.
  - Evidence: ZIF-8 exhibits the second-highest loading attributed to its large pore volume. However, ZIF-8’s weak interaction energies with cisplatin (hydrophobic nature) mean cisplatin favors bulk water, and its small pore windows create high bonded diffusion barriers that hinder uptake from solution.
- **Among screened ZIFs, ZIF-82 is highlighted as promising because it combines large pore volume with polar groups that create dispersed adsorption hotspots (anchoring cisplatin), whereas ZIF-11 offers strong retention via small windows but blocks encapsulation and ZIF-70 has fewer polar groups leading to weaker interactions and faster release.**  
  - Task: `pld`; confidence: `high`
  - Implication: Prefer frameworks that combine large pore volumes with polar adsorption hotspots (e.g., ZIF-82) to balance high uptake and retention while retaining post-synthesis encapsulation capability; avoid bottleneck-window designs unless in situ encapsulation is planned.
  - Evidence: ZIF-82, 70, and 11 exhibit good uptake due to large pore volumes and large diffusion energy barriers. However, if encapsulation is from solution into a pre-synthesized framework, ZIF-11 would be omitted because cisplatin cannot enter without breaking bonds. ZIF-82 also has polar groups creating adsorption hotspots, making it promising for encapsulation.
- **Non-bonded energy barriers quantify how dispersed adsorption hotspots impede inter-site movement; bonded energy barriers quantify the framework-deformation cost and whether passage is feasible without bond breaking—both should be considered to understand and engineer release behavior.**  
  - Task: `pld`; confidence: `high`
  - Implication: When designing carriers, evaluate both non-bonded (adsorption hotspot distribution) and bonded (framework deformation) contributions to diffusion barriers to choose appropriate geometric and chemical strategies for retention and uptake.
  - Evidence: Non-bonded energy barriers provide a measure for the distribution of adsorption hotspots and hence the difficulty for cisplatin to pass between them. Bonded potential energy barriers can be used to determine whether cisplatin can physically pass through the MOF without breaking framework bonds.

## Extracted design rules

- **Ensure sufficient pore volume or stronger host–guest interactions to maximize drug loading in aqueous environments.**
  - IF: Loading from solution (aqueous), Guest retains a solvation shell (e.g., cisplatin)
  - THEN: Select frameworks with pore cavities/windows large enough to accommodate drug plus solvation shell (prefer octahedral/wider pores >~8 Å where cited), Or functionalize the framework to increase MOF–drug interaction energy (create dispersed adsorption hotspots)
  - Why: Either physical space for the solvated species or favorable host–guest energetics is needed to overcome solvation and achieve loading close to dry-GCMC maxima.
- **Control release rates through geometric gating or adsorption-site engineering; prefer adsorption-site engineering when post-synthesis encapsulation from solution is required.**
  - IF: Objective == slow_release (increase retention), Encapsulation method == loading from solution into pre-synthesized framework
  - THEN: Prefer increasing framework–drug non-bonded interaction energies (introduce polar functional groups/adsorption hotspots) over narrowing pore windows when uptake must occur post-synthesis, If in situ encapsulation is feasible, small pore windows may be used to create depot-like retention until triggered release
  - Why: Small windows hinder diffusion but also hinder uptake from solution; strong adsorption sites can retain drug while still permitting uptake if windows allow.
- **When screening many candidates for relative release/diffusivity, compute non-solvated non-bonded diffusion energy barriers (SMD) as an efficient semi-quantitative proxy and defer explicit-solvent MD to shortlisted candidates; use GCMC (without water) to estimate upper-bound capacity but validate promising hits with solvent-explicit methods.**
  - IF: Need relative ranking across many materials, Computational resources limited
  - THEN: Run pure-component GCMC without water for initial maximum-capacity screening, Run SMD or PMF in non-solvated frameworks to obtain diffusion energy barriers for ranking, Perform solvated MD and free-energy (e.g., BAR) calculations on top candidates for absolute uptake and rate estimates
  - Why: Non-bonded SMD barriers in non-solvated frameworks correlate with solvated diffusivities and dry GCMC captures theoretical maxima; solvent slows diffusion but preserves ranking.
- **If pore-window traversal requires framework deformation, evaluate bonded deformation energy barriers and the flexibility window to ensure passage is feasible without breaking bonds.**
  - IF: Guest size comparable to pore-window limiting dimensions, Diffusion path requires ligand rotation or framework deformation
  - THEN: Compute bonded and non-bonded contributions to diffusion barriers (SMD/umbrella sampling and energy decomposition), Run GASP to determine flexibility window and compare the required deformation extent to it
  - Why: Helmholtz barriers were dominated by bonded energies in UiO-66 variants; deformation from SMD was within the flexibility window indicating passage without bond breakage but with energetic cost.
- **If functionalization reduces bonded deformation barriers (e.g., polar ligands), consider linker functionalization to facilitate diffusion but evaluate trade-offs with host–guest binding and stability.**
  - IF: Bonded deformation contributes significantly to diffusion barrier, Functionalization will not introduce undesired trapping via strong host–guest interactions
  - THEN: Consider polar or flexible linker functionalization (e.g., -NH2) to lower bonded barriers, Evaluate whether functional groups increase adsorption too much or alter pH-sensitivity/stability
  - Why: UiO-66(NH2) showed lower SMD bonded potential energy barrier than UiO-66, consistent with polar ligands lowering rotation/deformation barriers.
- **If designing depot-style pH-triggered delivery and in situ encapsulation is possible, choose pH-sensitive frameworks with windows smaller than the drug to trap payload until degradation at the target pH.**
  - IF: Loading occurs during crystal formation (in situ encapsulation), Framework is pH-sensitive and degrades at target environment (e.g., acidic tumor pH)
  - THEN: Select frameworks whose pore windows are smaller than the drug to prevent diffusive escape, Rely on pH-triggered framework degradation to enable targeted release
  - Why: Small windows prevent diffusive escape; pH-triggered degradation then enables targeted release in acidic tumor environments (example: ZIF-11 discussed).

## Contradiction notes

- **Including solvent in screening vs. omitting solvent**: Use dry GCMC for rapid initial screening (upper-bound capacity). Follow up promising candidates with solvent-explicit MD/BAR to confirm that solvation does not prevent practical loading; treat dry-GCMC numbers as upper bounds, not guaranteed realized loadings.
  - Warning: Do not assume nGCMC maxima will be achieved experimentally; validate top candidates with explicit-solvent simulations or experiments.
- **Pore-window size numeric comparisons and flexibility (ZIF-8 vs ZIF-11)**: Both statements emphasize that these ZIFs have nominally small windows relative to the quoted cisplatin size and that framework flexibility (ligand rotation/gate opening) affects diffusion. Numeric values reported in different parts of the manuscript are close but may stem from differing definitions or contexts; users should verify experimental or high-resolution computational pore-window measurements for candidates.
  - Warning: Do not rely solely on single quoted numeric window diameters; consider framework flexibility, solvation, host–guest energetics, and measurement/definition differences. Verify pore-window values and dynamic behavior for candidate frameworks before design decisions.