---
title: "Computational screening and functional tuning of chemically stable metal organic frameworks for I2/CH3I capture in humid environments"
type: source
tags: [pld, source, paper]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_fc58db74fa]
confidence: medium
---


# Computational screening and functional tuning of chemically stable metal organic frameworks for I2/CH3I capture in humid environments

## Metadata

- Source ID: `src_fc58db74fa`
- Raw file: `raw_sources/inbox/main.pdf`
- Primary task: `pld`
- Task tags: pld
- Auto-classification confidence: `high`
- Auto-classification reason: The paper focuses on adsorption of I2 and CH3I in humid environments using computational screening, but its core contributions are structure-property relationships tied to pore metrics (PLD, LCD, void fraction, surface area, pore volume) and functional tuning of a MOF (MIL-53-Al). It uses GCMC and DFT to link pore topology/size and hydrophilicity to uptake/selectivity, so pore/PLD/topology design is the best single-fit task. The work is about iodine (not CO2 or H2), so co2/h2 labels are not applicable.
- Authors: Haoyi Tan, Guangcun Shan
- Year: 2024
- Journal: iScience
- DOI: 10.1016/j.isci.2024.109096
- Material families: metal-organic frameworks (MOFs), MIL-53-Al, functionalized MIL-53-Al (MIL-53-Al-X), MIL-53-Al-ht (high-temperature phase), UiO-66 (examples cited), other screened chemically stable MOFs (e.g., Zn(1,3-BDP), JUC-110 mentioned as examples)
- Methods: grand canonical Monte Carlo (GCMC) simulations (RASPA), density functional theory (DFT; VASP with PBE + D3(BJ)), Zeo++ pore analysis (PLD, LCD, void fraction, etc.), force-field modelling (UFF, TIP3P, explicit all-atom models for CH3I), density-derived electrostatic charges (DDEC) for atomic charges, DFT binding-energy calculations
- Gas targets: I2, CH3I, H2O, N2, O2

## Extracted mechanism claims

- **Pore limiting diameter (PLD) smaller than the kinetic diameter of CH3I (4.23 Å) prevents CH3I adsorption; PLD therefore acts as a size-exclusion filter for CH3I.**  
  - Task: `pld`; confidence: `high`
  - Implication: When designing or selecting MOFs to capture CH3I under the studied conditions (423 K, 1 bar, humid mixed gas), ensure the PLD is at least ~4.23 Å (the kinetic diameter of CH3I) to permit pore access; otherwise exclude the material by size or consider pore-expanding modifications.
  - Evidence: “for certain selected MOFs (e.g., UiO-66, UiO-66-NH2, JUC-110, etc.), the PLD was smaller than the kinetic diameter of CH3I molecules (4.23 Å), rendering them unsuitable for evaluating CH3I adsorption performance.”
- **Geometric pore metrics (LCD, void fraction, surface area, pore volume) correlate with I2 and CH3I uptake across the screened MOFs; empirically identified optimal ranges for higher uptake were LCD ≈ 7.1 Å, void fraction 0.3–0.7, surface area 450–2230 m2/g, and pore volume 0.2–0.9 cm3/g.**  
  - Task: `pld`; confidence: `medium`
  - Implication: Target MOFs with LCD ≈ 7 Å, moderate void fraction (0.3–0.7), and moderate-to-high surface area and pore volume within the stated ranges to maximize I2/CH3I uptake under the simulated humid conditions, while also checking hydrophilicity (see separate rule).
  - Evidence: “For I2 and CH3I adsorption, Figures 1A and 1B showed that the optimal LCD and void fraction were around 7.1 Å and at the range of 0.3–0.7, respectively; Figures 1C and 1D indicated that the optimal surface area and pore volume were at the range of 450–2230 m2/g and 0.2–0.9 cm3/g, respectively.”
- **Largest cavity diameter (LCD) exerts a stronger influence than other single geometric factors on iodine adsorption by controlling constricted porosity and the compactness of MOF–iodine interactions.**  
  - Task: `pld`; confidence: `medium`
  - Implication: Prioritize tuning LCD (pore cavity size) when engineering MOFs for iodine capture, as LCD more directly alters interaction strength and effective porosity than some other single metrics.
  - Evidence: “...LCD exhibited more obvious and greater impact on adsorption performance, by causing the constricted porosity and compact interaction between the MOFs and iodine molecules.”
- **Hydrophilicity (as quantified by isosteric heat Qst of H2O) can override pore-metric benefits: high Qst(H2O) leads to competitive adsorption with I2 and reduces I2 uptake/selectivity even when other pore metrics are favorable.**  
  - Task: `pld`; confidence: `medium`
  - Implication: Even if pore metrics (LCD, PLD, surface area) are within optimal ranges, ensure low affinity for water (low Qst(H2O)) for I2 capture in humid conditions; otherwise hydrophilicity can negate structural advantages.
  - Evidence: “The reason might lie in its high Qst of H2O (34.8 kJ/mol), which led to the more drastic competitive adsorption between the H2O and I2 and therefore reduced I2 selectivity... Conversely, Zn(1,3-BDP) and MIL-53-Al with the lowest Qst of H2O of 16.5 kJ/mol and 13.6 kJ/mol, exhibited the top-two I2 uptake amounts and selectivity. Consequently, it could be concluded that the Qst of H2O had a significant impact on I2 adsorption due to competitive adsorption in MOFs.”
- **Pore volume is a major determining factor for I2 uptake within the functionalized MIL-53-Al (MIL-53-Al-X) series; moderate changes in isosteric heat of I2 (Qst) influenced selectivity but had a relatively minor effect on absolute I2 uptake compared with pore-volume/steric effects.**  
  - Task: `pld`; confidence: `high`
  - Implication: For high I2 uptake in MIL-53-Al-type materials under humid competitive conditions, prioritize preserving or increasing pore volume when functionalizing because pore-volume/steric constraints can dominate over modest increases in binding energy.
  - Evidence: “Figure 4A illustrated that the pore volumes (0.37–0.62 cm3/g) were a major determining factor, whereas the Qst of I2 (59.4–71.9 kJ/mol) played a relatively minor role in influencing I2 uptake. For instance, MIL-53-Al-Cl and MIL-53-Al-Br ... their small pore volumes (0.463 cm3/g and 0.369 cm3/g) resulted in the lower I2 adsorption amounts of 44.96 cm3/g and 36.72 cm3/g, respectively. Conversely, MIL-53-Al-NH2 and MIL-53-Al-CH3 with relatively large pore volumes (0.509 cm3/g and 0.470 cm3/g) exhibited the top-two I2 uptake amounts of 50.65 cm3/g and 49.74 cm3/g, respectively.”
- **Introducing polar functional groups increases iodine (I2 and CH3I) adsorption selectivity by raising affinity (Qst), but often reduces pore volume; the pore-volume reduction particularly reduces I2 uptake while having a smaller effect on CH3I uptake.**  
  - Task: `pld`; confidence: `medium`
  - Implication: When tuning MIL-53-Al for iodine capture under humid conditions, use polar functional groups to raise selectivity/affinity but monitor and limit pore-volume loss; for I2 maximize pore volume retention, while for CH3I prioritize increasing affinity since uptake is affinity-driven in this series.
  - Evidence: “the functionalization of the polarized functional groups did enhance the I2 selectivity (except the MIL-53-Al-PYDC), but the I2 adsorption amounts did not have the obvious enhancement. ... it was attributed to the smaller pore volume and bigger steric hindrance that limited the I2 uptake in functionalized MIL-53-Al-X series, despite the enhanced the I2 selectivity. ... The introduction of polar functional groups proved to substantially enhance the iodine adsorption selectivity by promoting the adsorption affinity. However, this enhancement came at the cost of reduced pore volume, particularly affecting the uptake capacity for I2 adsorption. ... hydrophilicity had a more pronounced impact on I2 adsorption behaviors compared to CH3I.”
- **CH3I uptake and selectivity in the MIL-53-Al-X series are positively correlated with the isosteric heat of adsorption (Qst) for CH3I; affinity (Qst) is the dominant factor for CH3I uptake and small reductions in pore volume from functionalization have negligible impact.**  
  - Task: `pld`; confidence: `high`
  - Implication: To maximize CH3I capture in MIL-53-Al-type materials under humid competitive conditions, focus on surface functionalization that increases CH3I binding energy (Qst), since affinity more strongly determines CH3I uptake than modest pore-volume loss in the studied series.
  - Evidence: “the CH3I uptake amounts and selectivity were positively correlated with the Qst of CH3I, indicating the affinity for CH3I played a major role in CH3I uptake in MIL-53-Al-X series. The impact of the functionalization-induced reduction in pore volume was nearly negligible (Figure S5). MIL-53-Al-CH3, exhibiting the highest Qst for CH3I of 71.95 kJ/mol, achieved the highest CH3I uptake amount of 2.8 cm3/g, which was more than twice that of the pristine MIL-53-Al (1.19 cm3/g); followed by the MIL-53-Al-NH2 with the CH3I uptake amount of 1.81 cm3/g.”
- **Adsorption site preference differs by species: I2 and CH3I preferentially occupy the center of the pore channel (or slightly off-center), while H2O preferentially binds near Al clusters and framework backbones via hydrogen bonding; this spatial partitioning affects competitive uptake under humid conditions.**  
  - Task: `pld`; confidence: `medium`
  - Implication: Design pore channels with central cavities favorable to large iodine species while controlling hydrophilic sites (e.g., Al-coordinated hydroxyls) to limit water binding at critical adsorption positions; consider functional groups that steer large adsorbates to channel center while keeping water at less competitive locations.
  - Evidence: “It could be observed that the I2 and CH3I molecules were primarily concentrated near the center of pore channels, whereas the H2O molecules were mainly located near the backbones of the framework. ... DFT calculations ... The optimal adsorption positions for I2 (65.90 kJ/mol) and CH3I (47.86 kJ/mol) were slightly off-center from the channel; ... the adsorption situations for H2O were complex: Al clusters were the optimal adsorption sites with the highest binding energy of 40.52 kJ/mol, followed by the methyl (34.16 kJ/mol), the benzene ring (23.25 kJ/mol), and the center of the pore channel (12.45 kJ/mol). Importantly, the hydroxyl functional groups connected to Al clusters played a significant role in hydrogen bonding interactions to achieve a high binding energy.”
- **Pore geometry metrics (PLD, LCD) were computed using Zeo++ and used as structural descriptors for the MOFs in screening.**  
  - Task: `pld`; confidence: `high`
  - Implication: Use computed PLD and LCD (e.g., from Zeo++) as primary screening descriptors for candidate MOFs when considering molecular accessibility and pore-size-dependent adsorption.
  - Evidence: “The structure features of the aforementioned MOFs, including pore limiting diameter (PLD) and largest cavity diameter (LCD), were calculated using the open-source package Zeo++.49”
- **MIL-53-Al exhibits breathing/flexible pore phases; the high-temperature form (MIL-53-Al-ht) was used to represent 423 K screening conditions.**  
  - Task: `pld`; confidence: `high`
  - Implication: For breathing MOFs (e.g., MIL-53-Al), select the structural phase that corresponds to the operating temperature (here MIL-53-Al-ht for 423 K) when predicting adsorption — failure to do so may misrepresent the effective PLD and adsorption behavior.
  - Evidence: “Considering the well-known breathing effect of MIL-53-Al, whose pore size was tunable and could undergo great changes, the high temperature form of MIL-53-Al (MIL-53-Al-ht) was used to conform to the high temperature environment of 423 K.”
- **Guest molecular kinetic diameters and explicit molecular models were specified and used (I2: 3.34 Å spherical; CH3I: 4.23 Å all-atom; H2O: TIP3P 2.64 Å; N2: 3.04 Å; O2: 3.10 Å), informing size-accessibility and modeling.**  
  - Task: `pld`; confidence: `medium`
  - Implication: Compare guest kinetic diameters to MOF PLD/LCD when screening materials: molecules with kinetic diameters near or below PLD are likely accessible; larger molecules may be excluded or strongly size-constrained.
  - Evidence: “The guest I2 molecules had a kinetic diameter of 3.34 Å and were modeled as spherical... The CH3I molecules with a kinetic diameter of 4.23 Å were represented by an explicit all-atom model... The H2O molecules (kinetic diameter of 2.64 Å) were mimicked by the transferable intermolecular potential (TIP3P) model... Both N2 and O2 molecules (kinetic diameter of 3.04 Å and 3.10 Å, respectively) were modeled by a three-site model...”
- **Iodine selectivity (I2 or CH3I) in mixed-gas adsorption was computed using a ratio-based metric: (X_iodine/Y_iodine) / (X_others/Y_others), where X denotes uptake and Y denotes gas-phase concentration; competing components included N2, O2 and H2O.**  
  - Task: `mixed`; confidence: `high`
  - Implication: To increase iodine selectivity in a MOF under mixed-gas conditions, design or choose materials that maximize iodine uptake while minimizing uptake of competing components at relevant gas-phase concentrations.
  - Evidence: “In addition, the selectivity of I2 and CH3I during adsorption was calculated as the following equation: selectivity_iodine = (X_iodine/Y_iodine) / (X_others/Y_others) ... where X_iodine and Y_iodine denoted the uptake amounts and gas phase concentration of targeted gas iodine (I2 or CH3I)... X_others and Y_others were the uptake amounts and gas phase concentration of other gas components (N2, O2 and H2O).”
- **Electrostatic interactions were explicitly treated by computing MOF atomic charges using the DDEC method to better capture host–guest Coulombic contributions, important for polar or polarizable guests.**  
  - Task: `pld`; confidence: `high`
  - Implication: Include chemically meaningful atomic charges (e.g., DDEC) when modelling adsorption of polar or polarizable guests so electrostatic host–guest contributions to binding are captured.
  - Evidence: “to accurately address the electrostatic interaction, atomic charges of MOFs were computed using the high-quality density-derived electrostatic charges (DDECs) method.”
- **GCMC simulations treated MOF structures as rigid frameworks (periodic); supercells were applied when necessary to ensure system dimensions at least twice the nonbonded cutoff (12 Å), which neglects dynamic framework flexibility except via choosing representative phases.**  
  - Task: `pld`; confidence: `high`
  - Implication: When using rigid-framework GCMC, explicitly select the MOF structural phase representative of operating conditions (temperature/pressure) for flexible/breathing MOFs, or consider flexible-framework methods if breathing is expected to affect adsorption.
  - Evidence: “All the MOFs structures were treated as rigid frameworks with periodic boundaries; when necessary, supercells were applied to ensure the system size to be twice longer than the cutoff distance (12 Å ).”
- **DFT calculations (PBE + D3(BJ), VASP) were used to compute binding energies between MOF and guest molecules with binding energy defined as ΔE = E_coordinated − E_MOF − E_guest to quantify host–guest interaction strengths.**  
  - Task: `pld`; confidence: `high`
  - Implication: Use DFT binding energies (with dispersion corrections) to rank specific host–guest interactions and validate or refine force-field-based adsorption predictions from GCMC.
  - Evidence: “DFT calculations were carried out ... DFT-D3(BJ) dispersion corrections were included... the binding energy between the MOF and guest gas molecule was determined through the following equation: ΔE = E_coordinated − E_MOF − E_guest”
- **No explicit mechanism claims about CO2 adsorption are presented in the provided text; CO2 appears only in cited literature but not as a studied target in the methods described.**  
  - Task: `co2`; confidence: `high`
  - Implication: The provided text does not supply MOF-specific mechanistic guidance for CO2; do not infer CO2-specific rules from this paper without additional CO2-specific evidence.
  - Evidence: “The methods and guest models described list I2, CH3I, H2O, N2 and O2; CO2 is not included among the modeled guests in the METHOD DETAILS text (CO2 only appears in literature citations).”
- **No direct mechanism statements about H2 adsorption are made in the provided text; H2 is referenced in cited literature but not modeled or described in the METHOD DETAILS excerpt.**  
  - Task: `h2`; confidence: `high`
  - Implication: The provided excerpt does not provide mechanistic guidance for H2 adsorption — consult H2-specific literature or other sections of the paper for H2 mechanisms.
  - Evidence: “References to hydrogen storage in MOFs appear in the bibliography (e.g., references 36, 37), but the METHOD DETAILS describe guest models for I2, CH3I, H2O, N2 and O2 only.”

## Extracted design rules

- **Exclude MOF candidates whose PLD is smaller than the kinetic diameter of the target molecule (e.g., CH3I ≈ 4.23 Å) when aiming to adsorb that molecule.**
  - IF: target_molecule = CH3I, PLD < 4.23 Å
  - THEN: filter_out_candidate_from_CH3I_adsorption_set, or consider pore-expanding modifications or choose a different MOF
  - Why: A PLD smaller than the molecular kinetic diameter prevents the molecule from entering pore space, rendering adsorption negligible.
- **For humid-I2 (and CH3I) capture under the studied screening conditions, prefer MOFs with LCD ≈ 7 Å, moderate void fraction (0.3–0.7), surface area 450–2230 m2/g, and pore volume 0.2–0.9 cm3/g to maximize uptake, but screen for hydrophilicity concurrently.**
  - IF: operating_conditions = humid air, 423 K, 1 bar, target_molecule in {I2, CH3I}
  - THEN: prefer_candidates_with_LCD_around_7Å, prefer_void_fraction_between_0.3_and_0.7, prefer_surface_area_between_450_and_2230_m2_g, prefer_pore_volume_between_0.2_and_0.9_cm3_g, also_apply_hydrophilicity_filter (low Qst(H2O))
  - Why: Screening across a set of chemically stable MOFs found these pore-metric ranges correlated with higher I2/CH3I uptake; LCD in particular modulates constricted porosity and stronger host–guest interactions.
- **When designing MOFs for I2 capture in humid air, include hydrophobicity (low Qst(H2O)) as an explicit filter or design objective alongside pore metrics.**
  - IF: operating_conditions = humid air (high relative humidity), target_molecule = I2
  - THEN: prioritize materials with low isosteric heat of H2O adsorption (low Qst(H2O)), if candidate has high Qst(H2O), deprioritize even if pore metrics are optimal
  - Why: High affinity for water leads to competitive adsorption that reduces available sites for I2 and lowers I2 selectivity/uptake.
- **If the goal is to maximize I2 uptake in MIL-53-Al-type MOFs under humid competitive conditions, then prioritize preserving or increasing pore volume even when adding functionality, because pore-volume/steric capacity dominates I2 uptake relative to modest gains in binding energy.**
  - IF: material family: MIL-53-Al or similar narrow/medium pore MOFs, operating under humid competitive gas environment with H2O and other small gases, functionalization is being considered to improve selectivity
  - THEN: select functional groups and grafting strategies that minimize reduction in pore volume (avoid bulky linkers or dense pore-blocking groups), evaluate pore volume (Vp) quantitatively during design (target higher end of 0.37–0.62 cm3/g range or above if possible), prioritize retaining central pore cavity volume for large iodine species
  - Why: Simulations show pore volume correlates strongly with I2 uptake while changes in Qst within the studied range have lesser impact on uptake; small pores and steric hindrance reduce I2 capacity.
- **If the objective is to maximize CH3I uptake/selectivity in MIL-53-Al-type MOFs under humid competitive conditions, then introduce surface functionalities that increase CH3I binding affinity (Qst), because CH3I uptake is affinity-driven and modest pore-volume reduction is less detrimental.**
  - IF: material family: MIL-53-Al or similar, CH3I is the target contaminant in presence of humidity, modest pore volume reductions are acceptable
  - THEN: prioritize functional groups that increase CH3I binding energy (e.g., -CH3, -NH2 as tested), evaluate Qst for CH3I as a primary metric during screening, accept small reductions in pore volume if they lead to substantial Qst increases
  - Why: Simulations show CH3I uptake and selectivity correlate positively with Qst and that pore-volume reductions from functionalization had nearly negligible impact on CH3I uptake in the studied series.
- **If water (H2O) is present (humid conditions), then account for H2O preferential binding at Al-cluster/hydroxyl sites and design to avoid water occupying the central channel adsorption sites needed by large iodine species.**
  - IF: humid gas streams with competitive adsorption (H2O present), framework contains Al clusters and hydroxyls or other strong hydrogen-bond donors
  - THEN: consider limiting exposed hydrophilic sites in channel center or sequestering them away from central adsorption volume, use functionalization strategies that steer H2O to secondary sites while keeping central cavity available for I2/CH3I, simulate competitive adsorption density to verify spatial partitioning
  - Why: GCMC density plots and DFT show H2O prefers Al-cluster/backbone sites (high binding energies via hydrogen bonding), while I2/CH3I occupy channel center; water occupying key sites could reduce effective uptake or alter selectivity.
- **Use computed PLD/LCD (Zeo++) as primary filters for molecular-accessibility-based screening and compare against known guest kinetic diameters.**
  - IF: You have a target guest with known kinetic diameter, You have computed MOF PLD and LCD using Zeo++
  - THEN: Filter out MOFs whose PLD is clearly below the guest kinetic diameter (reduced accessibility), Prioritize MOFs with PLD comparable to or larger than the guest kinetic diameter for further adsorption simulation
  - Why: The study computes PLD and LCD as structure features and explicitly models guest kinetic diameters to represent molecular size for adsorption modelling.
- **For flexible/breathing MOFs, select the structural phase corresponding to the operating temperature prior to adsorption prediction (e.g., MIL-53-Al-ht for 423 K).**
  - IF: The MOF is known to exhibit breathing or polymorphic pore phases (e.g., MIL-53-Al), Operating temperature differs from ambient (e.g., high-temperature operation)
  - THEN: Use the structural phase representative of the operating temperature (e.g., MIL-53-Al-ht for 423 K) in simulations, If phase behavior under conditions is uncertain, consider flexible-framework simulation methods or experimental validation
  - Why: MIL-53-Al breathing causes large tunable changes in pore size; the authors explicitly used MIL-53-Al-ht to match 423 K conditions.
- **Include chemically meaningful atomic charges (e.g., DDEC) when modelling adsorption involving polar or polarizable guests.**
  - IF: The guest molecule is polar or has significant partial charges (e.g., H2O, CH3I all-atom model), Electrostatic host–guest interactions are expected to matter
  - THEN: Compute and assign high-quality atomic charges for the MOF (e.g., DDEC) prior to GCMC, Include Coulombic interactions in adsorption simulations
  - Why: The authors computed DDEC atomic charges 'to accurately address the electrostatic interaction' when performing adsorption simulations.
- **Use DFT binding energies (with dispersion corrections) to validate or rank specific host–guest affinities obtained from force-field GCMC.**
  - IF: You need quantitative ranking of specific adsorption sites or host–guest binding strengths, Force-field predictions require validation
  - THEN: Perform DFT (e.g., PBE + D3(BJ)) calculations of coordinated host–guest complexes and compute ΔE = E_coordinated − E_MOF − E_guest, Use DFT-derived rankings to refine selection of high-affinity candidates
  - Why: The study carried out DFT (PBE + D3(BJ)) and defined binding energy as ΔE = E_coordinated − E_MOF − E_guest to quantify host–guest interactions.
- **When using rigid-framework GCMC, ensure system-size choices (supercells) respect nonbonded cutoff distances (e.g., 12 Å) to avoid artifacts.**
  - IF: GCMC uses a finite nonbonded cutoff (e.g., 12 Å), Periodic boundary conditions are applied
  - THEN: Apply supercells so that system dimensions are at least twice the cutoff distance, Check that chosen supercell is compatible with computational cost constraints
  - Why: The authors applied supercells to ensure the system size was twice longer than the cutoff distance (12 Å) when necessary.

## Contradiction notes

- **CO2 and H2 adsorption data absence**: The provided study and evidence focus exclusively on I2, CH3I and competition with H2O/N2/O2 under the screening conditions; it does not provide data or mechanism statements for CO2 or H2.
  - Warning: Do not transfer these PLD/LCD rules or confidence levels to CO2 or H2 adsorption without additional evidence specific to those gases; screening/selection criteria may differ for different gas sizes, polarities and chemistries.
- **Affinity (Qst) vs pore-volume effects on iodine uptake/selectivity**: Affinity improvements (higher Qst) increase selectivity, but for large species like I2 the absolute uptake is strongly limited by available pore volume/steric space; for CH3I uptake within the MIL-53-Al-X series is more affinity-driven and less sensitive to modest pore-volume loss.
  - Warning: Do not assume that raising binding energy via heavy functionalization will increase capacity for large adsorbates; always evaluate pore-volume changes and competitive adsorption with water. Trade-offs differ between I2 and CH3I and depend on the specific MOF geometry and degree of pore blocking.