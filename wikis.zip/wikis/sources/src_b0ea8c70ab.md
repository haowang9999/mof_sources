---
title: "Framework Reduction and Alkali-Metal Doping of a Triply-Catenating Metal–Organic Framework Enhances and Then Diminishes H2 Uptake"
type: source
tags: [h2, source, paper]
created: "2026-05-02"
updated: "2026-05-02"
sources: [src_b0ea8c70ab]
confidence: medium
---


# Framework Reduction and Alkali-Metal Doping of a Triply-Catenating Metal–Organic Framework Enhances and Then Diminishes H2 Uptake

## Metadata

- Source ID: `src_b0ea8c70ab`
- Raw file: `raw_sources/inbox/framework-reduction-and-alkali-metal-doping-of-a-triply-catenating-metal-organic-framework-enhances-and-then-diminishes.pdf`
- Primary task: `h2`
- Task tags: h2, pld, mixed
- Auto-classification confidence: `high`
- Auto-classification reason: The paper's central focus is on H2 adsorption: measuring 77 K, 1 atm H2 uptakes, isosteric heats, and how chemical reduction/alkali-metal doping alters H2 storage. It also discusses pore-structure effects (triply catenated framework displacement creating pores) as a key mechanism, so pore/design (pld) is also relevant—hence inclusion of mixed.
- Authors: Mulfort et al.
- Year: 2009
- Journal: Langmuir
- DOI: 
- Material families: Zn2(NDC)2(diPyTz) triply interwoven (triply catenated) MOF (referred to as 1), partially reduced / alkali-metal-doped MOFs (Li+, Na+, K+; 1·M and higher-loading variants such as 1·Li*), triply interwoven (catenated) metal–organic frameworks (general)
- Methods: low-temperature H2 adsorption isotherms (measurements reported at 77 K and 87 K), N2 adsorption / BET and t-plot surface area and micropore analyses, isosteric heats (Qst) from virial fits to 77 and 87 K H2 isotherms, 1H NMR solvent quantification, ICP analysis, CW EPR, single-crystal XRD / PXRD / TGA, reference to computational studies in discussion
- Gas targets: H2, N2

## Extracted mechanism claims

- **Partial framework reduction followed by low-level alkali-metal (Li+, Na+, K+) doping of the triply interwoven MOF increases cryogenic H2 uptake (measured at 77 K and 87 K, 1 atm) relative to the undoped parent material; the largest enhancements occur at M/Zn ≈ 0.05–0.10.**  
  - Task: `h2`; confidence: `high`
  - Implication: Introduce substoichiometric reduction and low-level alkali-metal doping (target M/Zn ≈0.05–0.10) to increase gravimetric H2 uptake at cryogenic conditions in similar interpenetrated MOFs, while monitoring dopant level carefully to remain within the enhancement window.
  - Evidence: We find that improved adsorption performance for these materials is obtained at doping levels that are much lower than 1 cation per dipyridyl ligand; the greatest enhancements are found for M/Zn ≈0.05 to 0.10 ... H2 uptake by the three reduced materials, 1·M, considerably exceeds that for the neutral MOF. Partial framework reduction and doping of a triply interwoven MOF with lithium, sodium, or potassium cations enhance the cryogenic uptake of H2 by between 30 and 43% at 1 atm.
- **Increasing alkali-metal doping beyond the low M/Zn range (example: Li/Zn increased from ≈0.05 to 0.35) diminishes H2 uptake and reduces micropore-accessible surface area/micropore volume (e.g., 1·Li* has ~50% of the micropore volume and H2 uptake of 1).**  
  - Task: `h2`; confidence: `high`
  - Implication: Avoid over-doping; optimize alkali-metal loading (target M/Zn ≈0.05–0.10) because higher dopant concentrations can reduce micropore volume and H2 uptake (monitor micropore volume/BET during tuning).
  - Evidence: Further doping (which was not explored in detail) leads to less effective H2 uptake. (For example, increasing Li/Zn from 0.05 to 0.35 caused the H2 loading at 77 K and 1 atm to drop by ca. (relatively) 50%; see Table 2 and Supporting Information.) Notably, the micropore volume for 1·Li* is about half that of 1, as is the H2 uptake at 1 atm.
- **Isosteric heats of adsorption (Qst) for H2 are very similar between the undoped and doped frameworks over the measured loading range (from fits to 77 and 87 K isotherms), indicating that enhanced uptake is not due to stronger H2 binding at dopant cation sites.**  
  - Task: `h2`; confidence: `medium`
  - Implication: Do not assume that alkali-metal doping of reducible ligands in catenated MOFs will increase H2 binding energy; enhanced uptake may arise from structural/porosity changes rather than stronger site-specific binding.
  - Evidence: Values were obtained by fitting a virial-type equation to the 77 and 87 K H2 adsorption isotherms... the more striking observation (Figure 4) is just how closely isosteric heats agree for 1, 1·Li, 1·Na, and 1·K over the entire range of H2 pressures examined. We conclude from the above that direct hydrogen/dopant-cation interactions are not responsible for the enhanced H2 uptake illustrated in Figure 3.
- **The added alkali-metal cations are likely inaccessible to H2 (not acting as exposed strong binding sites); 1H NMR solvent quantification rules out extensive cation solvation, so cations are inferred to be localized near carboxylates and shielded by framework interpenetration or otherwise inaccessible.**  
  - Task: `mixed`; confidence: `medium`
  - Implication: When doping interpenetrated MOFs, check cation accessibility—if cations are localized/shielded, do not expect direct cation–H2 coordination; instead, focus on structural effects (e.g., displacement/interpenetration changes) to improve uptake.
  - Evidence: we infer that the added metal ions are simply inaccessible to hydrogen. Two scenarios can be envisioned: (1) dopant cations localized near negatively charged carboxylates which effectively shielded them from gas exposure on account of framework interpenetration or (2) dopant cations strongly solvated (by DMF or THF molecules). To test the second idea, we determined the post evacuation solvent content of the 1·M materials via 1H NMR... the residual solvent content is independent of lithium cation loading, indicating that not-quite-complete framework evacuation rather than the solvation of dopant ions accounts for the small amount of solvent found. We can therefore rule out cation solvation as a factor in the adsorption performance ...
- **Alkali-metal doping correlates with increased BET surface area and (in most analyses) increased micropore-accessible surface area; the ordering of BET areas (1 < 1·Li < 1·K < 1·Na) matches the ordering for hydrogen adsorption, supporting a pore-structure (increased internal surface area via displacement of interwoven networks) mechanism for enhanced uptake.**  
  - Task: `pld`; confidence: `high`
  - Implication: Use controlled low-level alkali-metal doping to alter interpenetrated MOF packing and increase accessible surface area (BET/micropore) as a viable route to improve cryogenic H2 uptake; monitor N2-accessible metrics to support the attribution.
  - Evidence: As shown in Table 2, the BET surface areas for the various 1·M materials significantly exceed those for the undoped parent material. Furthermore, the ordering of surface areas (1 < 1·Li < 1·K < 1·Na) matches the ordering for hydrogen adsorption. Nitrogen isotherms suggest that the key role of dopant cations and/or partial framework reduction in improving hydrogen uptake instead is to enhance the microporous surface area, presumably by facilitating the displacement of interwoven networks.
- **Empirically, the increases in H2 uptake observed upon doping correspond to as many as ~13 hydrogen molecules per added alkali cation under the cryogenic, 1 atm conditions studied.**  
  - Task: `h2`; confidence: `high`
  - Implication: When quantifying the effect of alkali-metal doping, report uptake both per unit mass and per dopant ion; expect up to ~13 H2 molecules associated (empirically) with each added cation in these materials under cryogenic, 1 atm conditions, but interpret cautiously given cation inaccessibility inference.
  - Evidence: The increases correspond to the uptake of as many as 13 hydrogen molecules per added cation.
- **Prior computational studies predict that if dopant ions can be made directly accessible to H2 (i.e., not shielded by catenation), MOF H2 binding and heats of adsorption could increase dramatically (e.g., up to ~500% uptake at ambient temperature/high pressure and several kJ/mol in Qst); realizing such gains likely requires single (non-catenated) permanently microporous networks that expose dopant ions.**  
  - Task: `h2|pld|mixed`; confidence: `medium`
  - Implication: To achieve large H2 binding enhancements and increased heats of adsorption at ambient/high-pressure conditions, design MOFs that expose dopant ions (e.g., single, non-catenated permanently microporous networks) rather than catenated frameworks that shield dopants.
  - Evidence: Recent computational studies suggest that MOF binding of H2 can be increased by as much as 500% at ambient temperature and high pressure and that heats of adsorption can be increased by several kJ/mol, provided that direct interaction of dopant ions with hydrogen can be achieved. In efforts toward direct dopant-H2 interaction, current work is focused on reducing and characterizing permanently microporous MOF materials comprising single rather than multiple (i.e., catenated) networks.

## Extracted design rules

- **Use substoichiometric framework reduction and low-level alkali-metal (Li+/Na+/K+) doping to boost cryogenic H2 uptake in interpenetrated (catenated) MOFs, but avoid over-doping which reduces microporosity and performance.**
  - IF: Material is a reducible, interpenetrated (doubly/triply catenated) MOF with reducible ligand (e.g., diPyTz), Objective is to increase gravimetric H2 uptake at cryogenic temperatures (77–87 K, ~1 atm), Alkali-metal dopants (Li+, Na+, K+) can be introduced via chemical reduction
  - THEN: Perform controlled chemical reduction and load alkali-metal cations at low M/Zn (target ≈0.05–0.10), Activate samples carefully (e.g., 110 °C under vacuum) and quantify residual solvent (1H NMR) to ensure consistent evacuation, Measure N2 adsorption (BET/t-plot) and H2 isotherms to confirm enhancement and to track micropore volume, Avoid increasing dopant loading into ranges (e.g., Li/Zn ≈0.35) that have been shown to halve micropore volume and reduce H2 uptake
  - Why: Experimental data show greatest H2 uptake enhancement at M/Zn ≈0.05–0.10; higher loading can reduce micropore volume and uptake. Residual solvent/activation issues can confound interpretation, so careful activation and solvent quantification are necessary.
- **If alkali-metal doping does not change H2 binding energetics (Qst), attribute uptake increases first to pore-structure changes (BET/micropore area) and investigate cation accessibility if pore metrics do not explain the effect.**
  - IF: Measured isosteric heats (Qst) for doped and undoped MOF are similar across loadings, Observed increase in H2 uptake upon doping
  - THEN: Measure BET surface area and t-plot micropore metrics using N2 at 77 K to assess changes in accessible surface area, If BET/micropore increases correlate with H2 uptake, attribute enhancement to increased accessible surface area (e.g., displacement of interwoven networks), If BET/micropore do not increase, investigate dopant cation accessibility (solvation, localization) and structural changes via 1H NMR, PXRD, single-crystal XRD, and other techniques
  - Why: Study found closely matching Qst values for 1 and 1·M while BET surface areas increased for doped samples and tracked H2 uptake, suggesting structural (pore) changes are responsible rather than stronger binding.
- **To realize direct dopant–H2 binding (higher Qst and larger ambient/high-pressure gains), design MOFs that expose dopant ions—favor single (non-catenated), permanently microporous networks over catenated frameworks.**
  - IF: Goal is increased H2 binding energy (higher isosteric heats) and enhanced uptake at ambient temperature/high pressure, Direct dopant–H2 interaction is required
  - THEN: Design MOFs with non-catenated (single) frameworks that expose dopant ions to pore space, Avoid embedding dopant ions within interwoven/catenated networks which can shield ions from gas access, Use computational screening to identify candidate frameworks where dopant ions are accessible and predicted to increase heats of adsorption, then validate experimentally
  - Why: Computational studies predict large gains if direct ion–H2 interaction can be achieved; experimentally, catenation shields dopants preventing such interactions, so single networks may enable the computationally predicted benefits.
- **Use micropore volume (from t-plot/N2 analyses) as a monitoring metric because micropore volume changes tend to track H2 uptake changes in these modified catenated MOFs.**
  - IF: Working with catenated MOFs subject to reduction/doping, Micropore volume measurable via N2 adsorption/t-plot analyses
  - THEN: Measure micropore volume alongside H2 isotherms to assess impact of modifications, Interpret proportional changes in micropore volume as indicative of proportional changes in cryogenic H2 uptake (but cross-check with activation/solvent data)
  - Why: The study reports that micropore volume variations track variations in hydrogen uptake; example: 1·Li* had ~half the micropore volume of 1 and half the H2 uptake at 1 atm.

## Contradiction notes

- **direct dopant–H2 binding predicted computationally vs. experimental observation of unchanged Qst and cation shielding in catenated MOFs**: The computational potential applies when dopant ions are exposed and can directly interact with H2; in the studied triply catenated frameworks the dopants are embedded/shielded (1H NMR rules out solvation as the reason) and the observed uptake enhancements correlate with increased BET/micropore area rather than increased Qst. Thus the computational predictions are not contradicted per se, but their applicability is limited by dopant accessibility in catenated systems.
  - Warning: Do not assume computationally predicted large increases in ambient-temperature/high-pressure H2 binding will be realized in catenated MOFs with embedded/shielded dopants. Verify cation accessibility, Qst, and pore metrics experimentally; if direct ion–H2 binding is desired, redesign toward single, non-catenated networks that expose dopant sites.